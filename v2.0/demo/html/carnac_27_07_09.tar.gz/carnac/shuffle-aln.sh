#!/bin/bash

OUTPUT_BASE="$1"
CURRENT=0

while read LINE ; do
    if echo "$LINE" | grep ^CLUSTAL > /dev/null ; then
	CURRENT=`expr $CURRENT + 1`
	echo "$LINE" > $OUTPUT_BASE.$CURRENT
    else
	echo "$LINE" >> $OUTPUT_BASE.$CURRENT	
    fi
done
