#ifndef __ARNICA_BOXES_H__
#define __ARNICA_BOXES_H__

#include "sequence.h"



typedef struct blackbox_t {
   char* name;
   char* dir;
   char* out_file;
   char* graph_out_file;
   char* ranked_graph_out_file;
   int (*fun)(const sequence*, const int, sequence**);
} *blackbox;


/*typedef blackbox_t* blackbox;*/


extern struct blackbox_t blackboxes[];
extern blackbox EMPTY_BOX;
extern blackbox NEEDLE_IDENTITY_BOX;
extern blackbox CARNAC_ENERGY_BOX;
extern blackbox GC_PERCENTAGE_BOX;
extern blackbox DINUCLEOTIDE_PERCENTAGE_BOX;
extern blackbox LENGTH_BOX;
extern blackbox NEEDLE_PROTEIN_BOX;
extern blackbox CARNAC_BOX;



#endif
