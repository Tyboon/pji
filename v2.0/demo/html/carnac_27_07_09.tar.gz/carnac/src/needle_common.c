#ifdef HAVE_CONFIG_H
    #include "config.h"
#endif
/*
Copyright or © or CCopr. INRIA : Arnaud FONTAINE

arnaud.fontaine@lifl.fr

This software is a computer program whose purpose is to predict 
significantly conserved protein coding sequences and/or RNA structure 
on a set of unaligned nucleic sequences.

This software is governed by the CeCILL  license under French law and
abiding by the rules of distribution of free software.  You can  use,
modify and/ or redistribute the software under the terms of the CeCILL
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info".

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability.

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or
data to be ensured and,  more generally, to use and operate it in the
same conditions as regards security.

The fact that you are presently reading this means that you have had
knowledge of the CeCILL license and that you accept its terms.
*/

#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <ctype.h>
#include <regex.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>

#include "needle_common.h"
#include "opts.h"
#include "display.h"
#include "boxes.h"
#include "input.h"
#include "output.h"
#include "results.h"
#include "reduce.h"

regex_t* needle_identity_regex = NULL;
regex_t* needle_identity_score_regex = NULL;



int
box_needle(const sequence* seqs, const int nb_seqs, sequence** prots) {
   int i, j, l;
   double res;
   FILE *output_fd = NULL;
   char *output = NULL;



   if(OPTS_output_dir) {
     NEW(output, char, (strlen(OPTS_output_dir) + strlen(NEEDLE_IDENTITY_BOX->out_file) + 1));
     strcpy(output, OPTS_output_dir);
     strcat(output, NEEDLE_IDENTITY_BOX->out_file);
     
     if((output_fd = fopen(output, "w")) == NULL) {
       ERROR_ "unable to create output file '%s'\n", output _ERROR;
       return 1;
     }
   } else output_fd = stdout;
   
   
   
   if(RESULTS_sequence_similarities == NULL) {
      RESULTS_sequence_similarities = similarities(seqs, nb_seqs);
   } else {
      INFO_ "Computing %s...ok\n", NEEDLE_IDENTITY_BOX->name _INFO;
      FLUSH_OUT;
   }

   res = 0.0;
   l = 0;
   
   for(i = 0; i < (nb_seqs - 1); i++) {
      for(j = i+1; j < nb_seqs; j++) {
	 res += RESULTS_sequence_similarities[i][j - i - 1];
	 l++;
      }
   }
	 
   res /= l;
   /* 2*identit� [0;1], centr�e en 0, [-1;1]*/
   /* normalisation du pourcentage d'identit� [-1;1] */
   /*   (*res)->score = ((*res)->score / 50.0) - 1;*/


   fprintf(output_fd, "identity = %.4f\n", res);
   
   
   if(output) {
      fflush(output_fd);
      fclose(output_fd);
      DESTROY(output);
   }



   return 0;
}


int
init_needle() {

  char* sw = NULL;

  if(OPTS_output_dir) {
    if(OPTS_keep_files) {
      NEW(sw, char, (strlen(OPTS_output_dir) + strlen(NEEDLE_IDENTITY_BOX->dir) + 1));
      sprintf(sw, "%s%s",OPTS_output_dir, NEEDLE_IDENTITY_BOX->dir);
      if(prepare_dir(sw)) {
	ERROR_ "unable to create output dir '%s'\n", sw _ERROR;
	return 1;
      }
      DESTROY(sw);
    }
  }
  
  if(needle_identity_regex == NULL) {
     NEW(needle_identity_regex, regex_t, 1);
     NEW(needle_identity_score_regex, regex_t, 1);
     
     if(regcomp(needle_identity_regex, NEEDLE_IDENTITY_REGEX, REG_EXTENDED | REG_NEWLINE)) {
	ERROR_ "REGULAR EXPRESSION needle_identity_regex IN NEEDLE PROBLEM\n" _ERROR;
	return 1;
     }
     
     if(regcomp(needle_identity_score_regex, NEEDLE_IDENTITY_SCORE_REGEX, REG_EXTENDED)) {
	ERROR_ "REGULAR EXPRESSION needle_identity_score_regex IN NEEDLE PROBLEM\n" _ERROR;
	return 1;
     }
  }
  
  return 0;
}


int
needle_identity_result(const char* output, float* res) {
   int nb;
   char *line = NULL;
   char *trans = NULL, *trans2 = NULL;
   FILE* fd;
   regmatch_t regmatch;

   if((fd = fopen(output, "r"))) {
      
      NEW(trans, char, 100);
      NEW(trans2, char, 100);
      
      *res = -1.0; /* a negative value to force a first value */
      
      while((*res < 0.0) && (line = read_line(fd, &nb))) {
	 RENEW(trans, char, (nb + 1));
	 strncpy(trans, line, nb);
	 trans[nb] = '\0';
	 
	 if(regexec(needle_identity_regex, trans, 1, &regmatch, 0) == 0) {
	    RENEW(trans2, char, (nb + 1));
	    
	    regexec(needle_identity_score_regex, trans, 1, &regmatch, 0);
	    strncpy(trans2, &(trans[regmatch.rm_so]), regmatch.rm_eo - regmatch.rm_so - 1);
	    trans2[regmatch.rm_eo - regmatch.rm_so - 1] = '\0';

	    *res = atof(trans2);
	 }
	 DESTROY(line);
      }
      
      fclose(fd);

      DESTROY(trans);
      DESTROY(trans2);

      if(*res < 0.0) return 1;
   } else {
      ERROR_ "unable to open %s output file '%s'\n", NEEDLE_IDENTITY_BOX->name, output _ERROR;
      return 1;
   }

   return 0;
}
