/*
Copyright or © or CCopr. INRIA : Arnaud FONTAINE

arnaud.fontaine@lifl.fr

This software is a computer program whose purpose is to predict 
significantly conserved protein coding sequences and/or RNA structure 
on a set of unaligned nucleic sequences.

This software is governed by the CeCILL  license under French law and
abiding by the rules of distribution of free software.  You can  use,
modify and/ or redistribute the software under the terms of the CeCILL
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info".

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability.

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or
data to be ensured and,  more generally, to use and operate it in the
same conditions as regards security.

The fact that you are presently reading this means that you have had
knowledge of the CeCILL license and that you accept its terms.
*/

#ifndef __ARNICA_SEQUENCE_H__
#define __ARNICA_SEQUENCE_H__


typedef enum { DNA, RNA, PROTEIN, OTHER } sequence_k;

typedef struct {
   char* file;
   char* name;
   char* input_name;
   int nb_gaps;
   sequence_k kind;
   int strand;
   int length;
   char* bases;
} sequence_t;

typedef sequence_t* sequence;

extern sequence
alloc_sequence();

extern sequence
init_sequence(const char* file, const char* input_name, const char* name, char* bases, const int length, const int strand);

extern sequence
new_sequence(const char* file, const char* input_name, const char* name, char *bases, const int from, const int to, const int strand);

extern void
concat_sequence(sequence seq1, const sequence seq2);

extern void
concat_bases(sequence seq1, const char* bases, const int length);


extern sequence
change_sequence_strand(const sequence in, const int new_strand);

extern sequence
traduct(const sequence in);

extern sequence
translate(const sequence in);

extern
char
translate_codon(const sequence s, const int pos);

extern sequence
ungap(const sequence in);

extern sequence
complement(const sequence in);


extern sequence
to_protein(const sequence in);

extern double
gc_percentage(const sequence s);


extern void
check_sequence(const sequence s);

extern sequence**
translate_and_write_sequences(const sequence* seqs, const int nb_seqs);



extern int
reverse_compatible_phase(const int mod, const int phase);

extern int
reverse_mod(const int* phases1, const int* phases2, const int* rev_mod, const int nb_seqs);

extern int
common_mod(const int* phases1, const int* phases2, const int nb_seqs);


#endif
