#ifndef __ARNICA_MY_NEEDLE_MATRICES_H
#define __ARNICA_MY_NEEDLE_MATRICES_H



#define GET_NU_INDICE(Nu,Ii)			\
   switch(Nu) {					\
   case 'A':					\
   case 'a':					\
      (Ii) = 0;					\
      break;					\
   case 'T':					\
   case 't':					\
   case 'U':					\
   case 'u':					\
      (Ii) = 1;					\
      break;					\
   case 'G':					\
   case 'g':					\
      (Ii) = 2;					\
      break;					\
   case 'C':					\
   case 'c':					\
      (Ii) = 3;					\
      break;					\
   case 'N':					\
   case 'n':					\
      (Ii) = 4;					\
      break;					\
   default:					\
      ERROR_ "unknown nucleotide '%c' (ascii %i)\n !!!",(Nu), (Nu)  _ERROR; \
      (Ii) = -1;				\
      break;					\
   }




#define GET_IUPAC_INDICE(Nu,Ii)			\
   switch(Nu) {					\
   case 'A':					\
   case 'a':					\
      (Ii) = 0;					\
      break;					\
   case 'T':					\
   case 't':					\
      (Ii) = 1;					\
      break;					\
   case 'G':					\
   case 'g':					\
      (Ii) = 2;					\
      break;					\
   case 'C':					\
   case 'c':					\
      (Ii) = 3;					\
      break;					\
   case 'S':					\
   case 's':					\
      (Ii) = 4;					\
      break;					\
   case 'W':					\
   case 'w':					\
      (Ii) = 5;					\
      break;					\
   case 'R':					\
   case 'r':					\
      (Ii) = 6;					\
      break;					\
   case 'Y':					\
   case 'y':					\
      (Ii) = 7;					\
      break;					\
   case 'K':					\
   case 'k':					\
      (Ii) = 8;					\
      break;					\
   case 'M':					\
   case 'm':					\
      (Ii) = 9;					\
      break;					\
   case 'B':					\
   case 'b':					\
      (Ii) = 10;				\
      break;					\
   case 'V':					\
   case 'v':					\
      (Ii) = 11;				\
      break;					\
   case 'H':					\
   case 'h':					\
      (Ii) = 12;				\
      break;					\
   case 'D':					\
   case 'd':					\
      (Ii) = 13;				\
      break;					\
   case 'N':					\
   case 'n':					\
      (Ii) = 14;				\
      break;					\
   case 'U':					\
   case 'u':					\
      (Ii) = 15;				\
      break;					\
   default:					\
      ERROR_ "unknown nucleotide '%c' (ascii %i)\n !!!",(Nu), (Nu)  _ERROR; \
      (Ii) = -1;				\
      break;					\
   }



typedef int blosum_dna_matrix_t[5][5];
typedef blosum_dna_matrix_t *blosum_dna_matrix;

extern
blosum_dna_matrix_t dna_full;



typedef int blosum_iupac_matrix_t[16][16];
typedef blosum_iupac_matrix_t *blosum_iupac_matrix;

extern
blosum_iupac_matrix_t iupac_full;
#endif
