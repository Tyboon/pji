#ifndef __ARNICA_CARNAC_MFE_H__
#define __ARNICA_CARNAC_MFE_H__

#include "sequence.h"
#include "boxes.h"

#define CARNAC_ENERGY_REGEX "energy -?[0-9]+.[0-9]+e(-|[+])[0-9]+"


extern int
box_carnac_mfe(const sequence* seqs, const int nb_seqs, sequence** prots);


extern int
call_carnac(const sequence* seqs, const int nb_seqs, double** res, const int dontdelete);


#endif
