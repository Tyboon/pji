#ifdef HAVE_CONFIG_H
    #include "config.h"
#endif
#include <assert.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

/* #include <mpfr.h> */


#include "fusion.h"
#include "opts.h"
#include "list.h"
#include "stack.h"
#include "display.h"
/* #include "pvalues.h" */
#include "output.h"
#include "alignment.h"
#include "results.h"

#ifdef PROTEA_FUSION_MAX_INDEP_SET
#include "reduce.h"
#endif




sequence_set
sequence_set_new(const int max_size) {
   sequence_set res = NULL;
   NEW(res, sequence_set_t, 1);
   NEW(res->seqs, sequence, max_size);
   NEW(res->seq_id, int, max_size);
   res->frames = NULL;
   res->nb_seqs = 0;
   return res;
}

int
sequence_set_contains(const sequence_set set, const sequence s) {
   register int i = 0;
   while((i < set->nb_seqs) && (set->seqs[i] != s)) i++;
   return set->nb_seqs - i;
}


int
sequence_set_add(sequence_set set, const sequence s, const int seq_id) {
   if(sequence_set_contains(set, s) == 0) {
      set->seq_id[set->nb_seqs] = seq_id;
      set->seqs[set->nb_seqs++] = s;
      return 1;
   }
   return 0;
}

void
sequence_set_destroy(sequence_set set) {
   register int p,i;

   if(OPTS_first_phase < 0) p = 6;
   else p = 3;

   if(set->frames) {
      for(i = 0; i < p; i++) {
	 DESTROY(set->frames[i]);
      }
      DESTROY(set->frames);
   }

   DESTROY(set->seq_id);
   DESTROY(set->seqs);
   DESTROY(set);
}


int
sequence_set_equals(const sequence_set s1, const sequence_set s2) {
   register int i;
   if(s1->nb_seqs != s2->nb_seqs) return 0;
   for(i = 0; i < s1->nb_seqs; i++) {
      if(sequence_set_contains(s2, s1->seqs[i]) == 0) return 0;
   }
   return 1;
}



void
sequence_set_frameset(sequence_set set, float ****rfg) {
   register int i, j, l, p;
   int maxl, last_mod;

   if(OPTS_first_phase < 0) p = 6;
   else p = 3;

   NEW(set->frames, int*, p);
   for(i = 0; i < p; i++) {
      NEW(set->frames[i], int, set->nb_seqs);
      set->frames[i][0] = i; /* frame i de l'ensemble => frame i seq 0 */
   }
   
   for(j = 1; j < set->nb_seqs; j++) {
      maxl = 0;
#ifdef SYNC_STRAND
      for(l = 0; l < 3; l++) {
#else
      for(l = 0; l < p; l++) {
#endif
	 if(rfg[set->seq_id[0]][0][set->seq_id[j] - set->seq_id[0] - 1][l] > rfg[set->seq_id[0]][0][set->seq_id[j] - set->seq_id[0] - 1][maxl]) {
	    maxl = l;
	 }
      }
      
      set->frames[0][j] = maxl;
   }
   
   for(i = 0; i < 3; i++) {
      
      last_mod = reverse_compatible_phase(set->seqs[0]->length % 3, set->frames[i][0]);
      
      for(j = 1; j < set->nb_seqs; j++) {
	 set->frames[i][j] = (set->frames[0][j] + i) % 3;
	 if(OPTS_first_phase < 0) {
	    set->frames[last_mod][j] = reverse_compatible_phase(set->seqs[j]->length % 3, set->frames[i][j]);
	 }
      }
   }
}





fusion_set
fusion_set_new(const int max_size) {
   fusion_set res = NULL;
   NEW(res, fusion_set_t, 1);
   NEW(res->sets, sequence_set, max_size);
   res->size = 0;
   return res;
}


int
fusion_set_contains_seq(const fusion_set set, const sequence s) {
   register int i = 0;
   while((i < set->size) && sequence_set_contains(set->sets[i], s) == 0) i++;
   return set->size - i;
}

int
fusion_set_contains(const fusion_set set, const sequence_set s) {
   register int i;
   for(i = 0; i < set->size; i++) {
      if(sequence_set_equals(set->sets[i], s)) return 1;
   }
   return 0;
}


int
fusion_set_add(fusion_set set, const sequence_set s) {
   if(fusion_set_contains(set, s) == 0) {
      set->sets[set->size++] = s;
      return 1;
   }
   return 0;   
}

void
fusion_set_destroy(fusion_set set, const int recurse) {
   register int i;
   if(recurse)
      for(i = 0; i < set->size; i++)
	 sequence_set_destroy(set->sets[i]);

   DESTROY(set->sets);
   DESTROY(set);
}






fusion_set
fusion_set_union(const fusion_set s1, const fusion_set s2) {
   fusion_set res = NULL;
   register int i;
   
   res = fusion_set_new(s1->size + s2->size);
   for(i = 0; i < s1->size; i++)
      fusion_set_add(res, s1->sets[i]);

   for(i = 0; i < s2->size; i++) {
      if(fusion_set_contains(res, s2->sets[i]) == 0) {
	 fusion_set_add(res, s2->sets[i]);
      }
   }

   return res;
}

















float ****
rank_vrfg_results(const int nb_vertices, float**** vrfg, const fusion_set srfg, const fusion_set sepsilon) {
   float ****new_result = NULL;
   int i, j, l, m, n, k;
   int phases[2];
   list order_list = NULL;


   NEW(new_result, float***, nb_vertices);

   if(OPTS_first_phase < 0) k = 6;
   else k = 3;
   
   for(i = 0; i < nb_vertices; i++) {

      NEW(new_result[i], float**, k);

      for(j=0;j<k;j++) {
	 if(fusion_set_contains(sepsilon, srfg->sets[i])) {
	    NEW(new_result[i][j], float*, (nb_vertices - i));

	    NEW(new_result[i][j][nb_vertices - i - 1], float, 1);

	    new_result[i][j][nb_vertices - i - 1][0] = -1.0; /* SUR LES BOUCLES ON AUTORISE QUE LES MEILLEURS */
	 } else {
	    NEW(new_result[i][j], float*, (nb_vertices - i - 1));
	 }
	 for(l = 0; l < (nb_vertices - i - 1); l++) {
	    NEW(new_result[i][j][l], float, k);
	    for(m = 0; m < k; m++) {
#ifdef SYNC_STRAND
	       if(((j < 3) && (m < 3)) || ((j > 2) && (m > 2))) {
#endif
		  new_result[i][j][l][m] = 0.0;
#ifdef SYNC_STRAND
	       }
#endif
	    }
	 }
      }
   }

   m = (OPTS_first_phase < 0) ? 6 : 3;
   
   for(i = 0 ; i< nb_vertices; i++) {

      if(fusion_set_contains(sepsilon, srfg->sets[i])) {

	 n = (OPTS_first_phase < 0) ? (NB_RANK) : (NB_RANK/2);
	 
	 order_list = new_list(2, n);
	 for(k = 0; k < m; k++) {
	    phases[0] = k;
	    phases[1] = 0;
	    insert_list(order_list, phases, -vrfg[i][k][nb_vertices - i - 1][0]);
	 }	 

	 k = 0;
	 l = 0;
	 
	 n++;
	 while(k < list_size(order_list)) {
	    if((k == 0) || ((k > 0) && (order_list->elements[k-1].value == order_list->elements[k].value))) {
	       l++;
	    } else {
	       n -= l;
	       for(; l > 0; l--) {
		  new_result[i][order_list->elements[k-l].phases[0]][nb_vertices - i - 1][order_list->elements[k-l].phases[1]] = n;
		  
	       }
	       l = 1;
	    }
	    
	    k++;
	 }
	 
	 n -= l;
	 for(; l > 0; l--) {
	    new_result[i][order_list->elements[k-l].phases[0]][nb_vertices - i - 1][order_list->elements[k-l].phases[1]] = n;
	 }
	 
	 free_list(order_list);
      }

      
      
      for(j = i + 1; j < nb_vertices; j++) {

	 n = (OPTS_first_phase < 0) ? (NB_RANK) : (NB_RANK/2);

	 order_list = new_list(2, n);

	 for(k = 0; k < m; k++) {
	    for(l = 0; l < m; l++) {
	       /* couple de phases accept� */
#ifdef SYNC_STRAND
	       if(((k < 3) && (l < 3)) || ((k > 2) && (l > 2))) {
#endif
		  phases[0] = k;
		  phases[1] = l;
		  insert_list(order_list, phases, -vrfg[i][k][j - i - 1][l]);
#ifdef SYNC_STRAND
	       }
#endif
	    }
	 }

	 k = 0;
	 l = 0;

	 n++;
	 while(k < list_size(order_list)) {
	    if((k == 0) || ((k > 0) && (order_list->elements[k-1].value == order_list->elements[k].value))) {
	       l++;
	    } else {
	       n -= l;
	       for(; l > 0; l--) {
		  new_result[i][order_list->elements[k-l].phases[0]][j - i - 1][order_list->elements[k-l].phases[1]] = n;
	       }
	       l = 1;
	    }

	    k++;
	 }

	 n -= l;
	 for(; l > 0; l--) {
	    new_result[i][order_list->elements[k-l].phases[0]][j - i - 1][order_list->elements[k-l].phases[1]] = n;
	 }

	 free_list(order_list);
      }
   }

   return new_result;
}








int
prune_rank_vrfg(const int nb_vertices, float**** rank_vrfg, const fusion_set srfg, const double sim_threshold) {
   int i, j, l, m, k;
   int count = 0;
   int seqidmin, seqidmax;

   if(OPTS_first_phase < 0) k = 6;
   else k = 3;
   
   for(i = 0; i < nb_vertices; i++) {
      for(l = 0; l < (nb_vertices - i - 1); l++) {
	 if((srfg->sets[i]->nb_seqs == 1) && (srfg->sets[l]->nb_seqs == 1)) {
	    if(srfg->sets[i]->seq_id[0] > srfg->sets[l]->seq_id[0]) {
	       seqidmax = srfg->sets[i]->seq_id[0];
	       seqidmin = srfg->sets[l]->seq_id[0];
	    } else {
	       seqidmin = srfg->sets[i]->seq_id[0];
	       seqidmax = srfg->sets[l]->seq_id[0];
	    }
	    
	    if(RESULTS_sequence_similarities[seqidmin][seqidmax - seqidmin - 1] >= sim_threshold) {

	       count++;

	       for(j=0;j<k;j++) {
		  for(m = 0; m < k; m++) {
#ifdef SYNC_STRAND
		     if(((j < 3) && (m < 3)) || ((j > 2) && (m > 2))) {
#endif
			rank_vrfg[i][j][l][m] = 0.0;
#ifdef SYNC_STRAND
		     }
#endif
		  }
	       }
	    }
	 }
      }
   }

   return count;
}








list
find_best_clique_fusion(const int nb_vertices, const float min, const float max, float**** results, const fusion_set srfg, const fusion_set sepsilon, const int zscore) {
   list res = NULL;
   int b, k, peek;
   register int i, j;
   int_stack stack = NULL;
   int finished;
   int breaker;

   double somme_score = 0.0;
   float t;

   if(zscore == 0) {
      res = new_list(nb_vertices, OPTS_max_res);
   }
#ifdef NB_RANK
   else {
      if(OPTS_first_phase < 0) {
#ifdef SYNC_STRAND
	 res = new_list(nb_vertices, 2 * quick_pow(3,nb_vertices));
#else
	 res = new_list(nb_vertices, quick_pow(6,nb_vertices));
#endif
      } else {
	 res = new_list(nb_vertices, quick_pow(3,nb_vertices));
      }
   }
#endif


   NEW_INT_STACK(stack, nb_vertices);

   
   while(!STACK_IS_FULL(stack)) {
      STACK_PUSH(stack,0);
   }

#ifdef SYNC_STRAND
   b = (OPTS_first_phase < 0) ? 3 : 0;
#else
   b = 0;
#endif

   finished = 1;
   while(finished) {
      
      k = b;
      while(k >= 0) {
	 somme_score = 0.0;
	 
	 breaker = 1;
	 i = 0;
	 while((breaker != 0) && (i < nb_vertices)) {
	    if(fusion_set_contains(sepsilon, srfg->sets[i])) {
	       t = results[i][STACK_VALUE_AT(stack,i) + k][nb_vertices - i - 1][0];
	       if((t >= min) && (t <= max)) {
		  somme_score += t;
	       } else {
		  breaker = 0;
	       }
	    }
	    j = i+1;
	    while((breaker != 0) && (j < nb_vertices)) {
	       t = results[i][STACK_VALUE_AT(stack,i) + k][j - i - 1][STACK_VALUE_AT(stack,j) + k];
	       if((t >= min) && (t <= max)) {
		  somme_score += t;
	       } else {
		  breaker = 0;
	       }
	       j++;
	    }
	    i++;
	 }

	 if(breaker) {
	    if(k) {
	       for(i = 0; i < nb_vertices; i++) {
		  STACK_VALUE_AT(stack, i) += k;
	       }
	    }

	    if(somme_score != 0.0) {
	       insert_list(res, stack->elements, -somme_score);
	    }

	    if(k) {
	       for(i = 0; i < nb_vertices; i++) {
		  STACK_VALUE_AT(stack, i) -= k;
	       }
	    }
	 }
	 
	 k-=3;
      }

#ifdef SYNC_STRAND
      peek = 2;
      while((!STACK_IS_EMPTY(stack)) && ((peek = STACK_POP(stack)) == 2));

      if(STACK_IS_EMPTY(stack) && (peek == 2)) {
	 finished = 0;
      } else {
	 peek++;
	 STACK_PUSH(stack, peek);
	 
	 while(!STACK_IS_FULL(stack)) {
	    STACK_PUSH(stack,0);
	 }
      }
#else
      peek = (OPTS_first_phase < 0) ? (5) : (2);
      while((!STACK_IS_EMPTY(stack)) && ((peek = STACK_POP(stack)) == ((OPTS_first_phase < 0) ? (5) : (2))));
      
      if(STACK_IS_EMPTY(stack) && (peek == ((OPTS_first_phase < 0) ? (5) : (2)))) {
	 finished = 0;
      } else {
	 peek++;
	 STACK_PUSH(stack, peek);
	 
	 while(!STACK_IS_FULL(stack)) {
	    STACK_PUSH(stack,0);
	 }
      }
#endif
   }
   
   DESTROY_STACK(stack);
   
   return res;
}
















/* int */
/*    display_fusion_phases(const fusion_set srfg, FILE* output_fd, const int* phases, const double sum, const mpfr_t value, const int nb_vertices) { */
/*    int i, j; */
/*    int c = 0; */

/*    if(srfg->sets[0]->frames[phases[0]][0] < 3) { */
/*       c += fprintf(output_fd, "{ %2i", (srfg->sets[0]->frames[phases[0]][0] + 1)); */
/*    } else { */
/*       c += fprintf(output_fd, "{ %2i", (2 - srfg->sets[0]->frames[phases[0]][0])); */
/*    } */
/*    for(j = 1; j < srfg->sets[0]->nb_seqs; j++) { */
/*       if(srfg->sets[0]->frames[phases[0]][j] < 3) {       */
/* 	 c += fprintf(output_fd, ", %2i", (srfg->sets[0]->frames[phases[0]][j] + 1)); */
/*       } else { */
/* 	 c += fprintf(output_fd, ", %2i", (2 - srfg->sets[0]->frames[phases[0]][j])); */
/*       } */
/*    } */

/*    for(i = 1; i < nb_vertices; i++) { */
/*       for(j = 0; j < srfg->sets[i]->nb_seqs; j++) { */
/* 	 if(srfg->sets[i]->frames[phases[i]][j] < 3) { */
/* 	    c += fprintf(output_fd, ", %2i", (srfg->sets[i]->frames[phases[i]][j] + 1)); */
/* 	 } else { */
/* 	    c += fprintf(output_fd, ", %2i", (2 - srfg->sets[i]->frames[phases[i]][j])); */
/* 	 } */
/*       } */
/*    } */



/*    c += fprintf(output_fd, " }  sum = %.4e  pvalue = ", sum); */
/*    c += mpfr_out_str(output_fd, 10, 4, value, GMP_RNDN); */

   

/*    c += fprintf(output_fd, " \n"); */
   
/*    return c; */
/* } */








/* int */
/* format_fusion_result_list(const fusion_set srfg, FILE* output_fd, const list l, const sequence* seqs, const int score_min, mpfr_t *values) { */
/*    mpfr_t un; */
/*    int i, j, k, m, p = 0; */
/*    int* rev_mod, *displayed; */
/*    int* rev_phases = NULL; */

/*    list_element_t** cur_mod[2]; */

/*    mpfr_init(un); */
/*    mpfr_set_ui(un, 1, GMP_RNDN); */



/*    list display_list = NULL; */


/*    display_list = new_list(l->nb_seqs, 6); */

   
/*    NEW(rev_mod, int, l->nb_seqs); */
/*    NEW(displayed, int, l->size); */
/*    NEW(cur_mod[0], list_element_t*, 3); /\* 2 fois ... *\/ */
/*    cur_mod[1] = NULL; */

/*    if(OPTS_first_phase < 0) { */
/*       NEW(cur_mod[1], list_element_t*, 3); /\* ... 3 phases *\/ */
/*       NEW(rev_phases, int, l->nb_seqs); */

/*       for(i = 0; i < l->nb_seqs; i++) */
/* 	 rev_mod[i] = seqs[i]->length % 3; */
/*    } */

/*    for(i = 0; i < l->size; i++) */
/*       displayed[i] = 0; */
   

/*    p = 0; */
/*    for(i = 0; i < l->size; i++) { */
/*       if(displayed[i] == 0) { */
/* 	 p++; */

/* 	 for(j = 0; j < 3; j++) { */
/* 	    cur_mod[0][j] = NULL; */
/* 	    if(OPTS_first_phase < 0) */
/* 	       cur_mod[1][j] = NULL; */
/* 	 } */
	 
/* 	 displayed[i] = 1; */
/* 	 cur_mod[0][0] = &(l->elements[i]); */
/* 	 k = 1; */
	 
/* 	 /\* mod equivalents sur le meme brin *\/ */
/* 	 for(j = i + 1; (k < 4) && (j < l->size); j++) */
/* 	    if(displayed[j] == 0) { */
/* 	       if(common_mod(cur_mod[0][0]->phases, l->elements[j].phases, l->nb_seqs)) { */
/* 		  cur_mod[0][k++] = &(l->elements[j]); */
/* 		  displayed[j] = 1; */
/* 	       } */
/* 	    } */
	 
/* 	 if(OPTS_first_phase < 0) { */
/* 	    /\* rev_phases sont les phases correspondantes sur le brin oppos� *\/ */
/* 	    for(j = 0; j < l->nb_seqs; j++) */
/* 	       rev_phases[j] = reverse_compatible_phase(rev_mod[j], cur_mod[0][0]->phases[j]); */
	    
/* 	    m = 0; */
/* 	    /\* mod equivalents sur le brin oppos� *\/ */
/* 	    for(j = i + 1; j < l->size; j++) */
/* 	       if(displayed[j] == 0) { */
/* 		  if(common_mod(rev_phases, l->elements[j].phases, l->nb_seqs) != 0) { */
/* 		     cur_mod[1][m++] = &(l->elements[j]); */
/* 		     displayed[j] = 1; */
/* 		  } */
/* 	       } */
/* 	 } */



/* 	 /\* sortie *\/ */
/* 	 display_list->size = 0; */
	 
/* 	 for(j = 0; j < ((OPTS_first_phase < 0) ? (2) : (1)); j++) { */
/* 	    for(k = 0; k < 3; k++) { */
/* 	       if(cur_mod[j][k]) { */
/* 		  insert_list(display_list, cur_mod[j][k]->phases, cur_mod[j][k]->value); */
/* 	       } */
/* 	    } */
/* 	 } */

/* 	 if(display_list->size > 0) { */
/* 	    if(-display_list->elements[0].value < score_min) { */

/* 	       display_fusion_phases(srfg, output_fd, display_list->elements[0].phases, -display_list->elements[0].value, un, display_list->nb_seqs); */
/* 	    } else { */
/* 	       display_fusion_phases(srfg, output_fd, display_list->elements[0].phases, -display_list->elements[0].value, values[-(int)display_list->elements[0].value - score_min], display_list->nb_seqs); */
/* 	    } */
/* 	    for(j = 1; j < display_list->size; j++) { */
/* 	       fprintf(output_fd, "\t"); */
/* 	       if(-display_list->elements[j].value < score_min) { */
/* 		  display_fusion_phases(srfg, output_fd, display_list->elements[j].phases, -display_list->elements[j].value, un, display_list->nb_seqs); */
/* 	       } else { */
/* 		  display_fusion_phases(srfg, output_fd, display_list->elements[j].phases, -display_list->elements[j].value, values[-(int)display_list->elements[j].value - score_min], display_list->nb_seqs); */
/* 	       } */
/* 	    } */
/* 	 } */
/*       } */
/*    } */

/*    free_list(display_list); */


/*    if(OPTS_first_phase < 0) { */
/*       DESTROY(rev_mod); */
/*    } */

/*    mpfr_clear(un); */

/*    return 0; */
/* } */










int
display_fusion_phases_zscore(const fusion_set srfg, FILE* output_fd, const int* phases, const double sum, const long double value, const int nb_vertices, const int disp_value) {
   int i, j;
   int c = 0;

   if(srfg->sets[0]->frames[phases[0]][0] < 3) {
      c += fprintf(output_fd, "{ %2i", (srfg->sets[0]->frames[phases[0]][0] + 1));
   } else {
      c += fprintf(output_fd, "{ %2i", (2 - srfg->sets[0]->frames[phases[0]][0]));
   }
   for(j = 1; j < srfg->sets[0]->nb_seqs; j++) {
      if(srfg->sets[0]->frames[phases[0]][j] < 3) {      
	 c += fprintf(output_fd, ", %2i", (srfg->sets[0]->frames[phases[0]][j] + 1));
      } else {
	 c += fprintf(output_fd, ", %2i", (2 - srfg->sets[0]->frames[phases[0]][j]));
      }
   }

   for(i = 1; i < nb_vertices; i++) {
      for(j = 0; j < srfg->sets[i]->nb_seqs; j++) {
	 if(srfg->sets[i]->frames[phases[i]][j] < 3) {
	    c += fprintf(output_fd, ", %2i", (srfg->sets[i]->frames[phases[i]][j] + 1));
	 } else {
	    c += fprintf(output_fd, ", %2i", (2 - srfg->sets[i]->frames[phases[i]][j]));
	 }
      }
   }

   if(disp_value) {
      c += fprintf(output_fd, " }  sum = %.4e  zscore = %.4Le\n", sum, value);
   } else {
      c += fprintf(output_fd, " }  sum = %.4e\n", sum);
   }
   
   return c;
}

















int
   format_fusion_result_list_zscore(const fusion_set srfg, FILE* output_fd, const list l, const sequence* seqs, double* zscore_res, int *frames) {
   int i,j,  k, m = 0;
   int* rev_mod;
   int* rev_phases = NULL;
   int* displayed = NULL;
   long double mean, var;

   list_element_t** cur_mod[2];

   list display_list = NULL;

   display_list = new_list(l->nb_seqs, ((OPTS_first_phase < 0) ? 6 : 3));
   
   NEW(rev_mod, int, l->nb_seqs);
   NEW(displayed, int, l->size);
   NEW(cur_mod[0], list_element_t*, 3); /* 2 fois ... */
   cur_mod[1] = NULL;

   if(OPTS_first_phase < 0) {
      NEW(cur_mod[1], list_element_t*, 3); /* ... 3 phases */
      NEW(rev_phases, int, l->nb_seqs);

      for(i = 0; i < l->nb_seqs; i++)
	 rev_mod[i] = seqs[i]->length % 3;
   }


   for(i = 0; i < l->size; i++)
      displayed[i] = 0;
   

   for(i = 0; i < l->size; i++) {
      if(displayed[i] == 0) {
	 
	 for(j = 0; j < 3; j++) {
	    cur_mod[0][j] = NULL;
	    if(OPTS_first_phase < 0)
	       cur_mod[1][j] = NULL;
	 }
	 
	 displayed[i] = 1;
	 cur_mod[0][0] = &(l->elements[i]);
	 k = 1;
	 
	 
	 /* mod equivalents sur le meme brin */
	 for(j = i + 1; (k < 3) && (j < l->size); j++) {
	    if(displayed[j] == 0) {
	       if(common_mod(cur_mod[0][0]->phases, l->elements[j].phases, l->nb_seqs)) {
		  cur_mod[0][k++] = &(l->elements[j]);
		  displayed[j] = 1;
	       }
	    }
	 }
	 
	 if(OPTS_first_phase < 0) {
	    /* rev_phases sont les phases correspondantes sur le brin oppos� */
	    for(j = 0; j < l->nb_seqs; j++)
	       rev_phases[j] = reverse_compatible_phase(rev_mod[j], cur_mod[0][0]->phases[j]);
	    
	    m = 0;
	    /* mod equivalents sur le brin oppos� */
	    for(j = 1; j < l->size; j++) {
	       if(displayed[j] == 0) {
		  if(common_mod(rev_phases, l->elements[j].phases, l->nb_seqs) != 0) {
		     cur_mod[1][m++] = &(l->elements[j]);
		     displayed[j] = 1;
		  }
	       }
	    }
	 }
	 
	 /* sortie */
	 display_list->size = 0;
	 
	 for(j = 0; j < ((OPTS_first_phase < 0) ? (2) : (1)); j++) {
	    for(k = 0; k < 3; k++) {
	       if(cur_mod[j][k]) {
		  insert_list(display_list, cur_mod[j][k]->phases, cur_mod[j][k]->value);
	       }
	    }
	 }
	 
	 if(display_list->size > 0) {



	    if(OPTS_first_phase < 0) {
	       j=1;
	       while((j < display_list->size) && (srfg->sets[0]->frames[display_list->elements[0].phases[0]][0] != reverse_compatible_phase(rev_mod[0], srfg->sets[0]->frames[display_list->elements[j].phases[0]][0]))) {
		  j++;
	       }
	    } else {
	       j = display_list->size + 1;
	    }
	    
	    mean = 0.0;
	    for(k = 1; k < ((OPTS_first_phase < 0) ? 6 : 3); k++) {
	       if(k < display_list->size)
		  if(k != j) {
		     /* on refuse d'inclure l'affect compatible du brin oppose de la meilleure */
		     mean -= display_list->elements[k].value;
		  }
	    }
	    mean /= (((OPTS_first_phase < 0) ? (6-2) : (3-1)));
	    
	    var = 0.0;
	    for(k = 1; k < ((OPTS_first_phase < 0) ? 6 : 3); k++) {
	       if(k < display_list->size) {
		  if(k != j) {
		     /* idem */
		     var += quick_powd((-display_list->elements[k].value - mean), 2);
		  }
	       } else
		  var += quick_powd((0.0 - mean), 2);
	    }
	    var /= (((OPTS_first_phase < 0) ? (6-2) : (3-1)));
	    var = sqrtl(var);
	    
	    if(i == 0) {
	       (*zscore_res) = (-display_list->elements[0].value - mean) / var;

	       m = 0;
	       for(j = 0; j < srfg->size; j++) {
		  for(k = 0; k < srfg->sets[j]->nb_seqs; k++) {
		     frames[m++] = srfg->sets[j]->frames[display_list->elements[0].phases[j]][k];
		  }
	       }
	    }

	    display_fusion_phases_zscore(srfg, output_fd, display_list->elements[0].phases, -display_list->elements[0].value, (-display_list->elements[0].value - mean) / var, display_list->nb_seqs, 1);
	    
	    for(j = 1; j < display_list->size; j++) {
	       fprintf(output_fd, "\t");
	       display_fusion_phases_zscore(srfg, output_fd, display_list->elements[j].phases, -display_list->elements[j].value, 0.0, display_list->nb_seqs, 0);
	    }
	 }
      }
   }
   
   free_list(display_list);
   
   if(OPTS_first_phase < 0) {
      DESTROY(rev_mod);
   }

   DESTROY(displayed);
   
   return 0;
}










fusion_set
build_slinked(const sequence* seqs, const int nb_seqs, const int* equiv_class, const int nb_class) {
   fusion_set res = NULL;
   sequence_set cur_seq_set = NULL;
   int i, j;

   res = fusion_set_new(nb_class);
   for(i = 1; i < nb_class; i++) {
      cur_seq_set = sequence_set_new(nb_seqs);
      for(j = 0; j < nb_seqs; j++) {
	 if(equiv_class[j] == i) {
	    sequence_set_add(cur_seq_set, seqs[j], j);
	 }
      }
      fusion_set_add(res, cur_seq_set);
   }

   return res;
}



fusion_set
build_ssingle(const sequence* seqs, const int nb_seqs, const int* equiv_class, const int nb_class) {
   fusion_set res = NULL;
   sequence_set cur_seq_set = NULL;
   int i;

   res = fusion_set_new(nb_seqs);
   for(i = 0; i < nb_seqs; i++)
      if(equiv_class[i] == 0) {
	 cur_seq_set = sequence_set_new(1);
	 sequence_set_add(cur_seq_set, seqs[i], i);
	 fusion_set_add(res, cur_seq_set);
      }

   return res;
}



fusion_set
build_sepsilon(const sequence* seqs, const int nb_seqs, const fusion_set slinked, const fusion_set ssingle) {
   fusion_set res = NULL;
   int i;

#ifndef PROTEA_FUSION_SP
   int j, k;
   sequence_set cur_seq_set = NULL;
#endif
   


#ifdef PROTEA_PRE_FUSION
   if((slinked->size + ssingle->size) > 1) {
      res = fusion_set_new(1);
   } else {
#endif

   res = fusion_set_new(slinked->size);
   for(i = 0; i < slinked->size; i++) {
#ifdef PROTEA_FUSION_SP
      /* FULL SP */
      fusion_set_add(res, slinked->sets[i]);
#else
      cur_seq_set = slinked->sets[i];
      
      /* PARTIAL SP */
      for(j = 0; (fusion_set_contains(res, cur_seq_set) == 0) && (j < (cur_seq_set->nb_seqs - 1)); j++) {
	 for(k = j + 1; (fusion_set_contains(res, cur_seq_set) == 0) && (k < cur_seq_set->nb_seqs); k++) {
	    if(RESULTS_sequence_similarities[cur_seq_set->seq_id[j]][cur_seq_set->seq_id[k] - cur_seq_set->seq_id[j] - 1] < sim_threshold) {
	       fusion_set_add(res, cur_seq_set);
	    }
	 }
      }
#endif
   }


#ifdef PROTEA_PRE_FUSION
   }
#endif

   return res;
}


void
   build_equiv_class(int** equiv_class, int* nb_class, const sequence* seqs, const int nb_seqs, const double sim_threshold) {

#ifdef PROTEA_FUSION_MAX_INDEP_SET
   sequence *sseqs = NULL;
   int nb_sseqs;
   float maxsim;
   int maxsimid;
   sequence_set removed = NULL;
   sequence_set left = NULL;
#endif

   int i, j, k;


   NEW((*equiv_class), int, nb_seqs);
   for(i = 0; i < nb_seqs; i++) {
      (*equiv_class)[i] = 0; /* pas de classe */ 
   }
   (*nb_class) = 1; /* premiere classe vide */

#ifdef PROTEA_FUSION_MAX_INDEP_SET

   /*********** max indep set + injection **********/

   reduce_seq_set(seqs, nb_seqs, &sseqs, &nb_sseqs, sim_threshold);

   if(nb_sseqs < nb_seqs) {
      removed = sequence_set_new(nb_seqs - nb_sseqs);
      if(nb_sseqs > 0) {
	 left = sequence_set_new(nb_sseqs);
      } else {
	 left = sequence_set_new(1);
      }
      
      for(i = 0; i < nb_seqs; i++) {
	 j = 0;
	 while((j < nb_sseqs) && (seqs[i] != sseqs[j])) {
	    j++;
	 }
	 if(j < nb_sseqs) {
	    sequence_set_add(left, seqs[i], i);
	 } else {
	    sequence_set_add(removed, seqs[i], i);
	 }
      }

      for(i = 0; i < removed->nb_seqs; i++) {
	 maxsim = -1.0;
	 maxsimid = 0;
	 for(j = 0; j < left->nb_seqs; j++) {
	    if(removed->seq_id[i] < left->seq_id[j]) {
	       if(RESULTS_sequence_similarities[removed->seq_id[i]][left->seq_id[j] - removed->seq_id[i] - 1] > maxsim) {
		  maxsim = RESULTS_sequence_similarities[removed->seq_id[i]][left->seq_id[j] - removed->seq_id[i] - 1];
		  maxsimid = left->seq_id[j];
	       }
	    } else {
	       if(RESULTS_sequence_similarities[left->seq_id[j]][removed->seq_id[i] - left->seq_id[j] - 1] > maxsim) {
		  maxsim = RESULTS_sequence_similarities[left->seq_id[j]][removed->seq_id[i] - left->seq_id[j] - 1];
		  maxsimid = left->seq_id[j];
	       }
	    }
	 }
	 if((*equiv_class)[maxsimid] == 0)
	    (*equiv_class)[maxsimid] = (*nb_class)++;
	 (*equiv_class)[removed->seq_id[i]] = (*equiv_class)[maxsimid];
      }

      DESTROY(sseqs);
      sequence_set_destroy(removed);
      sequence_set_destroy(left);
   }
#else

   /********* connexite *********/

   for(i = 0; i < (nb_seqs - 1); i++) {
      for(j = i + 1; j < nb_seqs; j++) {
	 if(RESULTS_sequence_similarities[i][j - i - 1] >= sim_threshold) {
	    if((*equiv_class)[i] == 0 && (*equiv_class)[j] == 0) {
	       (*equiv_class)[i] = (*equiv_class)[j] = (*nb_class)++;
	    } else if((*equiv_class)[i] == 0 || (*equiv_class)[j] == 0) {
	       (*equiv_class)[i] = (*equiv_class)[j] = MAX((*equiv_class)[i], (*equiv_class)[j]);
	    } else {
	       if((*equiv_class)[j] != (*equiv_class)[i]) {
		  for(k = 0; k < nb_seqs; k++) {
		     if(k != i && k != j) {
			if((*equiv_class)[k] == (*equiv_class)[i]
			   || (*equiv_class)[k] == (*equiv_class)[j]) {
			   (*equiv_class)[k] = MIN((*equiv_class)[i], (*equiv_class)[j]);
			} else if((*equiv_class)[k] == (*nb_class)-1) {
			   (*equiv_class)[k]--;
			}
		     }
		  }
		  (*nb_class)--;
		  (*equiv_class)[j] = (*equiv_class)[i] = MIN((*equiv_class)[i], (*equiv_class)[j]);
	       }
	    }
	 }
      }
   }
   
   
   
#endif

   return;
}




float
****build_vrfg(const fusion_set srfg, const fusion_set sepsilon, float**** rfg) {
   float**** vrfg = NULL;
   int i, j, p, si, sj, k, l;
   int iseps, nbv;
   sequence_set cur_seq_set = NULL;


   if(OPTS_first_phase < 0) p = 6;
   else p = 3;


   NEW(vrfg, float***, srfg->size);
   for(i = 0; i < srfg->size; i++) {

      iseps = fusion_set_contains(sepsilon, srfg->sets[i]);

      NEW(vrfg[i], float**, p);

      for(j = 0; j < p; j++) {
	 /* epsilon edge is the last one... */
	 if(iseps) {
	    nbv = (srfg->size - i);
	    NEW(vrfg[i][j], float*, nbv);
	    
	    NEW(vrfg[i][j][nbv - 1], float, 1);
	    vrfg[i][j][nbv - 1][0] = 0.0;

	    cur_seq_set = srfg->sets[i];

	    for(si = 0; si < (cur_seq_set->nb_seqs - 1); si++) {
	       for(sj = si + 1; sj < cur_seq_set->nb_seqs; sj++) {
#ifndef PROTEA_FUSION_SP
		  if(RESULTS_sequence_similarities[cur_seq_set->seq_id[si]][cur_seq_set->seq_id[sj] - cur_seq_set->seq_id[si] - 1] < sim_threshold) {
#endif
		     /* FULL SP */
		     vrfg[i][j][nbv - 1][0] += rfg[cur_seq_set->seq_id[si]][j][cur_seq_set->seq_id[sj] - cur_seq_set->seq_id[si] - 1][cur_seq_set->frames[j][sj]];
#ifndef PROTEA_FUSION_SP
		  }
#endif
	       }
	    }

	 } else {
	    nbv = (srfg->size - 1 - i);
	    if(nbv > 0) {
	       NEW(vrfg[i][j], float*, nbv);
	    }
	 }

	 for(k = i+1; k < srfg->size; k++) {
	    NEW(vrfg[i][j][k-i-1], float, p);
	    
	    for(l = 0; l < p; l++) {
#ifdef SYNC_STRAND
	       if(((j < 3) && (l < 3)) || ((j > 2) && (l > 2))) {
#endif
		  vrfg[i][j][k-i-1][l] = 0.0;
		  
		  for(si = 0; si < srfg->sets[i]->nb_seqs; si++) {
		     for(sj = 0; sj < srfg->sets[k]->nb_seqs; sj++) {
			if(srfg->sets[i]->seq_id[si] < srfg->sets[k]->seq_id[sj]) {
#ifndef PROTEA_FUSION_SP
			   if(RESULTS_sequence_similarities[srfg->sets[i]->seq_id[si]][srfg->sets[k]->seq_id[sj] - srfg->sets[i]->seq_id[si] - 1] < sim_threshold) {
#endif
			      vrfg[i][j][k-i-1][l] += rfg[srfg->sets[i]->seq_id[si]][srfg->sets[i]->frames[j][si]][srfg->sets[k]->seq_id[sj] - srfg->sets[i]->seq_id[si] - 1][srfg->sets[k]->frames[l][sj]];
#ifndef PROTEA_FUSION_SP
			      }
#endif
			} else {
#ifndef PROTEA_FUSION_SP
			   if(RESULTS_sequence_similarities[srfg->sets[k]->seq_id[sj]][srfg->sets[i]->seq_id[si] - srfg->sets[k]->seq_id[sj] - 1] < sim_threshold) {
#endif
			      vrfg[i][j][k-i-1][l] += rfg[srfg->sets[k]->seq_id[sj]][srfg->sets[k]->frames[l][sj]][srfg->sets[i]->seq_id[si] - srfg->sets[k]->seq_id[sj] - 1][srfg->sets[i]->frames[j][si]];
#ifndef PROTEA_FUSION_SP
			      }
#endif
			}
		     }
		  }
#ifdef SYNC_STRAND
	       }
#endif
	    }
	 }
      }
   }   


   return vrfg;
}





int
write_fusion_graph(FILE* output, float**** results, const int nb_seqs, const sequence* seqs, const fusion_set srfg, const fusion_set sepsilon) {
   int i, j, k, l;
   
   fprintf(output, "\\documentclass[landscape,10pt]{article}\n\n\\usepackage[latin1]{inputenc}\n\\newlength{\\marger}\\newlength{\\margeh}\\newlength{\\margeb}\\newlength{\\margegd}\n");
   fprintf(output, "\\setlength{\\marger}{0cm}\\setlength{\\margeh}{0cm}\\setlength{\\margeb}{0cm}\\setlength{\\margegd}{4cm}\\setlength{\\parindent}{1cm}\\setlength{\\voffset}{-1in}\\setlength{\\topmargin}{.333\\margeh}\\setlength{\\headheight}{.333\\margeh}\\setlength{\\headsep}{.333\\margeh}\\setlength{\\textheight}{\\paperheight}\n\n\n\\usepackage{supertabular}\n\n\\addtolength{\\textheight}{-2cm}");
   fprintf(output, "\\addtolength{\\textheight}{-\\margeh}\\addtolength{\\textheight}{-\\margeb}\\setlength{\\hoffset}{-1in}\\addtolength{\\hoffset}{\\margegd}\\setlength{\\oddsidemargin}{\\marger}\\setlength{\\evensidemargin}{0pt}\\setlength{\\textwidth}{\\paperwidth}\\addtolength{\\textwidth}{-2\\margegd}\\addtolength{\\textwidth}{-\\marger}\n\n\\begin{document}\n\\tt\n\\vspace*{\\fill}\n\\begin{center}\n");


   fprintf(output, "\\begin{tabular}{rl}\nId&Sequence name\\\\\n");
   for(i = 0; i < nb_seqs; i++)
     fprintf(output, "%2i&%s\\\\\n", i, seqs[i]->input_name);
   fprintf(output, "\\end{tabular}\n\n");
     
     
   fprintf(output, "\\begin{tabular}{rl}\nId&Sequences\\\\\n");
   for(i = 0; i < srfg->size; i++) {
      fprintf(output, "%2i&\\{", i);
      fprintf(output, "%i", srfg->sets[i]->seq_id[0]);
      for(j = 1; j < srfg->sets[i]->nb_seqs; j++) {
	 fprintf(output, ",%i", srfg->sets[i]->seq_id[j]);
      }
      if(fusion_set_contains(sepsilon, srfg->sets[i])) {
	 fprintf(output, "\\}*\\\\\n");
      } else {
	 fprintf(output, "\\}\\\\\n");
      }
   }
   fprintf(output, "\\end{tabular}\n\n");


#ifdef SYNC_STRAND
   fprintf(output, "\\begin{supertabular}{|r|ccc|ccc|ccc|}\n\\hline\n");
#else
   fprintf(output, "\\begin{supertabular}{|r|cccccc|cccccc|cccccc|}\n\\hline\n");
#endif

   for(i = 1; i <= 3; i++) {
      for(j = 1; j <= 3; j++) {
	 fprintf(output, "&%i/%i", i, j);
      }
#ifndef SYNC_STRAND
      for(j = -3; j <= -1; j++) {
	 fprintf(output, "&%i/%i", i, j);
      }
#endif
   }
   fprintf(output, "\\\\\n");
   if(OPTS_first_phase < 0) {
      for(i = -3; i <= -1; i++) {
	 for(j = -3; j <= -1; j++) {
	    fprintf(output, "&%i/%i", i, j);
	 }
#ifndef SYNC_STRAND
      for(j = 1; j <= 3; j++) {
	 fprintf(output, "&%i/%i", i, j);
      }
#endif
      }
      fprintf(output, "\\\\\n");
   }
   fprintf(output, "\\hline\n");
   
   
   for(i = 0; i < srfg->size; i++) {
      if(fusion_set_contains(sepsilon, srfg->sets[i])) {
	 if(fprintf(output, "%2i/%2i", i, i) < 0) return 1;
	 for(k = 0; k < 3; k++) {
	    for(l = 0; l < 3; l++) {
	       if(k == l) {
		  if(fprintf(output, "&%.1f", results[i][k][srfg->size - i - 1][0]) < 0) return 1;
	       } else {
		  if(fprintf(output, "&") < 0) return 1;
	       }
	    }
#ifndef SYNC_STRAND
	    for(l = 5; l > 2; l--) {
	       if(fprintf(output, "&") < 0) return 1;
	    }
#endif
	 }
	 if(OPTS_first_phase < 0) {
	    if(fprintf(output, "\\\\\n") < 0) return 1;
	    for(k = 5; k > 2; k--) {
	       for(l = 5; l > 2; l--) {
		  if(k == l) {
		     if(fprintf(output, "&%.1f", results[i][k][srfg->size - i - 1][0]) < 0) return 1;
		  } else {
		     if(fprintf(output, "&") < 0) return 1;
		  }
	       }
#ifndef SYNC_STRAND
	       for(l = 0; l < 3; l++) {
		  if(fprintf(output, "&") < 0) return 1;
	       }
#endif
	    }
	 }

	 if(fprintf(output, "\\\\\n") < 0) return 1;
      }


      for(j = i + 1; j < srfg->size; j++) {
	 if(fprintf(output, "%2i/%2i", i, j) < 0) return 1;
	 
	 for(k = 0; k < 3; k++) {
	    for(l = 0; l < 3; l++) {
	       if(fprintf(output, "&%.1f", results[i][k][j - i - 1][l]) < 0) return 1;
	    }
#ifndef SYNC_STRAND
	    for(l = 5; l > 2; l--) {
	       if(fprintf(output, "&%.1f", results[i][k][j - i - 1][l]) < 0) return 1;
	    }
#endif
	 }
	 
	 if(OPTS_first_phase < 0) {
	    if(fprintf(output, "\\\\\n") < 0) return 1;
	    
	    for(k = 5; k > 2; k--) {
	       for(l = 5; l > 2; l--) {
		  if(fprintf(output, "&%.1f", results[i][k][j - i - 1][l]) < 0) return 1;
	       }
#ifndef SYNC_STRAND
	       for(l = 0; l < 3; l++) {
		  if(fprintf(output, "&%.1f", results[i][k][j - i - 1][l]) < 0) return 1;
	       }
#endif
	    }
	 }
	 
	 if(fprintf(output, "\\\\\n") < 0) return 1;
      }
      fprintf(output, "\\hline\n");
   }

   fprintf(output, "\\end{supertabular}\n\\end{center}\n\\vspace*{\\fill}\n\\end{document}\n");

   return 0.0;
}
