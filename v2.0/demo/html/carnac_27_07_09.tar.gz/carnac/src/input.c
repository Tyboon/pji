#ifdef HAVE_CONFIG_H
    #include "config.h"
#endif
/*
Copyright or © or CCopr. INRIA : Arnaud FONTAINE

arnaud.fontaine@lifl.fr

This software is a computer program whose purpose is to predict 
significantly conserved protein coding sequences and/or RNA structure 
on a set of unaligned nucleic sequences.

This software is governed by the CeCILL  license under French law and
abiding by the rules of distribution of free software.  You can  use,
modify and/ or redistribute the software under the terms of the CeCILL
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info".

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability.

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or
data to be ensured and,  more generally, to use and operate it in the
same conditions as regards security.

The fact that you are presently reading this means that you have had
knowledge of the CeCILL license and that you accept its terms.
*/

#include <errno.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>

#include "input.h"
#include "display.h"
#include "opts.h"
/*#include "neuron.h"*/
#include "carnac_interface.h"
#include "carnac_parser.h"


char*
read_line(FILE* fd, int* nb) {
   char *res = NULL, buf[80];
   int nr, i;
   register int j;

   *nb = 0;
   nr = -1;
   
   while((nr = fread(buf, sizeof(char), 80, fd)) > 0) {
      i = 0;
      while((i < nr) && (buf[i] != '\n')) i++;

      if((*nb)) { RENEW(res, char, (i + *nb + 1)); }
      else { NEW(res, char, (i + 1)); }
      for(j = 0; j < i; j++) {
	 res[*nb + j] = buf[j];
      }
      *nb += i;
      res[*nb] = '\0';

      if(i < nr) {
	 fseek(fd, (i - nr) + 1, SEEK_CUR);
	 return res;	 
      }
   }

   if(feof(fd) == 0) {
      *nb = 0;
      ERROR_ "read_line failed !!!\n" _ERROR;
      return NULL;
   }

   return res;
}

/* int */
/* read_clustal(const char *file, FILE* fd, sequence** seqs, int* nb)  { */
/*    ERROR_ "not implemented yet ;)\n" _ERROR; */
/*    return 0; */
/* } */

/* int */
/* read_fasta(const char *file, FILE* fd, sequence** seqs, int* nb)  { */
/*    char* buf = NULL; */
/*    char* buf2; */
/*    int length; */
/*    int state = 0, i, j = 0; */

/*    *nb = 0; */
/*    NEW(buf2, char, INPUT_BUFFER); */

/*    while((buf = read_line(fd, &length))) { */

/*       RENEW(buf2, char, (1+length)); */

/*       for(i = 0; i < length; i++) { */
/* 	 switch(buf[i]) { */
/* 	 case '>': */
/* 	    switch(state) { */
/* 	    case 0: */
/* 	       state = 1; */
/* 	       j = 0; */
/* 	       break; */
/* 	    case 2: */
/* 	       if(j > 0) concat_bases((*seqs)[*nb - 1], buf2, j); */
/* 	       state = 1; */
/* 	       j = 0; */
/* 	       break; */
/* 	    case 1: */
/* 	    default: */
/* 	       break; */
/* 	    } */
/* 	    break; */
/* 	 case ' ': */
/* 	 case '\t': */
/* 	 case '0': */
/* 	 case '1': */
/* 	 case '2': */
/* 	 case '3': */
/* 	 case '4': */
/* 	 case '5': */
/* 	 case '6': */
/* 	 case '7': */
/* 	 case '8': */
/* 	 case '9': */
/* 	    switch(state) { */
/* 	    case 1: */
/* 	       buf2[j++] = buf[i]; */
/* 	       break; */
/* 	    case 0: */
/* 	    case 2: */
/* 	    default: */
/* 	       break; */
/* 	    } */
/* 	    break; */
/* 	 case '/': */
/* 	    buf2[j++] = '|'; */
/* 	    break; */
/* 	 case '-': */
/* 	    switch(state) { */
/* 	    case 1: */
/* 	       buf2[j++] = buf[i]; */
/* 	       break; */
/* 	    case 0: */
/* 	    case 2: */
/* 	    default: */
/* 	       break; */
/* 	    } */
	    
/* 	    break; */
/* 	 default: */
/* 	    buf2[j++] = buf[i]; */
/* 	    break; */
/* 	 } */
/*       } */

/*       switch(state) { */
/*       case 1: */
/* 	 if(*nb == 0) { NEW(*seqs, sequence, 1); } */
/* 	 else { RENEW(*seqs, sequence, ((*nb)+1)); } */
	 
/* 	 buf2[j] = '\0';	  */
	 
/* 	 (*seqs)[*nb] = new_sequence(file, buf2, buf2, "", 0, 0, 1); /\* trouver le brin *\/ */
/* 	 (*nb)++; */
/* 	 state = 2; */
/* 	 j = 0; */
/* 	 break; */
/*       case 2: */
/* 	 if(j > 0) { */
/* 	    concat_bases((*seqs)[*nb - 1], buf2, j); */
/* 	    j = 0; */
/* 	 } */
/* 	 break; */
/*       case 0: */
/*       default: */
/* 	 break; */
/*       } */

/*       DESTROY(buf); */
/*    } */
   
/*    DESTROY(buf2); */

/*    return 0; */
/* } */

/* int */
/* read_raw(const char *file, FILE* fd, sequence** seqs, int* nb)  { */
/*    char buf[INPUT_BUFFER]; */
/*    char buf2[INPUT_BUFFER]; */
/*    int nr = 0, i, j; */

/*    *nb = 1; */

/*    NEW((*seqs), sequence, (*nb)); */
/*    (*seqs)[0] = new_sequence(file, "raw sequence", "raw sequence", "", 0, 0, 1); */

/*    while((nr = fread(buf, sizeof(char), INPUT_BUFFER, fd)) > 0) { */
/*       j = 0; */
/*       for(i = 0; i < nr; i++) { */
/* 	 switch(buf[i]) { */
/* 	 case ' ': */
/* 	 case '\r': */
/* 	 case '\t': */
/* 	 case '\n': */
/* 	    break; */
/* 	 default: */
/* 	    buf2[j] = buf[i]; */
/* 	    j++; */
/* 	    break; */
/* 	 } */
/*       } */
/*       concat_bases((**seqs), buf2, j); */
/*    } */
   
/*    if(feof(fd) == 0) { */
/*       ERROR_ "a problem occured while reading '%s': %s\n", file, strerror(errno) _ERROR; */
/*    } */
  
/*    return 0; */
/* } */


int
read_sequences(char *file, sequence** seqs, int* nb) {

   /*   if(verbose) { INFO_ "Reading sequence(s) from '%s'...\n", file _INFO ; }*/
   
   /*return fmt->read_fun(file, fd, seqs, nb);*/

   if(file == NULL) {
      arnicain = stdin;
      arnica_file_name = "stdin";
   } else if((arnicain = fopen(file, "r"))) {
      arnica_file_name = file;
   } else {
      ERROR_ "unable to open '%s' for reading !\n", file _ERROR;
      return -1;
   }

   
   arnica_nb_errors = 0;
   arnicalineno = 1;
   
   arnicarestart(arnicain);
   
   arnicaparse();
   
   if(arnica_nb_errors) {
      ERROR_ "unable to recover previous errors !\n" _ERROR;
      (*seqs) = NULL;
      (*nb) = 0;
   } else {
      (*seqs) = arnica_result;
      (*nb) = 0;
      while(arnica_result[(*nb)]) (*nb)++;
   }

   if(arnicain != stdin) {
      fclose(arnicain);
   }

   return arnica_nb_errors;

}


/*
network
read_network(char *file_name) {
   
   network_nb_errors = 0;

   if((networkin = fopen(file_name, "r"))) {

      NEW(network_file_name, char, (1 + strlen(file_name)));
      strncpy(network_file_name, file_name, strlen(file_name));
*/
      /*   networkdebug = 1;*/
/*      networkparse();
      if(network_nb_errors) {
	 ERROR_ "unable to recover previous errors !\n" _ERROR;
	 return NULL;
      }
      fclose(networkin);
      return neuron_result;
   }

   ERROR_ "unable to open '%s' for reading !\n", file_name _ERROR;
   return NULL;
}



samples
*read_samples(char* file_name) {

   learner_nb_errors = 0;

   if((learnerin = fopen(file_name, "r"))) {

      NEW(learner_file_name, char, (1 + strlen(file_name)));
      strncpy(learner_file_name, file_name, (1 + strlen(file_name)));
*/
      /*learnerdebug = 1;*/
/*      learnerparse();
      if(learner_nb_errors) {
	 ERROR_ "unable to recover previous errors !\n" _ERROR;
	 return NULL;
      }   

      fclose(learnerin);
      return learner_result;
   }
      
   return NULL;
}
*/
