#ifndef __ARNICA_STACK_H__
#define __ARNICA_STACK_H__


typedef struct {
   int *elements;
   int size;
   int max_size;
} int_stack_t;

typedef int_stack_t* int_stack;


typedef struct {
   short *elements;
   short size;
   short max_size;
} short_stack_t;

typedef short_stack_t* short_stack;


#define STACK_IS_EMPTY(St) ((St)->size <= 0)
#define STACK_IS_FULL(St) ((St)->size == (St)->max_size)

#define STACK_VALUE_AT(St,In) ((St)->elements[In])
#define STACK_PEEK(St) ((St)->elements[(St)->size - 1])
#define STACK_POP(St) ((St)->elements[--((St)->size)])
#define STACK_PUSH(St,Val) ((St)->elements[((St)->size)++] = Val)

#define STACK_SIZE(St) ((St)->size)

#define STACK_EMPTY(St) ((St)->size = 0)

#define DESTROY_STACK(St)			\
   DESTROY((St)->elements);			\
   DESTROY(St)

#define NEW_INT_STACK(St,MSiz)			\
   NEW((St), int_stack_t, 1);			\
   NEW(((St)->elements), int, (MSiz));		\
   (St)->size=0;				\
   (St)->max_size=MSiz


#define NEW_SHORT_STACK(St,MSiz)		\
   NEW((St), short_stack_t, 1);			\
   NEW(((St)->elements), short, (MSiz));	\
   (St)->size=0;				\
   (St)->max_size=MSiz







/****************************/
/*  two elements            */
/****************************/

typedef struct{
  int x; 
  int y;
}pair;

typedef struct{
  pair * elements; 
  int top;
} stack; 

/*Empile un ?l?ment ? la pile*/
void push(stack * p, int x,int y);

/*D?pile un ?l?ment a la pile*/
void pop(stack * p,int * x,int * y);

/* is the stack empty ? */
int is_empty_stack(stack * p);

/* Memory allocation + initialisation of the stack */
void init_stack(stack * p, int size);

void display_stack(stack * p);

void free_stack(stack *s);

/*********************************/
/*   four elements               */
/*********************************/
 
typedef struct{
  int x; 
  int y;
  int z; 
  int t; 
}quadruplet;

typedef struct{
  quadruplet * elements; 
  int top;
} quadruple_stack; 

/*Empile un ?l?ment ? la pile*/
void quadruple_push(quadruple_stack * p, int x,int y,int z, int t);

/*D?pile un ?l?ment a la pile*/
void quadruple_pop(quadruple_stack * p,int * x,int * y, int * z, int * t);

/* is the stack empty ? */
int is_empty_quadruple_stack(quadruple_stack * p);

/* Memory allocation + initialisation of the stack */
void init_quadruple_stack(quadruple_stack * p, int size);


void display_quadruple_stack(quadruple_stack * p);

void free_quadruple_stack(quadruple_stack *s);




#endif
