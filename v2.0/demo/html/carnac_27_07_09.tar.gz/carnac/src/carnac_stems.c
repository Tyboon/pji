#ifdef HAVE_CONFIG_H
    #include "config.h"
#endif
#include <stdlib.h>
#include <ctype.h>
#include <assert.h>
#include <stdio.h>
#include <string.h>


#include "display.h"
#include "opts.h"
#include "qsort.h"
#include "output.h"

#include "carnac_stems.h"
#include "carnac_energy.h"




#ifdef CARNAC_OLD_MODE

int
stem_energy_threshold(int dist, int gcpercentage) {
   double a, b, out;
   
   /* idem old carnac */
   
   const double THD_1 = -700;
   const double DIST_1 = 0;
   const double THD_2 = -1300;
   const double DIST_2 = 300;
   const double TOP_TH = THD_2;
   
   a = (THD_2 - THD_1) / (DIST_2 - DIST_1);
   b = THD_1 - a * DIST_1;
   out =  a * dist + b; 
   if(OPTS_carnac_correct_thd) out -=  out * ((50.0 - gcpercentage)/100.0);

   /* relax to nearest possible energy value below */
   out = (int)(out / 10.0) * 10.0;

   return MAX(TOP_TH, out);
}

#else

int
stem_energy_threshold(int dist, int gcpercentage) {
   double out;

   out = -dist - 700;
   out = MAX(out, -1250);
   /****out = -1.5*dist - 700;****/
   /****out = -2*dist - 700;****/
   if(OPTS_carnac_correct_thd) out -=  out * ((50.0 - gcpercentage)/100.0);

   /* relax to nearest possible energy value below */
   out = (int)(out / 10.0) * 10.0;
 
   return out;
   /*   return MAX(out, -1250);*/
   /*****   return MAX(out, -1300);****/
}

#endif









int
compare_stem_begin(const void *a1, const void *a2) {
   stem_t* s1 = (stem_t*)a1;
   stem_t* s2 = (stem_t*)a2;
   int r = s1->begin_start - s2->begin_start;
   
   if(r == 0)  {
      r = s1->begin_stop - s2->begin_stop;
      
      if(r == 0) {
	 r = s1->end_start - s2->end_start;
      }
   }

   return r;
}


void
sort_stems_by_begin(stem_t_list l) {
   qsort(l->stems, l->nb_stems, sizeof(stem_t), compare_stem_begin);
}











int
compare_stem_end(const void *a1, const void *a2) {
   stem_t* s1 = (stem_t*)a1;
   stem_t* s2 = (stem_t*)a2;
   int r = s1->end_stop - s2->end_stop;
   
   if(r == 0)  {
      r = s1->end_start - s2->end_start;
   }

   return r;
}


void
sort_stems_by_end(stem_t_list l) {
   qsort(l->stems, l->nb_stems, sizeof(stem_t), compare_stem_end);
}



int
compare_stem_begin_closure(const void *a1, const void *a2) {
   stem_t* s1 = (stem_t*)a1;
   stem_t* s2 = (stem_t*)a2;
   int r = s1->begin_stop - s2->begin_stop;
   
   if(r == 0)  {
      r = s1->begin_start - s2->begin_start;
      
      if(r == 0) {
	 r = s1->end_stop - s2->end_stop;

	 if(r == 0) {
	    r = s1->end_start - s2->end_start;
	 }
      }
   }

   return r;
}


void
sort_stems_by_begin_closure(stem_t_list l) {
   qsort(l->stems, l->nb_stems, sizeof(stem_t), compare_stem_begin_closure);
}






int
compare_stem_begin_then_end(const void *a1, const void *a2) {
   stem_t* s1 = (stem_t*)a1;
   stem_t* s2 = (stem_t*)a2;
   int r = s1->begin_start - s2->begin_start;
   
   if(r == 0) {
      r = s1->end_stop - s2->end_stop;
      if(r == 0) {
	 r = s1->begin_stop - s2->begin_stop;
      }
   }

   return r;
}





void
sort_stems_by_begin_then_end(stem_t_list l) {
   qsort(l->stems, l->nb_stems, sizeof(stem_t), compare_stem_begin_then_end);
}





int
compare_stem_begin_then_end_closure(const void *a1, const void *a2) {
   stem_t* s1 = (stem_t*)a1;
   stem_t* s2 = (stem_t*)a2;
   int r = s1->begin_start - s2->begin_start;
   
   if(r == 0) {
      r = s1->end_start - s2->end_start;
      if(r == 0) {
	 r = s1->begin_stop - s2->begin_stop;
      }
   }

   return r;
}


void
sort_stems_by_begin_then_end_closure(stem_t_list l) {
   qsort(l->stems, l->nb_stems, sizeof(stem_t), compare_stem_begin_then_end_closure);
}







int
compare_stem_id_begin_then_length(void *s, const void *a1, const void *a2) {
   stem_t *s1 = &(((stem_t_list)s)->stems[*((int*)a1)]);
   stem_t *s2 = &(((stem_t_list)s)->stems[*((int*)a2)]);
   int r = s1->begin_start - s2->begin_start;
   
   if(r == 0) {
      r = s1->begin_stop - s2->begin_stop;
   }
 
   return r;
}


void
sort_stems_id_by_begin_then_length(stem_list *l, stem_t_list s) {
   my_qsort_r(l->stem_id, l->nb_stems, sizeof(int), s, compare_stem_id_begin_then_length);
}



int
compare_stem_id_begin_closure_then_length(void *s, const void *a1, const void *a2) {
   stem_t *s1 = &(((stem_t_list)s)->stems[*((int*)a1)]);
   stem_t *s2 = &(((stem_t_list)s)->stems[*((int*)a2)]);
   int r = s1->end_start - s2->end_start;
   
   if(r == 0) {
      r = s1->end_stop - s2->end_stop;
   }

   return r;
}

void
sort_stems_id_by_begin_closure_then_length(stem_list *l, stem_t_list s) {
   my_qsort_r(l->stem_id, l->nb_stems, sizeof(int), s, compare_stem_id_begin_closure_then_length);
}







int
is_canonical_pair(const char a, const char b) {
   switch(a) {
   case 'A':
      switch(b) {
      case 'U':
      case 'T':
	 return 1;
      }
      return 0;
   case 'C':
      switch(b) {
      case 'G':
	 return 1;
      }
      return 0;
   case 'G':
      switch(b) {
      case 'C':
      case 'U':
      case 'T':
	 return 1;
      }
      return 0;
   case 'U':
   case 'T':
      switch(b) {
      case 'A':
      case 'G':
	 return 1;
      }
      return 0;
   }

   return 0;
}




int
covariate(char a1, char b1, char a2, char b2) {
   int r;

   r = 0;

   if(is_canonical_pair(a1,b1)) {
      if(is_canonical_pair(a2,b2)) {
	 if(a1 != a2) {
	    r++;
	 }
	 if(b1 != b2) {
	    r++;
	 }
      }
   }

   return r;
}



int
conserved_non_canonical(char a1, char b1, char a2, char b2) {
   int r;

   r = 0;

   if(!is_canonical_pair(a1,b1)) {
      if(!is_canonical_pair(a2,b2)) {
	 if(isalpha(a1) && (a1 == a2)) {
	    r++;
	 }
	 if(isalpha(b1) && (b1 == b2)) {
	    r++;
	 }
      }
   }

   return r;
}








int
have_a_common_base_pair(stem_t *s1, stem_t *s2) {
   return ((IS_BETWEEN(s1->begin_start, s1->begin_stop, s2->begin_start)
	   || IS_BETWEEN(s2->begin_start, s2->begin_stop, s1->begin_start))
	   && ((s2->begin_start - s1->begin_start) == (s1->end_stop - s2->end_stop)));
}










void
remove_common_stems(stem_t_list comst) {
   int j;
   int max_stems;
   /* suppression des copies */
   j = 1;
   
   sort_stems_by_begin_then_end(comst);

   max_stems = comst->nb_stems;

   while(j < comst->nb_stems) { 
      if(((comst->stems[j].begin_start == comst->stems[j-1].begin_start)
	  && (comst->stems[j].end_stop == comst->stems[j-1].end_stop))
	 || ((comst->stems[j].begin_stop == comst->stems[j-1].begin_stop)
	     && (comst->stems[j].end_start == comst->stems[j-1].end_start))) {
	 
	 if(comst->stems[j].energy <= comst->stems[j-1].energy) {
	    memmove(&(comst->stems[j-1]), &(comst->stems[j]), (comst->nb_stems - j) * sizeof(stem_t));
	 } else {
	    if((j+1) < comst->nb_stems) {
	       memmove(&(comst->stems[j]), &(comst->stems[j+1]), (comst->nb_stems - j - 1) * sizeof(stem_t));
	    }
	 }
	 
	 comst->nb_stems--;
      } else {
	 j++;
      }
   }
   
   if((comst->nb_stems > 0) && (comst->nb_stems < max_stems)) {
      RENEW(comst->stems, stem_t, comst->nb_stems);
   }
}










void
print_stem(stem_t *stem, metasequence s) {
   if(s) {
      print_seq_stem(stem, s->seqs[0]);
   } else {
      print_seq_stem(stem, NULL);
   }
}

void
println_stem(stem_t *stem, metasequence s) {
   print_stem(stem, s);
   INFO_ "\n" _INFO;
}



void
print_seq_stem(stem_t *stem, sequence s) {
   char *sopen = NULL, *sclose = NULL;

   INFO_ "[%5i .. %5i : %5i .. %5i]  %8i", stem->begin_start, stem->begin_stop, stem->end_start, stem->end_stop, stem->energy _INFO;

   if(s) {
      NEW(sopen, char, stem->begin_stop - stem->begin_start + 1 +1);
      NEW(sclose, char, stem->end_stop - stem->end_start + 1 +1);
      
      strncpy(sopen, &(s->bases[stem->begin_start]), stem->begin_stop - stem->begin_start +1);
      strncpy(sclose, &(s->bases[stem->end_start]), stem->end_stop - stem->end_start + 1);
      
      INFO_ "  %s / %s", sopen, sclose _INFO;
      
      DESTROY(sopen);
      DESTROY(sclose);
   }
}

void
println_seq_stem(stem_t *stem, sequence s) {
   print_seq_stem(stem, s);
   INFO_ "\n" _INFO;
}







void
destroy_stem_t_list(stem_t_list l) {
   DESTROY(l->stems);
   DESTROY(l);
}














stem_t_list
stems_in_seq(const sequence s) {
   stem_t_list res = NULL, resext = NULL;
   int max_stems = 100; /* taille par defaut, augmenté par la suite si necessaire */
   int i, j, k, l, state;
   int gcpercentage;
   int ni, nj, nk, nl;
   int nrj, ext;

   
   gcpercentage = gc_percentage(s) * 100.0;



   NEW(res, stem_t_list_t, 1);
   NEW(res->stems, stem_t, max_stems);
   res->nb_stems = 0;


   state = 0;
   i = 0;
   j = SIZE_HAIRPIN+1;
   k = 0;
   l = 0;
   nrj = 0;
   while((i < (s->length - SIZE_HAIRPIN - 1)) && (j < s->length)) {
      /*      INFO_ "LOOK AT %i %i\n", i+k, j-k _INFO;*/
      switch(state) {
      case 0: /* ready */
	 if(is_canonical_pair(s->bases[i+k], s->bases[j-k])) {
	    nrj = 0;
	    l = 1;
	    state = 1;
	 }
	 break;
      case 1: /* in stem */
	 if(is_canonical_pair(s->bases[i+k], s->bases[j-k])) {
	    nrj += stack_inside(s, i+k-1,j-k+1);
	    l++;
	 } else {
	    state = 0;
	    nrj += tstack_inside(s, i+k-1,j-k+1);
	    /*	    if(nrj <= STEM_ENERGY_THRESHOLD) {*/
	    if(nrj <= MAX(stem_energy_threshold ((j-k+1) - (i+k-l), gcpercentage), STEM_ENERGY_THRESHOLD)) {
	       if(res->nb_stems == max_stems) {
		  max_stems += 50;
		  RENEW(res->stems, stem_t, max_stems);
	       }
	       res->stems[res->nb_stems].begin_start = i+k-l;
	       res->stems[res->nb_stems].end_stop = j-k+l;
	       res->stems[res->nb_stems].begin_stop = i + k - 1;
	       res->stems[res->nb_stems].end_start = j - k + 1;
	       res->stems[res->nb_stems].energy = nrj;
	       res->stems[res->nb_stems].is_a_single_stem = 1;
	       /*	       res->stems[res->nb_stems].freq = 0;*/
	       res->nb_stems++;
	    }
	 }
	 break;
      }
      
      k++;
      if(((i+k) >= s->length) || (((j-k) - (i+k)) <= SIZE_HAIRPIN)) {
	 if(state == 1) {
	    nrj += tstack_inside(s, i+k-1,j-k+1);
	    /*if(nrj <= STEM_ENERGY_THRESHOLD) {*/
	    if(nrj <= MAX(stem_energy_threshold ((j-k+1) - (i+k-l), gcpercentage), STEM_ENERGY_THRESHOLD)) {
	       if(res->nb_stems == max_stems) {
		  max_stems += 50;
		  RENEW(res->stems, stem_t, max_stems);
	       }
	       res->stems[res->nb_stems].begin_start = i+k-l;
	       res->stems[res->nb_stems].end_stop = j-k+l;
	       res->stems[res->nb_stems].begin_stop = i + k - 1;
	       res->stems[res->nb_stems].end_start = j - k + 1;
	       res->stems[res->nb_stems].energy = nrj;
	       res->stems[res->nb_stems].is_a_single_stem = 1;
	       /*	       res->stems[res->nb_stems].freq = 0;*/
	       res->nb_stems++;
	    }
	 }
	 state = 0;
	 k = 0;
	 j++;
	 if(j == s->length) {
	    j = s->length-1;
	    i++;
	 }
      }
   }

   if((res->nb_stems < max_stems) && (res->nb_stems > 0)) {
      RENEW(res->stems, stem_t, res->nb_stems);
   }

   /****/


   sort_stems_by_begin(res);

   /* extension des tiges */
   /* il y a de nouvelles tiges ?? des tiges en moins ???? */



   NEW(resext, stem_t_list_t, 1);
   NEW(resext->stems, stem_t, max_stems);
   resext->nb_stems = 0;
   

   for(i = 0; i < res->nb_stems; i++) {
      /*** select stem if enough energy ***/
      if((res->stems[i].energy <= stem_energy_threshold(res->stems[i].end_stop - res->stems[i].begin_start, gcpercentage)) && ((res->stems[i].begin_stop - res->stems[i].begin_start+1) >= SIZE_HAIRPIN)) {
	 
	 if(resext->nb_stems == max_stems) {
	    max_stems += 50;
	    RENEW(resext->stems, stem_t, max_stems);
	 }
	 resext->stems[resext->nb_stems] = res->stems[i];
	 resext->nb_stems++;
      } else {
	 /*	 	 fprintf(stderr, "-------- REJECTING stem [%2i..%2i] [%2i..%2i] nrj = %i (threshold = %2i)\n", res->stems[i].begin_start, res->stems[i].begin_stop, res->stems[i].end_start, res->stems[i].end_stop, res->stems[i].energy, stem_energy_threshold(res->stems[i].end_stop - res->stems[i].begin_start, gcpercentage));*/
      }
      
      



#ifdef CARNAC_NON_WATSON_CRICK

      /*** try to extend outside : {1,2} MISMATCHES
      
         ------ o ------ ........ ------ o ---
        --- oo ------ ........ ------ oo ---
      */
      for(j = 2; j <= 3 ; j++) {
	 
	 ni = res->stems[i].begin_start - j;
	 nl = res->stems[i].end_stop + j;
	 nrj = res->stems[i].energy + (j-1)*STEM_MISMATCH_MALUS;
	 
	 if((ni >= 0)
	    && (nl < s->length)
	    && is_canonical_pair(s->bases[ni], s->bases[nl])
	    && ((j == 2) || (!is_canonical_pair(s->bases[ni+1], s->bases[nl-1])))) {

	    /*fprintf(stderr, "      << STEM stem [%i..%i] [%i..%i]  energy %i\n", res->stems[i].begin_start, res->stems[i].begin_stop, res->stems[i].end_start, res->stems[i].end_stop, res->stems[i].energy);*/
	       
	    if(j == 2) {
	       nrj += sint2_outside (s, res->stems[i].begin_start, res->stems[i].end_stop);
	       /*fprintf(stderr, "      >>>> sint2_out => energy %i\n", nrj);*/
	    }
	    if(j == 3) {
	       nrj += sint4_outside (s, res->stems[i].begin_start, res->stems[i].end_stop);
	       /*fprintf(stderr, "      >>>> sint4_out => energy %i\n", nrj);*/
	    }
	    
	    
	    /* stack AU, CG, GU
	     */
	    ext = 1;
	    while((ni>0)
		  && (nl < (s->length-1))
		  && (is_canonical_pair(s->bases[ni-1], s->bases[nl+1]))) {
	       nrj += stack_outside (s, ni, nl);
	       /*fprintf(stderr, "      >>>> stack_out => energy %i\n", nrj);*/
	       ni--;
	       nl++;
	       ext++;
	    }
	    
	    /* check if energy < threshold
	     */
	    if((ext >= STEM_MINIMAL_EXTEND)
	       && (nrj <= stem_energy_threshold((nl-1)-(ni+1), gcpercentage))
	       && (nrj < res->stems[i].energy)) {
	       
	       if(resext->nb_stems == max_stems) {
		  max_stems += 50;
		  RENEW(resext->stems, stem_t, max_stems);
	       }
	       resext->stems[resext->nb_stems].energy = nrj;
	       resext->stems[resext->nb_stems].begin_start = ni;
	       resext->stems[resext->nb_stems].end_stop = nl;
	       resext->stems[resext->nb_stems].begin_stop = res->stems[i].begin_stop;
	       resext->stems[resext->nb_stems].end_start = res->stems[i].end_start;

	       resext->stems[resext->nb_stems].is_a_single_stem = res->stems[i].is_a_single_stem;
	       /*	       resext->stems[resext->nb_stems].freq = 0;*/
	       
	       resext->nb_stems++;
	       
	       /*fprintf(stderr, "      >> outside STEM (j=%i) stem [%i..%i] [%i..%i]  ext = %i  energy %i\n", j, resext->stems[resext->nb_stems-1].begin_start, resext->stems[resext->nb_stems-1].begin_stop, resext->stems[resext->nb_stems-1].end_start, resext->stems[resext->nb_stems-1].end_stop, ext, resext->stems[resext->nb_stems-1].energy);*/
	       
	    }
	 }
      }
      
      


      /* extend inside */
      
      for(j = 2; j<=3; j++) {

	 nj = res->stems[i].begin_stop + j;
	 nk = res->stems[i].end_start - j;
	 nrj = res->stems[i].energy - tstack_inside (s, res->stems[i].begin_stop, res->stems[i].end_start) + (j-1) * STEM_MISMATCH_MALUS;
	 /*fprintf(stderr, "      >>>> tstack_in => energy %i\n", nrj);*/
	 
	 if(((nk - nj) > SIZE_HAIRPIN)
	    && is_canonical_pair(s->bases[nj], s->bases[nk])
	    && ((j == 2) || !is_canonical_pair(s->bases[nj-1], s->bases[nk+1]))) {

	    /*fprintf(stderr, "      << STEM stem [%i..%i] [%i..%i]  energy %i\n", res->stems[i].begin_start, res->stems[i].begin_stop, res->stems[i].end_start, res->stems[i].end_stop, res->stems[i].energy);*/

	    if(j == 2) {
	       nrj += sint2_inside (s, res->stems[i].begin_stop, res->stems[i].end_start);
	       /*fprintf(stderr, "      >>>> sint2_in => energy %i\n", nrj);*/
	    }
	    if(j == 3) {
	       nrj = nrj + sint4_inside (s, res->stems[i].begin_stop, res->stems[i].end_start);
	       /*fprintf(stderr, "      >>>> sint4_in => energy %i\n", nrj);*/
	    }

	    ext = 1;
	    /* stack AU, CG, GU*/
	    while((((nk-1) - (nj+1)) > SIZE_HAIRPIN)
		  && is_canonical_pair(s->bases[nj+1], s->bases[nk-1])) {

	       nrj += stack_inside (s, nj, nk);
	       /*fprintf(stderr, "      >>>> stack_in => energy %i\n", nrj);*/
	       nj++;
	       nk--;
	       ext++;
	    }
	    
	    nrj += tstack_inside(s, nj, nk);
	    /*fprintf(stderr, "      >>>> tstack_in => energy %i\n", nrj);*/

	    
	    /* check if energy < threshold*/
	    if ((ext >= STEM_MINIMAL_EXTEND)
		&& (nrj <= stem_energy_threshold(res->stems[i].end_stop - res->stems[i].begin_start, gcpercentage))
		&& (nrj < res->stems[i].energy)) {
	       
	       if(resext->nb_stems == max_stems) {
		  max_stems += 50;
		  RENEW(resext->stems, stem_t, max_stems);
	       }
	       resext->stems[resext->nb_stems].energy = nrj;
	       resext->stems[resext->nb_stems].begin_start = res->stems[i].begin_start;
	       resext->stems[resext->nb_stems].end_stop = res->stems[i].end_stop;
	       resext->stems[resext->nb_stems].begin_stop = nj;
	       resext->stems[resext->nb_stems].end_start = nk;
	       resext->stems[resext->nb_stems].is_a_single_stem = res->stems[i].is_a_single_stem;
	       /*	       resext->stems[resext->nb_stems].freq = 0;*/

	       resext->nb_stems++;


	       /*fprintf(stderr, "      >> inside STEM (j=%i) stem [%i..%i] [%i..%i]  ext = %i  energy %i\n", j, resext->stems[resext->nb_stems-1].begin_start, resext->stems[resext->nb_stems-1].begin_stop, resext->stems[resext->nb_stems-1].end_start, resext->stems[resext->nb_stems-1].end_stop, ext, resext->stems[resext->nb_stems-1].energy);*/
	           
	    }
	 }
      }

#endif
   }
   /*****/


   
   
   DESTROY(res->stems);
   DESTROY(res);
   res = resext;
   
      
   
   sort_stems_by_begin(res);
   


   
   /* suppression des copies */
   i = 1;
   max_stems = res->nb_stems;
   while(i < res->nb_stems) {
      if((res->stems[i].begin_start == res->stems[i-1].begin_start)
	 && (res->stems[i].end_stop == res->stems[i-1].end_stop)
	 && (res->stems[i].begin_stop == res->stems[i-1].begin_stop)
	 && (res->stems[i].end_start == res->stems[i-1].end_start)) {
	 
	 if((i + 1) < res->nb_stems) {
	    memmove(&(res->stems[i]), &(res->stems[i+1]), (res->nb_stems - i - 1) * sizeof(stem_t));
	 }
	 res->nb_stems--;
      } else {
	 i++;
      }
   }
   
   if((res->nb_stems > 0) && (res->nb_stems < max_stems)) {
      RENEW(res->stems, stem_t, res->nb_stems);
   }
   /*****/


   return res;
}








int
write_ct(FILE* output, sequence seq, stem_t_list list) {
   int i,j;
   int *pairing_values = NULL;

   NEW(pairing_values, int, seq->length);
   for(i = 0; i < seq->length; i++) {
      pairing_values[i] = 0;
   }

   for(i = 0; i < list->nb_stems; i++) {
      for(j = 0; j < (list->stems[i].begin_stop - list->stems[i].begin_start + 1) ; j++) {
	 /*	 if(is_canonical_pair(seq->bases[list->stems[i].end_stop-j], seq->bases[list->stems[i].begin_start+j])) {*/
	    pairing_values[list->stems[i].begin_start+j] = 1 + list->stems[i].end_stop-j;
	    pairing_values[list->stems[i].end_stop-j] = 1 + list->stems[i].begin_start+j;
	    /*	 }*/
      }
   }

   fprintf(output, "%5i %s\n", seq->length, seq->input_name);
   for(i = 0; i < seq->length; i++) {
      j = i+2;
      if(j > seq->length) { j = 0; }
      fprintf(output, "%5i %c %5i %5i %5i %5i\n", (i+1), seq->bases[i], i, (i+2), pairing_values[i], (i+1));
   }
   
   DESTROY(pairing_values);

   return 0;
}


int
write_eq(FILE* output, sequence seq, stem_t_list list) {
   int i,j;
   int *pairing_values = NULL;

   NEW(pairing_values, int, seq->length);
   for(i = 0; i < seq->length; i++) {
      pairing_values[i] = 0;
   }

   for(i = 0; i < list->nb_stems; i++) {
      for(j = 0; j < (list->stems[i].begin_stop - list->stems[i].begin_start + 1) ; j++) {
	 /*	 if(is_canonical_pair(seq->bases[list->stems[i].end_stop-j], seq->bases[list->stems[i].begin_start+j])) {*/
	    pairing_values[list->stems[i].begin_start+j] = list->stems[i].folded_id;
	    pairing_values[list->stems[i].end_stop-j] = -list->stems[i].folded_id;
	    /*	 }*/
      }
   }

   fprintf(output, "%5i %s\n", seq->length, seq->input_name);
   for(i = 0; i < seq->length; i++) {
      fprintf(output, "%5i %c %5i\n", (i+1), seq->bases[i], pairing_values[i]);
   }
   
   DESTROY(pairing_values);

   return 0;
}

int
write_multieq(FILE* output, const sequence *seqs, stem_t_list_t *stems, int nb_seqs) {
   int i,j,s;
   int *pairing_values = NULL;

   for(s = 0; s < nb_seqs; s++) {
      NEW(pairing_values, int, seqs[s]->length);

      for(i = 0; i < seqs[s]->length; i++) {
	 pairing_values[i] = 0;
      }
      
      for(i = 0; i < stems[s].nb_stems; i++) {
	 for(j = 0; j < (stems[s].stems[i].begin_stop - stems[s].stems[i].begin_start + 1) ; j++) {
	    /*	    if(is_canonical_pair(seqs[s]->bases[stems[s].stems[i].end_stop-j], seqs[s]->bases[stems[s].stems[i].begin_start+j])) {*/
	       pairing_values[stems[s].stems[i].begin_start+j] = 1;
	       pairing_values[stems[s].stems[i].end_stop-j] = 2;
	       /*	    }*/
	 }
      }

      if(write_fasta(output, &(seqs[s]), 1, 1)) {
	 return 1;
      }

      for(i = 0; i < seqs[s]->length; i++) {
	 switch(pairing_values[i]) {
	 case 1:
	    if(fprintf(output, "(") < 0) return 2;
	    break;
	 case 2:
	    if(fprintf(output, ")") < 0) return 2;
	    break;
	 default:
	    if(fprintf(output, ".") < 0) return 2;
	    break;
	 }
      }

      if(fprintf(output, "\n") < 0) return 1;

      DESTROY(pairing_values);
   }

   return 0;
}
