#ifndef __ARNICA_STEMS_H__
#define __ARNICA_STEMS_H__


#include <stdio.h>
#include "sequence.h"
#include "metasequence.h"



typedef struct {
   int begin_start; /* position of first paired nucleotide */
   int begin_stop; /* position of last paired nucleotide */
   int end_start; /* position of first paired nucleotide */
   int end_stop; /* position of first paired nucleotide */
   int energy;
   int is_a_single_stem;
   int folded_id;
} stem_t;


typedef struct {
   stem_t *stems;
   int nb_stems;
} stem_t_list_t;

typedef stem_t_list_t *stem_t_list;


typedef struct {
   int *stem_id;
   int nb_stems;
} stem_list;


extern int
stem_energy_threshold (int dist, int gcpercentage);


extern int
have_a_common_base_pair(stem_t *s1, stem_t *s2);

extern stem_t_list
stems_in_seq(const sequence s);


extern int
are_overlapping_stems(stem_t* a, stem_t* b);


extern int
compare_stem_begin(const void *a1, const void *a2);

extern void
sort_stems_by_begin(stem_t_list l);

extern void
sort_stems_by_begin_closure(stem_t_list l);

extern void
sort_stems_by_begin_then_end(stem_t_list l);

extern void
sort_stems_by_begin_then_end_closure(stem_t_list l);


extern void
sort_stems_id_by_begin_then_length(stem_list *l, stem_t_list s);

extern void
sort_stems_id_by_begin_closure_then_length(stem_list *l, stem_t_list s);



extern int
is_canonical_pair(char a, char b);

extern int
covariate(char a1, char b1, char a2, char b2);


extern int
conserved_non_canonical(char a1, char b1, char a2, char b2);


extern void
print_stem(stem_t *stem, metasequence s);

extern void
print_seq_stem(stem_t *stem, sequence s);


extern void
println_stem(stem_t *stem, metasequence s);

extern void
println_seq_stem(stem_t *stem, sequence s);


extern void
destroy_stem_t_list(stem_t_list l);



extern void
remove_common_stems(stem_t_list comst);


extern int
write_ct(FILE* output, sequence seq, stem_t_list list);

extern int
write_eq(FILE* output, sequence seq, stem_t_list list);


extern int
write_multieq(FILE* output, const sequence *seqs, stem_t_list_t *stems, int nb_seqs);


#endif
