#ifndef __ARNICA_ALIGNMENT_H__
#define __ARNICA_ALIGNMENT_H__

#include "sequence.h"




typedef struct {
   sequence* seqs;
   char *file;
   int nb_seqs;
   int length;
} alignment_t;

typedef alignment_t* alignment;




extern alignment
init_alignment(const sequence* seqs, const int nb_seqs, const char* file);


 
extern int
align_clustalw(const char *input, const char *output);

extern int
align_tcoffee(const char *input, const char *output);


extern int
align_dialign(const char *input, const char *output);


extern int
compute_and_write_protein_alignment(const sequence* seqs, const int nb_seqs, const sequence* prots, const int nb_prots, const int *frames);





extern alignment
translate_alignment(const alignment na, const int frame, sequence **dna_translated);


extern double
compute_protein_alignment_score(const sequence s1, const sequence s2, const double identity);



#endif
