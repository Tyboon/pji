#ifndef __ARNICA_REV_ALIGN_H__
#define __ARNICA_REV_ALIGN_H__


#include <string.h>
#include "stack.h"
#include "sequence.h"


/*extern int_stack alignProteinDNA(const sequence aaSeq, const sequence dnaSeq, int maxNbFS);*/

extern sequence
*realign(const sequence *prots_aligned, const sequence *prots, const sequence *dna, const int nb_seqs, const int* nbfs, const char *output);



#endif
