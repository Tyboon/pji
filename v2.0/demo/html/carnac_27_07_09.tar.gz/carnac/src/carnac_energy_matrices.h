#ifndef __ARNICA_CARNAC_ENERGY_MATRICES_H__
#define __ARNICA_CARNAC_ENERGY_MATRICES_H__



#define Z (INT32_MAX/100)



typedef struct {
   char loop[6];
   int bonus;
} loop_bonus;



extern loop_bonus tloop_bonus [30];

extern int sint4_mat [36] [16] [16];

extern int sint2_mat [6] [4] [6] [4];

extern int stack_energy  [4] [4] [4] [4];

extern int tstackh_energy [4] [4] [4] [4];






#define GET_NUCLEOTIDE_ID(Aa,Ii)					\
   (Ii) = -1;								\
	switch(Aa) {							\
	case 'T':							\
	case 'U':							\
	   (Ii) = 3;							\
	   break;							\
	case 'G':							\
	   (Ii) = 2;							\
	   break;							\
	case 'C':							\
	   (Ii) = 1;							\
	   break;							\
	case 'A':							\
           (Ii) = 0;							\
	   break;							\
	default:							\
	   ERROR_ "unable to deal with nucleotide '%c' !!!\n",(Aa)  _ERROR; \
	   break;							\
	}								\


#define GET_NUCLEOTIDE_PAIR(Aa,Bb,Ii)					\
   (Ii) = -1;								\
	if(((Aa) == 'A') && (((Bb) == 'U') || ((Bb) == 'T')))			\
	   (Ii) = 0;							\
	else if(((Aa) == 'C') && ((Bb) == 'G'))		\
	   (Ii) = 1;							\
	else if(((Aa) == 'G') && ((Bb) == 'C'))		\
	   (Ii) = 2;							\
	else if((((Aa) == 'U') || ((Aa) == 'T')) && ((Bb) == 'A'))		\
	   (Ii) = 3;							\
	else if(((Aa) == 'G') && (((Bb) == 'U') || ((Bb) == 'T')))		\
	   (Ii) = 4;							\
	else if((((Aa) == 'U') || ((Aa) == 'T')) && ((Bb) == 'G'))		\
	   (Ii) = 5;							\
	else {								\
	   ERROR_ "unexpected non canonical pair\n" _ERROR;		\
	}								\


#define GET_NUCLEOTIDE_PAIR_NONWC(Aa,Bb,Ii)				\
   (Ii) = -1;								\
	switch(Aa) {							\
	case 'T':							\
	case 'U':							\
	   (Ii) = 3;							\
	   break;							\
	case 'G':							\
	   (Ii) = 2;							\
	   break;							\
	case 'C':							\
	   (Ii) = 1;							\
	   break;							\
	case 'A':							\
           (Ii) = 0;							\
	   break;							\
	default:							\
	   ERROR_ "unable to deal with nucleotide '%c' !!!\n",(Aa)  _ERROR; \
	   break;							\
	}								\
	(Ii) *= 4;							\
	switch(Bb) {							\
	case 'T':							\
	case 'U':							\
	   (Ii) += 3;							\
	   break;							\
	case 'G':							\
	   (Ii) += 2;							\
	   break;							\
	case 'C':							\
	   (Ii) += 1;							\
	   break;							\
	case 'A':							\
	   break;							\
	default:							\
	   ERROR_ "unable to deal with nucleotide '%c' !!!\n",(Bb)  _ERROR; \
	   break;							\
	}								\
	


	
   
#define GET_NUCLEOTIDE_QUAD(Aaaa,Bbbb,Cccc,Dddd, Iiii, Tt)	\
   GET_NUCLEOTIDE_PAIR((Aaaa), (Bbbb), (Iiii));			\
   (Iiii) *= 6;							\
   GET_NUCLEOTIDE_PAIR((Cccc), (Dddd), (Tt));			\
   (Iiii) += (Tt);						\





#endif
