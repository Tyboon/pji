/*
Copyright or © or CCopr. INRIA : Arnaud FONTAINE

arnaud.fontaine@lifl.fr

This software is a computer program whose purpose is to predict 
significantly conserved protein coding sequences and/or RNA structure 
on a set of unaligned nucleic sequences.

This software is governed by the CeCILL  license under French law and
abiding by the rules of distribution of free software.  You can  use,
modify and/ or redistribute the software under the terms of the CeCILL
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info".

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability.

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or
data to be ensured and,  more generally, to use and operate it in the
same conditions as regards security.

The fact that you are presently reading this means that you have had
knowledge of the CeCILL license and that you accept its terms.
*/

#ifndef __ARNICA_BUFFER_H__
#define __ARNICA_BUFFER_H__


typedef struct {
   char *data;
   int size;
   int max_size;
} arnica_buffer_t;

typedef arnica_buffer_t* arnica_buffer;


#define NEW_BUFFER(Buf,MSiz) \
   NEW((Buf), arnica_buffer_t, 1);\
   (Buf)->size=0;\
   (Buf)->max_size=(MSiz);\
   NEW(((Buf)->data), char, (1 + (MSiz)));\
   (Buf)->data[(Buf)->max_size]='\0'

#define BUFFER_EMPTY(Buf) ((Buf)->size=0)

#define BUFFER_MAXSIZE(Buf) ((Buf)->max_size)
#define BUFFER_SIZE(Buf) ((Buf)->size)

#define BUFFER_IS_FULL(Buf) ((Buf)->size == (Buf)->max_size)
#define BUFFER_RESIZE(Buf,MSiz)	\
   RENEW((Buf)->data, char, (1 + (MSiz)));\
   (Buf)->max_size = (MSiz);\
   (Buf)->data[(Buf)->max_size]='\0'

#define BUFFER_PUT(Buf,Val) ((Buf)->data[((Buf)->size)++] = (Val))

#define BUFFER_PUT_ALL(Buf,Oth) \
   strncpy(&((Buf)->data[(Buf)->size]), (Oth)->data, (Oth)->size);\
   (Buf)->size += (Oth)->size

#define BUFFER_RELEASE(Buf) ((Buf)->data[(Buf)->size] = '\0')
#define BUFFER_TOSTRING(Buf) ((Buf)->data)

#define DESTROY_BUFFER(Buf) \
   DESTROY(((Buf)->data));\
   DESTROY((Buf))



#endif
