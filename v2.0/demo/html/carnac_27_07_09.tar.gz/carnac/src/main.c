#ifdef HAVE_CONFIG_H
    #include "config.h"
#endif
#include <getopt.h>

#ifdef HAVE_STDLIB_H
#include <stdlib.h>
#endif

#include <assert.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <limits.h>
#include <math.h>

#ifdef _OPENMP
#include <omp.h>
#endif

#include "input.h"
#include "display.h"
#include "output.h"
#include "boxes.h"
#include "format.h"
#include "opts.h"
#include "reduce.h"
#include "results.h"


void
usage() {
   INFO_ "This is %s (version %s", PACKAGE_NAME, PACKAGE_VERSION _INFO;

# ifdef _OPENMP
   INFO_ ", OpenMP-compliant" _INFO;
# endif 

   INFO_ ")\n" _INFO;

   INFO_ "\nUsage: %s [options] file\n", PACKAGE_NAME _INFO;
   INFO_ "\nOptions:\n" _INFO;
   INFO_"     -A        Disable threshold correction according to GC%%\n" _INFO;
   /* INFO_"     -F        Full Sankoff mode (default is hairpin mode)\n" _INFO; */
   INFO_"     -s int    Number of shuffles\n" _INFO;
   INFO_"     -i        Identity threshold (80-100)\n" _INFO;
   /* INFO_"    -c   %s box\n", CARNAC_ENERGY_BOX->name _INFO; */

   /* INFO_"         -D        Use shuffling of di-nucleotides (instead of mono-nucleotides)\n" _INFO; */
   INFO_"\nMiscellaneous options:\n" _INFO;
   INFO_"    -h         This help and exit\n" _INFO;
   INFO_"    -q         Quiet (no info messages)\n" _INFO;
   INFO_"    -r         Use existing pairwise alignment files\n" _INFO;
   INFO_"    -o dir     Puts generated and kept files in the directory 'dir'\n" _INFO;



/*    INFO_ "\nExternal programs paths:\n" _INFO; */
/* #ifndef MY_NEEDLE */
/*    INFO_ "    needle   = '%s'\n", NEEDLE_EXE _INFO; */
/* #endif */
/*    INFO_ "    clustalw = '%s'\n", CLUSTALW_EXE _INFO; */
/*    INFO_ "    tcoffee  = '%s'\n", TCOFFEE_EXE _INFO; */
/*    INFO_ "    shuffle  = '%s'\n", SHUFFLE_EXE _INFO; */
/*    /\* INFO_ "    carnac   = '%s'\n", CARNAC_EXE _INFO; *\/ */
/*    INFO_ "    dialign2  = '%s'\n", DIALIGN2_2_EXE _INFO; */
/*    /\*   INFO_ "    revtrans = '%s'\n", REVTRANS_EXE _INFO;*\/ */


   INFO_ "\nThis software is under CeCILL license (http://www.cecill.info/index.en.html)\n"_INFO;

   INFO_ "\nFor questions or bug reports, please contact %s\n", PACKAGE_BUGREPORT _INFO;
}






int
main(int argc, char** argv) {
   blackbox* boxes = NULL;
   sequence* seqs = NULL;
   sequence* seq_t = NULL;
   sequence stemp = NULL;
   sequence** prots = NULL;
   char *temp = NULL;
   long int tli;
   

   char c;

   int nb_boxes, nb_seqs, t, i, tt, nerror, translate_sequences = 0;



   FILE *tf /*, *sample_output = NULL*/;


   if(argc == 1) {
      usage();
      exit(-2); /**** ATTENTION ****/
   }

#ifdef _OPENMP
   omp_set_nested(0);
   /* controle l'ouverture du nombre de threads dans les r�gions imbriqu�es..... */
#endif

   init_opts();

   NEW(boxes, blackbox, argc);
   nb_boxes = 0;
   nerror = 0;

   OPTS_keep_files = 1;
   while((c = getopt(argc, argv, ":Ahi:o:rs:q")) != EOF) {
      switch(c) {
      case 'A':
	 OPTS_carnac_correct_thd = 0;
	 break;
	 /*      case 'a':
	 OPTS_multiple_alignment = 1;
	 break;*/
      /* case 'c': */
      /* 	 boxes[nb_boxes++] = CARNAC_ENERGY_BOX; */
      /* 	 break; */
      /* case 'C': */
      /* 	 boxes[nb_boxes++] = CARNAC_BOX; */
      /* 	 break; */
      case 'D':
	 OPTS_shuffling_sissiz = 1;
	 break;
      case 'F':
	 OPTS_hairpin_mode = 0;
	 break;
      case 'g':
	 boxes[nb_boxes++] = GC_PERCENTAGE_BOX;
	 break;
      case 'h':
	usage();
	exit(2); /**** ATTENTION ****/
	break;
      case 'i':
	CARNAC_SIM_THRESHOLD = atof(optarg);
	if(CARNAC_SIM_THRESHOLD < 80 || CARNAC_SIM_THRESHOLD > 100){
	  printf("Wrong idendity threshold value\n");
	  exit(2);
	}
	 /* boxes[nb_boxes++] = NEEDLE_IDENTITY_BOX; */
	 break;
      case 'k':
	 OPTS_keep_files = 1;
	 break;
      case 'l':
	 boxes[nb_boxes++] = LENGTH_BOX;
	 break;
      case 'o':
	 if(OPTS_output_dir == NULL) {
	    NEW(OPTS_output_dir, char, (strlen(optarg) + 2));
	    strcpy(OPTS_output_dir, optarg);
	    if(OPTS_output_dir[strlen(optarg) - 1] != '/') {
	       OPTS_output_dir[strlen(optarg)] = '/';
	    } else {
	       OPTS_output_dir[strlen(optarg)] = '\0';
	    }
	    OPTS_output_dir[strlen(optarg) + 1] = '\0';
	    
	    if(prepare_dir(OPTS_output_dir))
	       exit(1);
	 } else {
	    ERROR_ "output directory already defined !!\n" _ERROR;
	    exit(2);
	 }
	 break;
      case 'r':
	 if(OPTS_use_cache == 0) {
	    OPTS_use_cache = 1;
	 } else {
	    ERROR_ "option 'r' already set !!\n" _ERROR;
	    exit(1);
	 }
	 break;
      case 's':
	OPTS_nb_shuffles = atoi(optarg);
	 boxes[nb_boxes++] = CARNAC_ENERGY_BOX;
	 break;
      case 'S':
	 OPTS_carnac_sankoff_stems = 0;
	 break;
      case 'q':
	 OPTS_quiet = 1;
	 break;
      case 'x':
	 boxes[nb_boxes++] = DINUCLEOTIDE_PERCENTAGE_BOX;
	 break;
      case ':':
      default:
	 ERROR_ "invalid option '-%c', or missing files !\n", optopt _ERROR;
	 exit(3);
	 break;
      }
   }

   if(OPTS_nb_shuffles == 0) {
     boxes[nb_boxes++] = CARNAC_BOX;      
   }
   nb_seqs = 0;
   while(optind < argc) {
      
      if(read_sequences(argv[optind], &seq_t, &t)) {
	 ERROR_ "problem while reading %s\n", argv[optind] _ERROR;
	 exit(4);
      } else {
	 for(i = 0; i < t; i++) {
	    check_sequence(seq_t[i]);
	    
	    stemp = ungap(seq_t[i]);
	    DESTROY(seq_t[i]->name);
	    DESTROY(seq_t[i]->input_name);
	    DESTROY(seq_t[i]->file);
	    DESTROY(seq_t[i]->bases);
	    DESTROY(seq_t[i]);
	    
	    seq_t[i] = stemp;
	    
	    if(seq_t[i]->length == 0) {
	       ERROR_ "Empty sequence '%s'\n", seq_t[i]->input_name _ERROR;
	       exit(4);
	    }
	    
	    
	    stemp = traduct(seq_t[i]);
	    DESTROY(seq_t[i]->name);
	    DESTROY(seq_t[i]->input_name);
	    DESTROY(seq_t[i]->file);
	    DESTROY(seq_t[i]->bases);
	    DESTROY(seq_t[i]);
	    
	    seq_t[i] = stemp;
	    NEW(temp, char, (strlen(seq_t[i]->name) + 1 + 10));
	    sprintf(temp, "seq_%i_%s", (nb_seqs + i), seq_t[i]->name);
	    DESTROY(seq_t[i]->name);
	    seq_t[i]->name = temp;
	    
	 }
	 
	 if(nb_seqs) { RENEW(seqs, sequence, (t+nb_seqs)); }
	 else { NEW(seqs, sequence, t); }
	 
	 for(i = 0; i < t; i++) {
	    seqs[nb_seqs + i] = seq_t[i];
	 }
	 /*memcpy(&(seqs[nb_seqs]), seq_t, t*sizeof(sequence));*/
	 
	 nb_seqs += t;
	 DESTROY(seq_t);
      }
      
      optind++;
   }


   /* read stdin */
   if(nb_seqs == 0) {
      if(read_sequences(NULL, &seq_t, &t)) {
	 ERROR_ "problem while reading %s\n", argv[optind] _ERROR;
	 exit(4);
      } else {
	 for(i = 0; i < t; i++) {
	    check_sequence(seq_t[i]);
	    
	    stemp = ungap(seq_t[i]);
	    DESTROY(seq_t[i]->name);
	    DESTROY(seq_t[i]->input_name);
	    DESTROY(seq_t[i]->file);
	    DESTROY(seq_t[i]->bases);
	    DESTROY(seq_t[i]);
	    
	    seq_t[i] = stemp;
	    
	    if(seq_t[i]->length == 0) {
	       ERROR_ "Empty sequence '%s'\n", seq_t[i]->input_name _ERROR;
	       exit(4);
	    }
	    
	    
	    stemp = traduct(seq_t[i]);
	    DESTROY(seq_t[i]->name);
	    DESTROY(seq_t[i]->input_name);
	    DESTROY(seq_t[i]->file);
	    DESTROY(seq_t[i]->bases);
	    DESTROY(seq_t[i]);
	    
	    seq_t[i] = stemp;
	    NEW(temp, char, (strlen(seq_t[i]->name) + 1 + 10));
	    sprintf(temp, "seq_%i_%s", (nb_seqs + i), seq_t[i]->name);
	    DESTROY(seq_t[i]->name);
	    seq_t[i]->name = temp;
	    
	 }
	 
	 if(nb_seqs) { RENEW(seqs, sequence, (t+nb_seqs)); }
	 else { NEW(seqs, sequence, t); }
	 
	 for(i = 0; i < t; i++) {
	    seqs[nb_seqs + i] = seq_t[i];
	 }
	 /*memcpy(&(seqs[nb_seqs]), seq_t, t*sizeof(sequence));*/
	 
	 nb_seqs += t;
	 DESTROY(seq_t);
      }
   }


   if(nb_seqs == 0) {
      ERROR_ "Missing sequences...\n" _ERROR;
      exit(5);
   }


   if(nb_seqs < 2) {
      ERROR_ "Not enough sequences (< 2) !! Exiting...\n" _ERROR;
      exit(6);
   }






   /*   if(output_dir == NULL) output_dir = "./";*/
   if(OPTS_first_phase == 0) OPTS_first_phase = 1;
   if(OPTS_max_res == 0) {
      if(OPTS_first_phase < 0) {
#ifdef SYNC_STRAND
	 tli = 2 * quick_pow(3,nb_seqs);
#else
	 tli = quick_pow(6,nb_seqs);
#endif
      } else {
	 tli = 2 * quick_pow(3,nb_seqs);
      }
      OPTS_max_res = MIN(tli, INT_MAX);
   }
   if(OPTS_max_res < 0) {
      OPTS_max_res = 36;
      INFO_ "falling back to default value %i for max_result\n", OPTS_max_res _INFO;
   }
   if(nb_boxes == 0) {
      ERROR_ "no blackbox !! Exiting...\n" _ERROR;
      exit(4);
   }

   if(OPTS_nb_shuffles == 0) {
    
      INFO_ "falling back to default value %i for nb_shuffles\n", OPTS_nb_shuffles _INFO;
   } else if(OPTS_nb_shuffles < 0) {
      ERROR_ "Invalid number of shuffled sequences (%i) !! Exiting...\n", OPTS_nb_shuffles _ERROR;
      exit(4);
   }


   if(OPTS_min_aln_score == -INFINITY) {
      OPTS_min_aln_score = 1.0;
      INFO_ "falling back to default value %.2f for min_aln_score\n", OPTS_min_aln_score _INFO;
   }


   for(i = 0; i < nb_seqs; i++) {
      if(seqs[i]->file) {
	 DESTROY(seqs[i]->file);
      }
      
      temp = tmpnam(NULL);
      NEW(seqs[i]->file, char, (strlen(temp) + 1));
      strcpy(seqs[i]->file, temp);
      
      if((tf = fopen(seqs[i]->file, "w"))) {
	 write_fasta(tf, &(seqs[i]), 1, 0);
	 fflush(tf);
	 fclose(tf);
      } else {
	 ERROR_ "unable to open file '%s' for writing\n", seqs[i]->file _ERROR;
	 return 2;
      }
   }



   if(OPTS_output_dir) {
      NEW(temp, char, (strlen(OPTS_output_dir) + strlen(SEQUENCES_FILE) + 1));
      strcpy(temp, OPTS_output_dir);
      strcat(temp, SEQUENCES_FILE);
      if((tf = fopen(temp, "w"))) {
	 write_fasta(tf, seqs, nb_seqs, 0);
	 fflush(tf);
	 fclose(tf);
      } else {
	 ERROR_ "unable to open file '%s' for writing\n", temp _ERROR;
	 return 2;
      }
      DESTROY(temp);
   }

   if(translate_sequences) {
      prots = translate_and_write_sequences(seqs, nb_seqs);
   }


   for(t = 0; t < nb_boxes; t++) {
      if(boxes[t]->fun(seqs, nb_seqs, prots)) {
	 nerror++;
	 WARN_ "box '%s' exited abnormally\n", boxes[t]->name _WARN;
      }
   }



   for(i = 0; i < nb_seqs; i++) {
      if(translate_sequences) {
	 for(t = OPTS_first_phase; t < 4; t++) {
	    if(t != 0) {
	       tt = (t > 0) ? (t - 1) : (2 - t);
	       unlink(prots[i][tt]->file);
	       
	       DESTROY(prots[i][tt]->file);
	       DESTROY(prots[i][tt]->input_name);
	       DESTROY(prots[i][tt]->name);
	       DESTROY(prots[i][tt]->bases);
	       DESTROY(prots[i][tt]);
	    }
	 }

	 DESTROY(prots[i]);
      }

      unlink(seqs[i]->file);

      DESTROY(seqs[i]->file);
      DESTROY(seqs[i]->input_name);
      DESTROY(seqs[i]->name);
      DESTROY(seqs[i]->bases);
      DESTROY(seqs[i]);
   }

   DESTROY(seqs);

   if(translate_sequences) {
      DESTROY(prots);
   }

   if(OPTS_output_dir) {
      DESTROY(OPTS_output_dir);
   }


   destroy_results(nb_seqs);
   
   /*   main_aux(seqs, nb_seqs, boxes, nb_boxes);*/

   return nerror;
}
