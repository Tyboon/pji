#ifndef __ARNICA_CARNAC_H__
#define __ARNICA_CARNAC_H__

#include <stdio.h>
#include "sequence.h"


extern int
carnac(const sequence*, const int, FILE*, int **, int);

extern int
box_carnac(const sequence*, const int, sequence**);


#endif
