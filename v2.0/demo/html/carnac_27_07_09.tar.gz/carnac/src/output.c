#ifdef HAVE_CONFIG_H
    #include "config.h"
#endif
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <ctype.h>

#include "output.h"
#include "display.h"
#include "opts.h"
#include "fusion.h"
#include "buffer.h"





char *
get_amino_acid_class(char c) {
   switch(c) {
   case 'A':
      return "w";
   case 'C':
      return "l";
   case 'D':
      return "i";
   case 'E':
      return "m";
   case 'F':
      return "a";
   case 'G':
      return "y";
   case 'H':
      return "u";
   case 'I':
      return "q";
   case 'K':
      return "n";
   case 'L':
      return "d";
   case 'M':
      return "b";
   case 'N':
      return "o";
   case 'P':
      return "t";
   case 'Q':
      return "p";
   case 'R':
      return "f";
   case 'S':
      return "c";
   case 'T':
      return "e";
   case 'V':
      return "h";
   case 'W':
      return "j";
   case 'Y':
      return "g";
   case '*':
   case 'U':
      return "z";
   }
   return NULL;
}



int
write_color_clustal_protein(FILE* output, const sequence* seqs, const int nb) {
   int per_line = 60;
   int name_length = 20;
   int i, disp, j;
   int length;
   char **names = NULL;
   char *class = NULL;


   NEW(names, char*, nb);

   length = seqs[0]->length;

   for(i = 0; i < nb; i++) {
      if(seqs[i]->length != length) {
	 ERROR_ "unable to write clustal file since submitted sequences don't have the same length !!\n" _ERROR;
	 return 0;
      }

      NEW(names[i], char, (name_length + 7)); /* + 6 espaces + \0 */
      j = 0;
      disp = strlen(seqs[i]->input_name);
      while((j < name_length) && (j < disp) && (seqs[i]->input_name[j] != ' ')) {
	 names[i][j] = seqs[i]->input_name[j];
	 j++;
      }
      while(j < name_length) {
	 names[i][j++] = ' ';
      }
      disp = 0;
      for(disp = 0; disp < 6; disp++) {
	 names[i][j++] = ' ';
      }
      names[i][j] = '\0';
   }
   
   /*fprintf(output, "CLUSTAL multiple alignment produced by %s version %s\n\n", PACKAGE_NAME, PACKAGE_VERSION);*/

   disp = 0;

   
   while(disp < (length/per_line)) {
      for(i = 0; i < nb; i++) {
	 fprintf(output, "%s", names[i]);

	 for(j = 0; j < per_line; j++) {
	    class = get_amino_acid_class(seqs[i]->bases[disp * per_line + j]);
	    if(class) {
	       fprintf(output , "<span class=\"%s\">%c</span>", class, seqs[i]->bases[disp * per_line + j]);
	    } else {
	       fprintf(output , "%c", seqs[i]->bases[disp * per_line + j]);
	    }
	 }

	 fprintf(output, "\n");
      }

      fprintf(output, "\n");

      disp++;
   }
   disp *= per_line;


   if(disp < length) {
      for(i = 0; i < nb; i++) {
	 fprintf(output, "%s", names[i]);

	 for(j = disp; j < length; j++) {
	    class = get_amino_acid_class(seqs[i]->bases[j]);
	    if(class) {
	       fprintf(output , "<span class=\"%s\">%c</span>", class, seqs[i]->bases[j]);
	    } else {
	       fprintf(output , "%c", seqs[i]->bases[j]);
	    }
	 }

	 fprintf(output, "\n");
      }
      fprintf(output, "\n");
   }

   for(i = 0; i < nb; i++) {
      DESTROY(names[i]);
   }
   DESTROY(names);

   return 1;
}
















int
write_color_clustal_dna(FILE* output, const sequence* seqs, const int nb, const int start_at) {
   int per_line = 60;
   int name_length = 20;
   int i, pos, j;
   int length;
   char **names = NULL;
   char *class = NULL;
   char aa;
   

   NEW(names, char*, nb);

   length = seqs[0]->length;

   for(i = 0; i < nb; i++) {
      if(seqs[i]->length != length) {
	 ERROR_ "unable to write clustal file since submitted sequences don't have the same length !!\n" _ERROR;
	 return 0;
      }

      NEW(names[i], char, (name_length + 7)); /* + 6 espaces + \0 */
      j = 0;
      pos = strlen(seqs[i]->input_name);
      while((j < name_length) && (j < pos) && (seqs[i]->input_name[j] != ' ')) {
	 names[i][j] = seqs[i]->input_name[j];
	 j++;
      }
      while(j < name_length) {
	 names[i][j++] = ' ';
      }
      pos = 0;
      for(pos = 0; pos < 6; pos++) {
	 names[i][j++] = ' ';
      }
      names[i][j] = '\0';
   }
   
   /*fprintf(output, "CLUSTAL multiple alignment produced by %s version %s\n\n", PACKAGE_NAME, PACKAGE_VERSION);*/


   pos = 0;
   while(pos < length) {
      j = 0;
      for(i = 0; i < nb; i++) {
	 fprintf(output, "%s", names[i]);
	 
	 j = pos;
	 while(j < start_at || (length - j) < 3) {
	    fprintf(output, "%c", seqs[i]->bases[j]);
	    j++;
	 }

	 while( ((j+2) < length) && (((j+2) - (per_line*((pos+2)/per_line))) < per_line)) {
	    aa = translate_codon(seqs[i], j);
	    class = get_amino_acid_class(aa);
	    if(class) {
	       fprintf(output , "<span class=\"%s\">%c%c%c</span>", class, seqs[i]->bases[j], seqs[i]->bases[j + 1], seqs[i]->bases[j + 2]);
	    } else {
	       fprintf(output , "%c%c%c", seqs[i]->bases[j], seqs[i]->bases[j + 1], seqs[i]->bases[j + 2]);
	    }
	    j += 3; 
	 }

	 while((j < length) && (length - j) < 3) {
	    fprintf(output, "%c", seqs[i]->bases[j]);
	    j++;
	 }


	 fprintf(output, "\n");
      }

      pos = j;
      /*INFO_ "%i %i\n", pos, length _INFO;*/
      fprintf(output, "\n");

   }





   for(i = 0; i < nb; i++) {
      DESTROY(names[i]);
   }
   DESTROY(names);

   return 1;
}











int
write_clustal(FILE* output, const sequence* seqs, const int nb, const int input_names) {
   int per_line = 60;
   int name_length = 20;
   int i, disp, j;
   int length;
   char **names = NULL;
   arnica_buffer dispbuf = NULL;

   NEW(names, char*, nb);

   length = seqs[0]->length;

   for(i = 0; i < nb; i++) {
      if(seqs[i]->length != length) {
	 ERROR_ "unable to write clustal file since submitted sequences don't have the same length !!\n" _ERROR;
	 return 0;
      }

      NEW(names[i], char, (name_length + 7)); /* + 6 espaces + \0 */
      j = 0;
      if(input_names) {
	 disp = strlen(seqs[i]->input_name);
	 while((j < name_length) && (j < disp) && (seqs[i]->input_name[j] != ' ')) {
	    names[i][j] = seqs[i]->input_name[j];
	    j++;
	 }
      } else {
	 disp = strlen(seqs[i]->name);
	 while((j < name_length) && (j < disp) && (seqs[i]->name[j] != ' ')) {
	    names[i][j] = seqs[i]->name[j];
	    j++;
	 }
      }
      while(j < name_length) {
	 names[i][j++] = ' ';
      }
      disp = 0;
      for(disp = 0; disp < 6; disp++) {
	 names[i][j++] = ' ';
      }
      names[i][j] = '\0';
   }
   
   fprintf(output, "CLUSTAL multiple alignment produced by %s version %s\n\n", PACKAGE_NAME, PACKAGE_VERSION);

   disp = 0;

   NEW_BUFFER(dispbuf, (per_line + 1));
   
   while(disp < (length/per_line)) {
      for(i = 0; i < nb; i++) {
	 for(j = 0; j < per_line; j++) {
	    BUFFER_PUT(dispbuf, seqs[i]->bases[disp * per_line + j]);
	 }
	 BUFFER_RELEASE(dispbuf);
	 fprintf(output, "%s%s\n", names[i], BUFFER_TOSTRING(dispbuf));
	 BUFFER_EMPTY(dispbuf);
      }

      fprintf(output, "\n");

      disp++;
   }
   disp *= per_line;

   DESTROY_BUFFER(dispbuf);

   if(disp < length) {
      for(i = 0; i < nb; i++) {
	 fprintf(output, "%s%s\n", names[i], &(seqs[i]->bases[disp]));
      }
      fprintf(output, "\n");
   }

   for(i = 0; i < nb; i++) {
      DESTROY(names[i]);
   }
   DESTROY(names);

   return 1;
}

int
write_fasta(FILE* output, const sequence* seqs, const int nb, const int input_name) {
   int i;
   for(i= 0; i < nb; i++) {
      if(input_name) {
	 if(fprintf(output, ">%s\n", seqs[i]->input_name) < 0) return 1;
      } else {
	 if(fprintf(output, ">%s\n", seqs[i]->name) < 0) return 1;
      }
      if(write_raw(output, &(seqs[i]), 1)) return 2;
   }
   return 0;
}

int
write_raw(FILE* output, const sequence* seqs, const int nb) {
   int i = 0, j, k, l;
   char buf[81];

   while(i < nb) {
      j = 0;
      while(j < seqs[i]->length) {
	 k = seqs[i]->length - j;

	 if(k > 80) {
	    for(l = 0; l < 80; l++){
	       buf[l] = seqs[i]->bases[j + l];
	    }
	    buf[80] = '\0';
	    j += 80;
	 } else {
	    for(l = 0; l < k; l++){
	       buf[l] = seqs[i]->bases[j + l];
	    }
	    buf[k] = '\0';
	    j += k;
	 }

	 if(fprintf(output, "%s", buf) < 0) return 1;
      }
      if(fprintf(output, "\n") < 0) return 1;

      i++;
   }
   return 0;
}


int
write_resume_header(FILE* output) {
   /*   if(fprintf(output, "#BOX\tOPTS\tSEQ1\tFRAME1\tSEQ2\tFRAME2\tRESULT\n") < 0) return 1;*/
   return 0;
}

int
write_resume(FILE* output, const char* box_name, const sequence s1, const sequence s2, const double res) {
   if(fprintf(output, "'%s'\t'__MISSING_OPTIONS__'\t'%s'\t%i\t'%s'\t%i\t%.2e\n", box_name, s1->name, s1->strand, s2->name, s2->strand, res) < 0) return 1;
   return 0;
}






int
write_graph(FILE* output, double**** results, const int nb_seqs, const sequence* seqs) {
   int i, j, k, l;
   
   fprintf(output, "\\documentclass[landscape,10pt]{article}\n\n\\usepackage[latin1]{inputenc}\n\\newlength{\\marger}\\newlength{\\margeh}\\newlength{\\margeb}\\newlength{\\margegd}\n");
   fprintf(output, "\\setlength{\\marger}{0cm}\\setlength{\\margeh}{0cm}\\setlength{\\margeb}{0cm}\\setlength{\\margegd}{4cm}\\setlength{\\parindent}{1cm}\\setlength{\\voffset}{-1in}\\setlength{\\topmargin}{.333\\margeh}\\setlength{\\headheight}{.333\\margeh}\\setlength{\\headsep}{.333\\margeh}\\setlength{\\textheight}{\\paperheight}\n\n\n\\usepackage{supertabular}\n\n\\addtolength{\\textheight}{-2cm}");
   fprintf(output, "\\addtolength{\\textheight}{-\\margeh}\\addtolength{\\textheight}{-\\margeb}\\setlength{\\hoffset}{-1in}\\addtolength{\\hoffset}{\\margegd}\\setlength{\\oddsidemargin}{\\marger}\\setlength{\\evensidemargin}{0pt}\\setlength{\\textwidth}{\\paperwidth}\\addtolength{\\textwidth}{-2\\margegd}\\addtolength{\\textwidth}{-\\marger}\n\n\\begin{document}\n\\tt\n\\vspace*{\\fill}\n\\begin{center}\n");


   fprintf(output, "\\begin{tabular}{rl}\nId&Sequence name\\\\\n");
   for(i = 0; i < nb_seqs; i++)
      fprintf(output, "%2i&%s\\\\\n", i, seqs[i]->name);
   fprintf(output, "\\end{tabular}\n\n");

#ifdef SYNC_STRAND   
   fprintf(output, "\\begin{supertabular}{|r|ccc|ccc|ccc|}\n\\hline\n");
#else
   fprintf(output, "\\begin{supertabular}{|r|cccccc|cccccc|cccccc|}\n\\hline\n");
#endif

   for(i = 1; i <= 3; i++) {
      for(j = 1; j <= 3; j++) {
	 fprintf(output, "&%i/%i", i, j);
      }
#ifndef SYNC_STRAND
      for(j = -3; j <= -1; j++) {
	 fprintf(output, "&%i/%i", i, j);
      }
#endif
   }
   fprintf(output, "\\\\\n");
   if(OPTS_first_phase < 0) {
      for(i = -3; i <= -1; i++) {
	 for(j = -3; j <= -1; j++) {
	    fprintf(output, "&%i/%i", i, j);
	 }
#ifndef SYNC_STRAND
      for(j = 1; j <= 3; j++) {
	 fprintf(output, "&%i/%i", i, j);
      }
#endif
      }
      fprintf(output, "\\\\\n");
   }
   fprintf(output, "\\hline\n");
   
   
   for(i = 0; i < (nb_seqs - 1); i++) {
      for(j = i + 1; j < nb_seqs; j++) {
	 if(fprintf(output, "%2i/%2i", i, j) < 0) return 1;
	 
	 for(k = 0; k < 3; k++) {
	    for(l = 0; l < 3; l++) {
	       if(fprintf(output, "&%.1f", results[i][k][j - i - 1][l]) < 0) return 1;
	    }
#ifndef SYNC_STRAND
	    for(l = 5; l > 2; l--) {
	       if(fprintf(output, "&%.1f", results[i][k][j - i - 1][l]) < 0) return 1;
	    }
#endif
	 }
	 
	 if(OPTS_first_phase < 0) {
	    if(fprintf(output, "\\\\\n") < 0) return 1;
	    
	    for(k = 5; k > 2; k--) {
	       for(l = 5; l > 2; l--) {
		  if(fprintf(output, "&%.1f", results[i][k][j - i - 1][l]) < 0) return 1;
	       }
#ifndef SYNC_STRAND
	       for(l = 0; l < 3; l++) {
		  if(fprintf(output, "&%.1f", results[i][k][j - i - 1][l]) < 0) return 1;
	       }
#endif
	    }
	 }
	 
	 if(fprintf(output, "\\\\\n") < 0) return 1;
      }
      fprintf(output, "\\hline\n");
   }

   fprintf(output, "\\end{supertabular}\n\\end{center}\n\\vspace*{\\fill}\n\\end{document}\n");

   return 0;
}









int
write_metastems(FILE* output, metasequence *seqs, metastem_t_list *stems, int nb_meta) {
   int i, j, k, l;
   
   for(i = 0; i < nb_meta; i++) {
      fprintf(output, "Metasequence %2i : %3i stems\n\tSTART / STOP\tSTART / STOP\tENERGY\tSEQ / SEQ\n", (i+1), stems[i]->nb_metastems);
      
      for(j = 0; j < stems[i]->nb_metastems; j++) {
	 for(k = 0; k < stems[i]->metastems[j].nb_seqs; k++) {
	    fprintf(output, "\t%5i /%5i\t%5i /%5i\t%5i\t", stems[i]->metastems[j].seq_stems[k].begin_start, stems[i]->metastems[j].seq_stems[k].begin_stop, stems[i]->metastems[j].seq_stems[k].end_start, stems[i]->metastems[j].seq_stems[k].end_stop, stems[i]->metastems[j].seq_stems[k].energy);
	    
	    for(l = stems[i]->metastems[j].seq_stems[k].begin_start; l <= stems[i]->metastems[j].seq_stems[k].begin_stop; l++) {
	       fprintf(output, "%c", tolower(seqs[i]->seqs[k]->bases[l]));
	    }
	    fprintf(output, " / ");
	    for(l = stems[i]->metastems[j].seq_stems[k].end_start; l <= stems[i]->metastems[j].seq_stems[k].end_stop; l++) {
	       fprintf(output, "%c", tolower(seqs[i]->seqs[k]->bases[l]));
	    }

	    fprintf(output, "\n");
	 }	 

	 fprintf(output, "\n");
      }
   }

   return 0;
}


int
write_stems(FILE* output, sequence *seqs, stem_t_list_t *stems, int nb_seqs) {
   int i, j, k;
   
   for(i = 0; i < nb_seqs; i++) {
      fprintf(output, "Sequence %2i : %3i stems\n\tSTART / STOP\tSTART / STOP\tENERGY\tSEQ / SEQ\n", (i+1), stems[i].nb_stems);
      
      for(j = 0; j < stems[i].nb_stems; j++) {
	 fprintf(output, "\t%5i /%5i\t%5i /%5i\t%5i\t", stems[i].stems[j].begin_start, stems[i].stems[j].begin_stop, stems[i].stems[j].end_start, stems[i].stems[j].end_stop, stems[i].stems[j].energy);
	 
	 for(k = stems[i].stems[j].begin_start; k <= stems[i].stems[j].begin_stop; k++) {
	    fprintf(output, "%c", tolower(seqs[i]->bases[k]));
	 }
	 fprintf(output, " / ");
	 for(k = stems[i].stems[j].end_start; k <= stems[i].stems[j].end_stop; k++) {
	    fprintf(output, "%c", tolower(seqs[i]->bases[k]));
	 }
	 
	 fprintf(output, "\n");
      }
   }

   return 0;
}
