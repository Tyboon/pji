#ifdef HAVE_CONFIG_H
    #include "config.h"
#endif
/*
Copyright or © or CCopr. INRIA : Arnaud FONTAINE

arnaud.fontaine@lifl.fr

This software is a computer program whose purpose is to predict 
significantly conserved protein coding sequences and/or RNA structure 
on a set of unaligned nucleic sequences.

This software is governed by the CeCILL  license under French law and
abiding by the rules of distribution of free software.  You can  use,
modify and/ or redistribute the software under the terms of the CeCILL
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info".

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability.

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or
data to be ensured and,  more generally, to use and operate it in the
same conditions as regards security.

The fact that you are presently reading this means that you have had
knowledge of the CeCILL license and that you accept its terms.
*/

#ifdef MY_NEEDLE


#include <ctype.h>
#include <unistd.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <math.h>

#include "needle_common.h"
#include "opts.h"
#include "display.h"
#include "boxes.h"
#include "input.h"
#include "output.h"
#include "my_needle_matrices.h"




int
call_needle(const sequence si, const sequence sj, float* res) {
   int i, j, mi, mj;
   float n1, n2, n3;
   float **prog_dyn_mm = NULL;
   float **prog_dyn_ins = NULL;
   float **prog_dyn_del = NULL;
   int **prog_dyn_mm_id = NULL;
   int **prog_dyn_ins_id = NULL;
   int **prog_dyn_del_id = NULL;
   int **prog_dyn_mm_length = NULL;
   int **prog_dyn_ins_length = NULL;
   int **prog_dyn_del_length = NULL;
   float *swaln = NULL;
   int *swalni = NULL;
   int state;
   float temp;

   /*   blosum_dna_matrix subsmatrix;*/
   blosum_iupac_matrix subsmatrix;
   
   float gapopen, gapextend;
   char *output = NULL;
   FILE *fd = NULL;
   int max_id = 0;
   int max_length = 0;
   int maxi, maxj;
   
#ifndef GLOBAL_NEEDLE
   float max = -INFINITY;
   
   maxi = si->length;
   maxj = sj->length;
#endif



   if(init_needle()) return -1;

   i = 0;
   if((OPTS_output_dir != NULL) && (OPTS_keep_files != 0)) {
      NEW(output, char, (1 + strlen(OPTS_output_dir) + strlen(NEEDLE_IDENTITY_BOX->dir) + 1 + strlen(si->name) + strlen(SEQUENCE_SEP) + strlen(sj->name)));
      
      sprintf(output, "%s%s/%s%s%s", OPTS_output_dir, NEEDLE_IDENTITY_BOX->dir, si->name, SEQUENCE_SEP,  sj->name);

      if(OPTS_use_cache) {
	 if((fd = fopen(output, "r")) != NULL) {

	    fclose(fd);
	    state = needle_identity_result(output, res);
	    DESTROY(output);
	    
	    i = 1;
	 }
      } else {
	 INFO_ "." _INFO;
      }
   }

   if(i == 0) {
      gapopen = 10.0;
      gapextend = 0.5;

      /* initialisation */
      NEW(prog_dyn_mm, float*, 2);
      NEW(prog_dyn_del, float*, 2);
      NEW(prog_dyn_ins, float*, 2);
      NEW(prog_dyn_mm_id, int*, 2);
      NEW(prog_dyn_del_id, int*, 2);
      NEW(prog_dyn_ins_id, int*, 2);
      NEW(prog_dyn_mm_length, int*, 2);
      NEW(prog_dyn_del_length, int*, 2);
      NEW(prog_dyn_ins_length, int*, 2);

      for(j = 0; j < 2; j++) {
	 NEW(prog_dyn_mm[j], float, (sj->length + 1));
	 NEW(prog_dyn_del[j], float, (sj->length + 1));
	 NEW(prog_dyn_ins[j], float, (sj->length + 1));
	 NEW(prog_dyn_mm_id[j], int, (sj->length + 1));
	 NEW(prog_dyn_del_id[j], int, (sj->length + 1));
	 NEW(prog_dyn_ins_id[j], int, (sj->length + 1));
	 NEW(prog_dyn_mm_length[j], int, (sj->length + 1));
	 NEW(prog_dyn_del_length[j], int, (sj->length + 1));
	 NEW(prog_dyn_ins_length[j], int, (sj->length + 1));
      }
      
      
      for(j = 0; j <= sj->length; j++) {
	 prog_dyn_mm[0][j] = -INFINITY;
#ifdef GLOBAL_NEEDLE
	 prog_dyn_ins[0][j] = - gapopen - (gapextend * j);
#else
	 prog_dyn_ins[0][j] = 0.0;
#endif
	 prog_dyn_del[0][j] = -INFINITY;

	 prog_dyn_mm_id[0][j] = prog_dyn_del_id[0][j] = prog_dyn_ins_id[0][j] = 0;
	 prog_dyn_del_length[0][j] =  prog_dyn_mm_length[0][j] = 0;

#ifdef GLOBAL_NEEDLE
	 prog_dyn_ins_length[0][j] = j + 1;
#else
	 prog_dyn_ins_length[0][j] = 0;
#endif
      }

      prog_dyn_mm[0][0] = 0.0;
      prog_dyn_ins[0][0] = prog_dyn_del[0][0] = -INFINITY;
   

      /*      subsmatrix = &dna_full;*/
      subsmatrix = &iupac_full;
   
      /* boucle */
   
      for(i=1; i <= si->length; i++) {
	 
	 prog_dyn_mm[1][0] = -INFINITY;
	 prog_dyn_ins[1][0] = -INFINITY;
#ifdef GLOBAL_NEEDLE
	 prog_dyn_del[1][0] = - gapopen - (gapextend * i);
#else
	 prog_dyn_del[1][0] = 0.0;
#endif
	 prog_dyn_mm_id[1][0] = prog_dyn_del_id[1][0] = prog_dyn_ins_id[1][0] = 0;

	 prog_dyn_mm_length[1][0] = prog_dyn_ins_length[1][0] = 0;
#ifdef GLOBAL_NEEDLE
	 prog_dyn_del_length[1][0] = i;
#else
	 prog_dyn_del_length[1][0] = 0;
#endif
	 
	 /*	 GET_NU_INDICE(si->bases[i-1], mi);*/
	 GET_IUPAC_INDICE(si->bases[i-1], mi);
	 if(mi == -1) {
	    ERROR_ "SEQUENCE '%s' contains invalid base at position %i!!!\n", si->name, i _ERROR;
	    return -1;
	 }
      
	 for(j=1; j <= sj->length; j++) {


	    /*	    GET_NU_INDICE(sj->bases[j-1], mj);*/
	    GET_IUPAC_INDICE(sj->bases[j-1], mj);
	    if(mj == -1) {
	       ERROR_ "SEQUENCE '%s' contains invalid base at position %i!!!\n", sj->name, j _ERROR;
	       return -1;
	    }

	    /* MAJ mm */
	    if(prog_dyn_mm[0][j-1] >= prog_dyn_ins[0][j-1]) {
	       temp = prog_dyn_mm[0][j-1];
	       prog_dyn_mm_id[1][j] = prog_dyn_mm_id[0][j-1] + ( (mi == mj) ? (1) : (0));
	       prog_dyn_mm_length[1][j] = prog_dyn_mm_length[0][j-1] + 1;
	    } else {
	       temp = prog_dyn_ins[0][j-1];
	       prog_dyn_mm_id[1][j] = prog_dyn_ins_id[0][j-1] + ( (mi == mj) ? (1) : (0));
	       prog_dyn_mm_length[1][j] = prog_dyn_ins_length[0][j-1] + 1;
	    }
	    
	    if(prog_dyn_del[0][j-1] > temp) {
	       temp = prog_dyn_del[0][j-1];
	       prog_dyn_mm_id[1][j] = prog_dyn_del_id[0][j-1] + ( (mi == mj) ? (1) : (0));
	       prog_dyn_mm_length[1][j] = prog_dyn_del_length[0][j-1] + 1;
	    }

	    prog_dyn_mm[1][j] = (*subsmatrix)[mi][mj] + temp;
	    /**/


	    /* MAJ ins */
	    n1 = - gapopen /*- gapextend*/ + prog_dyn_mm[1][j-1];
	    n2 = - gapextend + prog_dyn_ins[1][j-1];
	    n3 = - gapopen /*- gapextend*/ + prog_dyn_del[1][j-1];
	 
	    if(n1 >= n2) {
	       temp = n1;
	       prog_dyn_ins_id[1][j] = prog_dyn_mm_id[1][j-1];
	       prog_dyn_ins_length[1][j] = prog_dyn_mm_length[1][j-1] + 1;	       
	    } else {
	       temp = n2;
	       prog_dyn_ins_id[1][j] = prog_dyn_ins_id[1][j-1];
	       prog_dyn_ins_length[1][j] = prog_dyn_ins_length[1][j-1] + 1;
	    }

	    if(n3 > temp) {
	       temp = n3;
	       prog_dyn_ins_id[1][j] = prog_dyn_del_id[1][j-1];
	       prog_dyn_ins_length[1][j] = prog_dyn_del_length[1][j-1] + 1;	       
	    }
	    	 
	    prog_dyn_ins[1][j] = temp;
	    /**/



	    /* MAJ del */
	    n1 = - gapopen /*- gapextend*/ + prog_dyn_mm[0][j];
	    n2 = - gapopen /*- gapextend*/ + prog_dyn_ins[0][j];
	    n3 = - gapextend + prog_dyn_del[0][j];

	    
	    if(n1 >= n2) {
	       temp = n1;
	       prog_dyn_del_id[1][j] = prog_dyn_mm_id[0][j];
	       prog_dyn_del_length[1][j] = prog_dyn_mm_length[0][j] + 1;	       
	    } else {
	       temp = n2;
	       prog_dyn_del_id[1][j] = prog_dyn_ins_id[0][j-1];
	       prog_dyn_del_length[1][j] = prog_dyn_ins_length[0][j] + 1;
	    }

	    if(n3 > temp) {
 	       temp = n3;
	       prog_dyn_del_id[1][j] = prog_dyn_del_id[0][j];
	       prog_dyn_del_length[1][j] = prog_dyn_del_length[0][j] + 1;	       
	    }

	    prog_dyn_del[1][j] = temp;
	    /* */
	 }

#ifndef GLOBAL_NEEDLE
	 /*max = MAX2(max, prog_dyn_mm[i][sj->length]); */
	 if(max < prog_dyn_mm[1][sj->length]) {
	    max = prog_dyn_mm[1][sj->length];
	    maxi = i;
	    maxj = sj->length;
	    max_id = prog_dyn_mm_id[1][sj->length];
	    max_length = prog_dyn_mm_length[1][sj->length];
	 }
#endif


	 swaln = prog_dyn_mm[0];
	 prog_dyn_mm[0] = prog_dyn_mm[1];
	 prog_dyn_mm[1] = swaln;

	 swaln = prog_dyn_del[0];
	 prog_dyn_del[0] = prog_dyn_del[1];
	 prog_dyn_del[1] = swaln;

	 swaln = prog_dyn_ins[0];
	 prog_dyn_ins[0] = prog_dyn_ins[1];
	 prog_dyn_ins[1] = swaln;

	 swalni = prog_dyn_mm_id[0];
	 prog_dyn_mm_id[0] = prog_dyn_mm_id[1];
	 prog_dyn_mm_id[1] = swalni;

	 
	 swalni = prog_dyn_del_id[0];
	 prog_dyn_del_id[0] = prog_dyn_del_id[1];
	 prog_dyn_del_id[1] = swalni;

	 swalni = prog_dyn_ins_id[0];
	 prog_dyn_ins_id[0] = prog_dyn_ins_id[1];
	 prog_dyn_ins_id[1] = swalni;

	 swalni = prog_dyn_mm_length[0];
	 prog_dyn_mm_length[0] = prog_dyn_mm_length[1];
	 prog_dyn_mm_length[1] = swalni;

	 swalni = prog_dyn_del_length[0];
	 prog_dyn_del_length[0] = prog_dyn_del_length[1];
	 prog_dyn_del_length[1] = swalni;

	 swalni = prog_dyn_ins_length[0];
	 prog_dyn_ins_length[0] = prog_dyn_ins_length[1];
	 prog_dyn_ins_length[1] = swalni;
      }
   

      /* resultat */
   
#ifdef GLOBAL_NEEDLE
      if(prog_dyn_mm[0][sj->length] >= prog_dyn_ins[0][sj->length]) {
	 temp = prog_dyn_mm[0][sj->length];
	 max_id = prog_dyn_mm_id[0][sj->length];
	 max_length = prog_dyn_mm_length[0][sj->length];
      } else {
	 temp = prog_dyn_ins[0][sj->length];
	 max_id = prog_dyn_ins_id[0][sj->length];
	 max_length = prog_dyn_ins_length[0][sj->length];
      }
      if(prog_dyn_del[0][sj->length] > temp) {
	 temp = prog_dyn_del[0][sj->length];
	 max_id = prog_dyn_del_id[0][sj->length];
	 max_length = prog_dyn_del_length[0][sj->length];
      }

      (*res) = temp;

      maxi = i = si->length;
      maxj = j = sj->length;
#else


      /*    for(i = 1; i <= sj->length; i++) { */
      /*       max = MAX2(max, prog_dyn_mm[si->length][i]); */
      /*    } */
      for(j = 1; j <= sj->length; j++) {
	 if(max < prog_dyn_mm[0][j]) {
	    max = prog_dyn_mm[0][j];
	    maxi = si->length;
	    maxj = j;
	    max_id = prog_dyn_mm_id[0][j];
	    max_length = prog_dyn_mm_length[0][j];
	 }
      }


      (*res) = max;


      state = 0;
#endif






      /* nettoyage */
      for(j = 0; j < 2; j++) {
	 DESTROY(prog_dyn_mm[j]);
	 DESTROY(prog_dyn_ins[j]);
	 DESTROY(prog_dyn_del[j]);

	 DESTROY(prog_dyn_mm_id[j]);
	 DESTROY(prog_dyn_ins_id[j]);
	 DESTROY(prog_dyn_del_id[j]);

	 DESTROY(prog_dyn_mm_length[j]);
	 DESTROY(prog_dyn_ins_length[j]);
	 DESTROY(prog_dyn_del_length[j]);
      }

      DESTROY(prog_dyn_mm);
      DESTROY(prog_dyn_ins);
      DESTROY(prog_dyn_del);
	 
      DESTROY(prog_dyn_mm_id);
      DESTROY(prog_dyn_ins_id);
      DESTROY(prog_dyn_del_id);

      DESTROY(prog_dyn_mm_length);
      DESTROY(prog_dyn_ins_length);
      DESTROY(prog_dyn_del_length); 




      /* c'est l'identit� qu'il faut retourner */
      max_length += (sj->length - maxj) + (si->length - maxi);

      state = 0;
      if(output) {
	 if((fd = fopen(output, "w")) != NULL) {
	    fprintf(fd, "# Score:\t %.2f\n", (*res));
	    fprintf(fd, "# Identity:\t%i/%i (%.2f%%)\n\n", max_id, max_length, (100.0 * max_id) / (max_length + 0.0));
	    fflush(fd);
	    fclose(fd);
	 } else {
	    ERROR_ "unable to create file '%s'\n", output _ERROR;
	    state = -1;
	 }
	 
	 DESTROY(output);
      }
     

      (*res) = (100.0 * max_id ) / (0.0 + max_length);
     

   


   }

   return state;
}




#endif
