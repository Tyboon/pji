#ifdef HAVE_CONFIG_H
    #include "config.h"
#endif
#include <sys/types.h>
#include <sys/wait.h>
#include <ctype.h>
#include <regex.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <assert.h>


#include "alignment.h"
#include "output.h"
#include "opts.h"
#include "display.h"
#include "input.h"
#include "buffer.h"
/* #include "my_needlep_matrices.h" */
#include "stack.h"
#include "reverse_align.h"


int
align_clustalw(const char *input, const char *output) {
   char *str, *t, *rout, *dnd = NULL;
   int status;
   FILE *fd =  NULL;
   
   t = tmpnam(NULL);
   NEW(rout, char, (1 + strlen(t)));
   strcpy(rout, t);

   NEW(str, char, (1 + 78 + strlen(CLUSTALW_EXE) + strlen(input) + strlen(output) + strlen(rout)));
   sprintf(str, "%s -infile='%s' -batch -output=clustal -outorder=input -outfile='%s' > '%s'", CLUSTALW_EXE, input, output, rout);
   
   if((status = system(str)) == 0) {      
      NEW(dnd, char, (strlen(input) + 4)); /* +3 au cas ou... */
      strcpy(dnd, input);
      status = strlen(input) - 1;
      while((status >= 0) && (dnd[status] != '.'))
	 status--;
      
      if(status >= 0) {
	 strcpy(&(dnd[status]), ".dnd");
      } else {
	 strcpy(&(dnd[strlen(input)]), ".dnd");
      }

      status = 0;
   } else {
      ERROR_ "CLUSTALW output for '%s'\n", input _ERROR;
      if((fd = fopen(rout, "r"))) {
	 while((t = read_line(fd, &status))) {
	    ERROR_ "%s\n",t _ERROR;
	    DESTROY(t);
	 }
	 fclose(fd);
      }
      status = 1;
   }

   DESTROY(str);

   unlink(rout);
   if(dnd) {
      unlink(dnd);
   }
   
   return status;
}



int
align_tcoffee(const char *input, const char *output) {
   char *str, *t, *rout, *dnd = NULL;
   int status;

   t = tmpnam(NULL);
   NEW(rout, char, (1 + strlen(t)));
   strcpy(rout, t);

   NEW(str, char, (1 + 78 + strlen(TCOFFEE_EXE) + strlen(input) + strlen(output) + strlen(rout)));
   sprintf(str, "%s -infile='%s' -output=clustal -outorder=input -outfile='%s' > '%s' 2> /dev/null", TCOFFEE_EXE, input, output, rout);
   
   if((status = system(str)) == 0) {

      DESTROY(str);
   
      NEW(dnd, char, (strlen(input) + 4)); /* +3 au cas ou... */
      strcpy(dnd, input);
      status = strlen(input) - 1;
      while((status >= 0) && (dnd[status] != '.'))
	 status--;
   
      if(status >= 0) {
	 strcpy(&(dnd[status]), ".dnd");
      } else {
	 strcpy(&(dnd[strlen(input)]), ".dnd");
      }

      status = 0;
   }
   
   unlink(rout);
   if(dnd) {
      unlink(dnd);
   }
   
   return status;
}




int
align_dialign(const char *input, const char *output) {
   char *str, *aln_out = NULL;
   int status, nb;
   sequence *seqs = NULL;
   FILE *fd = NULL;

   NEW(str, char, (1 + 39 + strlen(DIALIGN2_2_EXE) + strlen(input) + strlen(output)));
   sprintf(str, "%s -fa -fn '%s' '%s' > /dev/null 2> /dev/null", DIALIGN2_2_EXE, output, input);
   
   if((status = system(str)) == 0) {

      DESTROY(str);
   
      unlink(output);
      NEW(aln_out, char, (1 + 4 + strlen(output)));
      strcpy(aln_out, output);
      strcat(aln_out, ".fa");


      /* reprendre le fasta et le remettre en format clustal... */

      if(read_sequences(aln_out, &seqs, &nb)) {
	 status = 1;
      } else {
	 if((fd = fopen(output, "w"))) {
	    write_clustal(fd, seqs, nb,1);
	    fclose(fd);
	 } else {
	    status = 2;
	 }
      }
      
      unlink(aln_out);
      DESTROY(aln_out);
   }
   
   return status;
}








sequence
purify(const sequence in, int *nbFS)
{
  unsigned int i,j;
  sequence res = NULL;
  
   /*   check_sequence(in);*/
  
  (*nbFS) = 0;

  res = new_sequence(in->file, in->input_name, in->name, "", 0, 0, in->strand);
  res->kind = in->kind;
  res->length = 0;
  res->nb_gaps = 0;
  
  if(in->length > 0) {
     
     RENEW(res->bases, char, (in->length + 1));
     
     j = 0;
     for(i=0; i < in->length; i++) {
	switch(in->bases[i]) {
	case '-':
	case '.':
	   break;
	case 'x':
	case 'X':
	   (*nbFS)++;
	   /*	   break;*/
	default:
	   res->bases[j++] = toupper(in->bases[i]);
	   break;
	}
     }
     res->length = j;
     
     if(res->length > 0) {
	RENEW(res->bases, char, (res->length + 1));
     }
     else {
	RENEW(res->bases, char, 1);
     }
     
     res->bases[res->length] = '\0';
  }
  
  return res;
}






int
reverse_translation(const sequence* dna, int nb_dna, const sequence* prots, char* prots_aligned_file, const char *output, const int *frames) {

   sequence* prots_aligned = NULL;
   sequence* seqs_aligned = NULL;
   sequence *stemp = NULL;

   int prots_length;
   int nb_prots;
   int i;
   int status;
   int* nbfs;
   sequence *rna = NULL;
#ifdef HTML_ALIGNMENT
   FILE *fd = NULL;
   char *temp = NULL;
#endif


   if(read_sequences(prots_aligned_file, &prots_aligned, &nb_prots)) {
      ERROR_ "problem while reading '%s'\n", prots_aligned_file _ERROR;
      return 1;
   }
      
   if(nb_prots != nb_dna) {
      ERROR_ "unable to reverse translate; invalid number of proteins aligned !\n" _ERROR;
      return 2;
   }
   
   prots_length = prots_aligned[0]->length;
   i= 1;
   while((i < nb_prots) && (prots_aligned[i]->length == prots_length)) i++;


   status = 0;

   if (i < nb_prots) {
      ERROR_ "invalid multiple alignemnt file; incorrect size of sequence %i\n", (i+1)  _ERROR;
      status++;
   }









   for(i = 0; i < nb_prots; i++) {
      DESTROY(prots_aligned[i]->input_name);
      NEW(prots_aligned[i]->input_name, char, (strlen(prots[i]->input_name) + 1));
      strcpy(prots_aligned[i]->input_name, prots[i]->input_name);
   }
   










#ifdef HTML_ALIGNMENT
   if(OPTS_html_alignment && OPTS_output_dir) {
      NEW(temp, char, (strlen(OPTS_output_dir) + 1 + strlen(PROTEIN_ALIGNMENT_HTML_FILE) + 1));
      strcpy(temp, OPTS_output_dir);
      strcat(temp, "/");
      strcat(temp, PROTEIN_ALIGNMENT_HTML_FILE);
      if((fd = fopen(temp, "w"))) {
	 write_color_clustal_protein(fd, prots_aligned, nb_prots);
	 fflush(fd);
	 fclose(fd);
      } else {
	 ERROR_ "unable to open '%s' for writing\n", temp _ERROR;
	 status = 1;
      }
      DESTROY(temp);
   }
#endif


   if(status == 0) {
      
      NEW(stemp, sequence, nb_prots);
      NEW(rna, sequence, nb_prots);
      NEW(nbfs, int, nb_prots);
      for(i = 0; i < nb_prots; i++) {
	 check_sequence(prots_aligned[i]);
	 stemp[i] = purify(prots[i], &nbfs[i]);

	 if(frames[i] >= 3) {
	    rna[i] = change_sequence_strand(dna[i], -1);
	 } else {
	    rna[i] = dna[i];
	 }
      }

      seqs_aligned = realign(prots_aligned, stemp, rna, nb_prots, nbfs, output);

      DESTROY(nbfs);
   }
   
   
   for(i = 0; i < nb_prots; i++) {
      if(prots_aligned[i]) {
	 DESTROY(prots_aligned[i]->file);
	 DESTROY(prots_aligned[i]->input_name);
	 DESTROY(prots_aligned[i]->name);
	 DESTROY(prots_aligned[i]->bases);
	 DESTROY(prots_aligned[i]);
      }

      if(frames[i] > 3) {
	 DESTROY(rna[i]->file);
	 DESTROY(rna[i]->input_name);
	 DESTROY(rna[i]->name);
	 DESTROY(rna[i]->bases);
	 DESTROY(rna[i]);
      }
   }
   DESTROY(prots_aligned);
   

   return status;
}









/* int */
/* compute_and_write_protein_alignment(const sequence* seqs, const int nb_seqs, const sequence* prots, const int nb_prots, const int *frames) { */
/*    char *protein_file = NULL, *protein_alignment_file = NULL, *rna_file = NULL, *rna_alignment_file = NULL, *t = NULL; */
/*    FILE* tf = NULL; */
/*    int status; */

/*    if(OPTS_output_dir) { */
/*       /\* stockage en fasta des prot�ines non align�es dans PROTEIN_FILE *\/ */
/*       NEW(protein_file, char, (strlen(OPTS_output_dir) + strlen(PROTEIN_FILE) + 1)); */
/*       strcpy(protein_file, OPTS_output_dir); */
/*       strcat(protein_file, PROTEIN_FILE); */
/*    } else { */
/*       t = tmpnam(NULL); */
/*       NEW(protein_file, char, (1 + strlen(t))); */
/*       strcpy(protein_file, t); */
/*    } */
      
      
/*    if((tf = fopen(protein_file, "w"))) { */
/*       write_fasta(tf, prots, nb_prots, 0); */
/*       fflush(tf); */
/*       fclose(tf); */
/*    } else { */
/*       ERROR_ "unable to open file '%s' for writing\n", protein_file _ERROR; */
/*       return 2; */
/*    } */




/*    if(OPTS_multiple_alignment == 0) { */
/*       DESTROY(protein_file); */
/*       return 0; */
/*    } */
      
/*    INFO_ "\tGenerating multiple alignment with best assignment " _INFO; */
      
/*    if(OPTS_clustalw_multiple_alignment) { */
/*       INFO_ "(ClustalW)..." _INFO; */
/*    } else { */
/*       if(OPTS_dialign_multiple_alignment) { */
/* 	 INFO_ "(Dialign2)..." _INFO; */
/*       } else { */
/* 	 INFO_ "(T-coffee)..." _INFO; */
/*       } */
/*    } */
      



/*    if(OPTS_output_dir) {       */
/*       /\* alignement des prot�ines dans PROTEIN_ALIGNMENT_FILE *\/ */
/*       NEW(protein_alignment_file, char, (strlen(OPTS_output_dir) + strlen(PROTEIN_ALIGNMENT_FILE) + 1)); */
/*       strcpy(protein_alignment_file, OPTS_output_dir); */
/*       strcat(protein_alignment_file, PROTEIN_ALIGNMENT_FILE); */
/*    } else { */
/*       INFO_ "\n" _INFO; */

/*       t = tmpnam(NULL); */
/*       NEW(protein_alignment_file, char, (1 + strlen(t))); */
/*       strcpy(protein_alignment_file, t); */
/*    } */
      


  
/*    status = 0; */
/*    if(OPTS_clustalw_multiple_alignment) { */
/*       if(align_clustalw(protein_file, protein_alignment_file)) { */
/* 	 ERROR_ "unable to align '%s' to '%s' with '%s'\n", protein_file, protein_alignment_file, CLUSTALW_EXE _ERROR; */
/* 	 status = 3; */
/*       } */
/*    } else { */
/*       if(OPTS_dialign_multiple_alignment) { */
/* 	 if(align_dialign(protein_file, protein_alignment_file)) { */
/* 	    ERROR_ "unable to align '%s' to '%s' with '%s'\n", protein_file, protein_alignment_file, DIALIGN2_2_EXE _ERROR; */
/* 	    status = 3; */
/* 	 } */
/*       }else { */
/* 	 if(align_tcoffee(protein_file, protein_alignment_file)) { */
/* 	    ERROR_ "unable to align '%s' to '%s' with '%s'\n", protein_file, protein_alignment_file, TCOFFEE_EXE _ERROR; */
/* 	    status = 3; */
/* 	 } */
/*       } */
/*    } */
      
      
/*    if((OPTS_keep_files == 0) || (OPTS_output_dir == NULL)) { */
/* /\*      unlink(protein_file);*\/ */

/*       if(status) { */
/* 	 unlink(protein_alignment_file); */
/*       } */
/*    } */

/*    if(status) return status; */


      
/*    DESTROY(protein_file); */
   
/*    if(OPTS_output_dir) { */
/*       NEW(rna_alignment_file, char, (strlen(OPTS_output_dir) + strlen(SEQUENCES_PROT_ALIGNMENT_FILE) + 1)); */
/*       strcpy(rna_alignment_file, OPTS_output_dir); */
/*       strcat(rna_alignment_file, SEQUENCES_PROT_ALIGNMENT_FILE); */
/*    } else { */
/*       rna_alignment_file = NULL; */
/*    } */
      
/*    if(reverse_translation(seqs, nb_seqs, prots, protein_alignment_file, rna_alignment_file, frames)) { */
/*       ERROR_ "unable to compute reverse translation of alignment '%s'\n", protein_alignment_file _ERROR; */
/*       status = 4; */
/*    } */
      
   
/*    if((OPTS_keep_files == 0) || (OPTS_output_dir == NULL)) { */
/*       unlink(protein_alignment_file); */
/*    } */

/*    if(status) return status; */

      
/*    DESTROY(rna_file); */
/*    if(rna_alignment_file) { */
/*       DESTROY(rna_alignment_file); */
/*    } */
/*    DESTROY(protein_alignment_file); */
      
/*    if(OPTS_output_dir) { */
/*       INFO_ "done\n" _INFO; */
/*    } */

/*    return 0; */
/* } */















#define INC_IF_GAP(Dd, Bo) \
   if(isalpha(Dd) == 0) {	   \
      (Bo)++;			   \
   } else {}

#define NB_GAPS(Aa,Bb,Cc,Bo) \
(Bo)=0;\
INC_IF_GAP((Aa),(Bo));\
INC_IF_GAP((Bb),(Bo));\
INC_IF_GAP((Cc),(Bo));\


alignment
init_alignment(const sequence* seqs, const int nb_seqs, const char* file) {
   int i;
   alignment res = NULL;

   if(nb_seqs > 0) {
      NEW(res, alignment_t, 1);
      NEW(res->seqs, sequence, nb_seqs);
      res->length = 0;
      res->nb_seqs = 0;


      if(seqs) {

	 i=1;
	 while((i < nb_seqs) && ((seqs[i-1]->length + seqs[i-1]->nb_gaps) == (seqs[i]->length+seqs[i]->nb_gaps))) {
	    i++;
	 }

	 if(i < nb_seqs) {
	    ERROR_ "unable to init alignment, invalid length of sequences\n" _ERROR;
	    return NULL;
	 }

	 res->nb_seqs = nb_seqs;
	 res->length = seqs[0]->length + seqs[0]->nb_gaps;
	 
	 memcpy(res->seqs, seqs, nb_seqs*sizeof(sequence));
      }

      if(file) {
	 NEW(res->file, char, (1+strlen(file)));
	 strcpy(res->file, file);
      }
   }

   return res;
}



alignment
translate_alignment(const alignment na, const int frame, sequence **dna_translated) {
   int i;
   int nbg;
   int j,l;
   alignment res = NULL;
   alignment ico_revc = NULL;
   

   res = init_alignment(NULL, na->nb_seqs, na->file);
   res->nb_seqs = na->nb_seqs;

   NEW((*dna_translated), sequence, na->nb_seqs);

   for(i = 0; i < na->nb_seqs; i++) {
      res->seqs[i] = init_sequence(na->seqs[i]->file, na->seqs[i]->input_name, na->seqs[i]->name, NULL, 0, frame);
      RENEW(res->seqs[i]->bases, char, 1+((na->length +3)/ 3));
      res->seqs[i]->kind = PROTEIN;
      res->seqs[i]->nb_gaps = 0;

      (*dna_translated)[i] = init_sequence(na->seqs[i]->file, na->seqs[i]->input_name, na->seqs[i]->name, NULL, 0, frame);
      RENEW((*dna_translated)[i]->bases, char, (1+na->length));
      (*dna_translated)[i]->kind = PROTEIN;
      (*dna_translated)[i]->nb_gaps = 0;
   }

   if(frame < 0) {
      ico_revc = init_alignment(NULL, na->nb_seqs, NULL);
      ico_revc->nb_seqs = na->nb_seqs; 
      ico_revc->length = na->length;
      for(i = 0; i < na->nb_seqs; i++) {
	 ico_revc->seqs[i] = change_sequence_strand(na->seqs[i], -1);
      }
   } else {
      ico_revc = na;
   }


   l = 0;
   for(i = 2 + ((frame > 0) ? (frame - 1) : (-frame - 1)); i < ico_revc->length; i = i + 3) {
      for(j = 0; j < ico_revc->nb_seqs; j++) {

	 NB_GAPS(ico_revc->seqs[j]->bases[i-2], ico_revc->seqs[j]->bases[i-1], ico_revc->seqs[j]->bases[i], nbg);

	 switch(nbg) {
	 case 0:
	    res->seqs[j]->bases[l] = translate_codon(ico_revc->seqs[j], (i-2));
	    (*dna_translated)[j]->bases[(l-res->seqs[j]->nb_gaps)*3] = ico_revc->seqs[j]->bases[i-2];
	    (*dna_translated)[j]->bases[(l-res->seqs[j]->nb_gaps)*3+1] = ico_revc->seqs[j]->bases[i-1];
	    (*dna_translated)[j]->bases[(l-res->seqs[j]->nb_gaps)*3+2] = ico_revc->seqs[j]->bases[i];
	    break;
	 case 3:
	    res->seqs[j]->bases[l] = '-';
	    res->seqs[j]->nb_gaps++;
	    break;
	 default:
	    res->seqs[j]->bases[l] = 'X';
	    if(isalpha(ico_revc->seqs[j]->bases[i-2])) {
	       (*dna_translated)[j]->bases[(l-res->seqs[j]->nb_gaps)*3] = ico_revc->seqs[j]->bases[i-2];
	    } else {
	       (*dna_translated)[j]->bases[(l-res->seqs[j]->nb_gaps)*3] = '-';
	    }
	    if(isalpha(ico_revc->seqs[j]->bases[i-1])) {
	       (*dna_translated)[j]->bases[(l-res->seqs[j]->nb_gaps)*3+1] = ico_revc->seqs[j]->bases[i-1];
	    } else {
	       (*dna_translated)[j]->bases[(l-res->seqs[j]->nb_gaps)*3+1] = '-';
	    }
	    if(isalpha(ico_revc->seqs[j]->bases[i])) {
	       (*dna_translated)[j]->bases[(l-res->seqs[j]->nb_gaps)*3+2] = ico_revc->seqs[j]->bases[i];
	    } else {
	       (*dna_translated)[j]->bases[(l-res->seqs[j]->nb_gaps)*3+2] = '-';
	    }
	    break;
	 }
      }

      l++;
   }

   if(frame < 0) {
      for(i = 0; i < ico_revc->nb_seqs; i++) {
	 DESTROY(ico_revc->seqs[i]->file);
	 DESTROY(ico_revc->seqs[i]->name);
	 DESTROY(ico_revc->seqs[i]->input_name);
	 DESTROY(ico_revc->seqs[i]->bases);
	 DESTROY(ico_revc->seqs[i]);
      }
      DESTROY(ico_revc);
   }

   res->length = l;
   for(j = 0; j < res->nb_seqs; j++) {
      res->seqs[j]->length = l;
      res->seqs[j]->bases[l] = '\0';
      (*dna_translated)[j]->length = (l-res->seqs[j]->nb_gaps)*3;
      (*dna_translated)[j]->bases[(l-res->seqs[j]->nb_gaps)*3] = '\0';
   }

   return res;
}




/* double */
/* compute_protein_alignment_score(const sequence s1, const sequence s2, const double identity) { */
/*    double res; */
/*    int i, mi, mj; */
/*    blosum_matrix subsmatrix; */

   
/*    if(s1->length != s2->length) { */
/*       ERROR_ "invalid alignment !\n" _ERROR; */
/*       return 1; */
/*    } */
   
/* #ifdef ADAPTIVE_BLOSUM */
/*    if(identity < 35.0) subsmatrix = &blosum30; */
/*    else if(identity < 40.0) subsmatrix = &blosum35; */
/*    else if(identity < 45.0) subsmatrix = &blosum40; */
/*    else if(identity < 50.0) subsmatrix = &blosum45; */
/*    else if(identity < 55.0) subsmatrix = &blosum50; */
/*    else if(identity < 60.0) subsmatrix = &blosum55; */
/*    else if(identity < 62.0) subsmatrix = &blosum60; */
/*    else if(identity < 65.0) subsmatrix = &blosum62; */
/*    else if(identity < 70.0) subsmatrix = &blosum65; */
/*    else if(identity < 75.0) subsmatrix = &blosum70; */
/*    else if(identity < 80.0) subsmatrix = &blosum75; */
/*    else if(identity < 85.0) subsmatrix = &blosum80; */
/*    else if(identity < 90.0) subsmatrix = &blosum85; */
/*    else subsmatrix = &blosum90; */
/* #else */
/*    subsmatrix = &blosum62; */
/* #endif */
   
/*    res = 0.0; */
/*    for(i = 0; i < s1->length; i++) { */

/*       GET_AA_INDICE(s1->bases[i], mi); */
/*       if(mi == -1) { */
/* 	 ERROR_ "SEQUENCE '%s' contains invalid base at position %i!!!\n", s1->name, (i+1) _ERROR; */
/* 	 return -1; */
/*       } */

/*       GET_AA_INDICE(s2->bases[i], mj); */
/*       if(mj == -1) { */
/* 	 ERROR_ "SEQUENCE '%s' contains invalid base at position %i!!!\n", s2->name, (i+1) _ERROR; */
/* 	 return -1; */
/*       } */

/*       res += (*subsmatrix)[mi][mj]; */
/*    } */

/*    return res; */
/* } */
