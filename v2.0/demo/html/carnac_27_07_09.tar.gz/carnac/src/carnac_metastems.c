#ifdef HAVE_CONFIG_H
    #include "config.h"
#endif
#include "carnac_metastems.h"
#include "opts.h"
#include "display.h"
#include "qsort.h"

#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <ctype.h>







#define ALL_SEQSTEMS_SATISFY(Ma,Fun)		\
   int m;					\
   for(m = 0; m < (Ma).nb_seqs; m++) {		\
      if(!(Fun())) {				\
	 return 0;				\
      }						\
   }						\
   return 1;


int
begin_start_gt(metastem_t m1, int value) {
#define _begin_start_gt() (m1.seq_stems[m].begin_start > value)
   ALL_SEQSTEMS_SATISFY(m1,_begin_start_gt);
}


int
begin_start_geq(metastem_t m1, int value) {
#define _begin_start_geq() (m1.seq_stems[m].begin_start >= value)
   ALL_SEQSTEMS_SATISFY(m1,_begin_start_geq);
}


int
begin_stop_lt(metastem_t m1, int value) {
#define _begin_stop_lt() (m1.seq_stems[m].begin_stop < value)
   ALL_SEQSTEMS_SATISFY(m1,_begin_stop_lt);
}

int
begin_stop_leq(metastem_t m1, int value) {
#define _begin_stop_leq() (m1.seq_stems[m].begin_stop <= value)
   ALL_SEQSTEMS_SATISFY(m1,_begin_stop_leq);
}


int
end_stop_lt(metastem_t m1, int value) {
#define _end_stop_lt() (m1.seq_stems[m].end_stop < value)
   ALL_SEQSTEMS_SATISFY(m1,_end_stop_lt);
}


int
end_stop_leq(metastem_t m1, int value) {
#define _end_stop_leq() (m1.seq_stems[m].end_stop <= value)
   ALL_SEQSTEMS_SATISFY(m1,_end_stop_leq);
}


int
end_start_gt(metastem_t m1, int value) {
#define _end_start_gt() (m1.seq_stems[m].end_start > value)
   ALL_SEQSTEMS_SATISFY(m1,_end_start_gt);
}

int
end_start_geq(metastem_t m1, int value) {
#define _end_start_geq() (m1.seq_stems[m].end_start >= value)
   ALL_SEQSTEMS_SATISFY(m1,_end_start_geq);
}






#define ALL_SEQSTEMS_PAIR_SATISFY(Ma,Mb,Fun)	\
   int m, n;					\
   for(m = 0; m < (Ma).nb_seqs; m++) {		\
      for(n = 0; n < (Mb).nb_seqs; n++) {	\
	 if(!(Fun())) {				\
	    return 0;				\
	 }					\
      }						\
   }						\
   return 1;




int
begin_start_leq_begin_stop(metastem_t m1, metastem_t m2, int right_float) {
#define _begin_start_leq_begin_stop() (m1.seq_stems[m].begin_start <= (m2.seq_stems[n].begin_stop + right_float))
   
   ALL_SEQSTEMS_PAIR_SATISFY(m1,m2,_begin_start_leq_begin_stop);
}

int
begin_start_leq_end_start(metastem_t m1, metastem_t m2, int right_float) {
#define _begin_start_leq_end_start() (m1.seq_stems[m].begin_start <= (m2.seq_stems[n].end_start + right_float))
   
   ALL_SEQSTEMS_PAIR_SATISFY(m1,m2,_begin_start_leq_end_start);
}

int
begin_stop_lt_end_start(metastem_t m1, metastem_t m2, int right_float) {
#define _begin_stop_lt_end_start() (m1.seq_stems[m].begin_stop < (m2.seq_stems[n].end_start + right_float))

   ALL_SEQSTEMS_PAIR_SATISFY(m1,m2,_begin_stop_lt_end_start);
}

int
end_stop_lt_end_start(metastem_t m1, metastem_t m2, int right_float) {
#define _end_stop_lt_end_start() (m1.seq_stems[m].end_stop < (m2.seq_stems[n].end_start + right_float))

   ALL_SEQSTEMS_PAIR_SATISFY(m1,m2,_end_stop_lt_end_start);
}


int
end_stop_geq_begin_start(metastem_t m1, metastem_t m2, int right_float) {
#define _end_stop_geq_begin_start() (m1.seq_stems[m].end_stop >= (m2.seq_stems[n].begin_start + right_float))

   ALL_SEQSTEMS_PAIR_SATISFY(m1,m2,_end_stop_geq_begin_start);
}

int
end_stop_geq_end_start(metastem_t m1, metastem_t m2, int right_float) {
#define _end_stop_geq_end_start() (m1.seq_stems[m].end_stop >= (m2.seq_stems[n].end_start + right_float))

   ALL_SEQSTEMS_PAIR_SATISFY(m1,m2,_end_stop_geq_end_start);
}



int
begin_start_leq_end_stop(metastem_t m1, metastem_t m2, int right_float) {
#define _begin_start_leq_end_stop() (m1.seq_stems[m].begin_start <= (m2.seq_stems[n].end_stop + right_float))
   
   ALL_SEQSTEMS_PAIR_SATISFY(m1,m2,_begin_start_leq_end_stop);
}

int
end_start_leq_begin_stop(metastem_t m1, metastem_t m2, int right_float) {
#define _end_start_leq_begin_stop() (m1.seq_stems[m].end_start <= (m2.seq_stems[n].begin_stop + right_float))
   
   ALL_SEQSTEMS_PAIR_SATISFY(m1,m2,_end_start_leq_begin_stop);
}

int
end_start_leq_end_stop(metastem_t m1, metastem_t m2, int right_float) {
#define _end_start_leq_end_stop() (m1.seq_stems[m].end_start <= (m2.seq_stems[n].end_stop + right_float))
   
   ALL_SEQSTEMS_PAIR_SATISFY(m1,m2,_end_start_leq_end_stop);
}

int
end_start_gt_begin_stop(metastem_t m1, metastem_t m2, int right_float) {
#define _end_start_gt_begin_stop() (m1.seq_stems[m].end_start > (m2.seq_stems[n].begin_stop + right_float))
   
   ALL_SEQSTEMS_PAIR_SATISFY(m1,m2,_end_start_gt_begin_stop);
}






int
have_a_common_base_pair_meta(metastem_t *s1, stem_t *s2) {
   int m;

   for(m = 0; m < s1->nb_seqs; m++) {
      if(!(have_a_common_base_pair(&(s1->seq_stems[m]), s2))) {
	 return 0;
      }
   }

   return 1;
}


int
overlapping_meta(metastem_t *s1, stem_t *s2) {
   int m;

   for(m = 0; m < s1->nb_seqs; m++) {
      if(!((1 + MIN(s1->seq_stems[m].begin_stop, s2->begin_stop) - MAX(s1->seq_stems[m].begin_start, s2->begin_start)) >= SIZE_HAIRPIN)) {
	 return 0;
      }
   }

   return 1;
}


metastem_t_list
overlapping_metastems(metasequence meta, metastem_t_list a, stem_t_list b) {
   int i, j, k;
   metastem_t_list res = NULL;
   int max_stems = 100;

   NEW(res, metastem_t_list_t, 1);
   NEW(res->metastems, metastem_t, max_stems);
   res->nb_metastems = 0;


   
   for(i = 0; i < a->nb_metastems; i++) {
      for(j = 0; j < b->nb_stems; j++) {
	 if(have_a_common_base_pair_meta(&(a->metastems[i]), &(b->stems[j]))
	    && overlapping_meta(&(a->metastems[i]), &(b->stems[j]))) {
	    if(res->nb_metastems == max_stems) {
	       max_stems += 100;
	       
	       RENEW(res->metastems, metastem_t, max_stems);
	    }

	    NEW(res->metastems[res->nb_metastems].seq_stems, stem_t, (a->metastems[i].nb_seqs + 1));
	    res->metastems[res->nb_metastems].nb_seqs = a->metastems[i].nb_seqs + 1;
	    
	    for(k = 0; k < a->metastems[i].nb_seqs; k++) {
	       res->metastems[res->nb_metastems].seq_stems[k] = a->metastems[i].seq_stems[k];
	    }
	    res->metastems[res->nb_metastems].seq_stems[a->metastems[i].nb_seqs] = b->stems[j];

	    res->nb_metastems++;
	 }
      }
   }
   
   return res;
}






int
can_pair_bases(const char a, const char b) {
   return is_canonical_pair(a,b) || (!isalpha(a) && !isalpha(b));
}

int
can_pair_columns(const metasequence m1, const int open, const int close) {
   int i;

   i = 0;
   while((i < m1->nb_seqs) && can_pair_bases(m1->seqs[i]->bases[open], m1->seqs[i]->bases[close])) {
      i++;
   }

   return !(i < m1->nb_seqs);
}






metastem_t_list
metastems_in_metasequence(metasequence meta) {
   stem_t_list *seq_stems = NULL;
   int i, j, k, l;
   sequence stemp = NULL;

   metastem_t_list comst = NULL;
   metastem_t_list agg = NULL;

   int counter[5];
   int *pos = NULL;
   int gcpercentage;

   int bstart, bstop, estop;


   NEW(seq_stems, stem_t_list, meta->nb_seqs);

   NEW(pos, int, meta->length);

   gcpercentage = 0;

   for(i = 0; i < meta->nb_seqs; i++) {

      stemp = ungap(meta->seqs[i]);

      seq_stems[i] = stems_in_seq(stemp);

      gcpercentage += gc_percentage(stemp) * 100.0;

      k = 0;
      for(j = 0; j < meta->length; j++) {
	 if(stemp->bases[k] == meta->seqs[i]->bases[j]) {
	    pos[k] = j;
	    k++;
	 }
      }


      for(j = 0; j < seq_stems[i]->nb_stems; j++) {
	 seq_stems[i]->stems[j].begin_start = pos[seq_stems[i]->stems[j].begin_start];
	 seq_stems[i]->stems[j].begin_stop = pos[seq_stems[i]->stems[j].begin_stop];
	 seq_stems[i]->stems[j].end_start = pos[seq_stems[i]->stems[j].end_start];
	 seq_stems[i]->stems[j].end_stop = pos[seq_stems[i]->stems[j].end_stop];
      }

      DESTROY(stemp->file);
      DESTROY(stemp->name);
      DESTROY(stemp->input_name);
      DESTROY(stemp->bases);
      DESTROY(stemp);
   }

   DESTROY(pos);


   gcpercentage /= meta->nb_seqs;


   /* recherche tiges chevauchantes */
   NEW(comst, metastem_t_list_t, 1);
   NEW(comst->metastems, metastem_t, seq_stems[0]->nb_stems);
   comst->nb_metastems = seq_stems[0]->nb_stems;

   for(i = 0; i < seq_stems[0]->nb_stems; i++) {
      NEW(comst->metastems[i].seq_stems, stem_t, 1);
      comst->metastems[i].nb_seqs = 1;
      comst->metastems[i].seq_stems[0] = seq_stems[0]->stems[i];
      comst->metastems[i].energy = seq_stems[0]->stems[i].energy;
   }
   
   DESTROY(seq_stems[0]->stems);
   
   for(i = 1; i < meta->nb_seqs; i++) {
      
      agg = overlapping_metastems(meta, comst, seq_stems[i]);
      
      DESTROY(seq_stems[i]->stems);

      for(j = 0; j < comst->nb_metastems; j++) {
	 if(comst->metastems[j].seq_stems) {
	    DESTROY(comst->metastems[j].seq_stems);
	 }
      }
      DESTROY(comst->metastems);
      DESTROY(comst);

      comst = agg;
      
      remove_common_metastems(comst);
   }

   DESTROY(seq_stems);




   for(i = 0; i < comst->nb_metastems; i++) {

      comst->metastems[i].energy = 0;

      bstart = comst->metastems[i].seq_stems[0].begin_start;
      estop = comst->metastems[i].seq_stems[0].end_stop;
      bstop = comst->metastems[i].seq_stems[0].begin_stop;
      
      for(j = 0; j < comst->metastems[i].nb_seqs; j++) {
	 comst->metastems[i].energy += comst->metastems[i].seq_stems[j].energy;

	 bstart = MIN(bstart, comst->metastems[i].seq_stems[j].begin_start);
	 estop = MAX(estop, comst->metastems[i].seq_stems[j].end_stop);
	 bstop = MAX(bstop, comst->metastems[i].seq_stems[j].begin_stop);
      }

      comst->metastems[i].energy /= comst->metastems[i].nb_seqs;

      /*INFO_ "BEFORE %5i", comst->stems[i].energy _INFO;*/

      /* covar bonus */
      l = 0;
      for(j = 0; j <= bstop - bstart; j++) {

	 if(can_pair_columns(meta, bstart + j, estop - j)) {
	    counter[0] = 0;
	    counter[1] = 0;
	    counter[2] = 0;
	    counter[3] = 0;
	    counter[4] = 0;
	    for(k = 0; k < meta->nb_seqs; k++) {
	       switch(meta->seqs[k]->bases[bstart + j]) {
	       case 'A':
		  counter[0]++;
		  break;
	       case 'C':
		  counter[1]++;
		  break;
	       case 'G':
		  counter[2]++;
		  break;
	       case 'U':
		  counter[3]++;
		  break;
	       default:
		  counter[4]++;
		  break;
	       }
	    }
	    for(k = 0; k < 5; k++) {
	       if(counter[k]) {
		  l++;
	       }
	       counter[k] = 0;
	    }
	    l--;

	    for(k = 0; k < meta->nb_seqs; k++) {
	       switch(meta->seqs[k]->bases[estop - j]) {
	       case 'A':
		  counter[0]++;
		  break;
	       case 'C':
		  counter[1]++;
		  break;
	       case 'G':
		  counter[2]++;
		  break;
	       case 'U':
		  counter[3]++;
		  break;
	       default:
		  counter[4]++;
		  break;
	       }
	    }
	    for(k = 0; k < 5; k++) {
	       if(counter[k]) {
		  l++;
	       }
	    }
	    l--;
	    
	 }
      }

      comst->metastems[i].energy += l * COVAR_BONUS;
      
      /*
      INFO_ "  AFTER %5i (l = %2i)\n", comst->metastems[i].energy, l _INFO;
      */

   }
   /****/

   /* TIGE FICTIVE POUR SANKOFF */
   if(comst->nb_metastems > 0) {
      RENEW(comst->metastems, metastem_t, (comst->nb_metastems+1));

      NEW(comst->metastems[comst->nb_metastems].seq_stems, stem_t, comst->metastems[0].nb_seqs);
      comst->metastems[comst->nb_metastems].nb_seqs = comst->metastems[0].nb_seqs;
      
      comst->metastems[i].energy = -1;

      for(i = 0; i < comst->metastems[0].nb_seqs; i++) {
	 comst->metastems[comst->nb_metastems].seq_stems[i].begin_start = -11;
	 comst->metastems[comst->nb_metastems].seq_stems[i].begin_stop = -10;
	 comst->metastems[comst->nb_metastems].seq_stems[i].end_start = meta->length + 10;
	 comst->metastems[comst->nb_metastems].seq_stems[i].end_stop = meta->length + 11;
	 comst->metastems[comst->nb_metastems].seq_stems[i].energy = -1;
      }

      comst->nb_metastems++;
   }
   /**/



   return comst;
}




void
adjust_meta(const metasequence_t m1, const metastem_t s1, const metasequence_t m2, const metastem_t s2, short_stack *values) {

   int i,j,s, l;
   int bstart1, bstart2, bstop1, bstop2, estart1, estart2, estop1, estop2, bstarts, bstartl, estops, estopl;
   int l1, longs, longl, l2;
   metastem_t ss, sl;
   metasequence_t short_seq, long_seq;
   int score, score_max;

   char *bases, *basel;


   
   bstart1 = s1.seq_stems[0].begin_start;
   bstop1 = s1.seq_stems[0].begin_stop;
   estart1 = s1.seq_stems[0].end_start;
   estop1 = s1.seq_stems[0].end_stop;
   
   for(i = 1; i < s1.nb_seqs; i++) {
      bstart1 = MIN(bstart1, s1.seq_stems[i].begin_start);
      bstop1 = MAX(bstop1, s1.seq_stems[i].begin_stop);
      estart1 = MIN(estart1, s1.seq_stems[i].end_start);
      estop1 = MAX(estop1, s1.seq_stems[i].end_stop);
   }
   l1 = 1 + (bstop1 - bstart1);
   
   bstart2 = s2.seq_stems[0].begin_start;
   bstop2 = s2.seq_stems[0].begin_stop;
   estart2 =s2.seq_stems[0].end_start;
   estop2 = s2.seq_stems[0].end_stop;
   
   for(j = 1; j < s2.nb_seqs; j++) {
      bstart2 = MIN(bstart2, s2.seq_stems[j].begin_start);
      bstop2 = MAX(bstop2, s2.seq_stems[j].begin_stop);
      estart2 = MIN(estart2, s2.seq_stems[j].end_start);
      estop2 = MAX(estop2, s2.seq_stems[j].end_stop);
   }
   l2 = 1 + (bstop2 - bstart2);
   

   if(l1 == l2) {
      NEW_SHORT_STACK((*values), 1);
      STACK_PUSH((*values), 0);
      return ;
   } else if(l1 < l2) {
      short_seq = m1;
      ss = s1;
      bstarts = bstart1;
      estops = estop1;
      longs = l1;
      long_seq = m2;
      sl = s2;
      longl = l2;
      bstartl = bstart2;
      estopl = estop2;


      NEW_SHORT_STACK((*values), (1+l2-l1));
   } else {
      short_seq = m2;
      ss = s2;
      bstarts = bstart2;
      estops = estop2;
      longs = l2;
      long_seq = m1;
      sl = s1;
      longl = l1;
      bstartl = bstart1;
      estopl = estop1;


      NEW_SHORT_STACK((*values), (1+l1-l2));
   }




   score_max = 0;

   for(s = 0; s <= (longl-longs); s++) {
      
      score = 0;

      for(j = 0; j < short_seq.nb_seqs; j++) {
	 bases = short_seq.seqs[j]->bases;
	 for(l = 0; l < long_seq.nb_seqs; l++) {
	    basel = long_seq.seqs[l]->bases;
	    for(i = 0; i < longs; i++) {
	       
	       if(bases[bstarts + i] == basel[bstartl + i + s]) {
		  score++;
	       }

	       if(bases[estops - i] == basel[estopl - i - s]) {
		  score++;
	       }
	    }
	 }
      }

      if(score > score_max) {
	 score_max = score;
	 STACK_EMPTY((*values));
	 STACK_PUSH((*values), s);
      } else if(score == score_max) {
	 STACK_PUSH((*values), s);
      }
   }


   if(l1 < l2) {
      for(i = 0; i < STACK_SIZE((*values)); i++) {
	 STACK_VALUE_AT((*values), i) = - STACK_VALUE_AT((*values), i);
      }
   }
}





int
do_covar_meta(const metasequence_t *m1, const metastem_t *ss, const metasequence_t *m2, const metastem_t *sa, const int shift, const int id) {
   
   
   
   int i;
   int r,rr;
   int count, dobreak;

   int m, n;

   int length;
   const int sh1 = MAX(shift,0);
   const int sh2 = MAX(-shift,0);
   

   count = 0;

   for(m = 0; m < ss->nb_seqs; m++) {
      for(n = 0; n < sa->nb_seqs; n++) {

	 length = 1 + MIN((ss->seq_stems[m].begin_stop - ss->seq_stems[m].begin_start), (sa->seq_stems[n].begin_stop - sa->seq_stems[n].begin_start));
	 
	 rr = 0;
	 i = 0;
	 dobreak = 0;

	 while((i < length) && !dobreak) {
	    r = covariate(m1->seqs[m]->bases[ss->seq_stems[m].begin_start + i + sh1],
			  m1->seqs[m]->bases[ss->seq_stems[m].end_stop - i - sh1],
			  m2->seqs[n]->bases[sa->seq_stems[n].begin_start + i + sh2],
			  m2->seqs[n]->bases[sa->seq_stems[n].end_stop - i - sh2]);

	    rr += r;
	    
	    if(r == 2) { count++; dobreak = 1; } /* there is a full covar */
	    else if((id >= CARNAC_COVAR_ID_THRESHOLD) && (rr > 0)) { count++; dobreak = 1; } /* there is a full or two half covar on close sequences */

	    i++;
	 }

	 if(!dobreak) { return 0; }
      }
   }

   return (count >= (ss->nb_seqs * sa->nb_seqs)/2.0);
}






int
conserved_non_canonical_meta(const metasequence_t *m1, const metastem_t *ss, const metasequence_t *m2, const metastem_t *sa, const int shift) {
   
   
   
   int i;
   int count, dobreak;

   int m, n;

   int length;
   const int sh1 = MAX(shift,0);
   const int sh2 = MAX(-shift,0);
   

   count = 0;

   for(m = 0; m < ss->nb_seqs; m++) {
      for(n = 0; n < sa->nb_seqs; n++) {

	 length = 1 + MIN((ss->seq_stems[m].begin_stop - ss->seq_stems[m].begin_start), (sa->seq_stems[n].begin_stop - sa->seq_stems[n].begin_start));
	 
	 i = 0;
	 dobreak = 0;

	 while((i < length) && !dobreak) {
	    if(conserved_non_canonical(m1->seqs[m]->bases[ss->seq_stems[m].begin_start + i + sh1],
				       m1->seqs[m]->bases[ss->seq_stems[m].end_stop - i - sh1],
				       m2->seqs[n]->bases[sa->seq_stems[n].begin_start + i + sh2],
				       m2->seqs[n]->bases[sa->seq_stems[n].end_stop - i - sh2])) {
	       count++;
	       dobreak = 1;
	    }
	    i++;
	 }

	 if(!dobreak) { return 0; }
      }
   }

   return (count >= (ss->nb_seqs * sa->nb_seqs)/2.0);
}






int
compare_metastem_id_begin_then_length(void *s, const void *a1, const void *a2) {
   metastem_t *m1 = &(((metastem_t_list)s)->metastems[*((int*)a1)]);
   metastem_t *m2 = &(((metastem_t_list)s)->metastems[*((int*)a2)]);

   int m;

   int r = 0;

   int mina1, mina2, maxb1, maxb2;

   mina1 = m1->seq_stems[0].begin_start;
   maxb1 = m1->seq_stems[0].begin_stop;

   for(m = 1; m < m1->nb_seqs; m++) {
      if(m1->seq_stems[m].begin_start < mina1) {
	 mina1 = m1->seq_stems[m].begin_start;
      }

      if(m1->seq_stems[m].begin_stop > maxb1) {
	 maxb1 = m1->seq_stems[m].begin_stop;
      }
   }


  
   mina2 = m2->seq_stems[0].begin_start;
   maxb2 = m2->seq_stems[0].begin_stop;

   for(m = 1; m < m2->nb_seqs; m++) {
      if(m2->seq_stems[m].begin_start < mina2) {
	 mina2 = m2->seq_stems[m].begin_start;
      }

      if(m2->seq_stems[m].begin_stop > maxb2) {
	 maxb2 = m2->seq_stems[m].begin_stop;
      }
   }

   r = mina1 - mina2;
   if(r == 0) {
      r = maxb1 - maxb2;

      if(r == 0) {
	 r = compare_metastem_id_end_closure_then_length(s,a1,a2);
      }
   }

   return r;
}


void
sort_metastems_id_by_begin_then_length(metastem_list *l, metastem_t_list s){
   my_qsort_r(l->metastem_id, l->nb_metastems, sizeof(int), s, compare_metastem_id_begin_then_length);
}


int
compare_metastem_id_end_closure_then_length(void *s, const void *a1, const void *a2) {
   metastem_t *m1 = &(((metastem_t_list)s)->metastems[*((int*)a1)]);
   metastem_t *m2 = &(((metastem_t_list)s)->metastems[*((int*)a2)]);

   int m;

   int r = 0;

   int mina1, mina2, maxb1, maxb2;

   mina1 = m1->seq_stems[0].end_start;
   maxb1 = m1->seq_stems[0].end_stop;

   for(m = 1; m < m1->nb_seqs; m++) {
      if(m1->seq_stems[m].end_start < mina1) {
	 mina1 = m1->seq_stems[m].end_start;
      }

      if(m1->seq_stems[m].end_stop > maxb1) {
	 maxb1 = m1->seq_stems[m].end_stop;
      }
   }


  
   mina2 = m2->seq_stems[0].end_start;
   maxb2 = m2->seq_stems[0].end_stop;

   for(m = 2; m < m2->nb_seqs; m++) {
      if(m2->seq_stems[m].end_start < mina2) {
	 mina2 = m2->seq_stems[m].end_start;
      }

      if(m2->seq_stems[m].end_stop > maxb2) {
	 maxb2 = m2->seq_stems[m].end_stop;
      }
   }

   /* begin croissant */
   /*   r = mina1 - mina2;
   if(r == 0) {
      r = maxb1 - maxb2;
      }*/

   /* end decroissant */
   r = maxb1 - maxb2;
   if(r == 0) {
      r = mina1 - mina2;
      if(r == 0) {

	 //
	 mina2 = m1->seq_stems[0].begin_start;
	 maxb2 = m1->seq_stems[0].begin_stop;
	 
	 for(m = 1; m < m1->nb_seqs; m++) {
	    if(m1->seq_stems[m].begin_start < mina1) {
	       mina1 = m1->seq_stems[m].begin_start;
	    }
	    
	    if(m1->seq_stems[m].begin_stop > maxb1) {
	       maxb1 = m1->seq_stems[m].begin_stop;
	    }
	 }
	 
	 
	 
	 mina1 = m2->seq_stems[0].begin_start;
	 maxb1 = m2->seq_stems[0].begin_stop;
	 
	 for(m = 1; m < m2->nb_seqs; m++) {
	    if(m2->seq_stems[m].begin_start < mina2) {
	       mina2 = m2->seq_stems[m].begin_start;
	    }
	    
	    if(m2->seq_stems[m].begin_stop > maxb2) {
	       maxb2 = m2->seq_stems[m].begin_stop;
	    }
	 }
	 
	 r = mina1 - mina2;
	 if(r == 0) {
	    r = maxb1 - maxb2;
	    
	 }
      }
   }



   return r;
}



void
sort_metastems_id_by_end_closure_then_length(metastem_list *l, metastem_t_list s) {
   my_qsort_r(l->metastem_id, l->nb_metastems, sizeof(int), s, compare_metastem_id_end_closure_then_length);
}







int
compare_metastem_begin_then_end(const void *a1, const void *a2) {
   metastem_t *m1 = (metastem_t*)a1;
   metastem_t *m2 = (metastem_t*)a2;


   int m;

   int r = 0;

   int mina1, mina2, maxb1, maxb2, maxc1, maxc2;

   mina1 = m1->seq_stems[0].begin_start;
   maxb1 = maxc1 = -1;

   for(m = 0; m < m1->nb_seqs; m++) {
      if(m1->seq_stems[m].end_start < mina1) {
	 mina1 = m1->seq_stems[m].begin_start;
      }

      if(m1->seq_stems[m].end_stop > maxb1) {
	 maxb1 = m1->seq_stems[m].end_stop;
      }

      if(m1->seq_stems[m].end_stop > maxc1) {
	 maxc1 = m1->seq_stems[m].begin_stop;
      }
   }


   mina2 = m2->seq_stems[0].begin_start;
   maxb2 = maxc2 = -1;

   for(m = 0; m < m2->nb_seqs; m++) {
      if(m2->seq_stems[m].end_start < mina2) {
	 mina2 = m2->seq_stems[m].begin_start;
      }

      if(m2->seq_stems[m].end_stop > maxb2) {
	 maxb2 = m2->seq_stems[m].end_stop;
      }

      if(m2->seq_stems[m].end_stop > maxc2) {
	 maxc2 = m2->seq_stems[m].begin_stop;
      }
   }


   r = mina1 - mina2;
   if(r == 0) {
      r = maxb1 - maxb2;
      if(r == 0) {
	 r = maxc1 - maxc2;
      }
   }

   return r;
}


void
sort_metastems_by_begin_then_end(metastem_t_list l) {
   qsort(l->metastems, l->nb_metastems, sizeof(metastem_t), compare_metastem_begin_then_end);
}


void
print_metastem(metastem_t *stem, metasequence s) {
   int i;

   for(i = 0; i < stem->nb_seqs; i++) {
      INFO_ "{seq %2i ", i _INFO;
      print_seq_stem(&(stem->seq_stems[i]), NULL);
      INFO_ "}" _INFO;
   }

   INFO_ " %5i", stem->energy _INFO;
}

void
println_metastem(metastem_t *stem, metasequence s) {
   print_metastem(stem, s);
   INFO_ "\n" _INFO;
}






int
common_metastems(metastem_t *m1, metastem_t *m2) {
   int m;

   if(m1->nb_seqs != m2->nb_seqs) {
      return 0;
   }

   for(m = 0; m < m1->nb_seqs; m++) {
      if(!(
	   ((m1->seq_stems[m].begin_start == m2->seq_stems[m].begin_start)
	    && (m1->seq_stems[m].end_stop == m2->seq_stems[m].end_stop))
	   || ((m1->seq_stems[m].begin_stop == m2->seq_stems[m].begin_stop)
	       && (m1->seq_stems[m].end_start == m2->seq_stems[m].end_start))
	   )) {
	 return 0;
      }
   }

   return 1;
}


void
remove_common_metastems(metastem_t_list comst) {


   int j, k;
   int max_stems;
   /* suppression des copies */
   j = 1;
   
   sort_metastems_by_begin_then_end(comst);
   
   max_stems = comst->nb_metastems;
   
   while(j < comst->nb_metastems) { 
      if(common_metastems(&(comst->metastems[j]), &(comst->metastems[j-1]))) {
	 if(comst->metastems[j].energy <= comst->metastems[j-1].energy) {
	    if(comst->metastems[j-1].seq_stems) {
	       DESTROY(comst->metastems[j-1].seq_stems);
	    }
	    for(k = j; k < comst->nb_metastems; k++) {
	       comst->metastems[k-1] = comst->metastems[k];
	    }
	 } else {
	    if(comst->metastems[j].seq_stems) {
	       DESTROY(comst->metastems[j].seq_stems);
	    }

	    for(k = j+1; k < comst->nb_metastems; k++) {
	       comst->metastems[k-1] = comst->metastems[k];
	    }
	 }
	 
	 comst->nb_metastems--;
      } else {
	 j++;
      }
   }
   
   if((comst->nb_metastems > 0) && (comst->nb_metastems < max_stems)) {
      RENEW(comst->metastems, metastem_t, comst->nb_metastems);
   }

}
