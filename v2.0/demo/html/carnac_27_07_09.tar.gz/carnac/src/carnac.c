#ifdef HAVE_CONFIG_H
    #include "config.h"
#endif

#include <stdlib.h>
#include <unistd.h>
#include <assert.h>
#include <string.h>
#include <ctype.h>
#include <libgen.h>

#include "carnac.h"
#include "carnac_blocks.h"
#include "carnac_stems.h"
#include "carnac_compatible.h"
#include "carnac_metaseq.h"
#include "carnac_energy.h"

#include "fusion.h"
#include "results.h"
#include "reduce.h"
#include "display.h"
#include "opts.h"
#include "output.h"
#include "input.h"
#include "alignment.h"
#include "carnac_sankoff.h"
#include "carnac_sankoff_bases.h"
#include "carnac_sankoff_stems.h"
#include "carnac_graph.h"
#include "carnac_metastems.h"














void
correct_stem_positions(stem_t_list_t *stems, sequence_set set, int seq) {
   
   int *pos = NULL;
   int i, j;

   NEW(pos, int , set->aln->length);
   j = 0;
   for(i = 0; i < set->aln->length; i++) {
      pos[i] = j;
      if(set->aln->seqs[seq]->bases[i] == set->seqs[seq]->bases[j]) {
	 j++;
      }
   }


   for(i = 0; i < stems->nb_stems; i++) {
      stems->stems[i].begin_start = pos[stems->stems[i].begin_start];
      stems->stems[i].begin_stop = pos[stems->stems[i].begin_stop];
      stems->stems[i].end_start = pos[stems->stems[i].end_start];
      stems->stems[i].end_stop = pos[stems->stems[i].end_stop];
   }


   
   DESTROY(pos);
}





void
shorten_overlapping_stems(stem_t_list_t *res) {
   int j, k;

   
   j = 0;
   while(j < res->nb_stems) {
      k = j+1;
      while(k < res->nb_stems) {
	 if(
	    (IS_BETWEEN(res->stems[j].begin_start, res->stems[j].begin_stop, res->stems[k].begin_start)
	     && IS_BETWEEN(res->stems[j].begin_start, res->stems[j].begin_stop, res->stems[k].begin_stop))
	    ||
	    (IS_BETWEEN(res->stems[j].end_start, res->stems[j].end_stop, res->stems[k].begin_start)
	     && IS_BETWEEN(res->stems[j].end_start, res->stems[j].end_stop, res->stems[k].begin_stop))
	    ||
	    (IS_BETWEEN(res->stems[j].begin_start, res->stems[j].begin_stop, res->stems[k].end_start)
	     && IS_BETWEEN(res->stems[j].begin_start, res->stems[j].begin_stop, res->stems[k].end_stop))
	    ||
	    (IS_BETWEEN(res->stems[j].end_start, res->stems[j].end_stop, res->stems[k].end_start)
	     && IS_BETWEEN(res->stems[j].end_start, res->stems[j].end_stop, res->stems[k].end_stop))
	    ) {
	    
	    res->stems[k] = res->stems[res->nb_stems - 1];
	    res->nb_stems--;
	 } else {

	    while(IS_BETWEEN(res->stems[j].begin_start, res->stems[j].begin_stop, res->stems[k].begin_start)
		  || IS_BETWEEN(res->stems[j].end_start, res->stems[j].end_stop, res->stems[k].begin_start)
		  || IS_BETWEEN(res->stems[j].end_start, res->stems[j].end_stop, res->stems[k].end_stop)
		  || IS_BETWEEN(res->stems[j].begin_start, res->stems[j].begin_stop, res->stems[k].end_stop)) {
	       res->stems[k].begin_start++;
	       res->stems[k].end_stop--;
	    }
	    
	    while(IS_BETWEEN(res->stems[j].begin_start, res->stems[j].begin_stop, res->stems[k].begin_stop)
		  || IS_BETWEEN(res->stems[j].end_start, res->stems[j].end_stop, res->stems[k].begin_stop)
		  || IS_BETWEEN(res->stems[j].end_start, res->stems[j].end_stop, res->stems[k].end_start)
		  || IS_BETWEEN(res->stems[j].begin_start, res->stems[j].begin_stop, res->stems[k].end_start)) {
	       res->stems[k].begin_stop--;
	       res->stems[k].end_start++;
	    }
	    
	    
	    if(OPTS_carnac_sankoff_stems && ((res->stems[k].begin_stop - res->stems[k].begin_start + 1) < SIZE_HAIRPIN)) {
	       res->stems[k] = res->stems[res->nb_stems - 1];
	       res->nb_stems--;
	    } else {
	    
	       k++;
	       
	    }
	       
	 }
      }

      
      if(OPTS_carnac_sankoff_stems && ((res->stems[j].begin_stop - res->stems[j].begin_start + 1) < SIZE_HAIRPIN)) {
	 res->stems[j] = res->stems[res->nb_stems - 1];
	 res->nb_stems--;
      } else {
      
	 j++;
	 
      }
	 
   }
}








int
carnac(const sequence* oseqs, const int onb_seqs, FILE* output_fd, int **energies, int create_files) {
   const sequence* seqs = NULL;
   int nb_seqs = 0;

#ifdef CARNAC_FUSION
   char* swi = NULL;
   char* swo = NULL;
   FILE* swfd = NULL;
   alignment tdna = NULL;
   sequence* tseqs = NULL;
   int tnb_seqs;
   int* equiv_class = NULL;
   int nb_class;
#else
   sequence_set cur_seq_set = NULL;
#endif

   fusion_set slinked, ssingle, sepsilon;
   metasequence *meta = NULL;

   metastem_t_list *stems = NULL;

   int i, j, k, l, m, nb_meta;

   sankoff_result sankoff_res = NULL;
   stem_graph graph = NULL;
   stem_t_list_t *final_stems = NULL;
   metastem_t_list_t *final_meta_stems = NULL;

   FILE *fd = NULL;
   char *output = NULL;
   char *sw = NULL;


   sankoff_result_pair_t *sankoffres;


   int **id = NULL;
   int *pairing = NULL;

   /* discard  sequences that are too similar (-c option)*/

#if defined(CARNAC_REDUCE) || defined(CARNAC_FUSION)
   /********** CALCUL SIMILARITE *******/
   if(RESULTS_sequence_similarities == NULL) {
      RESULTS_sequence_similarities = similarities(oseqs, onb_seqs);
   }
#endif


#if defined(CARNAC_REDUCE)
   /********** REDUCTION **********/

   reduce_seq_set(oseqs, onb_seqs, &seqs, &nb_seqs, CARNAC_SIM_THRESHOLD);

   if(nb_seqs < 2) {
      ERROR_ "Not enough non similar sequences !!\n" _ERROR;
      if(output_fd) {
	 fprintf(output_fd, "Not enough non similar sequences ...\n");
      }

      return 1;
   }

   slinked = fusion_set_new(1);
   sepsilon = fusion_set_new(1);
   ssingle = fusion_set_new(nb_seqs);
   for(i = 0; i < nb_seqs; i++) {
      cur_seq_set = sequence_set_new(1);
      sequence_set_add(cur_seq_set, seqs[i], i);
      fusion_set_add(ssingle, cur_seq_set);
   }

#else
   seqs = oseqs;
   nb_seqs = onb_seqs;


#if defined(CARNAC_FUSION)
   
   build_equiv_class(&equiv_class, &nb_class, seqs, nb_seqs, CARNAC_SIM_THRESHOLD);
   
   slinked = build_slinked(seqs, nb_seqs, equiv_class, nb_class);
   
   ssingle = build_ssingle(seqs, nb_seqs, equiv_class, nb_class);
   
   sepsilon = build_sepsilon(seqs, nb_seqs, slinked, ssingle);

   DESTROY(equiv_class);
   
#else
   slinked = fusion_set_new(1);
   sepsilon = fusion_set_new(1);
   ssingle = fusion_set_new(nb_seqs);
   for(i = 0; i < nb_seqs; i++) {
      cur_seq_set = sequence_set_new(1);
      sequence_set_add(cur_seq_set, seqs[i], i);
      fusion_set_add(ssingle, cur_seq_set);
   }
#endif

   INFO_ "Clustering sequences " _INFO;
   
   
   INFO_ "slinked={ " _INFO;
   for(i = 0; i < slinked->size; i++) {
      INFO_ "(" _INFO;
      for(j = 0; j < slinked->sets[i]->nb_seqs; j++) {
	 INFO_ "%i ", slinked->sets[i]->seq_id[j] _INFO;
      }
      INFO_ ") " _INFO;
   }
   INFO_ "} ssingle={ " _INFO;
   for(i = 0; i < ssingle->size; i++) {
      for(j = 0; j < ssingle->sets[i]->nb_seqs; j++) {
	 INFO_ "%i ", ssingle->sets[i]->seq_id[j] _INFO;
      }
   }
   INFO_ "} sepsilon={ " _INFO;
   for(i = 0; i < sepsilon->size; i++) {
      INFO_ "(" _INFO;
      for(j = 0; j < sepsilon->sets[i]->nb_seqs; j++) {
	 INFO_ "%i ", sepsilon->sets[i]->seq_id[j] _INFO;
      }
      INFO_ ") " _INFO;
   }
   INFO_ "}\n" _INFO;
   




#ifdef CARNAC_FUSION
   /******* construction aln multiples ADN ********/
   
   INFO_ "Producing nucleic alignments..." _INFO;
   FLUSH_OUT;


   sw = tmpnam(NULL);
   NEW(swi, char, (1+strlen(sw)));
   strcpy(swi, sw);
   sw = tmpnam(NULL);
   NEW(swo, char, (1+strlen(sw)));
   strcpy(swo, sw);

   for(i = 0; i < slinked->size; i++) {
      if((swfd = fopen(swi, "w"))) {
	 write_fasta(swfd, slinked->sets[i]->seqs, slinked->sets[i]->nb_seqs, 0);
	 fflush(swfd);
	 fclose(swfd);
	 if(align_clustalw(swi, swo)) {
	    ERROR_ "a problem occured during multiple alignment\n" _ERROR;
	    return 2;
	 } else {
	    if(read_sequences(swo, &tseqs, &tnb_seqs)) {
	       ERROR_ "unable to open '%s' for reading...\n", swo _ERROR;
	       return 2;
	    } else {
	       tdna = init_alignment(tseqs, tnb_seqs, swo);
	       tdna->nb_seqs = tnb_seqs;
	       DESTROY(tseqs);
	  
	       /*     
	       for(j = 0; j < tnb_seqs; j++) {
		  DESTROY(tdna->seqs[j]->file);
		  DESTROY(tdna->seqs[j]->name);
		  DESTROY(tdna->seqs[j]->input_name);
		  DESTROY(tdna->seqs[j]->bases);
	       }
	       DESTROY(tdna->seqs);
	       DESTROY(tdna->file);
	       DESTROY(tdna);
	       */
	       slinked->sets[i]->aln = tdna;
	    }
	 }
      } else {
	 ERROR_ "unable to open '%s' for writing...\n", swi _ERROR;
      }
   }
   INFO_ "ok\n" _INFO;

   unlink(swi);
   unlink(swo);


#endif


#endif
   





   /* metasequences */
   nb_meta = ssingle->size + slinked->size;
   NEW(meta, metasequence, nb_meta);
   for(i = 0; i < ssingle->size; i++) {
      INFO_ "metasequence %2i is sequence %2i '%s'\n", i, ssingle->sets[i]->seq_id[0], ssingle->sets[i]->seqs[0]->input_name _INFO;
      meta[i] = new_metasequence_from_sequence(ssingle->sets[i]->seqs[0]);
   }
   for(j = 0; j < slinked->size; j++) {
      INFO_ "metasequence %2i is alignment %2i\n", ssingle->size+j, j _INFO;
      meta[ssingle->size + j] = new_metasequence_from_alignment(slinked->sets[j]->aln);
   }
   /**/






/**/
   NEW(id, int*, (nb_meta-1));
   for(i = 0; i < (nb_meta-1); i++) {
      NEW(id[i], int, (nb_meta - i - 1));
   }


   for(i = 0; i < ssingle->size; i++) {
      for(j = i + 1; j < ssingle->size; j++) {
	 id[i][j-i-1] = RESULTS_sequence_similarities[MIN(ssingle->sets[i]->seq_id[0], ssingle->sets[j]->seq_id[0])][MAX(ssingle->sets[i]->seq_id[0], ssingle->sets[j]->seq_id[0]) - MIN(ssingle->sets[i]->seq_id[0], ssingle->sets[j]->seq_id[0]) - 1];
	 
	 /*INFO_ "* ID = %i\n",id[i][j-i-1] _INFO;*/
      }


      for(j = 0; j < slinked->size; j++) {
	 id[i][ssingle->size + j - i - 1] = 0;
	 
	 for(k = 0; k < slinked->sets[j]->nb_seqs; k++) {
	    m = RESULTS_sequence_similarities[MIN(slinked->sets[j]->seq_id[k], ssingle->sets[i]->seq_id[0])][MAX(slinked->sets[j]->seq_id[k], ssingle->sets[i]->seq_id[0]) - MIN(slinked->sets[j]->seq_id[k], ssingle->sets[i]->seq_id[0]) - 1];

	    id[i][ssingle->size + j - i - 1] = MIN(id[i][ssingle->size + j - i - 1], m);
	 }
	 
	 /*	 id[i][ssingle->size + j - i - 1] /= slinked->sets[j]->nb_seqs;*/
	 
	 /*INFO_ "*** ID = %i\n", id[i][ssingle->size + j - i - 1] _INFO;*/
      }
   }

   for(i = 0; i < slinked->size; i++) {
      for(j = i+1; j < slinked->size; j++) {
	 id[ssingle->size + i][j-i-1] = 0;
	 
	 for(k = 0; k < slinked->sets[i]->nb_seqs; k++) {
	    for(l = 0; l < slinked->sets[j]->nb_seqs; l++) {

	       m = RESULTS_sequence_similarities[MIN(slinked->sets[i]->seq_id[k], slinked->sets[j]->seq_id[l])][MAX(slinked->sets[i]->seq_id[k], slinked->sets[j]->seq_id[l]) - MIN(slinked->sets[i]->seq_id[k], slinked->sets[j]->seq_id[l]) - 1];
	       id[ssingle->size + i][j-i-1] = MIN(id[ssingle->size + i][j-i-1], m);
	    }
	 }
	 
	    /*	 id[ssingle->size + i][j-i-1] /= (slinked->sets[i]->nb_seqs * slinked->sets[j]->nb_seqs);*/
	 /*	 INFO_ "** ID = %i\n",id[ssingle->size + i][j-i-1] _INFO;*/
      }
   }

/**/

   

   /* finding stems */
   NEW(stems, metastem_t_list, nb_meta);
   
   for(i = 0; i < nb_meta; i++) {
      stems[i] = metastems_in_metasequence(meta[i]);
      

      
      INFO_ "metasequence %i: %i stems\n", i, stems[i]->nb_metastems _INFO;
      /*
      for(k = 0; k < stems[i]->nb_metastems; k++) {
	 INFO_ "%2i  ", k _INFO;
	 println_metastem(&(stems[i]->metastems[k]), meta[i]);
      }
      */
      
   }
   /**/


   if(OPTS_output_dir && create_files) {
      NEW(output, char, (strlen(OPTS_output_dir) + strlen(CARNAC_BOX->dir) + 1 + strlen(CARNAC_METASTEMS_FILE) + 1));
      sprintf(output, "%s%s/%s", OPTS_output_dir, CARNAC_BOX->dir, CARNAC_METASTEMS_FILE);
      
      if((fd = fopen(output, "w")) == NULL) {
	 ERROR_ "unable to create output file '%s'\n", output _ERROR;
	 DESTROY(output);
	 return 1;
      }
      
      write_metastems(fd, meta, stems, nb_meta);
      fclose(fd);
   }
   





   if(nb_meta > 1) {
      sankoff_res = sankoff_all(meta, nb_meta, stems, id);
      

      graph = build_stem_graph(sankoff_res, stems, meta, nb_meta, id);
      

      /* cleaning stems and meta */
      for(i = 0; i < nb_meta; i++) {

	 if(stems[i]->metastems) {
	    if(stems[i]->metastems->seq_stems) {
	       DESTROY(stems[i]->metastems->seq_stems);
	    }
	    DESTROY(stems[i]->metastems);
	 }

	 DESTROY(stems[i]);
      }
      DESTROY(stems);
      

      /* cleaning sankoff result */
      for(i = 0; i < (nb_meta-1); i++) {
	 for(j = i+1; j < nb_meta; j++) {
	    
	    sankoffres = &(SANKOFF_GET_FOLDING_PAIR(sankoff_res,i,j));
	    
	    if(sankoffres->stems1) {
	       for(m = 0; m < sankoffres->nb_stems; m++) {
		  if(sankoffres->stems1[m].seq_stems) {
		     DESTROY(sankoffres->stems1[m].seq_stems);
		  }
	       }
	       DESTROY(sankoffres->stems1);
	    }
	    
	    if(sankoffres->stems2) {
	       for(m = 0; m < sankoffres->nb_stems; m++) {
		  if(sankoffres->stems2[m].seq_stems) {
		     DESTROY(sankoffres->stems2[m].seq_stems);
		  }
	       }
	       DESTROY(sankoffres->stems2);
	    }

	    if(sankoffres->istems1) {
	       for(m = 0; m < sankoffres->nb_istems; m++) {
		  if(sankoffres->istems1[m].seq_stems) {
		     DESTROY(sankoffres->istems1[m].seq_stems);
		  }
	       }
	       DESTROY(sankoffres->istems1);
	    }


	    if(sankoffres->istems2) {
	       for(m = 0; m < sankoffres->nb_istems; m++) {
		  if(sankoffres->istems2[m].seq_stems) {
		     DESTROY(sankoffres->istems2[m].seq_stems);
		  }
	       }
	       DESTROY(sankoffres->istems2);
	    }

	 }
	 DESTROY(sankoff_res[i]);
      }
      DESTROY(sankoff_res);
      /**/
      
      
      
      /* final structures */
      final_meta_stems = final_structures(graph, nb_meta);
   
   
   
      /* cleaning graph */
      for(i = 0; i < graph->nb_components; i++) {
	 for(j = 0; j < (graph->components[i].max_nodes - 1); j++) {
	    DESTROY(graph->components[i].edges[j]);
	 }
	 for(j = 0; j < graph->components[i].nb_nodes; j++) {
	    for(k = 0; k < graph->components[i].nodes[j].stems.nb_metastems; k++) {

	       
	       if(graph->components[i].nodes[j].stems.metastems[k].seq_stems) {
		  DESTROY(graph->components[i].nodes[j].stems.metastems[k].seq_stems);
	       }
	       
	    }
	    if(graph->components[i].nodes[j].stems.nb_metastems > 0) {
	       DESTROY(graph->components[i].nodes[j].stems.metastems);
	    }
	 }
	 DESTROY(graph->components[i].edges);
	 DESTROY(graph->components[i].nodes);
      }
      DESTROY(graph->components);
      DESTROY(graph);
      /**/
   } else {

      NEW(final_meta_stems, metastem_t_list_t, 1);
      final_meta_stems->nb_metastems = 0;
      final_meta_stems->metastems = NULL;
      

      
   }   


   for(i = 0; i < (nb_meta-1); i++) {
      DESTROY(id[i]);
   }
   DESTROY(id);


   
   /****************************************/
   /**    retour aux sequences simples    **/
   /****************************************/
   NEW(final_stems, stem_t_list_t, onb_seqs); 

   for(i = 0; i < ssingle->size; i++) {
      if(final_meta_stems[i].nb_metastems) {
	 final_stems[ssingle->sets[i]->seq_id[0]].nb_stems = final_meta_stems[i].nb_metastems;
	 NEW(final_stems[ssingle->sets[i]->seq_id[0]].stems, stem_t, final_meta_stems[i].nb_metastems);
	 
	 for(j = 0; j < final_meta_stems[i].nb_metastems; j++) {
	    final_stems[ssingle->sets[i]->seq_id[0]].stems[j] = final_meta_stems[i].metastems[j].seq_stems[0];
	 }


      } else {
	 final_stems[ssingle->sets[i]->seq_id[0]].nb_stems = 0;
	 final_stems[ssingle->sets[i]->seq_id[0]].stems = NULL;
      }
   }
   for(i = 0; i < slinked->size; i++) {
      for(j = 0; j < slinked->sets[i]->nb_seqs; j++) {
	 if(final_meta_stems[ssingle->size + i].nb_metastems) {
	    final_stems[slinked->sets[i]->seq_id[j]].nb_stems = final_meta_stems[ssingle->size+i].nb_metastems;
	    NEW(final_stems[slinked->sets[i]->seq_id[j]].stems, stem_t, final_meta_stems[ssingle->size+i].nb_metastems);

	 /* recopie des tiges... */
	 
	    for(k = 0; k < final_meta_stems[ssingle->size+i].nb_metastems; k++) {
	       final_stems[slinked->sets[i]->seq_id[j]].stems[k] = final_meta_stems[ssingle->size+i].metastems[k].seq_stems[j];
	    }


	    correct_stem_positions(&(final_stems[slinked->sets[i]->seq_id[j]]), slinked->sets[i], j);


	 } else {
	    final_stems[slinked->sets[i]->seq_id[j]].nb_stems = 0;
	    final_stems[slinked->sets[i]->seq_id[j]].stems = NULL;
	 }
      }
   }






   
   for(i = 0; i < onb_seqs; i++) {
      shorten_overlapping_stems(&(final_stems[i]));
   }





   /* cleaning structures */
   for(i = 0; i < nb_meta; i++) {
      for(j = 0; j < final_meta_stems[i].nb_metastems; j++) {

	 if(final_meta_stems[i].metastems[j].seq_stems) {
	    DESTROY(final_meta_stems[i].metastems[j].seq_stems);
	 }
      }
      if(final_meta_stems[i].metastems) {
	 DESTROY(final_meta_stems[i].metastems);
      }
   }   
   DESTROY(final_meta_stems);


   for(i = 0; i < nb_meta; i++) {
      DESTROY(meta[i]->seqs);
      DESTROY(meta[i]->file);
      DESTROY(meta[i]);
   }
   DESTROY(meta);
   /********/










   /* rebuilding stems */
   if(!OPTS_carnac_sankoff_stems) {


      for(i = 0; i < onb_seqs; i++) {

	 if(final_stems[i].stems) {

	    NEW(pairing, int, oseqs[i]->length);
	    for(j = 0; j < oseqs[i]->length; j++) {
	       pairing[j] = -1;
	    }
	    for(j = 0; j < final_stems[i].nb_stems; j++) {
	       pairing[final_stems[i].stems[j].begin_start] = final_stems[i].stems[j].end_stop;
	       pairing[final_stems[i].stems[j].end_stop] = final_stems[i].stems[j].begin_start;
	    }

	    
	    
	    
	    DESTROY(final_stems[i].stems);
	    final_stems[i].nb_stems = 0;
	    
	    k = 0;
	    for(j = 0; j < oseqs[i]->length; j++) {
	       switch(k) {
	       case 0: /* no stem */
		  
		  if(pairing[j] > j) {
		     k = 1;

		     if(final_stems[i].nb_stems == 0) {
			NEW(final_stems[i].stems, stem_t, 1);
		     } else {
			RENEW(final_stems[i].stems, stem_t, (final_stems[i].nb_stems + 1));
		     }
		     
		     final_stems[i].stems[final_stems[i].nb_stems].begin_start = j;
		     final_stems[i].stems[final_stems[i].nb_stems].begin_stop = j;
		     final_stems[i].stems[final_stems[i].nb_stems].end_start = pairing[j];
		     final_stems[i].stems[final_stems[i].nb_stems].end_stop = pairing[j];
		     

		     final_stems[i].nb_stems++;
		  }
		  
		  break;

	       case 1: /* in a stem */
		  
		  if(pairing[j] > j) {
		     if(pairing[j] == (final_stems[i].stems[final_stems[i].nb_stems - 1].end_start - 1)) {
			final_stems[i].stems[final_stems[i].nb_stems - 1].begin_stop++;
			final_stems[i].stems[final_stems[i].nb_stems - 1].end_start--;
			
		     } else {
			
			RENEW(final_stems[i].stems, stem_t, (final_stems[i].nb_stems + 1));
			
			final_stems[i].stems[final_stems[i].nb_stems].begin_start = j;
			final_stems[i].stems[final_stems[i].nb_stems].begin_stop = j;
			final_stems[i].stems[final_stems[i].nb_stems].end_start = pairing[j];
			final_stems[i].stems[final_stems[i].nb_stems].end_stop = pairing[j];
			
			final_stems[i].nb_stems++;

		     }
		  } else {
		     k = 0;
		  }

		  break;
	       default:
		  ERROR_ "You've discovered a strong bug !!!\n" _ERROR;
		  break;
	       }
	    }


	    /* extending inside */
	    for(j = 0; j < final_stems[i].nb_stems; j++) {
	       while(((final_stems[i].stems[j].end_start - final_stems[i].stems[j].begin_stop) > (SIZE_HAIRPIN + 2))
		     && (pairing[final_stems[i].stems[j].begin_stop + 1] < 0)
		     && (pairing[final_stems[i].stems[j].end_start - 1] < 0)
		     && is_canonical_pair(oseqs[i]->bases[final_stems[i].stems[j].begin_stop + 1], oseqs[i]->bases[final_stems[i].stems[j].end_start - 1])) {
		  final_stems[i].stems[j].begin_stop++;
		  final_stems[i].stems[j].end_start--;

		  pairing[final_stems[i].stems[j].begin_stop] = final_stems[i].stems[j].end_start;
		  pairing[final_stems[i].stems[j].end_start] = final_stems[i].stems[j].begin_stop;
	       }
	    }

	    /* extending outside */
	    for(j = 0; j < final_stems[i].nb_stems; j++) {
	       while((final_stems[i].stems[j].begin_start > 0)
		     && (final_stems[i].stems[j].end_stop < (oseqs[i]->length-1))
		     && (pairing[final_stems[i].stems[j].begin_start - 1] < 0)
		     && (pairing[final_stems[i].stems[j].end_stop + 1] < 0)
		     && is_canonical_pair(oseqs[i]->bases[final_stems[i].stems[j].begin_start - 1], oseqs[i]->bases[final_stems[i].stems[j].end_stop + 1])) {
		  final_stems[i].stems[j].begin_start--;
		  final_stems[i].stems[j].end_stop++;

		  pairing[final_stems[i].stems[j].begin_start] = final_stems[i].stems[j].end_stop;
		  pairing[final_stems[i].stems[j].end_stop] = final_stems[i].stems[j].begin_start;
	       }
	    }
	    


	    DESTROY(pairing);
	 }


	 


	 j = 0;
	 while(j < final_stems[i].nb_stems) {

	    final_stems[i].stems[j].energy = 0;
	    final_stems[i].stems[j].folded_id = 0;


	    k = 0;
	    while((k < (final_stems[i].stems[j].begin_stop - final_stems[i].stems[j].begin_start + 1)) && !is_canonical_pair(oseqs[i]->bases[final_stems[i].stems[j].begin_start + k], oseqs[i]->bases[final_stems[i].stems[j].end_stop - k])) {

	       final_stems[i].stems[j].begin_start++;
	       final_stems[i].stems[j].end_stop--;
	    }

	    if(final_stems[i].stems[j].begin_stop < final_stems[i].stems[j].begin_start) {
	       final_stems[i].stems[j] = final_stems[i].stems[final_stems[i].nb_stems - 1];
	       final_stems[i].nb_stems--;

	    } else {


	       k = 0;
	       while((k < (final_stems[i].stems[j].begin_stop - final_stems[i].stems[j].begin_start + 1)) && !is_canonical_pair(oseqs[i]->bases[final_stems[i].stems[j].begin_stop - k], oseqs[i]->bases[final_stems[i].stems[j].end_start + k])) {
		  
		  final_stems[i].stems[j].begin_stop--;
		  final_stems[i].stems[j].end_start++;
	       }
	       
	       
	       
	       if(final_stems[i].stems[j].begin_stop < final_stems[i].stems[j].begin_start) {
		  final_stems[i].stems[j] = final_stems[i].stems[final_stems[i].nb_stems - 1];
		  final_stems[i].nb_stems--;
		  
	       } else {
		  
		  
		  
		  for(k = 1; k < (final_stems[i].stems[j].begin_stop - final_stems[i].stems[j].begin_start + 1); k++) {
		     
		     if(is_canonical_pair(oseqs[i]->bases[final_stems[i].stems[j].begin_start + k], oseqs[i]->bases[final_stems[i].stems[j].end_stop - k])) {
			if(is_canonical_pair(oseqs[i]->bases[final_stems[i].stems[j].begin_start + k - 1], oseqs[i]->bases[final_stems[i].stems[j].end_stop - k + 1])) {
			   /* stacking canonical */
			   final_stems[i].stems[j].energy += stack_inside(oseqs[i], final_stems[i].stems[j].begin_start + k - 1, final_stems[i].stems[j].end_stop - k + 1);
			   if((final_stems[i].stems[j].begin_start + k) == final_stems[i].stems[j].begin_stop) {
			      /* ending stem */
			      final_stems[i].stems[j].energy += tstack_inside(oseqs[i], final_stems[i].stems[j].begin_start + k, final_stems[i].stems[j].end_stop - k);
			   }
			} else {
			   if(k >= 2) {
			      if(is_canonical_pair(oseqs[i]->bases[final_stems[i].stems[j].begin_start + k - 2], oseqs[i]->bases[final_stems[i].stems[j].end_stop - k + 2])) {
				 final_stems[i].stems[j].energy += sint2_inside(oseqs[i], final_stems[i].stems[j].begin_start + k - 2, final_stems[i].stems[j].end_stop - k + 2);
			      } else {
				 if((k >= 3) && is_canonical_pair(oseqs[i]->bases[final_stems[i].stems[j].begin_start + k - 3], oseqs[i]->bases[final_stems[i].stems[j].end_stop - k + 3])) {
				    final_stems[i].stems[j].energy += sint4_inside(oseqs[i], final_stems[i].stems[j].begin_start + k - 3, final_stems[i].stems[j].end_stop - k + 3);
				 }
			      }
			   }
			}
		     }
		  }
		  
		  j++;



	       }
	    }
	 }
      }
   }
   /**/








   /****************/
   INFO_ "PREDICTED STEMS\n" _INFO;
   NEW((*energies), int, onb_seqs);
   for(i = 0; i < onb_seqs; i++) {

      sort_stems_by_begin_then_end(&(final_stems[i]));

      if(OPTS_output_dir && create_files) {

	 NEW(output, char, (strlen(OPTS_output_dir) + strlen(CARNAC_BOX->dir) + 3 + 7 + 1));
	 sprintf(output, "%s%s/seq%03i.ct", OPTS_output_dir, CARNAC_BOX->dir, (i+1));
	 
	 if((fd = fopen(output, "w")) == NULL) {
	    ERROR_ "unable to create output file '%s'\n", output _ERROR;
	    DESTROY(output);
	    return 1;
	 }
	 
	 write_ct(fd, oseqs[i], &(final_stems[i]));
	 fclose(fd);

	 DESTROY(output);

	 NEW(output, char, (strlen(OPTS_output_dir) + strlen(CARNAC_BOX->dir) + 3 + 7 + 1));
	 sprintf(output, "%s%s/seq%03i.eq", OPTS_output_dir, CARNAC_BOX->dir, (i+1));
	 
	 if((fd = fopen(output, "w")) == NULL) {
	    ERROR_ "unable to create output file '%s'\n", output _ERROR;
	    DESTROY(output);
	    return 1;
	 }
	 
	 write_eq(fd, oseqs[i], &(final_stems[i]));
	 fclose(fd);

	 DESTROY(output);
      }



      INFO_ "  sequence %i '%s' (%i stems)\n", i, oseqs[i]->input_name, final_stems[i].nb_stems _INFO;

      (*energies)[i] = 0;
      for(j = 0; j < final_stems[i].nb_stems; j++) {
	 INFO_ "    " _INFO;
	 println_seq_stem(&(final_stems[i].stems[j]), oseqs[i]);
	 (*energies)[i] += final_stems[i].stems[j].energy;
      }
   }
   /**/




   /* writing multieq */
   if(output_fd) {
      write_multieq(output_fd, oseqs, final_stems, onb_seqs);
      fflush(output_fd);
   }


   




   /*******************************************/
   /* cleaning final structures */
   /*******************************************/
   for(i = 0; i < onb_seqs; i++) {
      if(final_stems[i].stems) {
	 DESTROY(final_stems[i].stems);
      }
   }   
   DESTROY(final_stems);


   
   return 0;
}







int
box_carnac(const sequence* oseqs, const int onb_seqs, sequence** prots) {
   int status;
   FILE *output_fd = NULL;
   char *output = NULL, *sw = NULL;
   int *energies = NULL;
   

   if(OPTS_output_dir) {
      NEW(sw, char, (strlen(OPTS_output_dir) + strlen(CARNAC_BOX->dir) + 1));
      strcpy(sw, OPTS_output_dir);
      strcat(sw, CARNAC_BOX->dir);
      if(prepare_dir(sw)) {
	 ERROR_ "unable to create output dir '%s'\n", sw _ERROR;
	 return 1;
      }
      DESTROY(sw);

      NEW(output, char, (strlen(OPTS_output_dir) + strlen(CARNAC_BOX->out_file) + 1));
      strcpy(output, OPTS_output_dir);
      strcat(output, CARNAC_BOX->out_file);
      
      if((output_fd = fopen(output, "w")) == NULL) {
	 ERROR_ "unable to create output file '%s'\n", output _ERROR;
	 return 1;
      }      
   } else {
      output_fd = DISPLAY_OUT;
      output = NULL;
   }


   status = carnac(oseqs, onb_seqs, output_fd, &energies, 1);
   DESTROY(energies);


   if(output) {
      fclose(output_fd);
      DESTROY(output);
   }


   return status;
}




