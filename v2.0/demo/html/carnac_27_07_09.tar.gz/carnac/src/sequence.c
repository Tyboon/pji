#ifdef HAVE_CONFIG_H
    #include "config.h"
#endif
#include <string.h>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

#include "sequence.h"
#include "display.h"
#include "opts.h"
#include "output.h"



void
check_sequence(const sequence res) {
   int i, j;
   
   if(res->name) {

      j = MIN(12,strlen(res->name));

      for(i = 0; i < j; i++) {
	 if((res->name[i] != '.')
	    && ((res->name[i] < 'a') || (res->name[i] > 'z'))
	    && ((res->name[i] < 'A') || (res->name[i] > 'Z'))
	    && ((res->name[i] < '0') || (res->name[i] > '9'))
	    && (res->name[i] != '-')
	    && (res->name[i] != '+'))
	    res->name[i] = SUBSTITUTE_CHAR;
      }
      RENEW(res->name, char, (1+j));
      res->name[j] = '\0';
   }

   if(res->length > 0) {
      res->nb_gaps = 0;
      res->kind = OTHER;

      for(i=0; i < res->length; i++) {
	 switch(res->bases[i]) {
	 case 'U':
	    if(res->kind == OTHER) res->kind = RNA;
	    break;
	 case 'G':
	    if(res->kind == OTHER) res->kind = DNA;
	    break;
	 case 'W':
	 case 'X':
	 case '*':
	    if(res->kind == PROTEIN) res->kind = PROTEIN;
	    break;
	 case '-':
	 case '.':
	    res->nb_gaps++;
	 default:
	    break;
	 }
      }
   }
}

sequence
init_sequence(const char* file, const char* input_name, const char* name, char* bases, const int length, const int strand) {
   sequence res = NULL;

   if(strand != 0 && strand > -4 && strand < 4) {
      NEW(res, sequence_t, 1);
      
      res->length = 0;
      res->strand = strand;
      res->nb_gaps = 0;
      res->kind = DNA;
      
      NEW(res->file, char, (1+strlen(file)));
      strcpy(res->file, file);
      /*      res->file[strlen(file)]='\0';*/
      
      NEW(res->input_name, char, (1+strlen(input_name)));
      strcpy(res->input_name, input_name);


      NEW(res->name, char, (1+strlen(name)));
      strcpy(res->name, name);
      /*      res->name[strlen(name)]='\0';*/
      
      if(length > 0) {
	 NEW(res->bases, char, (1+length));
	 concat_bases(res, bases, length);
      } else {
	 NEW(res->bases, char, 100);
      }
   } else {
      ERROR_ "invalid strand (%i)\n", strand _ERROR;
   }

   return res;
}

sequence
new_sequence(const char* file, const char* input_name, const char* name, char *bases, const int from, const int to, const int strand) {
   return init_sequence(file, input_name, name, &(bases[from]), to - from, strand);
}


void
concat_sequence(sequence s1, const sequence s2) {
   concat_bases(s1, s2->bases, s2->length);
}


void
concat_bases(sequence seq, const char* bases, const int length) {
   /*   register int i;*/

   if(length > 0) {
      RENEW(seq->bases, char, (1 + seq->length + length));
      /*      for(i = 0; i < length; i++) {
	 seq->bases[seq->length + i] = bases[i];
	 }*/
      strncpy(&(seq->bases[seq->length]), bases, length);
      seq->bases[seq->length + length] = '\0';

      seq->length += length;
   }
}


sequence
change_sequence_strand(const sequence in, const int new_strand) {
   char* bases = NULL/*, *name*/;
   int reverse, offset, i;
   sequence res = NULL, rest = NULL;

   if(in->kind == OTHER) {
      ERROR_ "A sequence from '%s' is neither DNA nor RNA !!",in->file _ERROR;
      return NULL;
   }

   if(new_strand < -3 || new_strand == 0 || new_strand > 3) {
      ERROR_ "invalid strand (%i)\n", new_strand _ERROR;
      return NULL;
   }

   if(in->strand == new_strand) {
      bases = in->bases;
      offset = 0;
      reverse = 0;
   } else {
      if(in->strand > 0) {
	 if(new_strand > 0) {
	    offset = new_strand - in->strand;
	    if(offset < 0) offset += 3;
	    reverse = 0;
	 } else {
	    offset = new_strand;
	    if(offset < 0) { offset *=-1; }
	    offset--;
	    reverse = 1;
	 }
      } else {
	 if(new_strand > 0) {
	    reverse = 1;
	    offset = new_strand - 1;
	 } else {
	    offset = new_strand;
	    if(offset < 0) {
	       offset *= -1;
	    }
	    reverse = in->strand;
	    if(reverse < 0) {
	       reverse *= -1;
	    }
	    offset = offset - reverse;
	    if(offset < 0) offset += 3;
	    reverse = 0;
	 }
      }

      /*      INFO_ "OLD = %i, NEW = %i, OFFSET = %i, reverse = %i\n", in->strand, new_strand, offset, reverse _INFO;*/

      if(in->length > offset) {
	 NEW(bases, char, (in->length - offset));
	 
	 if(reverse) {
	    for(i = 0; i < (in->length - offset); i++)
	       bases[in->length - offset - 1 - i] = in->bases[i];
	 } else
	    for(i = 0; i < (in->length - offset); i++) {
	       bases[i] = in->bases[offset + i];
	    }
      }
      /*	 memcpy(bases, &(in->bases[offset]), (in->length - offset) * sizeof(char));*/
   }

   /* +2 pour la phase */
   /*
     NEW(name, char, (strlen(in->name) + strlen(STRAND_MARK) + 2 + 1));
     strncpy(name, in->name, strlen(in->name));
     strncpy(&(name[strlen(in->name)]), STRAND_MARK, strlen(STRAND_MARK));
     sprintf(&(name[strlen(in->name) + strlen(STRAND_MARK)]), "%+i", new_strand);
   */

   res = init_sequence(in->file, in->input_name, in->name, bases, in->length - offset, new_strand);
   res->kind = in->kind;
   
   if(in->bases != bases) {
      DESTROY(bases);
   }

   /*
   DESTROY(name);
   */


   if(reverse) {
      rest = complement(res);
      DESTROY(res->file);
      DESTROY(res->name);
      DESTROY(res->input_name);
      DESTROY(res->bases);
      DESTROY(res);
   } else {
      rest = res;
   }
   rest->kind = in->kind;

   return rest;
}



sequence
traduct(const sequence in) {
   unsigned int i;
   sequence res = NULL;
   
   /*   check_sequence(in);
   
   if(in->kind == DNA || in->kind == RNA) {*/
      res = new_sequence(in->file, in->input_name, in->name, "", 0, 0, in->strand);

      RENEW(res->bases, char, in->length);
      res->length = in->length;

      for(i=0; i < in->length; i++) {
	 switch(in->bases[i]) {
	 case 't':
	    res->bases[i] = 'u';
	    break;
	 case 'T':
	    res->bases[i] = 'U';
	    break;
	 default:
	    res->bases[i] = in->bases[i];
	    break;
	 }
      }
      /*   }*/

      res->kind = RNA;


   return res;
}

char
translate_codon(const sequence s, const int pos) {
   char base1, base2, base3;
  
   base1 = s->bases[pos];
   base2 = s->bases[pos+1];
   base3 = s->bases[pos+2];

   switch(base1) {
   case 'A':
      switch(base2) {
      case 'A':
	 /**/ 
	 switch(base3) {
	 case 'A':
	 case 'G':
	 case 'R':
	    return 'K';
	 case 'U':
	 case 'T':
	 case 'C':
	 case 'Y':
	    return 'N';
	 case '-':
	    return '-';
	 default:
	    WARN_ "ignoring symbol for translation: '%c' in '%s' at %i!!\n", base3, s->name, (pos+2+1) _WARN;
	    break;
	 }
	 /**/
	 break;
      case 'U':
      case 'T':
	 /**/ 
	 switch(base3) {
	 case 'U':
	 case 'T':
	 case 'C':
	 case 'A':
	 case 'H':
	 case 'M':
	 case 'Y':
	 case 'W':
	    return 'I';
	 case 'G':
	    return 'M';
	 case '-':
	    return '-';
	 default:
	    WARN_ "ignoring symbol for translation: '%c' in '%s' at %i!!\n", base3, s->name, (pos+2+1) _WARN;
	    break;
	 }
	 /**/ 
	 break;
      case 'C':
	 /**/ 
	 return 'T';
	 /**/ 
	 break;
      case 'G':
	 /**/ 
	 switch(base3) {
	 case 'U':
	 case 'T':
	 case 'C':
	 case 'Y':
	    return 'S';
	 case 'A':
	 case 'G':
	 case 'R':
	    return 'R';
	 case '-':
	    return '-';
	 default:
	    WARN_ "ignoring symbol for translation: '%c' in '%s' at %i!!\n", base3, s->name, (pos+2+1) _WARN;
	    break;
	 }	 
	 /**/ 
	 break;
      case '-':
	 return '-';
      default:
	 WARN_ "ignoring symbol for translation: '%c' in '%s' at %i!!\n", base2, s->name, (pos+1+1) _WARN;
	 break;
      }
      break;
   case 'U':
   case 'T':
      switch(base2) {
      case 'U':
      case 'T':
	 /**/ 
	 switch(base3) {
	 case 'U':
	 case 'T':
	 case 'C':
	 case 'Y':
	    return 'F';
	 case 'A':
	 case 'G':
	 case 'R':
	    return 'L';
	 case '-':
	    return '-';
	 default:
	    WARN_ "ignoring symbol for translation: '%c' in '%s' at %i!!\n", base3, s->name, (pos+2+1) _WARN;
	    break;
	 }	 
	 /**/ 
	 break;
      case 'A':
	 /**/ 
	 switch(base3) {
	 case 'U':
	 case 'T':
	 case 'C':
	 case 'Y':
	    return 'Y';
	 case 'A':
	 case 'G':
	 case 'R':
	    return 'U';
	 case '-':
	    return '-';
	 default:
	    WARN_ "ignoring symbol for translation: '%c' in '%s' at %i!!\n", base3, s->name, (pos+2+1) _WARN;
	    break;
	 }	 
	 /**/ 
	 break;
      case 'C':
	 return 'S';
	 /**/
	 break;
      case 'G':
	 /**/
	 switch(base3) {
	 case 'U':
	 case 'T':
	 case 'C':
	 case 'Y':
	    return 'C';
	 case 'A':
	    return 'U';
	 case 'G':
	    return 'W';
	 case '-':
	    return '-';
	 default:
	    WARN_ "ignoring symbol for translation: '%c' in '%s' at %i!!\n", base3, s->name, (pos+2+1) _WARN;
	    break;
	 }	 
	 /**/
	 break;
      case '-':
	 return '-';
      default:
	 WARN_ "ignoring symbol for translation: '%c' in '%s' at %i!!\n", base2, s->name, (pos+1+1) _WARN;
	 break;
      }	 
      break;
   case 'C':
      switch(base2) {
      case 'U':
      case 'T':
	 /**/
	 return 'L';
	 break;
	 /**/
      case 'C':
	 /**/
	 return 'P';
	 break;
	 /**/
      case 'A':
	 /**/
	 switch(base3) {
	 case 'U':
	 case 'T':
	 case 'C':
	 case 'Y':
	    return 'H';
	 case 'A':
	 case 'G':
	 case 'R':
	    return 'Q';
	 case '-':
	    return '-';
	 default:
	    WARN_ "ignoring symbol for translation: '%c' in '%s' at %i!!\n", base3, s->name, (pos+2+1) _WARN;
	    break;
	 }
	 break;
	 /**/
      case 'G':
	 /**/
	 return 'R';
	 break;
	 /**/
      case '-':
	 return '-';
      default:
	 WARN_ "ignoring symbol for translation: '%c' in '%s' at %i!!\n", base2, s->name, (pos+1+1) _WARN;
	 break;
      }	 
      break;
   case 'G':
      switch(base2) {
      case 'U':
      case 'T':
	 /**/
	 return 'V';
	 break;
	 /**/	 
      case 'C':
	 /**/
	 return 'A';
	 break;
	 /**/
      case 'A':
	 /**/
	 switch(base3) {
	 case 'U':
	 case 'T':
	 case 'C':
	 case 'Y':
	    return 'D';
	 case 'A':
	 case 'G':
	 case 'R':
	    return 'E';
	 case '-':
	    return '-';
	 default:
	    WARN_ "ignoring symbol for translation: '%c' in '%s' at %i!!\n", base3, s->name, (pos+2+1) _WARN;
	    break;
	 }
	 break;
	 /**/
      case 'G':
	 /**/
	 return 'G';
	 break;
	 /**/
      case '-':
	 return '-';
      default:
	 WARN_ "ignoring symbol for translation: '%c' in '%s' at %i!!\n", base2, s->name, (pos+1+1) _WARN;
	 break;
      }
      break;
   case '-':
      return '-';
   default:
      WARN_ "ignoring symbol for translation: '%c' in '%s' at %i!!\n", base1, s->name, (pos+1) _WARN;
      break;
   }

   return 'X';
}


sequence
translate(const sequence in) {
   sequence res = NULL;
   char bases[INPUT_BUFFER];
   int i,j;

   /*check_sequence(in);
   
   if(in->kind == RNA) {*/
      res = new_sequence(in->file, in->input_name, in->name, "", 0, 0, in->strand);

      RENEW(res->bases, char, 1 + (in->length / 3));
      res->length = 0;

      j = 0;
      for(i = 0; i < (in->length - 2); i += 3) {
	 bases[j++] = translate_codon(in, i);
	 if(j == INPUT_BUFFER) {
	    concat_bases(res, bases, j);
	    j = 0;
	 }
      }
      if(j > 0) { concat_bases(res, bases,j); }
      /*}*/

      res->kind = PROTEIN;
      

   return res;
}

sequence
ungap(const sequence in) {
   unsigned int i,j;
   sequence res = NULL;
   
   /*   check_sequence(in);*/
   
   res = new_sequence(in->file, in->input_name, in->name, "", 0, 0, in->strand);
   res->kind = in->kind;
   res->length = 0;
   res->nb_gaps = 0;
   
   if(in->length > 0) {

      in->nb_gaps = 0;
      
      RENEW(res->bases, char, in->length);      

      j = 0;
      for(i=0; i < in->length; i++) {
	 switch(in->bases[i]) {
	 case '-':
	 case '.':
	    in->nb_gaps++;
	    break;
	 default:
	    res->bases[j++] = in->bases[i];
	    break;
	 }
      }
      res->length = j;

      if(res->length > 0) {
	 RENEW(res->bases, char, (res->length + 1));
      } else {
	 RENEW(res->bases, char, 1);
      }

      res->bases[res->length] = '\0';
   }
   
   return res;
}


sequence
complement(const sequence in) {
   sequence res = NULL;
   unsigned int i;

   /*check_sequence(in);*/

   if(in->kind == DNA || in->kind == RNA) {
      res = new_sequence(in->file, in->input_name, in->name, "", 0, 0, in->strand);
      res->kind = in->kind;
      RENEW(res->bases, char, in->length);
      
      for(i = 0; i < in->length; i++) {
	 switch(in->bases[i]) {
	 case 'a':
	    res->bases[i] = (in->kind == DNA) ? ('t') : ('u');
	    break;
	 case 'A':
	    res->bases[i] = (in->kind == DNA) ? ('T') : ('U');
	    break;
	 case 't':
	 case 'u':
	    res->bases[i] = 'a';
	    break;
	 case 'T':
	 case 'U':
	    res->bases[i] = 'A';
	    break;
	 case 'c':
	    res->bases[i] = 'g';
	    break;
	 case 'C':
	    res->bases[i] = 'G';
	    break;
	 case 'g':
	    res->bases[i] = 'c';
	    break;
	 case 'G':
	    res->bases[i] = 'C';
	    break;
	 case 'n':
	    res->bases[i] = 'n';
	    break;
	 case 'N':
	    res->bases[i] = 'N';
	    break;
	 case 'w':
	    res->bases[i] = 'w';
	    break;
	 case 'W':
	    res->bases[i] = 'W';
	    break;
	 case 'r':
	    res->bases[i] = 'y';
	    break;
	 case 'R':
	    res->bases[i] = 'Y';
	    break;
	 case 'y':
	    res->bases[i] = 'r';
	    break;
	 case 'Y':
	    res->bases[i] = 'R';
	    break;
	 case 'k':
	    res->bases[i] = 'm';
	    break;
	 case 'K':
	    res->bases[i] = 'M';
	    break;
	 case 'm':
	    res->bases[i] = 'k';
	    break;
	 case 'M':
	    res->bases[i] = 'K';
	    break;
	 case 's':
	    res->bases[i] = 's';
	    break;
	 case 'S':
	    res->bases[i] = 'S';
	    break;
	 case 'b':
	    res->bases[i] = 'v';
	    break;
	 case 'B':
	    res->bases[i] = 'V';
	    break;
	 case 'v':
	    res->bases[i] = 'b';
	    break;
	 case 'V':
	    res->bases[i] = 'B';
	    break;
	 case 'h':
	    res->bases[i] = 'd';
	    break;
	 case 'H':
	    res->bases[i] = 'D';
	    break;	    
	 case 'd':
	    res->bases[i] = 'h';
	    break;
	 case 'D':
	    res->bases[i] = 'H';
	    break;	    
	 case '-':
	 case '.':
	    res->bases[i] = in->bases[i];
	    break;
	 default:
	    ERROR_ "ignoring symbol for complement ('%c')!!\n", in->bases[i] _ERROR;
	    break;
	 }
      }

      res->length = in->length;
   }

   return res;
}


sequence
to_protein(const sequence in) {
   sequence sw = in;
   sequence res = NULL;


   switch(sw->kind) {
   case DNA:
      sw = traduct(sw);
      if(sw == NULL) {
	 ERROR_ "unable to traduct %s ('%s')\n", in->name, in->file _ERROR;
	 return NULL;
      }
   case RNA:
      sw = translate(sw);
      if(sw == NULL) {
	 ERROR_ "unable to translate %s ('%s')\n", in->name, in->file _ERROR;
	 return NULL;
      }
   case PROTEIN:
      break;
   default:
      return NULL;
   }


   res = new_sequence(sw->file, sw->input_name, sw->name, sw->bases, 0, sw->length, sw->strand);

   res->kind = sw->kind;
   
   if(sw && (sw != in)) {
      DESTROY(sw->file);
      DESTROY(sw->name);
      DESTROY(sw->input_name);
      DESTROY(sw->bases);
      DESTROY(sw);
   }

   
   return res;
}



double
gc_percentage(const sequence s) {
   int i;
   double res = 0.0;

   for(i = 0; i < s->length; i++) {
      switch(s->bases[i]) {
      case 'g':
      case 'G':
      case 'c':
      case 'C':
	 res += 1.0;
      default:
	 break;
      }
   }

   return (res / s->length);
}





sequence**
translate_and_write_sequences(const sequence* seqs, const int nb_seqs) {
   sequence** prots = NULL;
   sequence st = NULL;
   char *sw = NULL;
   FILE* tf = NULL;

   int i, j, k;

   NEW(prots, sequence*, nb_seqs);

   for(i = 0; i < nb_seqs; i++) {
      NEW(prots[i], sequence, ((OPTS_first_phase < 0) ? (6) : (3)));
      
      for(j = OPTS_first_phase; j < 4 ; j++) {
	 if(j != 0) {
	    k = (j > 0) ? (j - 1) : (2 - j);

	    st = change_sequence_strand(seqs[i], j);
	    if((prots[i][k] = to_protein(st)) == NULL) return NULL;

	    DESTROY(st->file);
	    DESTROY(st->name);
	    DESTROY(st->input_name);
	    DESTROY(st->bases);
	    DESTROY(st);

	    sw = tmpnam(NULL);
	    RENEW(prots[i][k]->file, char, (1 + strlen(sw)));
	    strcpy(prots[i][k]->file, sw);
	    if((tf = fopen(prots[i][k]->file, "w"))) {
	       write_fasta(tf, &(prots[i][k]), 1, 0);
	       fflush(tf);
	       fclose(tf);
	    } else {
	       ERROR_ "unable to open file '%s' for writing\n", prots[i][k]->file _ERROR;
	       return NULL;
	    }
	 }
      }
   }

   return prots;
}













int
reverse_compatible_phase(int mod, int phase) {
   switch(phase) {
   case 0: /* phase 1 */
      switch(mod) {
      case 0: return 4;
      case 1: return 5;
      case 2: return 3;
      }
      break;
   case 1: /* phase 2 */
      switch(mod) {
      case 0: return 3;
      case 1: return 4;
      case 2: return 5;
      }
      break;
   case 2: /* phase 3 */
      switch(mod) {
      case 0: return 5;
      case 1: return 3;
      case 2: return 4;
      }
      break;
   case 3: /* phase -1 */
      switch(mod) {
      case 0: return 1;
      case 1: return 2;
      case 2: return 0;
      }
      break;
   case 4: /* phase -2 */
      switch(mod) {
      case 0: return 0;
      case 1: return 1;
      case 2: return 2;
      }
      break;
   case 5: /* phase -3 */
      switch(mod) {
      case 0: return 2;
      case 1: return 0;
      case 2: return 1;
      }
   }

   ERROR_ "FATAL ERROR !!!\n" _ERROR;
   return -1;
}



int
reverse_mod(const int* phases1, const int* phases2, const int* rev_mod, const int nb_seqs) {
   int i;
   
   i = 0;
   while((i < nb_seqs) && (phases2[i] == reverse_compatible_phase(rev_mod[i], phases1[i]))) {
      i++;
   }
  
   if(i < nb_seqs) return 0;
   return 1;
}



int
common_mod(const int* phases1, const int* phases2, const int nb_seqs) {
   int i;
   int cur_mod, last_mod, lmod_strand;
   
   last_mod = 0;
   if((phases2[0] < 3) && (phases1[0] < 3)) {
      lmod_strand = 3; /* positif */
   } else if((phases2[0] > 2) && (phases1[0] > 2)) {
      lmod_strand = -3; /* negatif */
   } else return 0;

   while(((phases1[0] + last_mod) % 3) != (phases2[0] % 3)) last_mod++;

   cur_mod = last_mod;
   i = 1;
   while((i < nb_seqs) && (cur_mod == last_mod)) {
      if((phases2[i] < 3) && (phases1[i] < 3)) {
	 if(lmod_strand > 0) {
	    if(((phases1[i] + last_mod) % 3) != phases2[i]) {
	       cur_mod = -1;
	    }
	 } else {
	    if(((phases1[i] + (3 - last_mod)) % 3) != phases2[i]) {
	       cur_mod = -1;
	    }
	 }
      } else if((phases2[i] > 2) && (phases1[i] > 2)) {
	 if(lmod_strand < 0) {
	    if(((phases1[i] - 3 + last_mod) % 3) != (phases2[i] - 3))
	       cur_mod = -1;
	 } else {
	    if(((phases1[i] - 3 + (3 - last_mod)) % 3) != (phases2[i] - 3))
	       cur_mod = -1;
	 }
      } else cur_mod = -1;
      
      i++;
   }

   if(cur_mod == last_mod) return last_mod + 1;
   return 0;
}
