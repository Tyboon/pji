#ifndef __ARNICA_OUTPUT_H__
#define __ARNICA_OUTPUT_H__

#include "sequence.h"
#include "format.h"
#include "boxes.h"
#include "time.h"
#include "carnac_stems.h"
#include "carnac_metastems.h"


extern int
write_color_clustal_dna(FILE* output, const sequence* seqs, const int nb, const int start_at);

extern int
write_color_clustal_protein(FILE* output, const sequence* seqs, const int nb);

extern int
write_clustal(FILE* output, const sequence* seqs, const int nb, const int input_names);

extern int
write_fasta(FILE* output, const sequence* seqs, const int nb, const int input_name);

extern int
write_raw(FILE* output, const sequence* seqs, const int nb);

extern int
write_resume_header(FILE* output);

extern int
write_resume(FILE* output, const char* box_name, const sequence s1, const sequence s2, const double res);


extern int
write_graph(FILE* output, double**** results, const int nb_seqs, const sequence* seqs);


extern int
write_metastems(FILE* output, metasequence *seqs, metastem_t_list *stems, int nb_meta);

extern int
write_stems(FILE* output, sequence *seqs, stem_t_list_t *stems, int nb_seqs);



#endif
