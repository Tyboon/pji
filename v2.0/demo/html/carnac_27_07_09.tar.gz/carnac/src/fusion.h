#ifndef __ARNICA_FUSION_H__
#define __ARNICA_FUSION_H__


#include <stdio.h>
/*#include <mpfr.h>*/

#include "sequence.h"
#include "alignment.h"
#include "list.h"


typedef struct {
   sequence* seqs;
   alignment aln;
   sequence *dna_translated;
   int *seq_id;
   int **frames;
   int nb_seqs;
} sequence_set_t;

typedef sequence_set_t* sequence_set;

extern
sequence_set sequence_set_new(const int max_size);

extern
int sequence_set_contains(const sequence_set set, const sequence s);

extern
int sequence_set_add(sequence_set set, const sequence s, const int seq_id);

extern
void sequence_set_destroy(sequence_set set);

extern
int sequence_set_equals(const sequence_set s1, const sequence_set s2);

extern
void sequence_set_frameset(sequence_set set, float ****results);





typedef struct {
   sequence_set *sets;
   int size;
} fusion_set_t;

typedef fusion_set_t* fusion_set;

extern
fusion_set fusion_set_new(const int max_size);

extern
int fusion_set_contains(const fusion_set set, const sequence_set s);

extern
int fusion_set_contains_seq(const fusion_set set, const sequence s);


extern
int fusion_set_add(fusion_set set, const sequence_set s);


extern
void fusion_set_destroy(fusion_set set, const int recurse);


extern
fusion_set fusion_set_union(const fusion_set s1, const fusion_set s2);


extern fusion_set
build_slinked(const sequence* seqs, const int nb_seqs, const int* equiv_class, const int nb_class);


extern fusion_set
build_ssingle(const sequence* seqs, const int nb_seqs, const int* equiv_class, const int nb_class);

extern fusion_set
build_sepsilon(const sequence* seqs, const int nb_seqs, const fusion_set slinked, const fusion_set ssingle);

extern void
build_equiv_class(int** equiv_class, int* nb_class, const sequence* seqs, const int nb_seqs, const double sim_threshold);


extern float****
build_vrfg(const fusion_set srfg, const fusion_set sepsilon, float**** rfg);

extern float****
rank_vrfg_results(const int nb_vertices, float**** vrfg, const fusion_set srfg, const fusion_set sepsilon);

extern int
prune_rank_vrfg(const int nb_vertices, float**** rank_vrfg, const fusion_set srfg, const double sim_threshold);





extern list
find_best_clique_fusion(const int nb_vertices, const float min, const float max, float**** vrfg, const fusion_set srfg, const fusion_set sepsilon, const int zscore);

/* extern int */
/* format_fusion_result_list(const fusion_set srfg, FILE* output_fd, const list l, const sequence* seqs, const int score_min, mpfr_t *pvalues); */

extern int
format_fusion_result_list_zscore(const fusion_set srfg, FILE* output_fd, const list l, const sequence* seqs, double *pred_res, int *frames);



extern int
write_fusion_graph(FILE* output, float**** results, const int nb_seqs, const sequence* seqs, const fusion_set srfg, const fusion_set sespilon);


#endif


