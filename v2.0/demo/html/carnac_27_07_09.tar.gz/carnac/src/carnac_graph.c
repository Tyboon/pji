#ifdef HAVE_CONFIG_H
    #include "config.h"
#endif

#include <stdlib.h>
#include <assert.h>
#include <math.h>

#include "carnac_graph.h"
#include "carnac_metaseq.h"
#include "opts.h"
#include "display.h"



int
find_node_of_stem_in_component(const graph_component_t comp, const int seq_id, const metastem_t *stem) {
   int i,j, k;

   for(i = 0; i < comp.nb_nodes; i++) {
      if(comp.nodes[i].seq_id == seq_id) {
	 for(j = 0; j < comp.nodes[i].stems.nb_metastems; j++) {
	    if(comp.nodes[i].stems.metastems[j].nb_seqs == stem->nb_seqs) {
	       for(k = 0; k < stem->nb_seqs; k++) {
		  
		  if((comp.nodes[i].stems.metastems[j].seq_stems[k].begin_start == stem->seq_stems[k].begin_start)
		     && (comp.nodes[i].stems.metastems[j].seq_stems[k].begin_stop == stem->seq_stems[k].begin_stop)
		     && (comp.nodes[i].stems.metastems[j].seq_stems[k].end_start == stem->seq_stems[k].end_start)
		     && (comp.nodes[i].stems.metastems[j].seq_stems[k].end_stop == stem->seq_stems[k].end_stop)) {
		     return i;
		  }

	       }
	    }
	 }
      }
   }
   
   return -1;
}


void
find_node_of_stem(const stem_graph graph, const int seq_id, const metastem_t *stem, int *comp, int *node) {
   int i,j;

   (*comp) = -1;
   (*node) = -1;

   for(i = 0; i < graph->nb_components; i++) {
      j = find_node_of_stem_in_component(graph->components[i], seq_id, stem);
      if(j >= 0) {
	 (*comp) = i;
	 (*node) = j;
	 return;
      }
   }

   return;
}



int
new_component(stem_graph graph) {
   if(graph->max_components == 0) {
      graph->max_components = 10;
      NEW(graph->components, graph_component_t, graph->max_components);
   } else if(graph->nb_components == graph->max_components) {
      graph->max_components += 10;
      RENEW(graph->components, graph_component_t, graph->max_components);
   }

   graph->components[graph->nb_components].nodes = NULL;
   graph->components[graph->nb_components].nb_nodes = 0;
   graph->components[graph->nb_components].max_nodes = 0;
   graph->components[graph->nb_components].nb_cofolded_edges = 0;
   graph->components[graph->nb_components].nb_identity_edges = 0;
   graph->components[graph->nb_components].nb_seqs = 0;
   
   graph->nb_components++;
   
   return (graph->nb_components - 1);
}


void
add_to_node(node_t *node, metastem_t *stem) {
   int m;

   if(node->stems.nb_metastems == 0) {
      NEW(node->stems.metastems, metastem_t, 1);
   } else {
      RENEW(node->stems.metastems, metastem_t, (node->stems.nb_metastems+1));
   }

   node->stems.metastems[node->stems.nb_metastems] = *stem;

   NEW(node->stems.metastems[node->stems.nb_metastems].seq_stems, stem_t, stem->nb_seqs);
   for(m = 0; m < stem->nb_seqs; m++) {
      node->stems.metastems[node->stems.nb_metastems].seq_stems[m] = stem->seq_stems[m];
   }

   node->stems.nb_metastems++;
}

int
add_node_to_component(graph_component comp, int seq_id, metastem_t *stem) {
   int i, save;


   if(comp->max_nodes == 0) {
      comp->max_nodes = 10;

      NEW(comp->nodes, node_t, comp->max_nodes);
      NEW(comp->edges, stem_graph_edge_kind*, (comp->max_nodes - 1));
      for(i = 0; i < (comp->max_nodes-1); i++) {
	 NEW(comp->edges[i], stem_graph_edge_kind, (comp->max_nodes - i - 1));
      }


   } else if(comp->nb_nodes == comp->max_nodes) {

      save = comp->max_nodes - 1;
      comp->max_nodes += 10;
      RENEW(comp->nodes, node_t, comp->max_nodes);
      RENEW(comp->edges, stem_graph_edge_kind*, (comp->max_nodes - 1));
      
      for(i = 0; i < save; i++) {
	 RENEW(comp->edges[i], stem_graph_edge_kind, (comp->max_nodes - i - 1));
      }

      for(i = save; i < (comp->max_nodes-1); i++) {
	 NEW(comp->edges[i], stem_graph_edge_kind, (comp->max_nodes - i - 1));
      }

   }

   comp->nodes[comp->nb_nodes].seq_id = seq_id;
   comp->nodes[comp->nb_nodes].cofolded_arity = 0;
   comp->nodes[comp->nb_nodes].stems.metastems = NULL;
   comp->nodes[comp->nb_nodes].stems.nb_metastems = 0;

   for(i = 0; i < comp->nb_nodes; i++) {
      comp->edges[i][comp->nb_nodes - i - 1] = NOTHING;
   }

   add_to_node(&(comp->nodes[comp->nb_nodes]), stem);
   

   i = 0;
   while((i < comp->nb_nodes) && (comp->nodes[i].seq_id != seq_id)) {
      i++;
   }

   if(i >= comp->nb_nodes) {
      comp->nb_seqs++;
   }

   comp->nb_nodes++;
   

   return (comp->nb_nodes - 1);
}


void
add_edge_to_component(graph_component comp, int node1, int node2, stem_graph_edge_kind kind) {
   int nodet;

   if(node1 > node2) {
      nodet = node1;
      node1 = node2;
      node2 = nodet;
   }

   if(comp->edges[node1][node2 - node1 - 1] == NOTHING) {
      comp->edges[node1][node2 - node1 - 1] = kind;
      
      switch(kind) {
      case COFOLDED_STEMS:
	 comp->nb_cofolded_edges++;
	 comp->nodes[node1].cofolded_arity++;
	 comp->nodes[node2].cofolded_arity++;
	 break;
      case IDENTICAL_STEMS:
	 comp->nb_identity_edges++;
	 break;
      case NOTHING:
	 break;
      }
   }
}

int
merge_components(stem_graph graph, int comp1, int comp2) {
   int i, j, offset, nn, m;
   

   if(comp1 > comp2) {
      i = comp1;
      comp1 = comp2;
      comp2 = i;
   }


   offset = graph->components[comp1].nb_nodes;

   for(i = 0; i < graph->components[comp2].nb_nodes; i++) {
      nn = add_node_to_component(&(graph->components[comp1]), graph->components[comp2].nodes[i].seq_id, &(graph->components[comp2].nodes[i].stems.metastems[0]));

      for(j = 1; j < graph->components[comp2].nodes[i].stems.nb_metastems; j++) {
	 add_to_node(&(graph->components[comp1].nodes[nn]), &(graph->components[comp2].nodes[i].stems.metastems[j]));
      }
      for(m = 0; m < graph->components[comp2].nodes[i].stems.nb_metastems; m++) {
	 if(graph->components[comp2].nodes[i].stems.metastems[m].seq_stems) {
	    DESTROY(graph->components[comp2].nodes[i].stems.metastems[m].seq_stems);
	 }
      }
      DESTROY(graph->components[comp2].nodes[i].stems.metastems);
   }
   DESTROY(graph->components[comp2].nodes);

   for(i = 0; i < (graph->components[comp2].nb_nodes - 1); i++) {
      for(j = i+1; j < graph->components[comp2].nb_nodes; j++) {
	 add_edge_to_component(&(graph->components[comp1]), offset + i, offset + j, graph->components[comp2].edges[i][j - i - 1]);
      }
   }

   for(i = 0; i < (graph->components[comp2].max_nodes - 1); i++) {
      DESTROY(graph->components[comp2].edges[i]);
   }
   DESTROY(graph->components[comp2].edges);

   
   for(i = comp2+1; i < graph->nb_components; i++) {
      graph->components[i-1] = graph->components[i];
   }

   graph->nb_components--;

   
   return comp1;
}













void
compute_component_index(graph_component comp, int sq) {
   double node_index, edge_index, deno;

   if(sq && ((2*comp->nb_seqs - comp->nb_nodes) > 0)) {
      /*node_index = 100.0 * sqrt(0.0 + (2*comp->nb_seqs - comp->nb_nodes)) / sqrt(0.0 + sq);*/
      node_index = 100.0 * (2*comp->nb_seqs - comp->nb_nodes) * (2*comp->nb_seqs - comp->nb_nodes) / (sq*sq);
   } else {
      node_index = 0.0;
   }

   deno = (comp->nb_seqs*(comp->nb_seqs-1))/2 - comp->nb_identity_edges;
   if(deno > 0.0) {
      edge_index = (0.0 + comp->nb_cofolded_edges) / deno;
   } else {
      edge_index = 0.0;
   }

   comp->index = round(node_index * edge_index);


   /*INFO_ "node_index = %.3f edge_index = %.3f index = %.3f\n", node_index, edge_index, comp->index _INFO;*/

}








int
is_almost_father(stem_t *s1, stem_t *s2, int overlap) {
   return ((s1->begin_stop < (s2->begin_start + overlap)) &&
	   (s2->end_stop < (s1->end_start + overlap)));
}



int
is_almost_father_meta(metastem_t *m1, metastem_t *m2, int overlap) {
   int m;

   if(m1->nb_seqs != m2->nb_seqs) {
      return 0;
   }

   for(m = 0; m < m1->nb_seqs; m++) {
      if(!(is_almost_father(&(m1->seq_stems[m]), &(m2->seq_stems[m]), overlap))) {
	 return 0;
      }
   }
   
   return 1;
}



int
are_equiv_stems(metastem_t *m1, metastem_t *m2) {
   const int OVERLAP = 2;
   const int MAX_DIST = 5;

   stem_t *s1, *s2;
   int m;

   if(m1->nb_seqs != m2->nb_seqs) {
      return 0;
   }

   for(m = 0; m < m1->nb_seqs; m++) {
      s1 = &(m1->seq_stems[m]);
      s2 = &(m2->seq_stems[m]);
      
      if(!((have_a_common_base_pair(s1, s2) ||
	    (((s2->begin_start - s1->begin_stop + s1->end_start - s2->end_stop) <= MAX_DIST) && is_almost_father(s1, s2, OVERLAP)) ||
	    (((s1->begin_start - s2->begin_stop + s2->end_start - s1->end_stop) <= MAX_DIST) && is_almost_father(s2, s1, OVERLAP))))) {
	 return 0;
      }
   }
      
   return 1;
}



int
are_equiv_nodes(node_t *n1, node_t *n2) {
   int i,j, k;

   for(i = 0; i < n1->stems.nb_metastems; i++) {
      k = 0;
      for(j = 0; (k==0) && (j < n2->stems.nb_metastems); j++) {
	 if(are_equiv_stems(&(n1->stems.metastems[i]), &(n2->stems.metastems[j]))) {
	    k = 1;
	 }
      }
      if(k == 0) { return 0; }
   }

   return 1;
}





int
is_father(stem_t *s1, stem_t *s2) {
   return is_almost_father(s1, s2, 0);
}

int
are_father_stems(stem_t *s1, stem_t *s2) {
   /*int MAX_DIST = 20;

   return (((s2->begin_start - s1->begin_stop + s1->end_start - s2->end_stop) <= MAX_DIST) && is_father(s1, s2)) ||
   (((s1->begin_start - s2->begin_stop + s2->end_start - s1->end_stop) <= MAX_DIST) && is_father(s2, s1));*/

   return is_father(s1,s2) || is_father(s2,s1);
}


int
are_father_metastems(metastem_t *m1, metastem_t *m2) {
   stem_t *s1, *s2;
   int m;

   if(m1->nb_seqs != m2->nb_seqs) {
      return 0;
   }

   for(m = 0; m < m1->nb_seqs; m++) {
      s1 = &(m1->seq_stems[m]);
      s2 = &(m2->seq_stems[m]);

      if(!are_father_stems(s1,s2)) {
	 return 0;
      }
   }

   return 1;
}



int
are_father_nodes(node_t *n1, node_t *n2) {
   int i,j,k;

   if(n1->seq_id != n2->seq_id) { return 0; }

   for(i = 0; i < n1->stems.nb_metastems; i++) {
      k = 0;
      for(j = 0; (k == 0) && (j < n2->stems.nb_metastems); j++) {
	 if(are_father_metastems(&(n1->stems.metastems[i]), &(n2->stems.metastems[j]))) {
	    k = 1;
	 }
      }
      if(k == 0) { return 0; }
   }

   return 1;
}






int
is_almost_brother(stem_t *s1, stem_t *s2, int overlap) {
   return (s1->end_stop < (s2->begin_start + overlap));
}



int
is_almost_brother_meta(metastem_t *m1, metastem_t *m2, int overlap) {
   stem_t *s1, *s2;
   int m;
   
   if(m1->nb_seqs != m2->nb_seqs) {
      return 0;
   }
   
   for(m = 0; m < m1->nb_seqs; m++) {
      s1 = &(m1->seq_stems[m]);
      s2 = &(m2->seq_stems[m]);
      
      if(!(is_almost_brother(s1,s2, overlap))) {
	 return 0;
      }
   }

   return 1;
}




int
merge_nodes_same_component(stem_graph g, int c1, int(*are_equivalent)(node_t*, node_t*)) {
   int flag = 0;
   int i,j, k;
   int *nodes1 = NULL;
   int nc, nn;

   int m;
   
   /*        INFO_ "EQUIV NODES FOR %i\n",c1 _INFO;FLUSH_OUT;*/
   
   
   NEW(nodes1, int, g->components[c1].nb_nodes);
   for(i = 0; i < g->components[c1].nb_nodes; i++) {
      nodes1[i] = i;
   }
   
   for(i = 0; i < g->components[c1].nb_nodes; i++) {

      for(j = i+1; j < g->components[c1].nb_nodes; j++) {

	 if((g->components[c1].nodes[i].seq_id == g->components[c1].nodes[j].seq_id)
	    && are_equivalent(&(g->components[c1].nodes[i]), &(g->components[c1].nodes[j]))) {
	    flag = 1;
	    nodes1[j] = nodes1[i];
	 }
      }
   }

   if(flag) {
      /*INFO_ "MERGE EQUIV SAME!!!\n" _INFO;*/


      nc = new_component(g);

      /* adding nodes */
      
      /*      INFO_ "ADDING NODES\n" _INFO;FLUSH_OUT;*/
      
      for(i = 0; i < g->components[c1].nb_nodes; i++) {
	 if(nodes1[i] < g->components[c1].nb_nodes) {
	    nn = add_node_to_component(&(g->components[nc]), g->components[c1].nodes[i].seq_id, &(g->components[c1].nodes[i].stems.metastems[0]));
	    
	    /*INFO_ "    nodes1[%i] = %i\n", i, nodes1[i] _INFO;*/
	    
	    for(j = 1; j < g->components[c1].nodes[i].stems.nb_metastems; j++) {
	       add_to_node(&(g->components[nc].nodes[nn]), &(g->components[c1].nodes[i].stems.metastems[j]));
	    }
	    
	    for(j = i+1; j < g->components[c1].nb_nodes; j++) {
	       if(nodes1[i] == nodes1[j]) {
		  for(k = 0; k < g->components[c1].nodes[j].stems.nb_metastems; k++) {
		     add_to_node(&(g->components[nc].nodes[nn]), &(g->components[c1].nodes[j].stems.metastems[k]));
		  }
		  nodes1[j] = g->components[c1].nb_nodes + nn;
	       }
	    }
	    
	    nodes1[i] = g->components[c1].nb_nodes + nn;
	 }
      }
      /**/


      /* adding edges */
      
      /*INFO_ "ADDING EDGES\n" _INFO;FLUSH_OUT;*/
      
      for(i = 0; i < g->components[c1].nb_nodes; i++) {
	 for(j = i+1; j < g->components[c1].nb_nodes; j++) {
	    if(g->components[c1].edges[i][j-i-1] != NOTHING) {
	       
	       /*INFO_ "    edge (%i,%i)\n", nodes1[i], nodes1[j] _INFO;FLUSH_OUT;*/
	       
	       add_edge_to_component(&(g->components[nc]), nodes1[i] - g->components[c1].nb_nodes, nodes1[j] - g->components[c1].nb_nodes, g->components[c1].edges[i][j-i-1]);
	    }
	 }
	 nodes1[i] -= g->components[c1].nb_nodes;
      }
      /**/
      



      /* detruire c1 */
      for(i = 0; i < g->components[c1].nb_nodes; i++) {
	 if(g->components[c1].nodes[i].stems.nb_metastems) {
	    for(m = 0; m < g->components[c1].nodes[i].stems.nb_metastems; m++) {
	       if(g->components[c1].nodes[i].stems.metastems[m].seq_stems) {
		  DESTROY(g->components[c1].nodes[i].stems.metastems[m].seq_stems);
	       }
	    }
	    DESTROY(g->components[c1].nodes[i].stems.metastems);
	 }
      }
      for(i = 0; i < (g->components[c1].max_nodes -1); i++) {
	 DESTROY(g->components[c1].edges[i]);
      }
      DESTROY(g->components[c1].nodes);
      /**/

      /*
      INFO_ "MOVE\n" _INFO;FLUSH_OUT;
      */
      for(i = c1+1; i < g->nb_components; i++) {
	 g->components[i-1] = g->components[i];
      }
      g->nb_components--;
   }

   DESTROY(nodes1);

   return flag;
}









int
merge_nodes(stem_graph g, int c1, int c2, int(*are_equivalent)(node_t*, node_t*)) {
   int flag = 0;
   int i,j;
   int *nodes1 = NULL;
   int *nodes2 = NULL;
   int nc;

   int m;

   NEW(nodes1, int, g->components[c1].nb_nodes);
   for(i = 0; i < g->components[c1].nb_nodes; i++) {
      nodes1[i] = i;
   }
   NEW(nodes2, int, g->components[c2].nb_nodes);
   for(i = 0; i < g->components[c2].nb_nodes; i++) {
      nodes2[i] = -1;
   }
   
   for(i = 0; i < g->components[c1].nb_nodes; i++) {

      for(j = 0; j < g->components[c2].nb_nodes; j++) {

	 if((g->components[c1].nodes[i].seq_id == g->components[c2].nodes[j].seq_id)
	    && are_equivalent(&(g->components[c1].nodes[i]), &(g->components[c2].nodes[j]))) {
	    flag = 1;
	    nodes2[j] = nodes1[i];
	    /*
	    INFO_ "--> nodes2[%i] <-> nodes1[%i]\n", j, i _INFO;
	    */
	 }
      }
   }



   if(flag) {

      nc = new_component(g);

      /* adding nodes */
      /*
      INFO_ "ADDING NODES\n" _INFO;FLUSH_OUT;
      */
      for(i = 0; i < g->components[c1].nb_nodes; i++) {
	 nodes1[i] = add_node_to_component(&(g->components[nc]), g->components[c1].nodes[i].seq_id, &(g->components[c1].nodes[i].stems.metastems[0]));
	 /*
	 INFO_ "    nodes1[%i] = %i\n", i, nodes1[i] _INFO;
	 */
	 for(j = 1; j < g->components[c1].nodes[i].stems.nb_metastems; j++) {
	    add_to_node(&(g->components[nc].nodes[nodes1[i]]), &(g->components[c1].nodes[i].stems.metastems[j]));
	 }
      }

      for(i = 0; i < g->components[c2].nb_nodes; i++) {
	 if(nodes2[i] == -1) {
	    nodes2[i] = add_node_to_component(&(g->components[nc]), g->components[c2].nodes[i].seq_id, &(g->components[c2].nodes[i].stems.metastems[0]));
	    /*
	    INFO_ "    nodes2[%i] = %i N\n", i, nodes2[i] _INFO;
	    */
	    for(j = 1; j < g->components[c2].nodes[i].stems.nb_metastems; j++) {
	       add_to_node(&(g->components[nc].nodes[nodes2[i]]), &(g->components[c2].nodes[i].stems.metastems[j]));
	    }	    
	 } else {
	    nodes2[i] = nodes1[nodes2[i]];
	    /*
	    INFO_ "    nodes2[%i] = %i\n", i, nodes2[i] _INFO;
	    */
	    for(j = 0; j < g->components[c2].nodes[i].stems.nb_metastems; j++) {
	       add_to_node(&(g->components[nc].nodes[nodes2[i]]), &(g->components[c2].nodes[i].stems.metastems[j]));
	    }
	 }
      }
      /**/


      /* adding edges */
      /*
      INFO_ "ADDING EDGES\n" _INFO;FLUSH_OUT;
      */
      for(i = 0; i < g->components[c1].nb_nodes; i++) {
	 for(j = i+1; j < g->components[c1].nb_nodes; j++) {
	    if(g->components[c1].edges[i][j-i-1] != NOTHING) {
	       /*
	       INFO_ "    edge (%i,%i)\n", nodes1[i], nodes1[j] _INFO;FLUSH_OUT;
	       */
	       add_edge_to_component(&(g->components[nc]), nodes1[i], nodes1[j], g->components[c1].edges[i][j-i-1]);
	    }
	 }
      }

      for(i = 0; i < g->components[c2].nb_nodes; i++) {
	 for(j = i+1; j < g->components[c2].nb_nodes; j++) {
	    if(g->components[c2].edges[i][j-i-1] != NOTHING) {
	       /*
	       INFO_ "    edge (%i,%i)\n", nodes2[i], nodes2[j] _INFO;FLUSH_OUT;
	       */
	       add_edge_to_component(&(g->components[nc]), nodes2[i], nodes2[j], g->components[c2].edges[i][j-i-1]);
	    }
	 }
      }
      /**/
      



      /* detruire c1 et c2 */
      for(i = 0; i < g->components[c1].nb_nodes; i++) {
	 if(g->components[c1].nodes[i].stems.nb_metastems) {
	    for(m = 0; m < g->components[c1].nodes[i].stems.nb_metastems; m++) {
	       if(g->components[c1].nodes[i].stems.metastems[m].seq_stems) {
		  DESTROY(g->components[c1].nodes[i].stems.metastems[m].seq_stems);
	       }
	    }

	    DESTROY(g->components[c1].nodes[i].stems.metastems);
	 }

	 

      }
      for(i = 0; i < (g->components[c1].max_nodes -1); i++) {
	 DESTROY(g->components[c1].edges[i]);
      }
      DESTROY(g->components[c1].nodes);

      for(i = 0; i < g->components[c2].nb_nodes; i++) {
	 if(g->components[c2].nodes[i].stems.nb_metastems) {
	    for(m = 0; m < g->components[c2].nodes[i].stems.nb_metastems; m++) {
	       if(g->components[c2].nodes[i].stems.metastems[m].seq_stems) {
		  DESTROY(g->components[c2].nodes[i].stems.metastems[m].seq_stems);
	       }
	    }
	    DESTROY(g->components[c2].nodes[i].stems.metastems);
	 }
      }
      for(i = 0; i < (g->components[c2].max_nodes -1); i++) {
	 DESTROY(g->components[c2].edges[i]);
      }
      DESTROY(g->components[c2].nodes);
      /**/

      /*
      INFO_ "MOVE\n" _INFO;FLUSH_OUT;
      */
      for(i = c1+1; i < g->nb_components; i++) {
	 g->components[i-1] = g->components[i];
      }
      g->nb_components--;
      if(c1 < c2) {
	 c2--;
      }
      /*
      INFO_ "MOVE\n" _INFO;FLUSH_OUT;
      */
      for(i = c2+1; i < g->nb_components; i++) {
	 g->components[i-1] = g->components[i];
      }
      g->nb_components--;
   }

   DESTROY(nodes1);
   DESTROY(nodes2);

   return flag;
}






int
kill_conflicting_nodes(stem_graph g, int comp, int nb_seqs) {
   int i, j;
   int *to_kill = NULL;
   int *count_edges = NULL;
   int ar, nc;
   int dobreak;
   

   NEW(to_kill, int, g->components[comp].nb_nodes);
   for(i = 0; i < g->components[comp].nb_nodes; i++) {
      to_kill[i] = 0;
   }

   dobreak = 0;
   ar = 1;
   while((ar <= (nb_seqs / 4)) && !dobreak) {
      i = 0; 
      while((i < g->components[comp].nb_nodes) && !dobreak) {
	 if(!to_kill[i]) {
	    j = i+1;
	    while((j < g->components[comp].nb_nodes) && !dobreak) {
	       if(!to_kill[j]) {
		  if(g->components[comp].nodes[i].seq_id == g->components[comp].nodes[j].seq_id) {
		     to_kill[i] |= (g->components[comp].nodes[i].cofolded_arity <= ar) && (g->components[comp].nodes[j].cofolded_arity >= (ar+1));
		     
		     to_kill[j] |= (g->components[comp].nodes[j].cofolded_arity <= ar) && (g->components[comp].nodes[i].cofolded_arity >= (ar+1));
		     
		     dobreak = (to_kill[i] || to_kill[j]);
		  }
	       }
	       j++;
	    }
	 }
	 i++;
      }
      ar++;
   }



   if(dobreak) {
      /* remove killed !!!! */


      NEW(count_edges, int, g->components[comp].nb_nodes);
      
      dobreak = 1;
      while(dobreak) {
	 
	 dobreak = 0;
	 
	 for(i = 0; i < g->components[comp].nb_nodes; i++) {
	    count_edges[i] = 0;
	 }
	 
	 for(i = 0; i < g->components[comp].nb_nodes; i++) {
	    if(to_kill[i] == 0) {
	       for(j = i+1; j < g->components[comp].nb_nodes; j++) {
		  if(to_kill[j] == 0) {
		     if(g->components[comp].edges[i][j-i-1] == COFOLDED_STEMS) {
			count_edges[i]++;
			count_edges[j]++;
		     }
		  }
	       }
	    }
	 }
	 
	 for(i = 0; i < g->components[comp].nb_nodes; i++) {
	    if((to_kill[i] == 0) && (count_edges[i] == 0)) {
	       to_kill[i] = 1;
	       dobreak = 1;
	    }
	 }
      }
      
      DESTROY(count_edges);


      j = 0;
      for(i = 0; i < g->components[comp].nb_nodes; i++) {
	 if(to_kill[i]) {
	    j++;
	    /*INFO_ "COMPONENT %i NODE TO KILL %i\n", comp, i _INFO;*/
	 }
      }

      if((g->components[comp].nb_nodes - j) == 0) {
	 /*INFO_ "COMPONENT %i KILLED\n", comp _INFO;*/
	 DESTROY(g->components[comp].nodes);
	 g->components[comp] = g->components[g->nb_components-1];
	 g->nb_components--;
	 return 1;
      } else {

	 nc = new_component(g);
	 for(i = 0; i < g->components[comp].nb_nodes; i++) {
	    if(!to_kill[i]) {
	       to_kill[i] = 1+add_node_to_component(&(g->components[nc]), g->components[comp].nodes[i].seq_id, &(g->components[comp].nodes[i].stems.metastems[0]));
	       for(j = 1; j < g->components[comp].nodes[i].stems.nb_metastems; j++) {
		  add_to_node(&(g->components[nc].nodes[to_kill[i]-1]), &(g->components[comp].nodes[i].stems.metastems[j]));
	       }
	    } else {
	       to_kill[i] = 0;
	    }
	 }
	 
	 
	 for(i = 0; i < g->components[comp].nb_nodes; i++) {
	    if(to_kill[i]) {
	       for(j = i+1; j < g->components[comp].nb_nodes; j++) {
		  if(to_kill[j]) {
		     add_edge_to_component(&(g->components[nc]), to_kill[i]-1, to_kill[j]-1, g->components[comp].edges[i][j-i-1]);
		  }
	       }
	    }
	 }
	 
	 DESTROY(g->components[comp].nodes);
	 g->components[comp] = g->components[g->nb_components-1];
	 g->nb_components--;
      }
   }
   
   DESTROY(to_kill);

   return dobreak;
}



stem_graph
build_stem_graph(const sankoff_result sankoff_res, const metastem_t_list *stems, const metasequence *seqs, const int nb_seqs, int **id) {
   stem_graph res = NULL;
   int comp1, comp2, node1, node2;
   sankoff_result_pair_t srt;
   int i, j, k, l, m, sq, s;
   short_stack shifts = NULL;
   int finished, dobreak;
   int idi;
   int *sqi = NULL;
   
   NEW(sqi, int, nb_seqs);
   for(i = 0; i < nb_seqs; i++) {
      sqi[i] = 0;
   }
   for(i = 0; i < (nb_seqs-1); i++) {
      for(j = i+1; j < nb_seqs; j++) {
	 srt = SANKOFF_GET_FOLDING_PAIR(sankoff_res,i,j);
	 if(srt.nb_stems) {
	    sqi[i] = sqi[j] = 1;
	 }
      }
   }
   sq = 0;
   for(i = 0; i < nb_seqs; i++) {
      if(sqi[i]) {
	 sq++;
      }
   }
   


   DESTROY(sqi);
   

   NEW(res, stem_graph_t, 1);
   res->nb_components = 0;
   res->max_components = 0;




   /* simple graph with cofolded edges */
   for(i = 0; i < (nb_seqs-1); i++) {
      for(j = i+1; j < nb_seqs; j++) {
	 
	 srt = SANKOFF_GET_FOLDING_PAIR(sankoff_res,i,j);	 


	 for(k = 0; k < srt.nb_stems; k++) {

	    find_node_of_stem(res, i, &(srt.stems1[k]), &comp1, &node1);
	    find_node_of_stem(res, j, &(srt.stems2[k]), &comp2, &node2);
	    

	    if(comp1 >= 0) {
	       if(comp2 >= 0) {
		  if(comp1 != comp2) {
		     comp1 = comp2 = merge_components(res, comp1, comp2);
		     node1 = find_node_of_stem_in_component(res->components[comp1], i, &(srt.stems1[k]));
		     node2 = find_node_of_stem_in_component(res->components[comp2], j, &(srt.stems2[k]));
		  }
		  
		  add_edge_to_component(&(res->components[comp1]), node1, node2, COFOLDED_STEMS);

	       } else {
		  comp2 = comp1;
		  node2 = add_node_to_component(&(res->components[comp1]), j, &(srt.stems2[k]));

		  add_edge_to_component(&(res->components[comp1]), node1, node2, COFOLDED_STEMS);
	       }
	    } else {
	       if(comp2 >= 0) {
		  comp1 = comp2;
		  node1 = add_node_to_component(&(res->components[comp2]), i, &(srt.stems1[k]));
		  add_edge_to_component(&(res->components[comp2]), node2, node1, COFOLDED_STEMS);
	       } else {
		  comp1 = comp2 = new_component(res);
		  node1 = add_node_to_component(&(res->components[comp1]), i, &(srt.stems1[k]));
		  node2 = add_node_to_component(&(res->components[comp2]), j, &(srt.stems2[k]));
		  
		  add_edge_to_component(&(res->components[comp1]), node1, node2, COFOLDED_STEMS);
	       }
	    }
	 }
      }
   }
   /***/




      /* merging components with equiv stems */
      finished = 0;
      while(!finished) {
	 finished = 1;
	 dobreak = 0;
	 
	 i = 0;
	 while((i < res->nb_components) && !dobreak) {
	    
	    if(merge_nodes_same_component(res, i, are_equiv_nodes)) {
	       finished = 0;
	       dobreak = 1;  
	    }
	    
	    j = i + 1;
	    while((j < res->nb_components) && !dobreak) {
	       if(merge_nodes(res, i, j, are_equiv_nodes)) {
		  finished = 0;
		  dobreak = 1;
	       }
	       j++;
	    }
	    i++;
	 }
      }
      /**/



#ifndef CARNAC_OLD_MODE
   for(i = 0; i < (nb_seqs-1); i++) {
      for(j = i+1; j < nb_seqs; j++) {
	 
	 srt = SANKOFF_GET_FOLDING_PAIR(sankoff_res,i,j);

	 for(k = 0; k < srt.nb_istems; k++) {

	    find_node_of_stem(res, i, &(srt.istems1[k]), &comp1, &node1);
	    find_node_of_stem(res, j, &(srt.istems2[k]), &comp2, &node2);
	    
	    if(comp1 >= 0) {
	       if(comp2 >= 0) {
		  /*
		  if(comp1 != comp2) {
		     comp1 = comp2 = merge_components(res, comp1, comp2);
		     node1 = find_node_of_stem_in_component(res->components[comp1], i, &(srt.istems1[k]));
		     node2 = find_node_of_stem_in_component(res->components[comp1], j, &(srt.istems2[k]));
		  }
		  */
		  if(comp1 == comp2) {
		      add_edge_to_component(&(res->components[comp1]), node1, node2, IDENTICAL_STEMS);
		  }
		  
	       } else {
		  /*
		  comp2 = comp1;
		  node2 = add_node_to_component(&(res->components[comp1]), j, &(srt.istems2[k]));
		  
		  add_edge_to_component(&(res->components[comp1]), node1, node2, IDENTICAL_STEMS);
		  */
	       }
	    } else {
	       if(comp2 >= 0) {
		  /*
		  comp1 = comp2;
		  node1 = add_node_to_component(&(res->components[comp2]), i, &(srt.istems1[k]));
		  add_edge_to_component(&(res->components[comp2]), node2, node1, IDENTICAL_STEMS);
		  */
	       } else {
		  /*
		  comp1 = comp2 = new_component(res);
		  node1 = add_node_to_component(&(res->components[comp1]), i, &(srt.istems1[k]));
		  node2 = add_node_to_component(&(res->components[comp1]), j, &(srt.istems2[k]));
		  
		  add_edge_to_component(&(res->components[comp1]), node1, node2, IDENTICAL_STEMS);
		  */
	       }
	    }	    
	 }
      }
   }
#endif


   /* identity edges */
   for(i = 0; i < res->nb_components; i++) {
      for(j = 0; j < res->components[i].nb_nodes; j++) {
	 for(k = j+1; k < res->components[i].nb_nodes; k++) {
	    if(res->components[i].nodes[j].seq_id != res->components[i].nodes[k].seq_id) {
	       for(l = 0; l < res->components[i].nodes[j].stems.nb_metastems; l++) {
		  for(m = 0; m < res->components[i].nodes[k].stems.nb_metastems; m++) {


		     adjust_meta(*(seqs[res->components[i].nodes[j].seq_id]), res->components[i].nodes[j].stems.metastems[l], *(seqs[res->components[i].nodes[k].seq_id]), res->components[i].nodes[k].stems.metastems[m], &shifts);

		     idi = id[MIN(res->components[i].nodes[j].seq_id, res->components[i].nodes[k].seq_id)][MAX(res->components[i].nodes[j].seq_id, res->components[i].nodes[k].seq_id) - MIN(res->components[i].nodes[j].seq_id, res->components[i].nodes[k].seq_id) - 1];
		     
		     s = 0; 
		     while((s < STACK_SIZE(shifts)) && do_covar_meta(seqs[res->components[i].nodes[j].seq_id], &(res->components[i].nodes[j].stems.metastems[l]), seqs[res->components[i].nodes[k].seq_id], &(res->components[i].nodes[k].stems.metastems[m]), STACK_VALUE_AT(shifts, s), idi)) {
			s++;
		     }

		     if(s < STACK_SIZE(shifts)) {
			add_edge_to_component(&(res->components[i]), j, k, IDENTICAL_STEMS);
		     }

		     DESTROY_STACK(shifts);

		  }
	       }
	    }
	 }
      }
   }
   /**/





   /* merging nodes with father stems */
   finished = 0;
   while(!finished) {
      finished = 1;
      dobreak = 0;
      i = 0;
      while((i < res->nb_components) && !dobreak) {
	 if(merge_nodes_same_component(res, i, are_father_nodes)) {
	    dobreak = 1;
	    finished = 0;
	 }
	 i++;
      }
   }
   /**/


   /* removing conflicting nodes */
   finished = 0;
   while(!finished) {
      dobreak = 0;
      finished = 1;

      i = 0;
      while((i < res->nb_components) && !dobreak) {
	 if(kill_conflicting_nodes(res, i, nb_seqs)) {
	    dobreak = 1;
	    finished = 0;
	 }
	 i++;
      }
   }
   /**/

   

   /* compute index */
   for(i = 0; i < res->nb_components; i++) {
      if(nb_seqs > 2) {
	 compute_component_index(&(res->components[i]), sq);
      } else {
	 res->components[i].index = 100.0;
      }

   }
   /**/

   
   return res;
}





int
same_stem(stem_t *s1, stem_t *s2) {
   return ((s1->begin_start == s2->begin_start) &&
	   (s1->begin_stop == s2->begin_stop) &&
	   (s1->end_start == s2->end_start) &&
	   (s1->end_stop == s2->end_stop));
}


int
same_metastem(metastem_t *m1, metastem_t *m2) {
   int m;

   if(m1->nb_seqs != m2->nb_seqs) {
      return 0;
   }

   for(m = 0; m < m1->nb_seqs; m++) {
      if(!same_stem(&(m1->seq_stems[m]), &(m2->seq_stems[m]))) {
	 return 0;
      }
   }

   return 1;
}


int
is_almost_compatible(stem_t *stem, stem_t_list list) {
   int OVERLAP = CARNAC_GRAPH_TOLERATE_OVERLAP;
   int i;

   i = 0;
   while((i < list->nb_stems) &&
	 !same_stem(stem, &(list->stems[i])) &&
	 (((is_almost_father(stem, &(list->stems[i]), OVERLAP)) ||
	   (is_almost_brother(stem, &(list->stems[i]), OVERLAP)) ||
	   (is_almost_father(&(list->stems[i]), stem, OVERLAP)) ||
	   (is_almost_brother(&(list->stems[i]), stem, OVERLAP))))) { 
      i++;
   }
   
   return (i >= list->nb_stems);
}

int
is_almost_compatible_meta(metastem_t *meta, metastem_t_list list) {
   int OVERLAP = CARNAC_GRAPH_TOLERATE_OVERLAP;
   int i;

   i = 0;
   while((i < list->nb_metastems) &&
	 !same_metastem(meta, &(list->metastems[i])) &&
	 (((is_almost_father_meta(meta, &(list->metastems[i]), OVERLAP)) ||
	   (is_almost_brother_meta(meta, &(list->metastems[i]), OVERLAP)) ||
	   (is_almost_father_meta(&(list->metastems[i]), meta, OVERLAP)) ||
	   (is_almost_brother_meta(&(list->metastems[i]), meta, OVERLAP))))) { 
      i++;
   }
   
   return (i >= list->nb_metastems);
}







metastem_t_list_t
*final_structures(stem_graph graph, int nb_seqs) {
   int i, j, k, l, finished, last;
   graph_component_t temp;
   int sid;
   metastem_t_list_t *res = NULL;
   metastem_t tstem;

   int m;

   /* sorting components */
   finished = 0;
   last = graph->nb_components - 1;
   while(!finished) {
      finished = 1;
      for(i = 0; i < last; i++) {
	 if(graph->components[i].index < graph->components[i+1].index) {

	    temp = graph->components[i];
	    graph->components[i] = graph->components[i+1];
	    graph->components[i+1] = temp;
	    finished = 0;
	 } else if ((graph->components[i].index == graph->components[i+1].index)
		    && (graph->components[i].nb_cofolded_edges < graph->components[i+1].nb_cofolded_edges)) {

	    temp = graph->components[i];
	    graph->components[i] = graph->components[i+1];
	    graph->components[i+1] = temp;
	    finished = 0;
	 } else if (graph->components[i].nb_cofolded_edges == graph->components[i+1].nb_cofolded_edges) {
	    
	    j = 0;
	    m = 0;
	    for(k = 0; k < graph->components[i].nb_nodes; k++) {
	       for(l = 0; l < graph->components[i].nodes[k].stems.nb_metastems; l++) {
		     j = MAX(j, (graph->components[i].nodes[k].stems.metastems[l].seq_stems[0].begin_stop - graph->components[i].nodes[k].stems.metastems[l].seq_stems[0].begin_start));
	       }
	    }
	    
	    for(k = 0; k < graph->components[i+1].nb_nodes; k++) {
	       for(l = 0; l < graph->components[i+1].nodes[k].stems.nb_metastems; l++) {
		  if(j < (graph->components[i+1].nodes[k].stems.metastems[l].seq_stems[0].begin_stop - graph->components[i+1].nodes[k].stems.metastems[l].seq_stems[0].begin_start)) {
		     m = 1;
		  }
	       }
	    }
	    
	    if(m == 0) {
	       temp = graph->components[i];
	       graph->components[i] = graph->components[i+1];
	       graph->components[i+1] = temp;
	       finished = 0;
	    }

	 }
      }

      last--;
   }
   /**/



   /* sorting stems in nodes */
   for(i = 0; i < graph->nb_components; i++) {
      for(j = 0; j < graph->components[i].nb_nodes; j++) {
	 
	 last = graph->components[i].nodes[j].stems.nb_metastems-1;
	 finished = 0;
	 while(!finished && (last >= 1)) {
	    finished = 1;
	    for(k = 1; k <= last; k++) {
	       if(graph->components[i].nodes[j].stems.metastems[k].energy > graph->components[i].nodes[j].stems.metastems[k-1].energy) {
		  tstem = graph->components[i].nodes[j].stems.metastems[k];
		  graph->components[i].nodes[j].stems.metastems[k] = graph->components[i].nodes[j].stems.metastems[k-1];
		  graph->components[i].nodes[j].stems.metastems[k-1] = tstem;
		  finished = 0;
	       }
	       
	    }
	    last--;
	 }
      }
   }
   /**/




   /*
   INFO_ "%i connex components:\n", graph->nb_components _INFO;
   for(i = 0; i < graph->nb_components; i++) {
      INFO_ "  component %i index = %.2f co = %i id = %i n = %i ns = %i\n", i, graph->components[i].index, graph->components[i].nb_cofolded_edges, graph->components[i].nb_identity_edges, graph->components[i].nb_nodes, graph->components[i].nb_seqs _INFO;
      for(j = 0; j < graph->components[i].nb_nodes; j++) {
	 INFO_ "     seq %i arity = %i\n", graph->components[i].nodes[j].seq_id, graph->components[i].nodes[j].cofolded_arity _INFO;
	 for(k = 0; k < graph->components[i].nodes[j].stems.nb_metastems; k++) {
	    INFO_ "                      " _INFO;
	    println_metastem(&(graph->components[i].nodes[j].stems.metastems[k]), NULL);
	 }
      }
   }
   */
      



   for(i = 0; i < graph->nb_components; i++) {
      for(j = 0; j < graph->components[i].nb_nodes; j++) {
	 for(k = 0; k < graph->components[i].nodes[j].stems.nb_metastems; k++) {
	    graph->components[i].nodes[j].stems.metastems[k].folded_id = (i+1);
	    for(l = 0; l < graph->components[i].nodes[j].stems.metastems[k].nb_seqs; l++) {
	       graph->components[i].nodes[j].stems.metastems[k].seq_stems[l].folded_id = graph->components[i].nodes[j].stems.metastems[k].folded_id;
	    }
	 }
      }
   }


   

   NEW(res, metastem_t_list_t, nb_seqs);
   for(i = 0; i < nb_seqs; i++) {
      res[i].nb_metastems = 0;
      res[i].metastems = NULL;
   }
   
   i = 0;
   while((i < graph->nb_components) && (graph->components[i].index >= CARNAC_INDEX_THRESHOLD1)) {
      for(j = 0; j < graph->components[i].nb_nodes; j++) {
	    
	 sid = graph->components[i].nodes[j].seq_id;

	 if(graph->components[i].nodes[j].cofolded_arity > CARNAC_LIMIT_FREQUENCY) {

	    for(k = 0; k < graph->components[i].nodes[j].stems.nb_metastems; k++) {

	       if(is_almost_compatible_meta(&(graph->components[i].nodes[j].stems.metastems[k]), &(res[sid]))) {

		  if(res[sid].nb_metastems == 0) {
		     NEW(res[sid].metastems, metastem_t, 1);
		  } else {
		     RENEW(res[sid].metastems, metastem_t, (res[sid].nb_metastems+1));
		  }
		  
		  
		  res[sid].metastems[res[sid].nb_metastems] = graph->components[i].nodes[j].stems.metastems[k];
		  NEW(res[sid].metastems[res[sid].nb_metastems].seq_stems, stem_t, graph->components[i].nodes[j].stems.metastems[k].nb_seqs);
		  for(m = 0; m < graph->components[i].nodes[j].stems.metastems[k].nb_seqs; m++) {
		     res[sid].metastems[res[sid].nb_metastems].seq_stems[m] = graph->components[i].nodes[j].stems.metastems[k].seq_stems[m];
		  }

		  res[sid].nb_metastems++;
	       }
	    }
	 }
      }
      i++;
   }

   i = 0;
   while((i < graph->nb_components) && (graph->components[i].index >= CARNAC_INDEX_THRESHOLD2)) {
      for(j = 0; j < graph->components[i].nb_nodes; j++) {

	 sid = graph->components[i].nodes[j].seq_id;

	 if(graph->components[i].nodes[j].cofolded_arity <= CARNAC_LIMIT_FREQUENCY) {

	    for(k = 0; k < graph->components[i].nodes[j].stems.nb_metastems; k++) {	    
	       if(is_almost_compatible_meta(&(graph->components[i].nodes[j].stems.metastems[k]), &(res[sid]))) {
		     
		  if(res[sid].nb_metastems == 0) {
		     NEW(res[sid].metastems, metastem_t, 1);
		  } else {
		     RENEW(res[sid].metastems, metastem_t, (res[sid].nb_metastems+1));
		  }

		  res[sid].metastems[res[sid].nb_metastems] = graph->components[i].nodes[j].stems.metastems[k];
		  NEW(res[sid].metastems[res[sid].nb_metastems].seq_stems, stem_t, graph->components[i].nodes[j].stems.metastems[k].nb_seqs);
		  for(m = 0; m < graph->components[i].nodes[j].stems.metastems[k].nb_seqs; m++) {
		     res[sid].metastems[res[sid].nb_metastems].seq_stems[m] = graph->components[i].nodes[j].stems.metastems[k].seq_stems[m];
		  }
		  res[sid].nb_metastems++;
	       }
	    }
	 }
      }
      
      i++;
   }
   


   return res;
}
