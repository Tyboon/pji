#ifdef HAVE_CONFIG_H
    #include "config.h"
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "stack.h"
#include "opts.h"
#include "display.h"

#include <assert.h>




/*************************************************/
/* pile de deux entiers                          */
/*************************************************/


/*Empile un �l�ment � la pile*/
void push(stack * p, int x,int y){
  pair element;
  (p->top)++; 
  element.x=x;
  element.y=y;
  p->elements[p->top]=element;
}

/*D�pile un �l�ment a la pile*/
void pop( stack * p,int * x,int * y){
  pair element;
  element=p->elements[p->top];   
  *x=element.x;
  *y=element.y;
  (p->top)--; 
}

/*Test si la pile est vide*/
int is_empty_stack(stack * p){
  return (p->top==-1); 
}

/*Initialise la pile*/
void init_stack(stack * p, int size){
   NEW(p->elements, pair, size);
   p->top=-1;
}
 
void display_stack(stack * p){
  pair element; 
  int i=p->top;
  printf("******\n");
  for (i=p->top; i>=0;i--){
    element=p->elements[i]; 
    printf("%d %d \n", element.x, element.y);
  }
  printf("******\n");
}

void free_stack(stack *s){
  DESTROY(s->elements);
  DESTROY(s);
}


/***********************************************/
/* pile quatre elements                        */
/***********************************************/


/*Empile un �l�ment � la pile*/
void quadruple_push(quadruple_stack * p, int x,int y,int z, int t){
  quadruplet element;
  (p->top)++; 
  element.x=x;
  element.y=y;
  element.z=z;
  element.t=t;
  p->elements[p->top]=element;
 }

/*D�pile un �l�ment a la pile*/
void quadruple_pop( quadruple_stack * p,int * x,int * y, int *z, int *t){
  quadruplet element;
  element=p->elements[p->top];   
  *x=element.x;
  *y=element.y;
  *z=element.z;
  *t=element.t;
  (p->top)--; 
}

/*Test si la pile est vide*/
int is_empty_quadruple_stack(quadruple_stack * p){
  return (p->top==-1); 
}

/*Initialise la pile*/
void init_quadruple_stack(quadruple_stack * p, int size){
   NEW(p->elements, quadruplet, size);
   p->top=-1;
}

void display_quadruple_stack(quadruple_stack * p){
   quadruplet element; 
   int i = p->top;

   INFO_ "******\n" _INFO;
   for (i = p->top; i >= 0;i--){
      element = p->elements[i]; 
      INFO_ "%d %d %d %d\n", element.x, element.y,element.z, element.t _INFO;
   }

   INFO_ "******\n" _INFO;
}

void free_quadruple_stack(quadruple_stack *s){
   DESTROY(s->elements);
   DESTROY(s);
}
