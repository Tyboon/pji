#ifndef GRAPH_H_
#define GRAPH_H_

#include "carnac_stems.h"


typedef struct{
   int weight;
   int targetX;
   int targetY;
} edge;


typedef struct {
   edge *elements; 
   int current_edge;
} vertex;



void update_edge(vertex *v, edge x);

/*Empile un �l�ment � la pile*/
void push_edge(vertex * v, edge x);

/*D�pile un �l�ment a la pile*/
void get_edge( const vertex * v, edge * x, int d);

/*Teste si la pile est vide*/
int end_of_edge_stack(vertex * v);

/*Initialise la pile*/
void init_edge_stack(vertex  * v, int size);

void reset_edge_stack(vertex * v);

void display_alignment_graph(vertex ** alignment_graph, int k, int l);

void free_edge_stack(vertex v);

void free_graph(vertex ** alignment_graph, int n, int m);

#endif /*GRAPH_H_*/
