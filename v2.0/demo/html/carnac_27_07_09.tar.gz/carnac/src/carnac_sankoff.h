#ifndef __ARNICA_CARNAC_SANKOFF_H__
#define __ARNICA_CARNAC_SANKOFF_H__


#include "metasequence.h"
#include "carnac_stems.h"
#include "carnac_metastems.h"





typedef struct {
   metastem_t *stems1;
   metastem_t *stems2;
      metastem_t *istems1;
      metastem_t *istems2;
      int nb_istems;
   int nb_stems;
   int energy1;
   int energy2;
} sankoff_result_pair_t;


typedef sankoff_result_pair_t *sankoff_result_pair;

typedef sankoff_result_pair_t **sankoff_result;



/*#define SANKOFF_GET_FOLDING_PAIR(Sank,Si,Sj) ( ((Si)<(Sj))?((Sank)[(Si)][(Sj)-(Si)-1]):((Sank)[(Sj)][(Si)-(Sj)-1]) )*/
#define SANKOFF_GET_FOLDING_PAIR(Sank,Si,Sj) (Sank)[MIN((Si),(Sj))][MAX((Sj),(Si)) - MIN((Si),(Sj)) - 1]


extern sankoff_result
sankoff_all(const metasequence *rna, const int nb_meta, const metastem_t_list *stems, int **id);




#endif
