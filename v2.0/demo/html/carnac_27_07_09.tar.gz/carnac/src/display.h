
#ifndef __ARNICA_DISPLAY_H__
#define __ARNICA_DISPLAY_H__

#define DISPLAY_OUT stdout
#define DISPLAY_ERR stderr

#define INFO_ if(OPTS_quiet == 0) { fprintf(DISPLAY_OUT,
#define _INFO );} else {}


#define FLUSH_OUT fflush(DISPLAY_OUT)



/*#define REWIND(A) fflush(DISPLAY_OUT);fprintf(DISPLAY_OUT, "\033[%iD", A)*/
#define REWIND(A) fprintf(DISPLAY_OUT, "\033[%iD", A)


#ifdef WITH_TRACE
#define WARN_ fprintf(DISPLAY_OUT,"warning ('%s', line %i): ",__FILE__,__LINE__);fprintf(DISPLAY_OUT,
#else
#define WARN_ fprintf(DISPLAY_OUT,"warning: ");fprintf(DISPLAY_OUT,
#endif
#define _WARN ); fflush(DISPLAY_OUT)

#ifdef WITH_TRACE
#define ERROR_ fprintf(DISPLAY_ERR,"error ('%s', line %i): ",__FILE__,__LINE__);fprintf(DISPLAY_ERR,
#else
#define ERROR_ fprintf(DISPLAY_ERR,"error: ");fprintf(DISPLAY_ERR,
#endif
#define _ERROR )


#endif
