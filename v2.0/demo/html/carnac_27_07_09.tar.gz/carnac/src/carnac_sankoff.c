#ifdef HAVE_CONFIG_H
    #include "config.h"
#endif
#include "carnac_sankoff.h"


#include "carnac_blocks.h"
#include "carnac_metaseq.h"
#include "carnac_compatible.h"
#include "carnac_sankoff_stems.h"
#include "carnac_sankoff_bases.h"



#include "display.h"
#include "opts.h"

#include <stdlib.h>
#include <assert.h>

#ifdef _OPENMP
        #include <omp.h>
#endif





void
do_a_sankoff(sankoff_result res, const int i, const int j, const metasequence *meta, const metastem_t_list *ostems, int **id) {
   int k, l, m, n;



   stem_open_index_t *open_atA;
   stem_open_index_t *open_atB;
   stem_close_index_t *close_atA;
   stem_close_index_t *close_atB;


   block_list blocks = NULL;
   cofoldable_t **compatibles = NULL;


   metastem_list stemsA;
   metastem_list stemsB;
   short_stack **istemableA;
   short_stack **istemableB;

   /*
   short *is_not_singleA;
   short *is_not_singleB;
   */

   sankoff_result_pair_t *srpt;



   istemableA = NULL;
   istemableB = NULL;




   /* finding conserved blocks */

#ifdef _OPENMP
#else
   INFO_ "BLOCK LIST FOR metaseq %i and metaseq %i\n", i, j _INFO;
   FLUSH_OUT;
#endif
 
   blocks = blocks_between_meta(meta[i], meta[j]);

   
   INFO_ "BLOCK LIST FOR metaseq %i and metaseq %i : %i elements\n", i, j, blocks->nb_blocks _INFO;

#ifdef _OPENMP
#else
   for(m = 0; m < blocks->nb_blocks; m++) {
      println_meta_block(&(blocks->blocks[m]), meta[i], meta[j]);
   }
#endif	 

   FLUSH_OUT;
	 
   /**/	 
	 
   /* finding compatible stems */
   /*   NEW(is_not_singleA, short, ostems[i]->nb_metastems);*/
   for(k = 0; k < ostems[i]->nb_metastems; k++) {
      ostems[i]->metastems[k].is_a_single_stem = 1;
	 /*      is_not_singleA[k] = 0;*/
   }
   /*   NEW(is_not_singleB, short, ostems[j]->nb_metastems);*/
   for(k = 0; k < ostems[j]->nb_metastems; k++) {
      ostems[j]->metastems[k].is_a_single_stem = 1;
      /*      is_not_singleB[k] = 0;*/
   }


#ifdef _OPENMP
#else
   INFO_ "COMPATIBLE STEMS FOR metaseq %i and metaseq %i\n", i, j _INFO;
   FLUSH_OUT;
#endif
	 

   compatibles = compatible_stems_meta(*(meta[i]), *(ostems[i]), *(meta[j]), *(ostems[j]), blocks, id[i][j-i-1]);


   for(k = 0; k < ostems[i]->nb_metastems; k++) {

      for(l = 0; l < ostems[j]->nb_metastems; l++) {
	 if(COMPATIBLE(compatibles[k][l]) && DO_COVARIATE(compatibles[k][l])) {
	    /*		  
#ifdef _OPENMP
#else
	    print_metastem(&(ostems[i]->metastems[k]), meta[i]);
	    INFO_ "\t\tvs\t\t" _INFO;
	    println_metastem(&(ostems[j]->metastems[l]), meta[j]);
#endif
	    */  	  

	    /* for this pair only */
	    /*	    is_not_singleA[k] = is_not_singleB[l] = 1;*/
	    
	    /* global */
	    ostems[i]->metastems[k].is_a_single_stem = ostems[j]->metastems[l].is_a_single_stem = 0;
	 }
      }
   }
   /**/

   destroy_block_list(blocks);


   /* filtering compatibles stems */
   m = 1;
   for(k = 0; k < ostems[i]->nb_metastems; k++) {
      /*      if(is_not_singleA[k]) {
	 is_not_singleA[k] = m++;
	 }*/
      if(!ostems[i]->metastems[k].is_a_single_stem) {
	 m++;
      }
   }
   stemsA.nb_metastems = (m-1);

   if((m-1) > 0) {


      NEW(stemsA.metastem_id, int, (m-1));
      m = 0;
      for(k = 0; k < ostems[i]->nb_metastems; k++) {
	 /*	 if(is_not_singleA[k]) {*/
	 if(!ostems[i]->metastems[k].is_a_single_stem) {
	    stemsA.metastem_id[m++] = k;
	 }
      }

      /*      DESTROY(is_not_singleA);*/

      n = 1;
      for(k = 0; k < ostems[j]->nb_metastems; k++) {
	 /*	 if(is_not_singleB[k]) {
	    is_not_singleB[k] = n++;
	 }
	 */
	 if(!ostems[j]->metastems[k].is_a_single_stem) {
	    n++;
	 }	 
      }
      stemsB.nb_metastems = (n-1);


      if((n-1) > 0) {


	 NEW(stemsB.metastem_id, int, (n-1));
	 n = 0;
	 for(k = 0; k < ostems[j]->nb_metastems; k++) {
	    /*	    if(is_not_singleB[k]) {*/
	    if(!ostems[j]->metastems[k].is_a_single_stem) {
	       stemsB.metastem_id[n++] = k;
	    }
	 }
	    
	 /*	 DESTROY(is_not_singleB);*/
	 /* */
	    
	    
	    
	 /* sankoff */
	    
	 srpt = &(SANKOFF_GET_FOLDING_PAIR(res,i,j));
	 srpt->stems1 = NULL;
	 srpt->stems2 = NULL;
	 srpt->nb_stems = 0;
	 srpt->energy1 = 0;
	 srpt->energy2 = 0;
	    
	    
	 if(OPTS_carnac_sankoff_stems) {

	    INFO_ "SANKOFF (stems) FOR metasequence %i vs metasequence %2i : %4i vs %4i stems\n", i, j, stemsA.nb_metastems, stemsB.nb_metastems _INFO;
	    FLUSH_OUT;

	    prepare_sankoff_stems(ostems[i], stemsA, &(open_atA), &(close_atA));
	    prepare_sankoff_stems(ostems[j], stemsB, &(open_atB), &(close_atB));


	    /*
		INFO_ "FOR %i\n", i _INFO;
		for(k = 0; k < stemsA.nb_metastems; k++) {
		INFO_ "    open_at[%i] id=%i on = %i cn = %i cp = %i hp = %i of = {", k,open_atA[k].stem_id,open_atA[k].open_next, open_atA[k].close_next, open_atA[k].close_prev, open_atA[k].is_hairpin   _INFO;
		     
		if(open_atA[k].open_for) {
		for(m = 0; m < STACK_SIZE(open_atA[k].open_for); m++) {
		INFO_ " %i",STACK_VALUE_AT(open_atA[k].open_for,m) _INFO;
		}
		}
		     
		INFO_ "} ci = %i os = %i cs = %i\n", open_atA[k].close_index, open_atA[k].open_sub, open_atA[k].close_sub _INFO;
		     
		     
		     
		INFO_ "    close_at[%i] id=%i cp = %i cf = {",k, close_atA[k].stem_id, close_atA[k].close_prev  _INFO;
		if(close_atA[k].close_for) {
		for(m = 0; m < STACK_SIZE(close_atA[k].close_for); m++) {
		INFO_ " %i",STACK_VALUE_AT(close_atA[k].close_for,m) _INFO;
		}
		}
		INFO_ "} oi = %i\n", close_atA[k].open_index _INFO;
		}
		  


		INFO_ "FOR %i\n", j _INFO;
		for(k = 0; k < stemsB.nb_metastems; k++) {
		INFO_ "    open_at[%i] id=%i on = %i cn = %i cp = %i hp = %i of = {", k,open_atB[k].stem_id,open_atB[k].open_next, open_atB[k].close_next, open_atB[k].close_prev, open_atB[k].is_hairpin   _INFO;
		     
		if(open_atB[k].open_for) {
		for(m = 0; m < STACK_SIZE(open_atB[k].open_for); m++) {
		INFO_ " %i",STACK_VALUE_AT(open_atB[k].open_for,m) _INFO;
		}
		}
		     
		INFO_ "} ci = %i os = %i cs = %i\n", open_atB[k].close_index, open_atB[k].open_sub, open_atB[k].close_sub _INFO;
		     
		     
		     
		INFO_ "    close_at[%i] id=%i cp = %i cf = {",k, close_atB[k].stem_id, close_atB[k].close_prev  _INFO;
		if(close_atB[k].close_for) {
		for(m = 0; m < STACK_SIZE(close_atB[k].close_for); m++) {
		INFO_ " %i",STACK_VALUE_AT(close_atB[k].close_for,m) _INFO;
		}
		}
		INFO_ "} oi = %i\n", close_atB[k].open_index _INFO;
		}
	    */

	    sankoff_stems(meta[i], ostems[i], stemsA, open_atA, close_atA, meta[j], ostems[j], stemsB, open_atB, close_atB, compatibles, &(res[i][j-i-1]));
	       
	       
	 } else {

	    INFO_ "SANKOFF (bases) FOR metasequence %i vs metasequence %i : %i vs %i stems\n", i, j, stemsA.nb_metastems, stemsB.nb_metastems _INFO;
	    FLUSH_OUT;
	       
	    istemableA = prepare_sankoff_bases(meta[i], stemsA, ostems[i]);
	    istemableB = prepare_sankoff_bases(meta[j], stemsB, ostems[j]);
	       
	    sankoff_bases(meta[i], istemableA, meta[j], istemableB, compatibles, &(res[i][j-i-1]));
	    
	 }
	 /**/








	 srpt->nb_istems = 0;

	 for(k = 0; k < ostems[i]->nb_metastems; k++) {
	    for(l = 0; l < ostems[j]->nb_metastems; l++) {
	       if(COMPATIBLE(compatibles[k][l]) && !(DO_COVARIATE(compatibles[k][l]))) {

		  /* compatibles but no covar --> pair them */
			
		  if(srpt->nb_istems == 0) {
		     NEW(srpt->istems1, metastem_t, 1);
		     NEW(srpt->istems2, metastem_t, 1);
		  } else {
		     RENEW(srpt->istems1, metastem_t, (srpt->nb_istems+1));
		     RENEW(srpt->istems2, metastem_t, (srpt->nb_istems+1));
		  }
			
		  NEW(srpt->istems1[srpt->nb_istems].seq_stems, stem_t, ostems[i]->metastems[k].nb_seqs);
		  srpt->istems1[srpt->nb_istems].nb_seqs = ostems[i]->metastems[k].nb_seqs;
		  srpt->istems1[srpt->nb_istems].energy = ostems[i]->metastems[k].energy;
		  srpt->istems1[srpt->nb_istems].is_a_single_stem = ostems[i]->metastems[k].is_a_single_stem;
		  srpt->istems1[srpt->nb_istems].folded_id = ostems[i]->metastems[k].folded_id;
		  for(m = 0; m < ostems[i]->metastems[k].nb_seqs; m++) {
		     srpt->istems1[srpt->nb_istems].seq_stems[m] = ostems[i]->metastems[k].seq_stems[m];
		  }
			
		  NEW(srpt->istems2[srpt->nb_istems].seq_stems, stem_t, ostems[j]->metastems[l].nb_seqs);
		  srpt->istems2[srpt->nb_istems].nb_seqs = ostems[j]->metastems[l].nb_seqs;
		  srpt->istems2[srpt->nb_istems].energy = ostems[j]->metastems[l].energy;
		  srpt->istems2[srpt->nb_istems].is_a_single_stem = ostems[j]->metastems[l].is_a_single_stem;
		  srpt->istems2[srpt->nb_istems].folded_id = ostems[j]->metastems[l].folded_id;
		  for(m = 0; m < ostems[j]->metastems[l].nb_seqs; m++) {
		     srpt->istems2[srpt->nb_istems].seq_stems[m] = ostems[j]->metastems[l].seq_stems[m];
		  }
			
		  srpt->nb_istems++;
	       }
	    }
	 }
	       


	   
	       
#ifdef _OPENMP
#else
	 INFO_ "    metasequence %i (%i stems, energy = %i)\n", i, srpt->nb_stems, srpt->energy1  _INFO;
	 for(k = 0; k < srpt->nb_stems; k++) {
	    INFO_ "        " _INFO;
	    println_metastem(&(srpt->stems1[k]), meta[i]);
	 }
	    
	 INFO_ "    metasequence %i (%i stems, energy = %i)\n", j, srpt->nb_stems, srpt->energy2  _INFO;
	 for(k = 0; k < srpt->nb_stems; k++) {
	    INFO_ "        " _INFO;
	    println_metastem(&(srpt->stems2[k]), meta[j]);
	 }
#endif	       


	 if(OPTS_carnac_sankoff_stems) {
	    DESTROY(open_atA);
	    DESTROY(close_atA);
	    DESTROY(open_atB);
	    DESTROY(close_atB);
	 } else {


	    for(l = 0; l < (meta[i]->length - 1); l++) {
	       for(m = l+1; m < meta[i]->length; m++) {
		  if(istemableA[l][m - l - 1]) {
		     DESTROY_STACK(istemableA[l][m - l - 1]);
		  }
	       }
		     
	       DESTROY(istemableA[l]);
		     
	    }
		  
	    DESTROY(istemableA);


	    for(l = 0; l < (meta[j]->length - 1); l++) {
	       for(m = l+1; m < meta[j]->length; m++) {
		  if(istemableB[l][m - l - 1]) {
		     DESTROY_STACK(istemableB[l][m - l - 1]);
		  }
	       }
		     
	       DESTROY(istemableB[l]);
		     
	    }
		  
	    DESTROY(istemableB);

	 }




	       

	 DESTROY(stemsB.metastem_id);



      } else {
	 /*INFO_ "No compatible stems between metasequence %i vs metasequence %i\n", i, j _INFO;*/
      }

	    
      DESTROY(stemsA.metastem_id);
   } else {
      /*INFO_ "No compatible stems between metasequence %i vs metasequence %i\n", i, j _INFO;*/
   }



   for(k = 0; k < ostems[i]->nb_metastems; k++) {
      for(l = 0; l < ostems[j]->nb_metastems; l++) {
	 if(compatibles[k][l].shifts) {
	    DESTROY_STACK(compatibles[k][l].shifts);
	 }
      }
      DESTROY(compatibles[k]);
   }
   DESTROY(compatibles);
}







sankoff_result
sankoff_all(const metasequence *meta, const int nb_meta, const metastem_t_list *ostems, int **id) {

   int i, j;


   sankoff_result_pair_t **res = NULL;

   NEW(res, sankoff_result_pair_t*, (nb_meta-1));
   for(i = 0; i < (nb_meta-1); i++) {   
      NEW(res[i], sankoff_result_pair_t, (nb_meta-i-1));
   }
   
#ifdef _OPENMP
#pragma omp parallel default(shared) 
   {

#pragma omp for
#endif
      for(i = 0; i < (nb_meta-1); i++) {   
#ifdef _OPENMP
#pragma omp parallel shared(i)
	 {

#pragma omp for
#endif
	    for(j = i+1; j < nb_meta; j++) {
	       
	       do_a_sankoff(res, i, j, meta, ostems, id);
	       
	    }
#ifdef _OPENMP
	 }
#endif
      }
#ifdef _OPENMP
   }
#endif
   
   return res;
}
