#!/bin/sh

make clean
make distclean

rm -f stamp-h1 src/config.h src/config.h.in config.sub config.guess
rm -f Makefile.in src/Makefile.in
rm -f *~ src/*~
rm -f configure.in autoscan.log configure.scan
rm -f src/*_parser.[ch]
rm -f src/*_lexer.[ch]
rm -f configure
rm -f arnica-*.tar.gz
rm -rf autom4te.cache
rm -f aclocal.m4
rm -f missing mkinstalldirs ylwrap install-sh depcomp
rm -f Makefile src/Makefile
rm -f compile
rm -f arnica muter fasta2raw fastasplit

