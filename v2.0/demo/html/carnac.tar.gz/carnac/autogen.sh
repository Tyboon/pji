#!/bin/sh




autoreconf --install



#autoscan
#aclocal
#autoupdate
#autoheader
#autoconf -Wall
#automake -Wall --add-missing -c

