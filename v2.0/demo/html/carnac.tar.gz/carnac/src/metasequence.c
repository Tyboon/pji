#ifdef HAVE_CONFIG_H
    #include "config.h"
#endif
#include "metasequence.h"

#include <stdlib.h>


metasequence
new_metasequence_from_alignment(alignment a) {
   metasequence res = NULL;

   res = (metasequence)init_alignment(a->seqs, a->nb_seqs, a->file);

   return res;
}


metasequence
new_metasequence_from_sequence(sequence s) {
   metasequence res = NULL;

   res = (metasequence)init_alignment(&s, 1, s->file);

   return res;
}
