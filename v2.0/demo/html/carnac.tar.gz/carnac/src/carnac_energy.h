#ifndef __ARNICA_CARNAC_ENERGY_H__
#define __ARNICA_CARNAC_ENERGY_H__


#include "sequence.h"
#include "carnac_stems.h"


extern int
generic_stack (sequence s, int i, int j, int matrix[4][4][4][4]);

extern int
stack_inside (sequence s, int i, int j);

extern int
stack_outside (sequence s, int i, int j);

extern int
tstack_inside (sequence s, int i, int j);


extern int
sint2_outside(sequence s, int i, int j);

extern int
sint4_outside(sequence s, int i, int j);

extern int
sint2_inside(sequence s, int i, int j);

extern int
sint4_inside(sequence s, int i, int j);



#endif
