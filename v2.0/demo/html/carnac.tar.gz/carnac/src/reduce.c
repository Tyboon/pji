#ifdef HAVE_CONFIG_H
    #include "config.h"
#endif
/*
Copyright or © or CCopr. INRIA : Arnaud FONTAINE

arnaud.fontaine@lifl.fr

This software is a computer program whose purpose is to predict 
significantly conserved protein coding sequences and/or RNA structure 
on a set of unaligned nucleic sequences.

This software is governed by the CeCILL  license under French law and
abiding by the rules of distribution of free software.  You can  use,
modify and/ or redistribute the software under the terms of the CeCILL
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info".

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability.

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or
data to be ensured and,  more generally, to use and operate it in the
same conditions as regards security.

The fact that you are presently reading this means that you have had
knowledge of the CeCILL license and that you accept its terms.
*/

#include "sequence.h"
#include "needle_common.h"
#include "boxes.h"
#include "stack.h"
#include "opts.h"
#include "display.h"
#include "input.h"
#include "output.h"
#include "results.h"

#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <errno.h>

#ifdef _OPENMP
#include <omp.h>
#endif




float
**similarities(const sequence *seqs, const int nb_seqs) {
   float **res = NULL;
   int i,j, r;

   INFO_ "Computing pairwise sequences similarity..." _INFO;
   FLUSH_OUT;

   r = 0;

   
   NEW(res, float*, (nb_seqs - 1));

   for(i = 0; i < (nb_seqs - 1); i++) {
      NEW(res[i], float, (nb_seqs - 1 - i));
   }

   
#ifdef _OPENMP
#pragma omp parallel default(shared)
   {
#pragma omp for
#endif
      for(i = 0; i < (nb_seqs - 1); i++) {
#ifdef _OPENMP
#pragma omp parallel shared(i)
	 {
#pragma omp for
#endif
	    for(j = i + 1; j < nb_seqs; j++) {
	       if(r == 0) {
		  /*	 INFO_ "." _INFO;*/
		  if(call_needle(seqs[i], seqs[j], &(res[i][j - i - 1]))) {
		     ERROR_ "unable to exec '%s' on sequences %i and %i\n", NEEDLE_IDENTITY_BOX->name, (i+1),(j+1)  _ERROR;
#ifdef _OPENMP
#pragma omp critical
		     {
#endif
			r = 1;
#ifdef _OPENMP
		     }
#endif
		  }
	       }
	    }
#ifdef _OPENMP
	 }
#endif
      }
#ifdef _OPENMP
   }
#endif
   
   
   if(r) {
      return NULL;
   }
   
      
   INFO_ "ok\n" _INFO;

   return res;
}



void
reduce_seq_set(const sequence* seqs, const int nb_seqs, sequence** res, int* res_nb, const double sim_th) {
   int **graph = NULL;
   int_stack stack = NULL;
   int has_next;
   int *flag_res = NULL;
   int nb = 0;
   int i, j, k;


   (*res) = NULL;
   (*res_nb) = 0;
   

   INFO_ "Reducing sequence set (id%% >= %.1f%%)... ", sim_th _INFO;
   FLUSH_OUT;

   NEW(graph, int*, (nb_seqs - 1));

   NEW_INT_STACK(stack, nb_seqs);
   
   NEW(flag_res, int, nb_seqs);

   for(i = 0; i < (nb_seqs - 1); i++) {
      NEW(graph[i], int, (nb_seqs - i - 1));

      for(j = i+1; j < nb_seqs; j++) {
	 if(RESULTS_sequence_similarities[i][j - i - 1] >= sim_th)
	    graph[i][j - i - 1] = 1;
	 else
	    graph[i][j - i - 1] = 0;
      }
   }


   NEW((*res), sequence, nb_seqs);


   /* aucun noeud */
   nb = 0;
   for(i = 0; i < nb_seqs; i++) {
      STACK_PUSH(stack, 0);
      flag_res[i] = 0;
   }

   has_next = 1;
   while(has_next) {

      k = 0;
      for(i = 0; (i < (nb_seqs - 1)) && (k>=0); i++) {
	 if(STACK_VALUE_AT(stack,i)) {
	    for(j = i + 1; (j < nb_seqs) && (k>=0); j++) {
	       if(STACK_VALUE_AT(stack,j)) {
		  if(graph[i][j - i - 1]) {
		     k = -1;
		  } else {
		     k++;
		  }
	       }
	    }
	 }
      }

      if(k > nb) {
	 nb = k;
	 for(i = 0; i < nb_seqs; i++) {
	    flag_res[i] = STACK_VALUE_AT(stack,i);
	 }
      }
      

      while((i = STACK_PEEK(stack)) == 1) {
	 i = STACK_POP(stack);
      }

      if(STACK_IS_EMPTY(stack)) {
	 has_next = 0;
      } else {
	 i = STACK_POP(stack);
	 STACK_PUSH(stack,1);
	 while(STACK_SIZE(stack) != nb_seqs) {
	    STACK_PUSH(stack,0);
	 }
      }
   }

   j = 0;
   for(i = 0; i < nb_seqs; i++) {
      if(flag_res[i]) {
	 (*res)[j++] = seqs[i];
      }
   }

   (*res_nb) = j;

   if((*res_nb) > 0) {
      RENEW((*res), sequence, (*res_nb));
   }

   DESTROY_STACK(stack);
   
   DESTROY(flag_res);

   for(i = 0; i < (nb_seqs - 1); i++) {
      DESTROY(graph[i]);
   }

   DESTROY(graph);


   INFO_ "%i sequence(s) removed\n", (nb_seqs-(*res_nb))  _INFO;


   return;
}
