#ifdef HAVE_CONFIG_H
    #include "config.h"
#endif
/*
Copyright or © or CCopr. INRIA : Arnaud FONTAINE

arnaud.fontaine@lifl.fr

This software is a computer program whose purpose is to predict 
significantly conserved protein coding sequences and/or RNA structure 
on a set of unaligned nucleic sequences.

This software is governed by the CeCILL  license under French law and
abiding by the rules of distribution of free software.  You can  use,
modify and/ or redistribute the software under the terms of the CeCILL
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info".

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability.

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or
data to be ensured and,  more generally, to use and operate it in the
same conditions as regards security.

The fact that you are presently reading this means that you have had
knowledge of the CeCILL license and that you accept its terms.
*/

#include <string.h>
#include <assert.h>
#include <stdlib.h>

#include "list.h"
#include "opts.h"
#include "display.h"


list
new_list(const int nb_seqs, const int max_size) {
   list res;

   NEW(res, list_t, 1);
   NEW(res->elements, list_element_t, max_size);
   res->size = 0;
   res->nb_seqs = nb_seqs;
   res->max_size = max_size;
   
   return res;
}

int
list_size(const list l) { return l->size; }

int
list_max_size(const list l) { return l->max_size; }

void
list_resize(list l, const int max_size) {
   if(l->max_size < max_size) {
      l->max_size = max_size;
      RENEW(l->elements, list_element_t, max_size);
   }
}

void
insert_list(list l, const int* phases, const double value) {
   int start, stop, middle;
   int* temp;

   if((l->size == l->max_size) && (l->elements[l->size - 1].value < value)) {
      return;
   }

   if(l->size > 0) {
      start = 0;
      stop = l->size - 1;
      
      while((stop - start) > 1) {
	 middle = (start + stop) / 2;
	 
	 if(l->elements[middle].value <= value) start = middle;
	 else stop = middle;
      }
      
      if(l->elements[stop].value <= value) middle = stop + 1;
      else if(l->elements[start].value <= value) middle = stop;
      else middle = start;
   } else middle = 0;


   if(l->size == l->max_size) {
      if(middle < (l->size - 1)) {
	 temp = l->elements[l->size - 1].phases;
	 
	 /* 	 for(i = l->size - middle - 2; i >= 0; i--) { */
	 /* 	    l->elements[middle + 1 + i] = l->elements[middle + i]; */
	 /* 	 } */
	 memmove(&(l->elements[middle + 1]), &(l->elements[middle]), (l->size - middle - 1) * sizeof(list_element_t));
	 if(phases) {
	    /* 	    for(i = 0; i < l->nb_seqs; i++) { */
	    /* 	       temp[i] = phases[i]; */
	    /* 	    } */
	    memcpy(temp, phases, l->nb_seqs * sizeof(int));
	    l->elements[middle].phases = temp;
	 } else {
	    l->elements[middle].phases = NULL;
	 }
	 l->elements[middle].value = value;
      } else {
	 if(middle < l->size) {
	    if(phases) {
	       /* 	       for(i = 0; i < l->nb_seqs; i++) { */
	       /* 		  l->elements[middle].phases[i] = phases[i]; */
	       /* 	       }	        */
	       memcpy(l->elements[middle].phases, phases, l->nb_seqs * sizeof(int));
	    } else {
	       l->elements[middle].phases = NULL;
	       }
	    l->elements[middle].value = value;
	 }
      }
   } else {
      if(l->size > 0) {
	 /* 	 for(i = l->size - middle - 1; i >= 0; i--) { */
	 /* 	    l->elements[middle + 1 + i] = l->elements[middle + i]; */
	 /* 	 } */
	 memmove(&(l->elements[middle + 1]), &(l->elements[middle]), (l->size - middle) * sizeof(list_element_t));
      }
      NEW(l->elements[middle].phases, int, l->nb_seqs);
      if(phases) {
	 /* 	 for(i = 0; i < l->nb_seqs; i++) { */
	 /* 	    l->elements[middle].phases[i] = phases[i]; */
	 /* 	 } */
	 memcpy(l->elements[middle].phases, phases, l->nb_seqs * sizeof(int));
      } else {
	 l->elements[middle].phases = NULL;
      }
      l->elements[middle].value = value;
      l->size++;
   }
}

void
free_list(list l) {
   int i;

   for(i = 0; i < l->size; i++) {
      DESTROY(l->elements[i].phases);
   }

   DESTROY(l->elements);
   DESTROY(l);
}
