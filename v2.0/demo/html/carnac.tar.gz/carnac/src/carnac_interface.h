#ifndef __ARNICA_INTERFACE_H__
#define __ARNICA_INTERFACE_H__

#include <stdio.h>


#include "alignment.h"
#include "sequence.h"
#include "buffer.h"



#define yytext arnicatext

/* Displays warning and increase the current number of warnings */
#define arnicawarning(s) (arnicawarning_token(s, yytext))
/* Displays error and increase the current number of errors */
#define arnicaerror(s) (arnicaerror_token(s, yytext))


extern void arnicarestart(FILE *f);
extern int arnicaparse();


extern int arnicalineno;
extern char* arnicatext;
extern int arnicalex();
extern FILE *arnicain;
extern char *arnica_file_name;
extern int arnica_nb_errors;
extern sequence* arnica_result;

/* Convenient warnings */
extern void
arnicawarning_token(const char *s, const char *token);

/* Convenient errors */
extern void
arnicaerror_token(const char *s, const char *token);





#endif
