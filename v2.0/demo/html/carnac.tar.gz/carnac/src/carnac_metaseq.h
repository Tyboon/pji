#ifndef __ARNICA_CARNAC_METASEQ_H__
#define __ARNICA_CARNAC_METASEQ_H__


#include "metasequence.h"
#include "carnac_stems.h"
#include "carnac_blocks.h"


extern block_list
blocks_between_meta(const metasequence meta1, const metasequence meta2);



#endif

