#ifdef HAVE_CONFIG_H
    #include "config.h"
#endif
/*
Copyright or © or CCopr. INRIA : Arnaud FONTAINE

arnaud.fontaine@lifl.fr

This software is a computer program whose purpose is to predict 
significantly conserved protein coding sequences and/or RNA structure 
on a set of unaligned nucleic sequences.

This software is governed by the CeCILL  license under French law and
abiding by the rules of distribution of free software.  You can  use,
modify and/ or redistribute the software under the terms of the CeCILL
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info".

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability.

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or
data to be ensured and,  more generally, to use and operate it in the
same conditions as regards security.

The fact that you are presently reading this means that you have had
knowledge of the CeCILL license and that you accept its terms.
*/

#ifndef MY_NEEDLE

#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <ctype.h>
#include <regex.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>

#include "needle_common.h"
#include "opts.h"
#include "display.h"
#include "boxes.h"
#include "input.h"
#include "output.h"


int
call_needle(const sequence si, const sequence sj, float* res) {
   pid_t pid;
   char* output = NULL, *sw = NULL;
   char* args[30];
   int cur_args;
   int status;
   FILE *fd = NULL;

   if(init_needle()) return -1;

   if((OPTS_output_dir != NULL) && (OPTS_keep_files != 0)) {
      NEW(output, char, (1 + strlen(OPTS_output_dir) + strlen(NEEDLE_IDENTITY_BOX->dir) + 1 + strlen(si->name) + strlen(SEQUENCE_SEP) + strlen(sj->name)));
      
      sprintf(output, "%s%s/%s%s%s", OPTS_output_dir, NEEDLE_IDENTITY_BOX->dir, si->name, SEQUENCE_SEP,  sj->name);
   } else {
      /*      output = tmpnam(NULL);*/
     /*Temp file change*/
     /*  sw = tmpnam(NULL); */
/*       NEW(output, char, (1 + strlen(sw))); */
/*       strcpy(output, sw); */

     FILE *file_d;
     char *temp_name;
     char *name = "temp_";
     int random = (rand() & 32767);
     
     NEW(temp_name, char, strlen(name) + 10);
     
     sprintf(temp_name,
	     "%s%i",
	     name,
	     random);
     while((file_d = fopen(temp_name, "r")) != NULL){
       DESTROY(temp_name);
       NEW(temp_name, char, strlen(name) + 10);
       random = (rand() & 32767);
       sprintf(temp_name,
	     "%s%i",
	       name,
	       random);
       fclose(file_d);
     
     }

     NEW(output, char, (1 + strlen(temp_name)));
     strcpy(output, temp_name);
     DESTROY(temp_name);


   }
   

   if(((fd = fopen(output, "r")) == NULL) || (OPTS_use_cache == 0)) {

      INFO_ "." _INFO;
      if(fd) { fclose(fd); }

      cur_args = 0;
      args[cur_args++] = NEEDLE_EXE;
      args[cur_args++] = "-auto";
      /*args[cur_args++] = "-brief";*/
      args[cur_args++] = "-outfile";
      args[cur_args++] = output;
      args[cur_args++] = "-snucleotide1";
      args[cur_args++] = "-snucleotide2";
      args[cur_args++] = si->file;
      args[cur_args++] = sj->file;
      /*args[cur_args++] = "-die";
	args[cur_args++] = "-warning";
	args[cur_args++] = "-error";
	args[cur_args++] = "-fatal";*/
      args[cur_args++] = NULL;

      status = 0;
      if((pid = fork())) {
	 /* pere */
	 waitpid(pid, &status, 0);
      } else {
	 /* fils */
	 execvp(args[0], args);
      	 exit(1);
      }
      
      if(WIFEXITED(status)) {
	 if(WEXITSTATUS(status) > 0) {
	    ERROR_ "'%s' has crashed or has not been found in from tour PATH !\n", args[0] _ERROR;
	    return -1;
	 }
      }
   } else {
      fclose(fd);
   }

   status = needle_identity_result(output, res);

   if((OPTS_output_dir == NULL) || (OPTS_keep_files == 0)) {
      unlink(output);
   }
   DESTROY(output);

   
   /* probleme grave ou non */
   if(status < 0) {
      ERROR_ "an error occured during %s result analysis\n", NEEDLE_IDENTITY_BOX->name _ERROR;
   }

   return status;
}
#endif
