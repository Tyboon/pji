#ifdef HAVE_CONFIG_H
    #include "config.h"
#endif
#include <ctype.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>

#include "alignment.h"
#include "carnac_energy.h"
#include "opts.h"
#include "carnac_covar.h"







short
hamming_distance(const sequence a, const sequence b, const int i, const int j) {
   
   short res = 2;

   if(a->bases[i] == b->bases[i]) {
      res--;
   }

   if(a->bases[j] == b->bases[j]) {
      res--;
   }

   return res;
}



float**
alifold_with_stacking(alignment a) {

   float **alifold_bs = NULL;
   float **alifold_covar = NULL;
   float **alifold_pen = NULL;
   float **alifold_b = NULL;
   float **res = NULL;

   int i, j, jj, alpha, beta;


   NEW(alifold_covar, float*, (a->length - SIZE_HAIRPIN));
   for(i = 0; i < (a->length - SIZE_HAIRPIN); i++) {
      NEW(alifold_covar[i], float, (a->length - i  - SIZE_HAIRPIN));
      
      for(j = i+SIZE_HAIRPIN; j < a->length; j++) {
	 
	 jj = j - i - SIZE_HAIRPIN;

	 alifold_covar[i][jj] = 0.0;

	 for(alpha = 0; alpha < a->nb_seqs; alpha++) {
	    if(is_canonical_pair(a->seqs[alpha]->bases[i], a->seqs[alpha]->bases[j])) {
	       for(beta = alpha+1; beta < a->nb_seqs; beta++) {
		  if(is_canonical_pair(a->seqs[beta]->bases[i], a->seqs[beta]->bases[j])) {
		     alifold_covar[i][jj] += hamming_distance(a->seqs[alpha], a->seqs[beta], i, j);
		     
		  }
	       }
	    } 
	 }

	 alifold_covar[i][jj] *= 2.0;
	 alifold_covar[i][jj] /= a->nb_seqs * (a->nb_seqs - 1.0);
	 
      }
   }


   
   NEW(alifold_pen, float*, (a->length - SIZE_HAIRPIN));
   for(i = 0; i < (a->length - SIZE_HAIRPIN); i++) {
      NEW(alifold_pen[i], float, (a->length - i - SIZE_HAIRPIN));
      
      for(j = i+SIZE_HAIRPIN; j < a->length; j++) {

	 jj = j - i - SIZE_HAIRPIN;

	 alifold_pen[i][jj] = 0.0;

	 for(alpha = 0; alpha < a->nb_seqs; alpha++) {

	    if(!is_canonical_pair(a->seqs[alpha]->bases[i], a->seqs[alpha]->bases[j])) {
	       alifold_pen[i][jj] += 1.0;
	    }
	 }

	 alifold_pen[i][jj] /= (0.0 + a->nb_seqs);
      }
   }







   NEW(alifold_b, float*, (a->length - SIZE_HAIRPIN));
   for(i = 0 ; i < (a->length - SIZE_HAIRPIN); i++) {
      NEW(alifold_b[i], float, (a->length - i - SIZE_HAIRPIN));
      
      for(j = i+SIZE_HAIRPIN ; j < a->length; j++) {
	 jj = j - i - SIZE_HAIRPIN;

	 alifold_b[i][jj] = alifold_covar[i][jj] - ALIFOLD_PHI*alifold_pen[i][jj];
      }

      DESTROY(alifold_pen[i]);
      DESTROY(alifold_covar[i]);
   }

   DESTROY(alifold_pen);
   DESTROY(alifold_covar);




   NEW(alifold_bs, float*, (a->length - SIZE_HAIRPIN));
   for(i = 0; i < (a->length - SIZE_HAIRPIN); i++) {
      NEW(alifold_bs[i], float, (a->length - i - SIZE_HAIRPIN));
      
      for(j = i + SIZE_HAIRPIN; j < a->length; j++) {
	 jj = j - i - SIZE_HAIRPIN;

	 alpha = 2;

	 alifold_bs[i][jj] = 2.0 * alifold_b[i][jj];
	 
	 if((i > 0) && ((j+1) < (a->length - (i - 1) - SIZE_HAIRPIN))) {
	    alpha++;
	    alifold_bs[i][jj] += alifold_b[i - 1][jj+1+1];
	 }
	 
	 if(((i + 1) < (a->length - SIZE_HAIRPIN)) && ((j-1-i) > SIZE_HAIRPIN)) {
	    alpha++;
	    alifold_bs[i][jj] += alifold_b[i + 1][jj-1-1];
	 }

	 alifold_bs[i][jj] /= (0.0 + alpha);

      }
   }


   for(i = 0 ; i < (a->length - SIZE_HAIRPIN); i++) {
      DESTROY(alifold_b[i]);
   }
   DESTROY(alifold_b);





   NEW(res, float*, (a->length - SIZE_HAIRPIN));
   for(i = 0; i < (a->length - SIZE_HAIRPIN); i++) {
      NEW(res[i], float, (a->length - i - SIZE_HAIRPIN));
      
      for(j = i + SIZE_HAIRPIN; j < a->length; j++) {
	 jj = j - i - SIZE_HAIRPIN;

	 alpha = 2;

	 res[i][jj] = 2.0 * alifold_b[i][jj];
	 
	 if((i > 0) && ((j+1) < (a->length - (i - 1) - SIZE_HAIRPIN))) {
	    alpha++;
	    res[i][jj] += alifold_b[i - 1][jj+1+1];
	 }
	 
	 if(((i + 1) < (a->length - SIZE_HAIRPIN)) && ((j-1-i) > SIZE_HAIRPIN)) {
	    alpha++;
	    res[i][jj] += alifold_b[i + 1][jj-1-1];
	 }

	 res[i][jj] /= (0.0 + alpha);

      }
   }


   return res;
}
