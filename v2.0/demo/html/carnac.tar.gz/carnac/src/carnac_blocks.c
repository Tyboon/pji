#ifdef HAVE_CONFIG_H
    #include "config.h"
#endif
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#include "qsort.h"
#include "carnac_blocks.h"
#include "display.h"
#include "opts.h"
#include <string.h>


block_list
new_block_list(int max_size) {
   block_list res = NULL;

   NEW(res, block_list_t, 1);
   res->nb_blocks = 0;
   res->max_size = max_size;
   NEW(res->blocks, block_t, max_size);

   return res;
}



int
qsort_blocks_by_increasing_from(const void *v1, const void *v2) {
   const block_t *b1 = v1;
   const block_t *b2 = v2;
   return b1->from1 - b2->from1;   
}


void
order_blocks_by_increasing_from(block_list l) {
   qsort(l->blocks, l->nb_blocks, sizeof(block_t), qsort_blocks_by_increasing_from);
}


int
qsort_blocks_by_decreasing_score(const void *v1, const void *v2) {
   const block_t *b1 = v1;
   const block_t *b2 = v2;
   int r;

   r = b2->score - b1->score;
   if(r) { return r; }
   
   r = (b2->to1 - b2->from1) - (b1->to1 - b1->from1);
   if(r) { return r; }
   
   r = (MAX(b1->from2, b1->from1) - MIN(b1->from2, b1->from1)) - (MAX(b2->from2, b2->from1) - MIN(b2->from2, b2->from1));
   return r;
}

void
order_blocks_by_decreasing_score(block_list l) {
   qsort(l->blocks, l->nb_blocks, sizeof(block_t), qsort_blocks_by_decreasing_score);
}





int
qsort_blocks_by_increasing_from_closure(const void *v1, const void *v2) {
   const block_t *b1 = v1;
   const block_t *b2 = v2;
   return b1->to1 - b2->to1;
}


void
order_blocks_by_increasing_from_closure(block_list l) {
   qsort(l->blocks, l->nb_blocks, sizeof(block_t), qsort_blocks_by_increasing_from_closure);
}







void
remove_block(block_list l, int idx) {
   if(l->nb_blocks > 1) {
      for(;idx < (l->nb_blocks - 1); idx++) {
	 l->blocks[idx] = l->blocks[idx+1];
      }
      l->nb_blocks--;
   } else {
      l->nb_blocks = 0;
   }
}

void
add_block(block_list l, int from1, int from2, int to1, int to2, int nb_mism, int score) {
   if(l->nb_blocks >= l->max_size) {
      l->max_size = l->nb_blocks + 20;
      RENEW(l->blocks, block_t, l->max_size);
   }
   l->blocks[l->nb_blocks].from1 = from1;
   l->blocks[l->nb_blocks].from2 = from2;
   l->blocks[l->nb_blocks].to1 = to1;
   l->blocks[l->nb_blocks].to2 = to2;
   l->blocks[l->nb_blocks].nb_mism = nb_mism;
   l->blocks[l->nb_blocks].score = score;

   l->nb_blocks++;
}


void
destroy_block_list(block_list l) {

   if(l->blocks) {
      DESTROY(l->blocks);
   }
   l->nb_blocks = -1;

   DESTROY(l);
}




void
print_meta_block(block_t *block, metasequence m1, metasequence m2) {
   char *sopen1 = NULL;

   NEW(sopen1, char, (block->to1-block->from1+1+1)); 
   
    if(m1 && (m1->nb_seqs >= 1)) {
       strncpy(sopen1, &(m1->seqs[0]->bases[block->from1]), (block->to1-block->from1+1));
    } else {
       sopen1[0] = '\0';
    }
    
    INFO_ "[%5i .. %5i] [%5i .. %5i]  %8i %8i %s", block->from1, block->to1, block->from2, block->to2, block->score, (block->to1 - block->from1 + 1), sopen1 _INFO;

    DESTROY(sopen1);
}


void
println_meta_block(block_t *block, metasequence m1, metasequence m2) {
   print_meta_block(block, m1, m2);
   INFO_ "\n" _INFO;
}
