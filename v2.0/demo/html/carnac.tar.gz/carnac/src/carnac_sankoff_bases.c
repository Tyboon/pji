#ifdef HAVE_CONFIG_H
    #include "config.h"
#endif
#include "carnac_sankoff_bases.h"

#include "opts.h"
#include "display.h"
#include "graph.h"


#include <stdlib.h>
#include <assert.h>
#include <math.h>



typedef struct {
   int otherA;
   int otherB;
} fold_pair_t;



short_stack **
prepare_sankoff_bases(const metasequence meta, const metastem_list stems, const metastem_t_list ostems) {
   short_stack **res = NULL;
   int i,j,l;
   int bo, bc, eo, ec;

   NEW(res, short_stack*, (meta->length - 1));
   
   for(i = 0; i < (meta->length - 1); i++) {
      NEW(res[i], short_stack, (meta->length - 1 - i));
      for(j = i+1; j < meta->length; j++) {
	 res[i][j-i-1] = NULL; /* no pairing */
      }
   }

   for(i = 0; i < stems.nb_metastems; i++) {
      
      bo = ostems->metastems[stems.metastem_id[i]].seq_stems[0].begin_start;
      bc = ostems->metastems[stems.metastem_id[i]].seq_stems[0].begin_stop;
      eo = ostems->metastems[stems.metastem_id[i]].seq_stems[0].end_start;
      ec = ostems->metastems[stems.metastem_id[i]].seq_stems[0].end_stop;

      for(j = 1; j < ostems->metastems[stems.metastem_id[i]].nb_seqs; j++) {

	 bo = MIN(bo, ostems->metastems[stems.metastem_id[i]].seq_stems[j].begin_start);
	 bc = MIN(bc, ostems->metastems[stems.metastem_id[i]].seq_stems[j].begin_stop);
	 eo = MIN(eo, ostems->metastems[stems.metastem_id[i]].seq_stems[j].end_start);
	 ec = MIN(ec, ostems->metastems[stems.metastem_id[i]].seq_stems[j].end_stop);
      }

      
      l = 1 + MIN((bc - bo), (ec - eo));

      while(l > 0) {
	 if(res[bo][ec - bo - 1]) {
	    if(STACK_IS_FULL(res[bo][ec - bo - 1])) {
	       res[bo][ec - bo - 1]->max_size += 2;
	       RENEW(res[bo][ec - bo - 1]->elements, short, res[bo][ec - bo - 1]->max_size);
	    }
	 } else {
	    NEW_SHORT_STACK(res[bo][ec - bo - 1], 2);
	 }
	 
	 STACK_PUSH(res[bo][ec - bo - 1], stems.metastem_id[i]);
	 
	 
	 bo++;
	 ec--;
	 l--;
      }
   }
   
   return res;
}








int pseudo_cost_seq(const sequence seq, const int open, const int close) {
   int o, c;

   
   const double pfold_proba[4][4] =
      {{10.0*log(0.001167), 10.0*log(0.001806), 10.0*log(0.001058), 10.0*log(0.177977)},
       {10.0*log(0.001806), 10.0*log(0.000391), 10.0*log(0.266974), 10.0*log(0.000763)},
       {10.0*log(0.001058), 10.0*log(0.266974), 10.0*log(0.000406), 10.0*log(0.049043)},
       {10.0*log(0.177977), 10.0*log(0.000763), 10.0*log(0.049043), 10.0*log(0.002793)}};
   
   
   switch(seq->bases[open]) {
   case 'A':
      o = 0;
      break;
   case 'C':
      o = 1;
      break;
   case 'G':
      o = 2;
      break;
   case 'T':
   case 'U':
      o = 3;
      break;
   default:
      return 0;
   }

   switch(seq->bases[close]) {
   case 'A':
      c = 0;
      break;
   case 'C':
      c = 1;
      break;
   case 'G':
      c = 2;
      break;
   case 'T':
   case 'U':
      c = 3;
      break;
   default:
      return 0;
   }

   return pfold_proba[o][c];

}


/*
int pseudo_cost_seq(const sequence seq, const int open, const int close) {
   int o;

   
   switch(seq->bases[open]) {
   case 'A':
      o = 1;
      break;
   case 'C':
      o = 4;
      break;
   case 'G':
      o = 6;
      break;
   case 'T':
   case 'U':
      o = 3;
      break;
   default:
      return 0;
   }

   switch(seq->bases[close]) {
   case 'A':
      o &= 1;
      break;
   case 'C':
      o &= 4;
      break;
   case 'G':
      o &= 6;
      break;
   case 'T':
   case 'U':
      o &= 3;
      break;
   default:
      return 0;
   }

   switch(o) {
   case 1:
      return -3;
   case 2:
      return -2;
   case 4:
      return -4;
   default:
      return -1;
   }
}
*/

int
pseudo_cost_metaseq(const metasequence meta, const int open, const int close) {
   int i, res = 0;

   for(i = 0; i < meta->nb_seqs; i++) {
      res += pseudo_cost_seq(meta->seqs[i], open, close);
   }

   return (100*res)/meta->nb_seqs;
}


int
pseudo_cost(const metasequence metaA, const int i, const int x, short_stack **pairingsA, const metasequence metaB, const int j, const int y, short_stack **pairingsB) {
   /*return (pseudo_cost_metaseq(metaA, i-1, x-1) * STACK_SIZE(pairingsA[i-1][x-i-1])) + (pseudo_cost_metaseq(metaB, j-1, y-1) * STACK_SIZE(pairingsB[j-1][y-j-1]));*/

   return pseudo_cost_metaseq(metaA, i-1, x-1) + pseudo_cost_metaseq(metaB, j-1, y-1);
}


void
add_edges_bases(const metasequence metaA, short_stack **pairingsA, const metasequence metaB, short_stack **pairingsB, const int i, const int j, const int x, const int y, int **table, vertex **graph, cofoldable_t **compatibles) {

   short sap, sbp;
   short sapi, sbpi;
   int w;
   edge ed;


   for(sap = 0; sap < STACK_SIZE(pairingsA[i-1][x - i - 1]); sap++) {
      sapi = STACK_VALUE_AT(pairingsA[i-1][x - i - 1], sap);
      
      for(sbp = 0; sbp < STACK_SIZE(pairingsB[j-1][y -j - 1]); sbp++) {
	 sbpi = STACK_VALUE_AT(pairingsB[j-1][y - j - 1], sbp);

	 if(COMPATIBLE(compatibles[sapi][sbpi])) {

	    w = table[x-1][y-1] + pseudo_cost(metaA, i, x, pairingsA, metaB, j, y, pairingsB);

	    if(w <= table[x][y]) {
	       ed.targetX = i - 1;
	       ed.targetY = j - 1;
	       ed.weight = w;
	       
	       update_edge(&(graph[x][y]), ed);
	    }

	 }
      }
   }
}







void
computeTable_Cell_bases(int **table, vertex **graph, const int i, const int x, const metasequence metaA, const int j, const int y, const metasequence metaB) {
   int  d, w;
   edge ed;
   
   table[x][y] = 0;

   if(x > i) {
      table[x][y] = table[x-1][y];
   }
   if((y > j) && (table[x][y-1] < table[x][y])) {
      table[x][y] = table[x][y-1];
   }
   
   for(d = 0; d <= graph[x][y].current_edge; d++) {
      
      get_edge(&(graph[x][y]), &ed, d);
      
      if((ed.targetX >= i) && (ed.targetY >= j)) {
	 
	 w = ed.weight + table[ed.targetX][ed.targetY];
	 
	 if(w < table[x][y]) {
	    table[x][y] = w;
	 }
      }
   }
}





void
computeTable_bases(const metasequence metaA, const int i, const int x, const metasequence metaB, const int j, const int y, int **table, vertex **graph) {
   int xx, yy;


   table[i][j] = 0;
   
   for(xx = i+1; xx <= x; xx++) {
      table[xx][j] = 0;
   }
   
   for(yy = j+1; yy <= y; yy++) {
      table[i][yy] = 0;
   }
   
   for(xx = i+1; xx <= x; xx++) {
      for(yy = j+1; yy <= y; yy++) {
	 computeTable_Cell_bases(table, graph, i, xx, metaA, j, yy, metaB);
      }
   }
}



void
build_alignment_graph_bases(const metasequence metaA, short_stack** pairingsA, const metasequence metaB, short_stack** pairingsB, int **table, vertex **graph, cofoldable_t **compatibles) {

   int i,j,x,y;

   for (i = metaA->length; i > 0; i--) {
      
      for (j = metaB->length; j > 0; j--) {

	 table[i][j] = 0;
	    
	 for(x = i + 1; x <= metaA->length; x++) {
	    table[x][j] = 0;
	 }

	 for(y = j + 1; y <= metaB->length; y++) {
	    table[i][y] = 0;
	 }
	 
	 for(x = i + 1; x <= metaA->length; x++) {

	    if(pairingsA[i-1][x-i-1]) {

	       for(y = j + 1; y <= metaB->length; y++) {

		  computeTable_Cell_bases(table, graph, i, x, metaA, j, y, metaB);

		  if(pairingsB[j-1][y-j-1]) {
		     
		     add_edges_bases(metaA, pairingsA, metaB, pairingsB, i,j,x,y, table, graph, compatibles);
		  }
	       }
	    } else {
	       for(y = j + 1; y <= metaB->length; y++) {
		  
		  computeTable_Cell_bases(table, graph, i, x, metaA, j, y, metaB);
		  
	       }
	    }
	 }
      }
   }
}














void
build_optimal_folding_bases(const int i, const int k, const metasequence metaA, const int j, const int l, const metasequence metaB, int **table, vertex **graph, quadruple_stack *p, sankoff_result_pair res) {
   
   int finished;
   int x, y;
   int d, m;
   edge ed;
   
   x = k;
   y = l;

   
   while((x+y) > (i+j)) {
      if((x>i) && (table[x][y] == table[x-1][y])) {
	 x--;
      } else if ((y>j) && (table[x][y] == table[x][y-1])){
	 y--; 
      } else {
	 finished = 0;
	 
	 for(d = 0;  (!finished) && (d <= graph[x][y].current_edge); d++) {
	    
	    get_edge(&(graph[x][y]), &ed, d);
	    
	    if((ed.targetX >= i) && (ed.targetY >= j) && (table[x][y] == (ed.weight + table[ed.targetX][ed.targetY]))) {
	       finished = 1;
	       
	       if(res->nb_stems == 0) {
		  NEW(res->stems1, metastem_t, 1);
		  NEW(res->stems2, metastem_t, 1);
	       } else {
		  RENEW(res->stems1, metastem_t, (res->nb_stems+1));
		  RENEW(res->stems2, metastem_t, (res->nb_stems+1));
	       }
	       
	       
	       res->stems1[res->nb_stems].nb_seqs = metaA->nb_seqs;
	       res->stems1[res->nb_stems].energy = 0; /*********************/
	       res->stems1[res->nb_stems].is_a_single_stem = 0;  /*********************/
	       res->stems1[res->nb_stems].folded_id = 0;  /*********************/
	       
	       NEW(res->stems1[res->nb_stems].seq_stems, stem_t, metaA->nb_seqs);
	       for(m = 0; m < metaA->nb_seqs; m++) {
		  res->stems1[res->nb_stems].seq_stems[m].begin_start = ed.targetX+1 - 1;
		  res->stems1[res->nb_stems].seq_stems[m].begin_stop = ed.targetX+1 - 1;
		  res->stems1[res->nb_stems].seq_stems[m].end_stop = x - 1;
		  res->stems1[res->nb_stems].seq_stems[m].end_start = x - 1;
	       }
	       res->energy1 += res->stems1[res->nb_stems].energy;
	       
	       
	       res->stems2[res->nb_stems].nb_seqs = metaB->nb_seqs;
	       res->stems2[res->nb_stems].energy = 0; /*********************/
	       res->stems2[res->nb_stems].is_a_single_stem = 0;  /*********************/
	       res->stems2[res->nb_stems].folded_id = 0;  /*********************/
	       
	       NEW(res->stems2[res->nb_stems].seq_stems, stem_t, metaB->nb_seqs);
	       for(m = 0; m < metaB->nb_seqs; m++) {
		  res->stems2[res->nb_stems].seq_stems[m].begin_start = ed.targetY+1 -1;
		  res->stems2[res->nb_stems].seq_stems[m].begin_stop = ed.targetY+1 -1;
		  res->stems2[res->nb_stems].seq_stems[m].end_stop = y - 1;
		  res->stems2[res->nb_stems].seq_stems[m].end_start = y - 1;
	       }
	       res->energy2 += res->stems2[res->nb_stems].energy;
	       
	       
	       res->nb_stems++;
	       
	       quadruple_push(p, ed.targetX, ed.targetY, x-1, y-1);
	       x = ed.targetX;
	       y = ed.targetY;
	    }
	 }
      } 
   }
}







void
trace_back_bases(const metasequence metaA, const metasequence metaB, int **table, vertex **graph, sankoff_result_pair res) {
   quadruple_stack *p = NULL;
   int i,j,x,y;
   int oldi, oldj, oldx, oldy;


   NEW(p, quadruple_stack, 1);

   init_quadruple_stack(p, (metaA->length + metaB->length)*2);
   
   oldi = oldj = oldx = oldy = -1;
   i = 0;
   j = 0;
   x = metaA->length;
   y = metaB->length;


   quadruple_push(p, i, j, x, y);


   while(!is_empty_quadruple_stack(p)) {
      quadruple_pop(p, &i, &j, &x, &y);
      if((i != oldi) || (j != oldj) || (x > oldx) || (y > oldy)) {
	 computeTable_bases(metaA, i, x, metaB, j, y, table, graph);
	 oldi = i;
	 oldj = j;
	 oldx = x;
	 oldy = y;
      }
      build_optimal_folding_bases(i, x, metaA, j, y, metaB, table, graph, p, res);
   }


   free_quadruple_stack(p);
}






void
sankoff_bases(const metasequence metaA, short_stack **pairingsA, const metasequence metaB, short_stack **pairingsB, cofoldable_t **compatibles, sankoff_result_pair res) {
   
   int i, j, k, sa, sb;
   int **table = NULL;
   vertex **graph = NULL;

   NEW(table, int*, (metaA->length+1));
   NEW(graph, vertex*, (metaA->length+1));
   for(i = 0; i <= metaA->length; i++) {
      NEW(table[i], int, (metaB->length+1));
      NEW(graph[i], vertex, (metaB->length+1));


      for(j = 0; j <= metaB->length; j++) {
	 table[i][j] = 0;

	 sa = 0;
	 for(k = 1; k < i; k++) {
	    if(pairingsA[k-1][i - k - 1]) {
	       sa += STACK_SIZE(pairingsA[k-1][i - k - 1]);
	    }
	 }
	 
	 sb = 0;
	 for(k = 1; k < j; k++) {
	    if(pairingsB[k-1][j - k - 1]) {
	       sb += STACK_SIZE(pairingsB[k-1][j - k - 1]);
	    }
	 }
	 
	 sa *= sb;
	 
	 if(sa) {
	    init_edge_stack(&(graph[i][j]), sa);
	 } else {
	    graph[i][j].elements = NULL;
	    graph[i][j].current_edge = -1;
	 }
      }	 
   }
   



   build_alignment_graph_bases(metaA, pairingsA, metaB, pairingsB, table, graph, compatibles);
   
   trace_back_bases(metaA, metaB, table, graph, res);
   
   
   for(i = 0; i <= metaA->length; i++) {
      DESTROY(table[i]);
   }
   DESTROY(table);

   free_graph(graph, metaA->length, metaB->length);











   




}
