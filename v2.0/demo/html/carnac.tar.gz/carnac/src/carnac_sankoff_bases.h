#ifndef __ARNICA_CARNAC_SANKOFF_BASES__
#define __ARNICA_CARNAC_SANKOFF_BASES__

#include "metasequence.h"
#include "carnac_stems.h"
#include "carnac_sankoff.h"
#include "carnac_compatible.h"
#include "stack.h"






extern short_stack**
prepare_sankoff_bases(const metasequence meta, const metastem_list stems, const metastem_t_list ostems);


extern void
sankoff_bases(const metasequence metaA, short_stack **pairingsA, const metasequence metaB, short_stack **pairingsB, cofoldable_t **compatibles, sankoff_result_pair res);


#endif
