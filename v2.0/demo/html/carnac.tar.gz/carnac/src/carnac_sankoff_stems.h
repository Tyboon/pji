#ifndef __ARNICA_CARNAC_SANKOFF_STEMS__
#define __ARNICA_CARNAC_SANKOFF_STEMS__

#include "metasequence.h"
#include "carnac_stems.h"
#include "carnac_sankoff.h"
#include "carnac_compatible.h"
#include "stack.h"


typedef struct {
   short stem_id;
   short close_index; /* close_index */
   short is_hairpin;
   short open_next; /* open_index */
   short close_prev; /* close_index */
} stem_open_index_t;

typedef struct {
   short stem_id;
   short open_index; /* open_index */
   short close_prev; /* close_index */
} stem_close_index_t;



extern void
prepare_sankoff_stems(const metastem_t_list ostems, const metastem_list stems, stem_open_index_t **oindex, stem_close_index_t **cindex);




extern void
sankoff_stems(const metasequence metaA, const metastem_t_list ostemsA, const metastem_list stemsA, const stem_open_index_t *open_atA, const stem_close_index_t *close_atA, const metasequence metaB, const metastem_t_list ostemsB, const metastem_list stemsB, const stem_open_index_t *open_atB, const stem_close_index_t *close_atB, cofoldable_t **compatibles, sankoff_result_pair res);


#endif
