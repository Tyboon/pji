/* src/config.h.  Generated from config.h.in by configure.  */
/* src/config.h.in.  Generated from configure.ac by autoheader.  */

/* Use appropriate BLOSUM matrix for alignments */
#define ADAPTIVE_BLOSUM /**/

/* minimal block size */
#define BLOCK_MIN_LENGTH 8

/* substitution cost between sequence blocks */
#define BLOCK_SUBSTITUTION -5

/* Bonus applied to cofoldable stems with conserved non canonical baise pairs
   */
#define CARNAC_CONSERVED_NON_CANONICAL_BONUS -2 * STEM_MISMATCH_MALUS

/* Carnac similarity threshold to require true covaraiation */
#define CARNAC_COVAR_ID_THRESHOLD 98.0

/* carnac */
#define CARNAC_EXE "carnac"

/* number of floating nucleotides outside anchor points */
#define CARNAC_FLOATING 1

/* Produce metasequences with similar sequences */
#define CARNAC_FUSION /**/

/* Possible overlap for graph */
#define CARNAC_GRAPH_TOLERATE_OVERLAP 3

/* First step component index selection threshold */
#define CARNAC_INDEX_THRESHOLD1 30

/* Second step component index selection threshold */
#define CARNAC_INDEX_THRESHOLD2 40

/* Minimal frequency to select a node in a component */
#define CARNAC_LIMIT_FREQUENCY 1

/* File to store metastems */
#define CARNAC_METASTEMS_FILE "metastems.out"

/* Enable non Watson-Crick base pairs */
#define CARNAC_NON_WATSON_CRICK /**/

/* File to store stems */
#define CARNAC_STEMS_FILE "stems.out"

/* Stem length ratio equal or below */
#define CARNAC_STEM_LENGTH_RATIO 2

/* Possible overlap for Sankoff */
#define CARNAC_TOLERATE_OVERLAP 2

/* clustalw2 */
#define CLUSTALW_EXE "clustalw2"

/* Bonus for stems with covariations in metasequences */
#define COVAR_BONUS -100

/* Define to one of `_getb67', `GETB67', `getb67' for Cray-2 and Cray-YMP
   systems. This function is required for `alloca.c' support on those systems.
   */
/* #undef CRAY_STACKSEG_END */

/* Define to 1 if using `alloca.c'. */
/* #undef C_ALLOCA */

/* dialign2-2 */
#define DIALIGN2_2_EXE "dialign2-2"

/* Define to 1 if you have `alloca', as a function or macro. */
#define HAVE_ALLOCA 1

/* Define to 1 if you have <alloca.h> and it should be used (not on Ultrix).
   */
#define HAVE_ALLOCA_H 1

/* Define to 1 if you have the `fork' function. */
#define HAVE_FORK 1

/* Define to 1 if you have the <inttypes.h> header file. */
#define HAVE_INTTYPES_H 1

/* Define to 1 if you have the <libintl.h> header file. */
#define HAVE_LIBINTL_H 1

/* Define to 1 if you have the <limits.h> header file. */
#define HAVE_LIMITS_H 1

/* Define to 1 if your system has a GNU libc compatible `malloc' function, and
   to 0 otherwise. */
#define HAVE_MALLOC 1

/* Define to 1 if you have the <malloc.h> header file. */
#define HAVE_MALLOC_H 1

/* Define to 1 if you have the `memmove' function. */
#define HAVE_MEMMOVE 1

/* Define to 1 if you have the <memory.h> header file. */
#define HAVE_MEMORY_H 1

/* Define to 1 if you have the `memset' function. */
#define HAVE_MEMSET 1

/* Define to 1 if you have the `mkdir' function. */
#define HAVE_MKDIR 1

/* Define to 1 if you have the `pow' function. */
/* #undef HAVE_POW */

/* Define to 1 if your system has a GNU libc compatible `realloc' function,
   and to 0 otherwise. */
#define HAVE_REALLOC 1

/* Define to 1 if you have the `regcomp' function. */
#define HAVE_REGCOMP 1

/* Define to 1 if you have the `sqrt' function. */
/* #undef HAVE_SQRT */

/* Define to 1 if you have the <stddef.h> header file. */
#define HAVE_STDDEF_H 1

/* Define to 1 if you have the <stdint.h> header file. */
#define HAVE_STDINT_H 1

/* Define to 1 if you have the <stdlib.h> header file. */
#define HAVE_STDLIB_H 1

/* Define to 1 if you have the `strerror' function. */
#define HAVE_STRERROR 1

/* Define to 1 if you have the <strings.h> header file. */
#define HAVE_STRINGS_H 1

/* Define to 1 if you have the <string.h> header file. */
#define HAVE_STRING_H 1

/* Define to 1 if you have the <sys/stat.h> header file. */
#define HAVE_SYS_STAT_H 1

/* Define to 1 if you have the <sys/types.h> header file. */
#define HAVE_SYS_TYPES_H 1

/* Define to 1 if you have <sys/wait.h> that is POSIX.1 compatible. */
#define HAVE_SYS_WAIT_H 1

/* Define to 1 if you have the <unistd.h> header file. */
#define HAVE_UNISTD_H 1

/* Define to 1 if you have the `vfork' function. */
#define HAVE_VFORK 1

/* Define to 1 if you have the <vfork.h> header file. */
/* #undef HAVE_VFORK_H */

/* Define to 1 if `fork' works. */
#define HAVE_WORKING_FORK 1

/* Define to 1 if `vfork' works. */
#define HAVE_WORKING_VFORK 1

/* Produce colorized HTML alignments in PROTEA */
#define HTML_ALIGNMENT /**/

/* Size of input buffer in octets */
#define INPUT_BUFFER 20000

/* Use internal version of Needleman&Wunsch algorithm */
#define MY_NEEDLE /**/

/* Enable the ranking computation (nb_ranked edges) instead of using alignment
   scores */
#define NB_RANK 6

/* needle */
#define NEEDLE_EXE "needle"

/* Define to 1 if your C compiler doesn't accept -c and -o together. */
/* #undef NO_MINUS_C_MINUS_O */

/* Size of output buffer in octets */
#define OUTPUT_BUFFER 20000

/* Name of package */
#define PACKAGE "carnac"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT "arnaud.fontaine@inria.fr"

/* Define to the full name of this package. */
#define PACKAGE_NAME "carnac"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "carnac 0.34"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "carnac"

/* Define to the home page for this package. */
#define PACKAGE_URL ""

/* Define to the version of this package. */
#define PACKAGE_VERSION "0.34"

/* Sum of pair fusion */
#define PROTEA_FUSION_SP /**/

/* Merger after */
#define PROTEA_POST_FUSION /**/

/* Merge before */
#define PROTEA_PRE_FUSION /**/

/* Protea similarity threshold */
#define PROTEA_SIM_THRESHOLD 95.0

/* File to store aligned proteins */
#define PROTEIN_ALIGNMENT_FILE "proteins_aligned.aln"

/* File to store aligned proteins */
#define PROTEIN_ALIGNMENT_HTML_FILE "proteins_aligned.html"

/* File to store translated sequences */
#define PROTEIN_FILE "proteins.fasta"

/* Forces the ranking computation above this number of EDGES */
#define RANKING_ABOVE 2

/* File to store original DNA or RNA sequences */
#define SEQUENCES_FILE "sequences.fasta"

/* File to store aligned sequences according to protein alignment */
#define SEQUENCES_PROT_ALIGNMENT_FILE "sequences_aligned_proteins.aln"

/* File to store aligned sequences according to protein alignment */
#define SEQUENCES_PROT_ALIGNMENT_HTML_FILE "sequences_aligned_proteins.html"

/* Sequence file name separator */
#define SEQUENCE_SEP ".vs."

/* shuffle-aln.pl */
#define SHUFFLE_EXE "shuffle-aln.pl"

/* SISSIz */
#define SHUFFLE_SISSIZ_EXE "SISSIz"

/* minimal hairpin size */
#define SIZE_HAIRPIN 3

/* shuffle-aln.sh */
#define SPLITSHUFFLE_SH "shuffle-aln.sh"

/* If using the C implementation of alloca, define if you know the
   direction of stack growth for your system; otherwise it will be
   automatically deduced at runtime.
	STACK_DIRECTION > 0 => grows toward higher addresses
	STACK_DIRECTION < 0 => grows toward lower addresses
	STACK_DIRECTION = 0 => direction of growth unknown */
/* #undef STACK_DIRECTION */

/* Define to 1 if you have the ANSI C header files. */
#define STDC_HEADERS 1

/* maximal free energy for selected stems */
#define STEM_ENERGY_THRESHOLD -500

/* minimal stem extension size */
#define STEM_MINIMAL_EXTEND 2

/* energy malus on mismatch extend */
#define STEM_MISMATCH_MALUS 250

/* Strand suffix to differenciate traducted sequences */
#define STRAND_MARK ".strand."

/* Substitute character for characters in sequence name */
#define SUBSTITUTE_CHAR '_'

/* t_coffee */
#define TCOFFEE_EXE "t_coffee"

/* Version number of package */
#define VERSION "0.34"

/* Unable trace within the code on warning or error */
#define WITH_TRACE /**/

/* Define to 1 if `lex' declares `yytext' as a `char *' by default, not a
   `char[]'. */
#define YYTEXT_POINTER 1

/* Define for Solaris 2.5.1 so the uint32_t typedef from <sys/synch.h>,
   <pthread.h>, or <semaphore.h> is not used. If the typedef were allowed, the
   #define below would cause a syntax error. */
/* #undef _UINT32_T */

/* Define for Solaris 2.5.1 so the uint8_t typedef from <sys/synch.h>,
   <pthread.h>, or <semaphore.h> is not used. If the typedef were allowed, the
   #define below would cause a syntax error. */
/* #undef _UINT8_T */

/* Define to empty if `const' does not conform to ANSI C. */
/* #undef const */

/* Define to the type of a signed integer type of width exactly 16 bits if
   such a type exists and the standard includes do not define it. */
/* #undef int16_t */

/* Define to the type of a signed integer type of width exactly 32 bits if
   such a type exists and the standard includes do not define it. */
/* #undef int32_t */

/* Define to the type of a signed integer type of width exactly 8 bits if such
   a type exists and the standard includes do not define it. */
/* #undef int8_t */

/* Define to rpl_malloc if the replacement function should be used. */
/* #undef malloc */

/* Define to `int' if <sys/types.h> does not define. */
/* #undef pid_t */

/* Define to rpl_realloc if the replacement function should be used. */
/* #undef realloc */

/* Define to `unsigned int' if <sys/types.h> does not define. */
/* #undef size_t */

/* Define to the type of an unsigned integer type of width exactly 16 bits if
   such a type exists and the standard includes do not define it. */
/* #undef uint16_t */

/* Define to the type of an unsigned integer type of width exactly 32 bits if
   such a type exists and the standard includes do not define it. */
/* #undef uint32_t */

/* Define to the type of an unsigned integer type of width exactly 8 bits if
   such a type exists and the standard includes do not define it. */
/* #undef uint8_t */

/* Define as `fork' if `vfork' does not work. */
/* #undef vfork */
