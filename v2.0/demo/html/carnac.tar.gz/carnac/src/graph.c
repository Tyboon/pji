#ifdef HAVE_CONFIG_H
    #include "config.h"
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

#include "graph.h"
#include "display.h"
#include "opts.h"

#include <assert.h>


/*Empile un �l�ment � la pile*/
void push_edge(vertex * v, edge x){
  /*printf("current edge : %d\n", v->current_edge);*/
  (v->current_edge)++; 
  v->elements[v->current_edge]=x;
}

void update_edge(vertex *v, edge x){

  int d=0; 
  int is_edge_found=0;
  for (d=0; (d<=v->current_edge) && !is_edge_found; d++){
    if ((v->elements[d].targetX==x.targetX) && (v->elements[d].targetY==x.targetY)){
      is_edge_found=1;
      if  (v->elements[d].weight<x.weight){
	v->elements[d].weight=x.weight;
      }
    }
    
  }
  if (!is_edge_found)
    push_edge(v,x);
}

/*D�pile un �l�ment a la pile*/
void get_edge(const vertex * v, edge * x, int d){
   *x = v->elements[d]; 
}


/*Teste si la pile est vide*/
int end_of_edge_stack(vertex * v){
  return (v->current_edge==-1);
}

/*Initialise la pile*/
void init_edge_stack(vertex * v, int size){
   NEW(v->elements, edge, size);
   v->current_edge=-1;
}

void reset_edge_stack(vertex * v){
  v->current_edge=-1;
}


void free_edge_stack(vertex v){
  DESTROY(v.elements);
}

void free_graph(vertex ** alignment_graph, int n, int m){
  int i,j;
  for (i=1; i<n; i++){
    for (j=1; j<m; j++){
      free_edge_stack (alignment_graph[i][j]);
    }
    DESTROY(alignment_graph[i]);
  }
  DESTROY(alignment_graph);
}


void display_alignment_graph(vertex ** alignment_graph, int k, int l){
  int i,j,d;
  edge ed;
  
  
  for (i=1; i<=k; i++){
    for (j=1; j<=l; j++){
      for (d=0; d<=alignment_graph[i][j].current_edge; d++){
	 get_edge(&(alignment_graph[i][j]), &ed, d);
	 INFO_ " (%d, %d) -> (%d,%d) weight %d\n", i, j, ed.targetX, ed.targetY, ed.weight _INFO;
      }
    }
  }
}
