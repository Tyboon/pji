#ifndef __ARNICA_CARNAC_COVAR_H__
#define __ARNICA_CARNAC_COVAR_H__


#include "alignment.h"


#define ALIFOLD_PHI 1.0


extern
float** alifold_with_stacking(alignment a);



#endif
