#ifndef __ARNICA_OPTS_H__
#define __ARNICA_OPTS_H__


#define NEW(Ref,Type,Nb) Ref=(Type*)calloc((Nb),sizeof(Type));assert(Ref != NULL)
#define RENEW(Ref,Type,Nb) Ref=(Type*)realloc(Ref,(Nb)*sizeof(Type));assert(Ref != NULL)
#define DESTROY(Ref) free(Ref);Ref=NULL
#define MIN(Aa,Bb) ((Aa <= Bb) ? (Aa) : (Bb))
#define MAX(Aa,Bb) ((Aa > Bb) ? (Aa) : (Bb))


#define IS_BETWEEN(Aa,Bb,Ii) (((Aa) <= (Ii)) && ((Ii) <= (Bb)))



#define MAX2(Aa,Bb) (((Aa) < (Bb)) ? (Bb) : (Aa))

/*#define MAX3(Aa,Bb,Cc) (((Aa) < (Bb)) ? (((Bb) < (Cc)) ? (Cc) : (Bb)) : (((Aa) < (Cc)) ? (Cc) : (Aa)))*/
extern double
MAX3(double n1, double n2, double n3);

extern float CARNAC_SIM_THRESHOLD;

extern int OPTS_quiet;
extern int OPTS_shuffling_sissiz;
extern int OPTS_keep_files;
extern int OPTS_first_phase;
extern char* OPTS_output_dir;
extern int OPTS_max_res;
/*extern double min_similarity;*/
extern double OPTS_min_aln_score;
extern int OPTS_nb_shuffles;
extern int OPTS_multiple_alignment;
extern int OPTS_clustalw_multiple_alignment;
extern int OPTS_dialign_multiple_alignment;
extern int OPTS_html_alignment;
extern int OPTS_use_cache;
extern int OPTS_carnac_allow_single;
extern int OPTS_carnac_sankoff_stems;
extern int OPTS_hairpin_mode;

extern int OPTS_carnac_correct_thd;


extern void
init_opts();



extern long int
quick_pow(const long int x, const int y);

extern long double
quick_powd(const long double x, const int y);

extern int
prepare_dir(const char *dir);

extern int
file_exists(const char *file);

extern int
move_file(const char* from, const char* to);

#endif
