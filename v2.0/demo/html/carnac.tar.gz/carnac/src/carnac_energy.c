#ifdef HAVE_CONFIG_H
    #include "config.h"
#endif
#include <ctype.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>


#include "carnac_energy.h"
#include "carnac_energy_matrices.h"
#include "carnac_stems.h"



#include "opts.h"
#include "display.h"











int generic_stack (sequence s, int i, int j, int matrix[4][4][4][4]) {
   int a, b, c, d;
   
   GET_NUCLEOTIDE_ID(s->bases[i], a);
   GET_NUCLEOTIDE_ID(s->bases[i+1], b);
   GET_NUCLEOTIDE_ID(s->bases[j], c);
   GET_NUCLEOTIDE_ID(s->bases[j-1], d);

   return matrix[a][b][c][d]; /* stack_mat */
}

int stack_inside (sequence s, int i, int j) {
   return generic_stack(s, i, j, stack_energy);
}

int stack_outside (sequence s, int i, int j) {
   return stack_inside(s, i-1,j+1);
}


int tstackh (sequence s, int i, int j) {
   return generic_stack(s, i, j, tstackh_energy);
}



int tloop(sequence s, int i, int j) {
   int k, out;
   char loop[6];

   out = 0;

   
   if ((j-i) == 5) {
      for(k = i; k <= j; k++) {
	 switch(s->bases[k]) {
	 case 'A':
	    loop[k-i] = 'a';
	    break;
	 case 'C':
	    loop[k-i] = 'c';
	    break;
	 case 'G':
	    loop[k-i] = 'g';
	    break;
	 case 'T':
	 case 'U':
	    loop[k-i] = 'u';
	    break;
	 default:
	    return out;
	 }
      }


      k = 0;
      while((k<30) && (strncmp(loop, tloop_bonus[k].loop, 6) != 0)) {
	 k++;
      }

      if(k < 30) {
	 out = tloop_bonus[k].bonus;
      }
   }

   return out;
}


int tstack_inside (sequence s, int i, int j) { /* */
  return tstackh(s,i,j) + tloop(s,i,j);
}















int sint2_outside (sequence s, int i, int j) {
   int a,b,c,d;
   

   GET_NUCLEOTIDE_PAIR(s->bases[i-2], s->bases[j+2], a);
   GET_NUCLEOTIDE_ID(s->bases[i-1], b);
   GET_NUCLEOTIDE_PAIR(s->bases[i], s->bases[j], c);
   GET_NUCLEOTIDE_ID(s->bases[j+1], d);

   return sint2_mat[a][b][c][d];
}


int sint2_inside (sequence s, int i, int j) {
   int a,b,c,d;
   
   GET_NUCLEOTIDE_PAIR(s->bases[i], s->bases[j], a);
   GET_NUCLEOTIDE_ID(s->bases[i+1], b);
   GET_NUCLEOTIDE_PAIR(s->bases[i+2], s->bases[j-2], c);
   GET_NUCLEOTIDE_ID(s->bases[j-1], d);

   
   return sint2_mat[a][b][c][d];
}









int sint4_outside(sequence s, int i, int j) {
   int a,b,c, t;

   GET_NUCLEOTIDE_QUAD(s->bases[i-3], s->bases[j+3], s->bases[i], s->bases[j], a, t);
   
   /* CORRECTION DE LA FONCTION DE carnac, risque de */
   /*   GET_NUCLEOTIDE_PAIR(s->bases[i-1], s->bases[j+1], jimu);*/
   /*  GET_NUCLEOTIDE_PAIR(s->bases[i-2], s->bases[j+2], jimd);*/

   GET_NUCLEOTIDE_PAIR_NONWC(s->bases[i-2], s->bases[j+2], b);
   GET_NUCLEOTIDE_PAIR_NONWC(s->bases[i-1], s->bases[j+1], c);

   return sint4_mat[a][b][c];
}





int sint4_inside (sequence s, int i, int j) {
   int a,b,c, t;

   GET_NUCLEOTIDE_QUAD(s->bases[i], s->bases[j], s->bases[i+3], s->bases[j-3], a, t);
   

   /* CORRECTION DE LA FONCTION DE carnac, risque de */
   /*   GET_NUCLEOTIDE_PAIR(s->bases[i+1], s->bases[j-1], ijm);*/
   /*   GET_NUCLEOTIDE_PAIR(s->bases[i+2], s->bases[j-2], ijd);*/

   GET_NUCLEOTIDE_PAIR_NONWC(s->bases[i+1], s->bases[j-1], b);
   GET_NUCLEOTIDE_PAIR_NONWC(s->bases[i+2], s->bases[j-2], c);

  return sint4_mat[a][b][c];
}




