#ifdef HAVE_CONFIG_H
    #include "config.h"
#endif
/*
Copyright or © or CCopr. INRIA : Arnaud FONTAINE

arnaud.fontaine@lifl.fr

This software is a computer program whose purpose is to predict 
significantly conserved protein coding sequences and/or RNA structure 
on a set of unaligned nucleic sequences.

This software is governed by the CeCILL  license under French law and
abiding by the rules of distribution of free software.  You can  use,
modify and/ or redistribute the software under the terms of the CeCILL
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info".

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability.

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or
data to be ensured and,  more generally, to use and operate it in the
same conditions as regards security.

The fact that you are presently reading this means that you have had
knowledge of the CeCILL license and that you accept its terms.
*/

#include <string.h>
#include <assert.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>
#include <dirent.h>

#include "opts.h"
#include "display.h"

int OPTS_quiet;
int OPTS_shuffling_sissiz;
int OPTS_keep_files;
int OPTS_first_phase;
char* OPTS_output_dir;
int OPTS_max_res;
/*double min_similarity;*/
double OPTS_min_aln_score;
int OPTS_nb_shuffles;
int OPTS_clustalw_multiple_alignment;
int OPTS_dialign_multiple_alignment;
int OPTS_multiple_alignment;
int OPTS_html_alignment;
int OPTS_use_cache;
int OPTS_carnac_correct_thd;
int OPTS_carnac_allow_single;
int OPTS_carnac_sankoff_stems;
int OPTS_hairpin_mode;
float CARNAC_SIM_THRESHOLD;

void
init_opts() {
   OPTS_keep_files = 0;
   OPTS_shuffling_sissiz = 0;
   OPTS_first_phase = 0;
   OPTS_output_dir = NULL;
   OPTS_max_res = -1;
   /*   min_similarity = -1.0;*/
   OPTS_min_aln_score = -INFINITY;
   OPTS_nb_shuffles = 0;
   OPTS_clustalw_multiple_alignment = 1;
   OPTS_dialign_multiple_alignment = 0;
   OPTS_multiple_alignment = 0;
   OPTS_use_cache = 0;
   OPTS_html_alignment = 0;
   OPTS_quiet = 0;
   OPTS_carnac_correct_thd = 1;
   OPTS_carnac_allow_single = 0;
   OPTS_carnac_sankoff_stems = 1;
   OPTS_hairpin_mode = 1;
   CARNAC_SIM_THRESHOLD = 92;
}

long int
quick_pow(const long int x, const int y) {
   if(y == 0) return 1;
   if(y == 1) return x;
   if((y % 2) == 0) return quick_pow(x * x, y / 2);

   return x * quick_pow(x * x, y / 2);   
}



long double
quick_powd(const long double d, const int y) {
   if(y == 0) return 1;
   if(y == 1) return d;
   if((y % 2) == 0) return quick_powd(d * d, y / 2);

   return d * quick_powd(d * d, y / 2);
}






int
prepare_dir(const char *dir) {
/*    if((mkdir(dir, ~0) != 0) && (errno != EEXIST)) { */
/*       ERROR_ "unable to create output directory '%s': %s\n", dir, strerror(errno) _ERROR; */
/*       return 1; */
/*    } */

  char *dir_to_create = NULL;
  int i,return_code;


  DIR *test_dir = opendir(dir);
  if(test_dir == NULL){

    if(dir[strlen(dir) - 1] == '\\'){
      
      NEW(dir_to_create, char, strlen(dir));
      for(i = 0; i < strlen(dir) - 2; i++){
	dir_to_create[i] = dir[i];
      }
      dir_to_create[strlen(dir) - 1] = '\0';
    }
    else{
      NEW(dir_to_create, char, strlen(dir) + 1);
      strcpy(dir_to_create,dir);
    }
    
    char *command_line = NULL;
    NEW(command_line, char, strlen("mkdir ") + strlen (dir_to_create) + 3);
    sprintf(command_line,
	    "%s%s%s",
	    "mkdir \"",
	    dir_to_create,
	    "\"");
    
    return_code = system(command_line);
    DESTROY(command_line);
    DESTROY(dir_to_create);
    
    
  }
  else{
    closedir(test_dir);

  }
  return 0;
}


unsigned long int
fact(const long int n) {
   return (n>1)?(n*fact(n-1)):(1);
}


int
file_exists(const char *file) {
  FILE* fd = NULL;

  errno = 0;

  if((fd = fopen(file, "r"))) {
    fclose(fd);
    return 1;
  }

  return 0;
}


int
move_file(const char* from, const char* to) {
   char* buffer = NULL;
   FILE* fdf = NULL;
   FILE* fdt = NULL;
   int nb = 0;
   int ret = 0;


   if(rename(from, to)) {
     if((fdf = fopen(from, "r"))) {
       if((fdt = fopen(to, "w"))) {
	 
	 NEW(buffer, char, INPUT_BUFFER);
	 
	 while(((nb = fread(buffer, sizeof(char), INPUT_BUFFER, fdf)) > 0)
	       && (fwrite(buffer, sizeof(char), nb, fdt) > 0));
	 
	 fclose(fdt);
	 unlink(from);
	 
	 DESTROY(buffer);
       } else {
	 ERROR_ "unable to open %s for writing\n", to _ERROR;
	 ret = 1;
       }
       
       fclose(fdf);
       
     } else {
       ERROR_ "unable to open %s for reading\n", from _ERROR;
       ret = 2;
     }
   }

   return ret;
}


double
MAX3(double n1, double n2, double n3) {
   double res;
   res = MAX2(n1, n2);
   res = MAX2(res, n3);
   return res;
}
