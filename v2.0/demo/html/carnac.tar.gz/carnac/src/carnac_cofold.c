#ifdef HAVE_CONFIG_H
    #include "config.h"
#endif

void compute_bounds (stem_list  , int **correlated) {
   int i, j, k, l;



  for (i=1; i<=Kn0; i++) {
     k=1;
     while((k<=Kn1) && (!correlated[K0[i]->s[0]][K1[k]->s[0]])) {
	k++;
     }
     
     K0[i]->k_bounds.min = k;
     if (k==Kn1+1)
	K0[i]->k_bounds.min = Z;
     
     k=Kn1;
     while((k>0) && (!correlated [K0[i]->s[0]] [K1[k]->s[0]])) {
	k--;
     }
     
     K0[i]->k_bounds.max = k;
  }

  // extend k bounds to single stems in seq 1
  for (i=1; i<=Kn0; i++) 
     if (!K0[i]->lonely)
	while ((K1 [MAX (K0[i]->k_bounds.min-1, 0)]->lonely) &&  (K0[i]->k_bounds.min >= 2)) 
	   K0[i]->k_bounds.min--;
  
  // l bounds : 0
  for (j=1; j<=Kn0; j++) {
     l=1;
     while((l<=Kn1) && (!correlated [L0[j]->s[0]] [L1[l]->s[0]])) {
	l++;
     }

     L0[j]->l_bounds.min = l;
     if (l==Kn1+1)
	L0[j]->l_bounds.min = Z;

     l=Kn1;
     while((l>0) && (!correlated [L0[j]->s[0]] [L1[l]->s[0]])) {
	l--;
     }

     L0[j]->l_bounds.max = l;
  }
  
  // extend l bounds to single stems in seq 1
  for (j=1; j<=Kn0; j++) 
     if (!L0[j]->lonely)
	while ((L1 [MIN (L0[j]->l_bounds.max+1, Kn1-1)]->lonely) && (L0[j]->l_bounds.max <= Kn1-1)) 
	   L0[j]->l_bounds.max++;
  
  // k bounds : 1
  for (k=1; k<=Kn1; k++) {
     i=1;
     while((i<=Kn0) && (!correlated [K0[i]->s[0]] [K1[k]->s[0]])) {
	i++;
     }
     
     K1[k]->k_bounds.min = i;
     if (i==Kn0+1)
	K1[k]->k_bounds.min = Z;

     i=Kn0;
     while((i>0) && (!correlated [K0[i]->s[0]] [K1[k]->s[0]])) {
	i--;
     }

     K1[k]->k_bounds.max = i;
  }
  
  
  // extend k bounds to single stems in seq 0
  for (k=1; k<=Kn1; k++) if (!K1[k]->lonely) //devrait assurer K1[k]-> k_bounds.min != Z
    while ((K0 [MAX (K1[k]->k_bounds.min-1, 0)]->lonely) && //question helene : O ou 1 dans le MAX ? idem ailleurs
	   (K1[k]->k_bounds.min >= 2)) K1[k]->k_bounds.min--;

  // l bounds : 1
  for (l=1; l<=Kn1; l++) {
    for (j=1; ((j<=Kn0) && (!correlated [L0[j]->s[0]] [L1[l]->s[0]])); j++);
    L1[l]->l_bounds.min = j; if (j==Kn0+1) L1[l]->l_bounds.min = Z;
    for (j=Kn0; ((j>0) && (!correlated [L0[j]->s[0]] [L1[l]->s[0]])); j--);
    L1[l]->l_bounds.max = j;}

  // extend l bounds to single stems in seq 0
  for (l=1; l<=Kn1; l++) if (!L1[l]->lonely)
    while ((L0 [MIN (L1[l]->l_bounds.max+1, Kn0-1)]->lonely) &&
	   (L1[l]->l_bounds.max <= Kn0-1)) L1[l]->l_bounds.max++;

  // ( 0 .. last_out ) [xxx[ (next_in .. last_in) ]xxx] (next_out ..)

  //  next (i,k) in         [0 .. Kn-1] U {Z}
  //  last (j,l) in  {-1} U [0 .. Kn-1]

  // last_in & last_out  :  0
  for (j=1; j<=Kn0; j++) {
     for (k=j-1; ((k>0) && (L0[k]->s[4] >= L0[j]->s[1])); k--);
     L0[j] -> last_out = k;
     for (k=j-1; ((k>0) && (L0[k]->s[4] >= L0[j]->s[3])); k--);
     L0[j] -> last_in = k;
  }
  // next_in & next_out :  0
  for (j=1; j<=Kn0; j++) {
    for (k=j+1; ((k<=Kn0) && (K0[k]->s[1] <= K0[j]->s[2])); k++);
    K0[j] -> next_in = k; if (k==Kn0+1) K0[j] -> next_in = Z;
    for (k=j+1; ((k<=Kn0) && (K0[k]->s[1] <= K0[j]->s[4])); k++);
    K0[j] -> next_out = k; if (k==Kn0+1) K0[j] -> next_out = Z;}

  // last_in & last_out  :  1
  for (j=1; j<=Kn1; j++) {
    for (k=j-1; ((k>0) && (L1[k]->s[4] >= L1[j]->s[1])); k--);
    L1[j] -> last_out = k;
    for (k=j-1; ((k>0) && (L1[k]->s[4] >= L1[j]->s[3])); k--);
    L1[j] -> last_in = k;}
  // next_in & next_out :  1
  for (j=1; j<=Kn1; j++) {
    for (k=j+1; ((k<=Kn1) && (K1[k]->s[1] <= K1[j]->s[2])); k++);
    K1[j] -> next_in = k; if (k==Kn1+1) K1[j] -> next_in = Z;
    for (k=j+1; ((k<=Kn1) && (K1[k]->s[1] <= K1[j]->s[4])); k++);
    K1[j] -> next_out = k; if (k==Kn1+1) K1[j] -> next_out = Z;}
}
