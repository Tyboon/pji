#ifndef __ARNICA_QSORT__
#define __ARNICA_QSORT__

#include <stdlib.h>


extern void
my_qsort_r(void *, size_t, size_t, void *, int (*)(void *, const void *, const void *));


#endif
