#ifndef __ARNICA_METASTEM_H__
#define __ARNICA_METASTEM_H__


#include <stdio.h>
#include "sequence.h"
#include "metasequence.h"
#include "stack.h"

#include "carnac_stems.h"


typedef struct {
   stem_t *seq_stems;
   int nb_seqs;
   int energy;
   short is_a_single_stem;
   int folded_id;
} metastem_t;




typedef struct {
   metastem_t *metastems;
   int nb_metastems;
} metastem_t_list_t;

typedef metastem_t_list_t *metastem_t_list;


typedef struct {
   int *metastem_id;
   int nb_metastems;
} metastem_list;


extern int
begin_start_gt(metastem_t m1, int value);

extern int
begin_stop_lt(metastem_t m1, int value);

extern int
begin_stop_leq(metastem_t m1, int value);

extern int
begin_start_geq(metastem_t m1, int value);
extern int
end_stop_lt(metastem_t m1, int value);
extern int
end_stop_leq(metastem_t m1, int value);
extern int
end_start_gt(metastem_t m1, int value);
extern int
end_start_geq(metastem_t m1, int value);


extern int
begin_start_leq_begin_stop(metastem_t m1, metastem_t m2, int floating);

extern int
begin_start_leq_end_start(metastem_t m1, metastem_t m2, int floating);

extern int
begin_stop_lt_end_start(metastem_t m1, metastem_t m2, int floating);

extern int
end_stop_lt_end_start(metastem_t m1, metastem_t m2, int floating);

extern int
end_stop_geq_begin_start(metastem_t m1, metastem_t m2, int floatinga);

extern int
end_stop_geq_end_start(metastem_t m1, metastem_t m2, int floating);

extern int
begin_start_leq_end_stop(metastem_t m1, metastem_t m2, int floating);

extern int
end_start_leq_begin_stop(metastem_t m1, metastem_t m2, int floating);

extern int
end_start_leq_end_stop(metastem_t m1, metastem_t m2, int floating);

extern int
end_start_gt_begin_stop(metastem_t m1, metastem_t m2, int floating);





extern int
metastems_have_a_common_base_pair(metastem_t *s1, metastem_t *s2);

extern stem_t_list
metastems_in_seq(const sequence s);


extern int
are_overlapping_metastems(metastem_t* a, metastem_t* b);



extern void
sort_metastems_id_by_begin_then_length(metastem_list *l, metastem_t_list s);

extern void
sort_metastems_id_by_end_closure_then_length(metastem_list *l, metastem_t_list s);




extern metastem_t*
largest_overlapping_metastem(metastem_t_list a, metastem_t_list b);

extern void
print_metastem(metastem_t *stem, metasequence s);


extern void
println_metastem(metastem_t *stem, metasequence s);


extern int
have_a_common_base_pair_meta(metastem_t *s1, stem_t *s2);



extern void
remove_common_metastems(metastem_t_list comst);

extern metastem_t_list
overlapping_metastems(metasequence meta, metastem_t_list a, stem_t_list b);





extern metastem_t_list
metastems_in_metasequence(metasequence meta);





extern void
adjust_meta(const metasequence_t m1, const metastem_t s1, const metasequence_t m2, const metastem_t s2, short_stack *values);



extern int
do_covar_meta(const metasequence_t *m1, const metastem_t *ss, const metasequence_t *m2, const metastem_t *sa, const int shift, const int id);


extern int
conserved_non_canonical_meta(const metasequence_t *m1, const metastem_t *ss, const metasequence_t *m2, const metastem_t *sa, const int shift);


#endif
