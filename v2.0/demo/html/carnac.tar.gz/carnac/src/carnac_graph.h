#ifndef __ARNICA_CARNAC_GRAPH_H__
#define __ARNICA_CARNAC_GRAPH_H__



#include "carnac_sankoff.h"
#include "carnac_stems.h"
#include "metasequence.h"



typedef enum { COFOLDED_STEMS, IDENTICAL_STEMS, NOTHING } stem_graph_edge_kind;


typedef struct {
   metastem_t_list_t stems;
   int seq_id;
   int cofolded_arity;
} node_t;


typedef struct {
   node_t *nodes;
   int nb_nodes;
   int max_nodes;
   stem_graph_edge_kind **edges;
   int nb_cofolded_edges;
   int nb_identity_edges;
   int nb_seqs;
   double index;
} graph_component_t;

typedef graph_component_t *graph_component;

typedef struct {
   graph_component_t *components;
   int nb_components;
   int max_components;
} stem_graph_t;


typedef stem_graph_t *stem_graph;




extern stem_graph
build_stem_graph(const sankoff_result sankoff, const metastem_t_list *stems, const metasequence *seqs, const int nb_seqs, int **id);

extern metastem_t_list_t*
final_structures(stem_graph graph, int nb_seqs);



#endif
