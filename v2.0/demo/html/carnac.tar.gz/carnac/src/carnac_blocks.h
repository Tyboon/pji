#ifndef __ARNICA_CARNAC_BLOCKS_H__
#define __ARNICA_CARNAC_BLOCKS_H__

#include "sequence.h"
#include "alignment.h"
#include "metasequence.h"

typedef struct {
   int from1;
   int to1;
   int from2;
   int to2;
   int nb_mism;
   int score;
} block_t;

typedef struct {
   block_t *blocks;
   int nb_blocks;
   int max_size;
} block_list_t;


typedef block_list_t *block_list;


extern block_list
new_block_list(int max_size);

extern void
add_block(block_list l, int from1, int from2, int to1, int to2, int nb_mism, int score);

extern void
destroy_block_list(block_list l);

extern void
order_blocks_by_decreasing_score(block_list l);

extern void
order_blocks_by_increasing_from(block_list l);

extern void
order_blocks_by_increasing_from_closure(block_list l);

extern void
remove_block(block_list l, int idx);



extern void
print_meta_block(block_t *block, metasequence m1, metasequence m2);

extern void
println_meta_block(block_t *block, metasequence m1, metasequence m2);



#endif
