#ifdef HAVE_CONFIG_H
    #include "config.h"
#endif
#include <math.h>
#include <string.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#include "boxes.h"
#include "display.h"
#include "opts.h"
#include "needle_common.h"
/* #include "needlep_common.h" */
#include "carnac_mfe.h"
#include "output.h"
#include "input.h"
#include "carnac.h"





extern int
box_nothing(const sequence* seqs, const int nb_seqs, sequence** prots);

extern int
box_gc(const sequence* seqs, const int nb_seqs, sequence** prots);

extern int
box_dinucleotide(const sequence* seqs, const int nb_seqs, sequence** prots);

extern int
box_length(const sequence* seqs, const int nb_seqs, sequence** prots);



struct blackbox_t blackboxes[] = {
   { "needle on nucleic sequences", "needle", "needle.out", "", "", box_needle},
   { "carnac", "carnac", "carnac_mfe.out", "", "", box_carnac_mfe},
   { "GC%", "gc", "gc.out", "", "", box_gc},
   { "dinucleotides frequencies", "dinucleotides", "dinucleotides.out", "", "", box_dinucleotide},
   { "length", "length", "length.out", "", "", box_length},
/*    { "needle on amino acid sequences", "needlep", "needlep.out", "needlep_graph.tex", "needlep_ranked_graph.tex", box_needlep}, */
   { "carnac (new version)", "carnac", "carnac.out", "", "", box_carnac},
};

blackbox NEEDLE_IDENTITY_BOX = &(blackboxes[0]);
blackbox CARNAC_ENERGY_BOX = &(blackboxes[1]);
blackbox GC_PERCENTAGE_BOX = &(blackboxes[2]);
blackbox DINUCLEOTIDE_PERCENTAGE_BOX = &(blackboxes[3]);
blackbox LENGTH_BOX = &(blackboxes[4]);
/*blackbox NEEDLE_PROTEIN_BOX = &(blackboxes[5]);*/
blackbox CARNAC_BOX = &(blackboxes[5]);


int
box_gc(const sequence* seqs, const int nb_seqs, sequence** prots) {
   int i;
   double r = 0.0;
   FILE* output_fd = NULL;
   char *output = NULL;

   if(OPTS_output_dir) {
      NEW(output, char, (strlen(OPTS_output_dir) + strlen(GC_PERCENTAGE_BOX->out_file) + 1));
      strcpy(output, OPTS_output_dir);
      strcat(output, GC_PERCENTAGE_BOX->out_file);
      
      if((output_fd = fopen(output, "w")) == NULL) {
	 ERROR_ "unable to create output file '%s'\n", output _ERROR;
	 return 1;
      }
   } else
      output_fd = stdout;
   

   for(i = 0; i < nb_seqs; i++)
      r += gc_percentage(seqs[i]);
   

   /* normalisation du score [-1;1] */
   /*   r = 2 * (r / nb_seqs) - 1;*/

   r = 100.0*r/nb_seqs;

   fprintf(output_fd, "GC = %.2f\n", r);

   if(OPTS_output_dir) {
      fflush(output_fd);
      fclose(output_fd);
      DESTROY(output);
   }

   return 0;
}




#define BASE_CONVERTER(Base,Indice)		\
   Indice = -1;					\
   switch(Base) {				\
   case 't':					\
   case 'T':					\
   case 'u':					\
   case 'U':					\
      Indice++;					\
   case 'g':					\
   case 'G':					\
      Indice++;					\
   case 'c':					\
   case 'C':					\
      Indice++;					\
   case 'a':					\
   case 'A':					\
      Indice++;					\
   default:					\
      break;					\
   }						\


int
box_dinucleotide(const sequence* seqs, const int nb_seqs, sequence** prots) {
   int i, j, prev, cur;
   int total;
   int** res = NULL;
   FILE* output_fd = NULL;
   char *output = NULL;
   char *nucl = "ACGU";


   if(OPTS_output_dir) {
      NEW(output, char, (strlen(OPTS_output_dir) + strlen(DINUCLEOTIDE_PERCENTAGE_BOX->out_file) + 1));
      strcpy(output, OPTS_output_dir);
      strcat(output, DINUCLEOTIDE_PERCENTAGE_BOX->out_file);
      
      if((output_fd = fopen(output, "w")) == NULL) {
	 ERROR_ "unable to create output file '%s'\n", output _ERROR;
	 return 1;
      }
   } else
      output_fd = stdout;


   NEW(res, int*, 4);
   for(i = 0; i < 4; i++) {
      NEW(res[i], int, 4);
      for(j = 0; j < 4; j++) {
	 res[i][j] = 0;
      }
   }

   total = 0;
   
   for(i = 0; i < nb_seqs; i++) {
      if(seqs[i]->length >= 2) {
	 BASE_CONVERTER(seqs[i]->bases[0], prev);
	 if(prev < 0) {
	    WARN_ "ignoring base '%c' at position %i in sequence '%s' !!\n", seqs[i]->bases[0], 1, seqs[i]->name _WARN;
	 } else {
	    for(j = 1; j < seqs[i]->length; j++) {
	       BASE_CONVERTER(seqs[i]->bases[j], cur);
	       if(cur < 0) {
		  WARN_ "ignoring base '%c' at position %i in sequence '%s' !!\n", seqs[i]->bases[j], (j+1), seqs[i]->name _WARN;
	       } else {
		  res[prev][cur]++;
		  total++;
		  
		  prev = cur;
	       }
	    }
	 }
      }
   }

   for(i = 0; i < 4; i++) {
      BASE_CONVERTER(nucl[i], prev);
      for(j = 0; j < 4; j++) {
	 BASE_CONVERTER(nucl[j], cur);

	 fprintf(output_fd, "%c%c = %.2f\n", nucl[i], nucl[j], 100.0 * res[prev][cur] / (total + 0.0));
      }
   }
      
   if(OPTS_output_dir) {
      fflush(output_fd);
      fclose(output_fd);
      DESTROY(output);
   }

   return 0;
}



int
box_length(const sequence* seqs, const int nb_seqs, sequence** prots) {
   int i;
   double r = 0.0;
   FILE* output_fd = NULL;
   char* output = NULL;

   if(OPTS_output_dir) {
      NEW(output, char, (strlen(OPTS_output_dir) + strlen(LENGTH_BOX->out_file) + 1));
      strcpy(output, OPTS_output_dir);
      strcat(output, LENGTH_BOX->out_file);
      
      if((output_fd = fopen(output, "w")) == NULL) {
	 ERROR_ "unable to create output file '%s'\n", output _ERROR;
	 return 1;
      }
   } else
      output_fd = stdout;

   for(i = 0; i < nb_seqs; i++)
      r += seqs[i]->length;
      
   r /= nb_seqs;

   fprintf(output_fd, "length = %.0f\n", r);

   if(OPTS_output_dir) {
      fflush(output_fd);
      fclose(output_fd);
      DESTROY(output);
   }


   return 0;
}
