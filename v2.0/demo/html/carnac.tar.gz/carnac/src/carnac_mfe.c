#ifdef HAVE_CONFIG_H
    #include "config.h"
#endif
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/stat.h>
//#include <sys/wait.h>
#include <regex.h>
#include <string.h>
#include <assert.h>
#include <errno.h>
#include <libgen.h>
#include <math.h>

#include "carnac_mfe.h"
#include "opts.h"
#include "display.h"
#include "boxes.h"
#include "input.h"
#include "output.h"
#include "stack.h"
#include "alignment.h"
#include "reduce.h"
#include "results.h"
#include "carnac.h"


regex_t* energy_regex = NULL;






/* output is a mask, which contains ONE X which will be replaced by the number of the shuffle */
/* shuffle-aln.pl */
int
shuffle_aln(const char* input, const int nb, const char* output_mask) {
   int status;
   char* str = NULL;


   if(nb > 1) {
      NEW(str, char, (1 + 28 + 20 + strlen(SHUFFLE_EXE) + strlen(output_mask) + strlen(input)));
      sprintf(str, "perl \"%s\" -n %i --mask \"%s\" < \"%s\"", SHUFFLE_EXE, nb, output_mask, input);
   } else {
      NEW(str, char, (1 + 10 + strlen(SHUFFLE_EXE) + strlen(output_mask) + strlen(input)));
      printf(str, " perl \"%s\" < \"%s\" > \"%s\"", SHUFFLE_EXE, input, output_mask);
   }

   if((status = system(str))) {
      return status;
   }

   DESTROY(str);

   return 0;   
}

/* SISSIZ */

int
shuffle_aln_di(const char* input, const int nb, const char* output_base) {
   int status;
   char* str = NULL;


   NEW(str, char, (strlen(SHUFFLE_SISSIZ_EXE) + 16 + 10 + 2 + strlen(input) + 4 + strlen(SPLITSHUFFLE_SH) + 2 + strlen(output_base) + 1 + 1));
   sprintf(str, "%s -s -d --rna -n %i '%s' | %s '%s'", SHUFFLE_SISSIZ_EXE, nb, input, SPLITSHUFFLE_SH, output_base);
   
   if((status = system(str))) {
      return status;
   }

   DESTROY(str);

   return 0;   
}







int
is_rna(const double zscore) { return zscore <= /*-1.165*/ -1.0; }


int
box_carnac_mfe(const sequence* oseqs, const int onb_seqs, sequence** prots) {
   int i, j, k, *counter, nb_sseqs, be_quiet;
   char *concat, *t, *align, *shuffle_base, *shuffle_mask, *sw, *output = NULL, *output1 = NULL;
   sequence* sseqs, stemp;
   int **carnac_res;
   double *mean , *type, tmp;
   FILE* fd, *output_fd = NULL, *output_fd1 = NULL;
   int *prediction = NULL;
  

   if(OPTS_output_dir) {
      if(OPTS_keep_files) {
	 NEW(sw, char, (strlen(OPTS_output_dir) + strlen(CARNAC_ENERGY_BOX->dir) + 1));
	 strcpy(sw, OPTS_output_dir);
	 strcat(sw, CARNAC_ENERGY_BOX->dir);
	 if(prepare_dir(sw)) {
	    ERROR_ "unable to create output dir '%s'\n", sw _ERROR;
	    return 1;
	 }
	 DESTROY(sw);
      }

      NEW(output, char, (strlen(OPTS_output_dir) + strlen(CARNAC_ENERGY_BOX->out_file) + 1));
      strcpy(output, OPTS_output_dir);
      strcat(output, CARNAC_ENERGY_BOX->out_file);

      NEW(output1, char, (strlen(OPTS_output_dir) + strlen("carnac.out") + 1));
      strcpy(output1, OPTS_output_dir);
      strcat(output1, "carnac.out");

      
      if((output_fd = fopen(output, "w")) == NULL) {
	 ERROR_ "unable to create output file '%s'\n", output _ERROR;
	 return 1;
      }      

      if((output_fd1 = fopen(output1, "w")) == NULL) {
	 ERROR_ "unable to create output file '%s'\n", output1 _ERROR;
	 return 1;
      }      

   } else {
      output_fd = DISPLAY_OUT;
      output = NULL;
   }


   if(RESULTS_sequence_similarities == NULL) {
      RESULTS_sequence_similarities = similarities(oseqs, onb_seqs);
   }


   /*   INFO_ "Computing %s...   0%%", CARNAC_ENERGY_BOX->name _INFO;*/
   INFO_ "Computing %s...", CARNAC_ENERGY_BOX->name _INFO;
   FLUSH_OUT;

   /* 1 pour chaque shuffle + 1 pour les s�quences originelles */
   NEW(carnac_res, int*, (OPTS_nb_shuffles + 1));
   
   /* s�quences originelles */
   be_quiet = OPTS_quiet;
   OPTS_quiet = 1;
   if(carnac(oseqs, onb_seqs, output_fd1, &(carnac_res[0]), 1) == 0) {
      /* OPTS_quiet = be_quiet; */
      /*	 INFO_ "(%i structured / %i sequences used) %3.0f%%", i, nb_seqs, (100.0*count)/nb_shuffles _INFO;*/
      /*	 nbs = i;*/
      /*	 INFO_ "%3.0f%%", (100.0*count)/nb_shuffles _INFO;*/
      INFO_ "." _INFO;
   } else {
      ERROR_ "an error occured during carnac runs\n" _ERROR;
      return 1;
   }
   
   
   /*Temp file change*/
/*    t = tmpnam(NULL); */
/*    NEW(concat, char, (1 + strlen(t))); */
/*    strcpy(concat, t); */
   
   FILE *file_d;
   char *temp_name;
   char *name = "temp_";
   int random = (rand() & 32767);

   NEW(temp_name, char, strlen(name) + 10);

   sprintf(temp_name,
	   "%s%i",
	   name,
	   random);
   while((file_d = fopen(temp_name, "r")) != NULL){
     DESTROY(temp_name);
     NEW(temp_name, char, strlen(name) + 10);
     random = (rand() & 32767);
     sprintf(temp_name,
	     "%s%i",
	     name,
	     random);
     fclose(file_d);

   }

   NEW(concat, char, strlen(temp_name) + 1);
   strcpy(concat,temp_name);
   DESTROY(temp_name);

   if((fd = fopen(concat, "w"))) {
      if(write_fasta(fd, oseqs, onb_seqs, 0) == 0) {
	 fflush(fd);
	 fclose(fd);
	 
	 /*Temp file change*/
	 /* t = tmpnam(NULL); */
/* 	 NEW(align, char, (1 + strlen(t))); */
/* 	 strcpy(align, t); */
	 
	 random = (rand() & 32767);

	 NEW(temp_name, char, strlen(name) + 10);

	 sprintf(temp_name,
		 "%s%i",
		 name,
		 random);
	 while((file_d = fopen(temp_name, "r")) != NULL){
	   DESTROY(temp_name);
	   NEW(temp_name, char, strlen(name) + 10);
	   random = (rand() & 32767);
	   sprintf(temp_name,
		   "%s%i",
		   name,
		   random);
	   fclose(file_d);
	   
	 }

	 NEW(align, char, strlen(temp_name) + 1);
	 strcpy(align,temp_name);
	 DESTROY(temp_name);


	 if(align_clustalw(concat, align) == 0) {
	    
	    unlink(concat);
	    DESTROY(concat);

	    if(OPTS_shuffling_sissiz) {
	       
	      /*Temp file change*/
/* 	       t = tmpnam(NULL); */
/* 	       NEW(shuffle_base, char, (strlen(t) + 1)); */
/* 	       strcpy(shuffle_base, t); */

	      random = (rand() & 32767);

	      NEW(temp_name, char, strlen(name) + 10);

	      sprintf(temp_name,
		      "%s%i",
		      name,
		      random);
	      while((file_d = fopen(temp_name, "r")) != NULL){
		DESTROY(temp_name);
		NEW(temp_name, char, strlen(name) + 10);
		random = (rand() & 32767);
		sprintf(temp_name,
			"%s%i",
			name,
			random);
		fclose(file_d);
		
	      }
	      
	      NEW(shuffle_mask, char, strlen(temp_name) + 2);
	      strcpy(shuffle_mask,temp_name);


	    } else {

	      /*Temp file change*/
/* 	       t = tmpnam(NULL); */
/* 	       NEW(shuffle_mask, char, (2 + strlen(t))); */
/* 	       strcpy(shuffle_mask, t); */

	      random = (rand() & 32767);

	      NEW(temp_name, char, strlen(name) + 10);

	      sprintf(temp_name,
		      "%s%i",
		      name,
		      random);
	      while((file_d = fopen(temp_name, "r")) != NULL){
		DESTROY(temp_name);
		NEW(temp_name, char, strlen(name) + 10);
		random = (rand() & 32767);
		sprintf(temp_name,
			"%s%i",
			name,
			random);
		fclose(file_d);
		
	      }
	      
	      NEW(shuffle_mask, char, strlen(temp_name) + 2);
	      strcpy(shuffle_mask,temp_name);

	       
	       for(i = 0; i < strlen(shuffle_mask); i++)
		  if((shuffle_mask[i] == 'X') || (shuffle_mask[i] == 'x'))
		     shuffle_mask[i] = '.';
	       
	       if(OPTS_nb_shuffles == 1) {
		  /* shuffle_mask[strlen(t)] = '1'; */
		 shuffle_mask[strlen(temp_name)] = '1';
	       } else {
		  /* shuffle_mask[strlen(t)] = 'X'; */
		 shuffle_mask[strlen(temp_name)] = 'X';
	       }
	       /* shuffle_mask[strlen(t) + 1] = '\0'; */
	       shuffle_mask[strlen(temp_name) + 1] = '\0';
	       DESTROY(temp_name);
	    }

	    if((OPTS_shuffling_sissiz && (shuffle_aln_di(align, OPTS_nb_shuffles, shuffle_base) == 0))
	       || (!OPTS_shuffling_sissiz && (shuffle_aln(align, OPTS_nb_shuffles, shuffle_mask) == 0))) {
	    
	       
	       unlink(align);
	       DESTROY(align);
	       
	       nb_sseqs = 0;
	       sseqs = NULL;
	       

	       for(i = 0; i < OPTS_nb_shuffles; i++) {
		  if(OPTS_shuffling_sissiz) {
		     
		     NEW(t, char, (1 + strlen(shuffle_base) + 30));
		     strcpy(t, shuffle_base);
		     sprintf(&(t[strlen(shuffle_base)]), ".%i", (i+1));
		     
		  } else {
		     NEW(t, char, (1 + strlen(shuffle_mask) + 30));
		     strncpy(t, shuffle_mask, (strlen(shuffle_mask) - 1));
		     sprintf(&(t[strlen(shuffle_mask) - 1]), "%i", (i+1));
		  }
		  
		  if(read_sequences(t, &(sseqs), &(nb_sseqs)) == 0) {
		     unlink(t);
		     DESTROY(t);
		     
		     if(nb_sseqs != onb_seqs) {
			ERROR_ "FATAL ERROR: missing sequences after shuffling\n" _ERROR;
			unlink(concat);
			return 1;
		     }
		     
		     for(j = 0; j < nb_sseqs; j++) {
			stemp = ungap(sseqs[j]);
			DESTROY(sseqs[j]->file);
			DESTROY(sseqs[j]->name);
			DESTROY(sseqs[j]->input_name);
			DESTROY(sseqs[j]->bases);
			
			DESTROY(sseqs[j]);
			
			sseqs[j] = stemp;
		     }
		     
		     be_quiet = OPTS_quiet;
		     OPTS_quiet = 1;
		     if(carnac(sseqs, nb_sseqs, NULL, &(carnac_res[i + 1]), 0) == 0) {
			OPTS_quiet = be_quiet;
			INFO_ "." _INFO;
			FLUSH_OUT;
			/*REWIND(4);
			  INFO_ "%3.0f%%", (100.0*count)/nb_shuffles _INFO;*/
		     } else {
			ERROR_ "an error occured during %s runs\n", CARNAC_EXE _ERROR;
			unlink(concat);
			return 1;
		     }
		     
		     for(j = 0; j < nb_sseqs; j++) {
			DESTROY(sseqs[j]->file);
			DESTROY(sseqs[j]->input_name);
			DESTROY(sseqs[j]->name);
			DESTROY(sseqs[j]->bases);
			DESTROY(sseqs[j]);
		     }
		     
		     DESTROY(sseqs);
		     nb_sseqs = 0;
		     
		  } else {
		     return 1;
		  }

		  DESTROY(t);
	       }
	       
	       /*		  INFO_ "\n" _INFO;*/
	       INFO_ "ok\n" _INFO;
	       
	       
	       NEW(mean, double, onb_seqs);
	       NEW(type, double, onb_seqs);
	       NEW(counter, int, onb_seqs);
	       j = 0;
	       
	       for(i=0;i<onb_seqs;i++) {
		  mean[i] = type[i] = 0.0;
		  counter[i] = 0;
		  if(carnac_res[0][i]) {
			j++;
		     }
		  }

		  fprintf(output_fd, "%2i / %2i structured sequences\n",  j, onb_seqs);
		  fprintf(output_fd, "\nSequences\tStructuredPvalue=%.2f\n", (j + 0.0)/onb_seqs);

		  fprintf(output_fd, "\t            ");
		  for(i=0;i<onb_seqs;i++) {
		     fprintf(output_fd, "\t%9s", oseqs[i]->name);
		  }
		  fprintf(output_fd, "\n");

		  fprintf(output_fd, "\tenergy      ");
		  for(i=0;i<onb_seqs;i++) {
		     fprintf(output_fd, "\t%9i", carnac_res[0][i]);
		  }
		  fprintf(output_fd, "\n");
		  
		  k = 0;

		  for(j=1;j<(OPTS_nb_shuffles+1);j++) {
		     for(i=0;i<onb_seqs;i++) {
			if(carnac_res[j][i]) {
			   mean[i] += carnac_res[j][i];
			   counter[i]++;
			   k++;
			}
		     }
		  }
		  
		  for(i=0;i<onb_seqs;i++) {
		     if(counter[i]) {
			mean[i] /= counter[i];

			for(j=1;j<(OPTS_nb_shuffles+1);j++) {
			   if(carnac_res[j][i]) {
			      type[i] += pow(carnac_res[j][i] - mean[i], 2.0);
			   }
			}
			
			
			if(counter[i] > 1) {
			   type[i] /= counter[i];
			   type[i] = sqrt(type[i]);
			} else {
			   type[i] /= (counter[i]+0.0);
			   type[i] = sqrt(type[i]);
			}
		     } else {
			mean[i] = 0.0;
			type[i] = 1.0;
		     }
		  }


		  NEW(prediction, int, onb_seqs);
		  fprintf(output_fd, "\tz-score     ");
		  for(i=0;i<onb_seqs;i++) {
		     if(is_rna((carnac_res[0][i] - mean[i]) / type[i])) {
			prediction[i] = 1;
		     } else {
			prediction[i] = 0;
		     }
		     fprintf(output_fd, "\t%9.2f", (carnac_res[0][i] - mean[i]) / type[i]);
		  }
		  fprintf(output_fd, "\n\n");


		  fprintf(output_fd, "Shuffles energy\tStructuredPvalue=%.2f", (k + 0.0)/(OPTS_nb_shuffles*onb_seqs));

		  for(j=1;j<(OPTS_nb_shuffles+1);j++) {
		     fprintf(output_fd, "\n\tshuffle%4i:", j);
		     for(i=0;i<onb_seqs;i++) {
			fprintf(output_fd, "\t%9i", carnac_res[j][i]);
		     }
		  }
		  fprintf(output_fd, "\n");

		  

		  j = 0;
		  tmp = 0.0;
		  for(i = 0; i < onb_seqs; i++) {
		     if(prediction[i]) {
			j++;
		     }
		     if(counter[i]) {
			tmp += (carnac_res[0][i] - mean[i]) / type[i];
		     }
		  }
		  tmp/=(0.0+onb_seqs);

		  /*if(j >= (onb_seqs/2.0)) {*/
		  if(is_rna(tmp)) {
		     fprintf(output_fd, "prediction = RNA\n");
		  } else {
		     fprintf(output_fd, "prediction = OTHER\n");
		  }




		  DESTROY(mean);
		  DESTROY(type);
		  DESTROY(counter);

		  for(i = 0; i < (OPTS_nb_shuffles+1); i++) {
		     DESTROY(carnac_res[i]);
		  }
		  DESTROY(carnac_res);
		  




		  
		  if(output) {
		     fflush(output_fd);
		     fclose(output_fd);
		     DESTROY(output);
		  }

		  
		  
	    } else {
	       ERROR_ "an error occured during alignment shuffling\n" _ERROR;
	       return 1;
	    }


	    if(OPTS_shuffling_sissiz) {
	       DESTROY(shuffle_base);
	    } else {
	       DESTROY(shuffle_mask);
	    }

	 } else {
	    ERROR_ "an error occured during CLUSTALW alignment\n" _ERROR;
	    return 1;
	 }
      } else {
	 ERROR_ "an error occured while writing sequences in fasta format\n" _ERROR;
	 return 1;
      }
   } else {
      ERROR_ "unable to open '%s' for writing\n", concat  _ERROR;
      return 1;
   }
   


   

   return 0;
}





