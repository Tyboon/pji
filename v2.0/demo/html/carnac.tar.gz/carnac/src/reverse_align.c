#ifdef HAVE_CONFIG_H
    #include "config.h"
#endif
#include "reverse_align.h"
#include "opts.h"
#include "display.h"
#include "output.h"

#include <ctype.h>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>



int_stack
dynamic_protein_dna(const sequence prot, const sequence dna, int nbfs) {
   
   int i, j, k, jj;
   
   int **pFS = NULL;

   int dobreak;

   int_stack pStack = NULL;
    

   /*  ERROR_ "nbfs = %i\n", nbfs _ERROR;*/


   
   /* Filling matrix */
   NEW(pFS, int*, prot->length);
   for (i=0; i<prot->length ;i++) {
      NEW(pFS[i], int, dna->length);
      for(j = 0; j < dna->length; j++) {
	 pFS[i][j] = 0;
      }
   }

   for(j = 0; j <= (3*nbfs); j++) {
      for(k = 0; k < 3; k++) {
	 if(translate_codon(dna, j+k) == prot->bases[0] || prot->bases[0] == 'X') {
	    pFS[0][j+k] = 1;
	 } else {
	    pFS[0][j+k] = 0;
	 }
	 /*ERROR_ "p[%i][%i] (%c, %.3s) = %i\n", 0, j+k, prot->bases[0], &(dna->bases[j+k]), pFS[0][j+k] _ERROR;*/
      }
   }

   for (i=1; i<prot->length ;i++) {
      for(j=3*i-(3*nbfs); j < (3*nbfs)+3*(i+1); j++) {
	 if(((j+3) <= dna->length) && j>=0) {
	    if(translate_codon(dna, j) == prot->bases[i] || prot->bases[i] == 'X') {
	       pFS[i][j] = 0;
	       for(k = -2; k <=3 ; k++) {
		  if(((j-3+k) < dna->length) && (j-3+k) >= 0) {
		     pFS[i][j] = MAX(pFS[i][j], (pFS[i-1][j-3+k] + 1));
		  }
	       }
	    } else {
	       pFS[i][j] = 0;
	    }
	    /*ERROR_ "p[%i][%i] (%c, %.3s) = %i\n", i, j, prot->bases[i], &(dna->bases[j]), pFS[i][j] _ERROR;*/
	 }
      }
   }

   /* Backtracking */
   
   NEW_INT_STACK(pStack, prot->length);
   
   dobreak = 0;
   for(j=3*(prot->length-1)-(3*nbfs); !dobreak && j < (3*nbfs)+3*prot->length; j++) {
      if(pFS[prot->length - 1][j] == prot->length) {

	 STACK_EMPTY(pStack);
	 STACK_PUSH(pStack, j);

	 i = prot->length-1;
	 jj = j;

	 dobreak = 1;
	 while(dobreak && (i > 0)) {

	    dobreak = 0;
	    
	    if(((jj-3) >= 0) && (1 + pFS[i-1][jj-3] == pFS[i][jj])) {
	       STACK_PUSH(pStack, jj-3);

	       jj-=3;
	       i-=1;
	       
	       dobreak = 1;

	    } else {
	       for(k = jj - 6; !dobreak && (k <= jj); k++) {
		  if(k >= 0) {
		     if(1 + pFS[i-1][k] == pFS[i][jj]) {
			STACK_PUSH(pStack, k);
			jj = k;
			i-=1;

			dobreak = 1;

		     }
		  }
	       }
	    }
	 }

      }
   }



  /* Free the frameshift's matrix */  
  for (i=0;i< prot->length; i++) {
     DESTROY(pFS[i]);
  }
  
  DESTROY(pFS);

  return pStack;
}







sequence
align_protein_dna(const sequence prot_aligned, const sequence prot, const sequence dna, const int nbfs, int *start, int *stop) {
   int_stack s = NULL;
   sequence res = NULL;
   int head, next;
   int i, j;
   int ppos, lastdna;


   s = dynamic_protein_dna(prot, dna, nbfs);

   
   if(s == NULL || STACK_IS_EMPTY(s)) {
      return NULL;
   }
   
   
   /*
   for(i = STACK_SIZE(s) - 1; i >= 0; i--) {
      fprintf(stdout, "%i, ", STACK_VALUE_AT(s,i));
   }
   fprintf(stdout, "\n");
   */


   res = init_sequence(prot->file, prot->input_name, prot->name, NULL, 0, dna->strand);
   res->nb_gaps = 0;
   RENEW(res->bases, char, 3*(STACK_SIZE(s) + prot_aligned->nb_gaps + 1) + 1);
   /*ERROR_ "STACK_SIZE %i nbfs %i peek %i ALLOCATED %i\n", STACK_SIZE(s), nbfs, STACK_PEEK(s), 3*(STACK_SIZE(s) + prot_aligned->nb_gaps + 1) + 1  _ERROR;*/

   /*
   i = 0;
   while((i < prot_aligned->length) && (prot_aligned->bases[i] == '.' || prot_aligned->bases[i] == '-')) i++;
   */


   /*
     (*start) = STACK_PEEK(s);
     
     
     res->length = 0;
     
     if(toupper(prot_aligned->bases[i]) == 'X') {
     for(i = (*start); i < 3; i++) {
	 res->bases[res->length++] = '-';
	 }
	 for(i = 0; i < (*start); i++) {
	 res->bases[res->length++] = dna->bases[i];
	 }
	 
	 (*start) = 0;
	 }
   */

   (*start) = STACK_PEEK(s);

   i = 0;
   ppos = 0;
   lastdna = 0;
   while(i < prot_aligned->length) {
      
      /*      ERROR_ "  BASE %3i '%c'\n", i, prot_aligned->bases[i] _ERROR;*/

      switch(prot_aligned->bases[i]) {
      case '-':
      case '.':
	 res->bases[res->length++] = '-';
	 res->bases[res->length++] = '-';
	 res->bases[res->length++] = '-';
	 res->nb_gaps += 3;
	 i++;
	 break;
      case 'X':
      case 'x':
	 i++;
	 break;
      default:
	 head = STACK_POP(s);
	 for(j = 0; j < 3; j++) {
	    res->bases[res->length++] = dna->bases[head+j];
	    lastdna = head+j;
	 }
	 
	 if(!STACK_IS_EMPTY(s)) {
	    next = STACK_PEEK(s);
	    
	    for(j = (head+3); j < next; j++) {
	       res->bases[res->length++] = dna->bases[j];
	       lastdna = j;
	    }
	    
	    for(j = (next - head); j > 3; j--) {
	       res->bases[res->length++] = '-';
	       res->nb_gaps++;
	    }
	 }
	 
	 if((ppos < prot->length) && (toupper(prot->bases[ppos]) != 'X')) i++;

	 ppos++;
	 
	 break;
      }
   }

   (*stop) = lastdna;


   RENEW(res->bases, char, (res->length+1));
   res->bases[res->length] = '\0';
   /*ERROR_ "LENGTH %i\n",res->length  _ERROR;*/
   

   DESTROY_STACK(s);

   return res;
}





sequence
*realign(const sequence *prots_aligned, const sequence *prots, const sequence *dna, const int nb_seqs, const int* nbfs, const char *output) {
   sequence *res = NULL;
   int i, j, k;
   int maxlength = 0;
   int maxstart = 0;
   int maxleft = 0;
   int *start = NULL, *stop = NULL;
   int status = 0;
   FILE *fd = NULL;
   int astart_at = 0;
#ifdef HTML_ALIGNMENT
   char *temp = NULL;
#endif


   NEW(res, sequence, nb_seqs);
   NEW(start, int, nb_seqs);
   NEW(stop, int, nb_seqs);
   
   for(i = 0; i < nb_seqs; i++) {
      res[i] = align_protein_dna(prots_aligned[i], prots[i], dna[i], nbfs[i], &(start[i]), &(stop[i]));
      maxstart = MAX(maxstart, start[i]);
      maxleft = MAX(maxleft, (dna[i]->length - stop[i] - 1));

      /*INFO_ "MAXSTART for %i = %i\n", i, start[i] _INFO;*/

   }
   


   astart_at = maxstart;


   /* complete untranslated nucleotides at the beginning */
   for(i = 0; i < nb_seqs; i++) {

      /*      write_fasta(DISPLAY_OUT, &(res[i]), 1, 1);*/

      if(maxstart > 0) {
	 RENEW(res[i]->bases, char, (res[i]->length + 1 + maxstart));
	 memmove(&(res[i]->bases[maxstart]), res[i]->bases, res[i]->length);
	 for(j = 0; j < (maxstart - start[i]); j++) {
	    res[i]->bases[j] = '-';
	 }
	 k = maxstart;
	 while(res[i]->bases[k] == '-') {
	    res[i]->bases[k-maxstart] = '-';
	    k++;
	 }
	 for(j = 0; j < start[i]; j++) {
	    res[i]->bases[(k-start[i])+j] = dna[i]->bases[j];
	 }
	 
	 res[i]->length += maxstart;
      }
      
      maxlength = MAX(maxlength, res[i]->length);

      /*      write_fasta(DISPLAY_OUT, &(res[i]), 1, 1);*/

      /*   fprintf(stdout, "(maxlength = %i), %s\n", maxlength, res[i]->bases);*/
   }
   
   DESTROY(start);


   /* complete alignment end with gaps */
   for(i = 0; i < nb_seqs; i++) {
      if(res[i]->length < maxlength) {

	 RENEW(res[i]->bases, char, (maxlength+1));
	 for(j = res[i]->length; j < maxlength; j++) {
	    res[i]->bases[j] = '-';
	 }
	 res[i]->length = maxlength;
      }
   }



   /* removing gapped positions at end */
   j = maxlength-1;
   k = 1;
   while(k && (j >= 0)) {
      i = 0;
      while(k && (i < nb_seqs)) {
	 k = (res[i++]->bases[j] == '-');
      }
      if(k) {
	 maxlength--;
	 for(i = 0; i < nb_seqs; i++) {
	    res[i]->length--;
	 }
      }
      j--;
   }


   /* removing gapped positions at beginning */
   j = 0;
   k = 1;
   while(k && (j < maxlength)) {
      i = 0;
      while(k && (i < nb_seqs)) {
	 k = (res[i++]->bases[j] == '-');
      }
      if(k) {
	 astart_at--;
	 maxlength--;
	 for(i = 0; i < nb_seqs; i++) {
	    res[i]->length--;
	    memmove(res[i]->bases, &(res[i]->bases[1]), (res[i]->length-1));
	 }
      }
      j--;
   }


   /* complete untranslated nucleotides at the end */
   for(i = 0; i < nb_seqs; i++) {
      if(maxleft > 0) {
	 RENEW(res[i]->bases, char, (maxlength + 1 + maxleft));
	 
	 for(j = stop[i]+1; j < dna[i]->length; j++) {
	    res[i]->bases[res[i]->length++] = dna[i]->bases[j];
	 }
	 for(j = 0; j < (maxleft - (dna[i]->length - stop[i] - 1)); j++) {
	    res[i]->bases[res[i]->length++] = '-';
	 }
      }

      res[i]->bases[res[i]->length] = '\0';
      /*fprintf(stdout,"\n>%s\n%s\n", res[i]->input_name, res[i]->bases);*/
   }

   DESTROY(stop);





   status = 0;

   if(output) {
      if((fd = fopen(output, "w"))) {

	 write_clustal(fd, res, nb_seqs, 1);
	 fflush(fd);
	 fclose(fd);
#ifdef HTML_ALIGNMENT
	 if(OPTS_html_alignment) {
	    NEW(temp, char, (strlen(OPTS_output_dir) + 1 + strlen(SEQUENCES_PROT_ALIGNMENT_HTML_FILE) + 1));
	    strcpy(temp, OPTS_output_dir);
	    strcat(temp, "/");
	    strcat(temp, SEQUENCES_PROT_ALIGNMENT_HTML_FILE);
	    if((fd = fopen(temp, "w"))) {
	       write_color_clustal_dna(fd, res, nb_seqs, astart_at);
	       fflush(fd);
	       fclose(fd);
	    } else {
	       ERROR_ "unable to open '%s' for writing\n", temp _ERROR;
	       status = 1;
	    }
	    DESTROY(temp);
	 }
#endif
      } else {
	 ERROR_ "unable to open '%s' for writing !!\n", output _ERROR;
	 status = 1;
      }
   } else {
      write_clustal(stdout, res, nb_seqs, 1);
   }

   for(i = 0; i < nb_seqs; i++) {
      if(res[i]) {
	 DESTROY(res[i]->file);
	 DESTROY(res[i]->input_name);
	 DESTROY(res[i]->name);
	 DESTROY(res[i]->bases);
	 DESTROY(res[i]);
      }
   }
   DESTROY(res);


   return res;
}

