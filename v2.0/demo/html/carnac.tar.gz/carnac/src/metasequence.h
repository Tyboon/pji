#ifndef __ARNICA_METASEQUENCE_H__
#define __ARNICA_METASEQUENCE_H__


#include "alignment.h"
#include "sequence.h"


typedef alignment_t metasequence_t;
typedef metasequence_t *metasequence;


extern
metasequence new_metasequence_from_alignment(alignment a);


extern
metasequence new_metasequence_from_sequence(sequence s);



#endif
