#ifdef HAVE_CONFIG_H
    #include "config.h"
#endif
#include "carnac_metaseq.h"
#include "carnac_compatible.h"
#include "opts.h"
#include "display.h"

#include <stdlib.h>
#include <assert.h>
#include <time.h>


#ifdef _OPENMP
#include <omp.h>
#endif







void
create_anchor_stem_list(const metastem_t_list_t l1, const metastem_t_list_t l2, const block_list bl, anchor_stem_list res) {
   int i, j, t;
   int cg, cd, og, od;


   NEW(res->astems_1, anchor_stem_t, l1.nb_metastems);
   NEW(res->astems_2, anchor_stem_t, l2.nb_metastems);

   
   res->nb_astems_1 = 0;
   res->nb_astems_2 = 0;



   for(i = 0; i < l1.nb_metastems; i++) {
      res->astems_1[i].metastem = &(l1.metastems[i]);
      res->astems_1[i].open_left_block = NULL;
      res->astems_1[i].open_right_block = NULL;
      res->astems_1[i].close_left_block = NULL;
      res->astems_1[i].close_right_block = NULL;
   }
   res->nb_astems_1 = l1.nb_metastems;
   
   for(i = 0; i < l2.nb_metastems; i++) {
      res->astems_2[i].metastem = &(l2.metastems[i]);
      res->astems_2[i].open_left_block = NULL;
      res->astems_2[i].open_right_block = NULL;
      res->astems_2[i].close_left_block = NULL;
      res->astems_2[i].close_right_block = NULL;
   }
   res->nb_astems_2 = l2.nb_metastems;



   if(bl->nb_blocks == 0) {
      return ; /****** !!!! ****/
   }
   
   order_blocks_by_increasing_from_closure(bl);



   /******* OPENINGS ********/

   for(i = 0; i < l1.nb_metastems; i++) {

      t = 0;

      j = bl->nb_blocks - 1;
      while((j >= 0) && begin_stop_leq(l1.metastems[i], bl->blocks[j].from1)) {
	 j--;
      }

      if(j >= 0) {
	 cg = j;

	 if(begin_stop_leq(l1.metastems[i], bl->blocks[j].to1)) {
	    cd = j;
 	    res->astems_1[i].open_right_block = &(bl->blocks[j]);
	 } else {
	    j++;
	    cd = j;
	    if(j < bl->nb_blocks) {
	       res->astems_1[i].open_right_block = &(bl->blocks[j]);
	    }
	 }
      } else {
	 cg = -1;
	 cd = 0;
	 res->astems_1[i].open_right_block = &(bl->blocks[0]);	 
      }


      j = 0;
      while((j < bl->nb_blocks) && begin_start_gt(l1.metastems[i], bl->blocks[j].to1)) {
	 j++;
      }



      if(j < bl->nb_blocks) {
	 od = j;

	 if(begin_start_geq(l1.metastems[i], bl->blocks[j].from1)) {
	    og = j;
	    res->astems_1[i].open_left_block = &(bl->blocks[j]);
	 } else {
	    j--;
	    og = j;
	    if(j >= 0) {
	       res->astems_1[i].open_left_block = &(bl->blocks[j]);
	    }
	 }
      } else {
	 od = -1;
	 og = bl->nb_blocks - 1;
	 res->astems_1[i].open_left_block = &(bl->blocks[bl->nb_blocks - 1]);	 
      }


      if(cg == cd) { t = 1; }
      if(og == od) { t += 2; }

      if(t == 0) {
	 if((od == cg) && (od != -1)) {
	    res->astems_1[i].open_left_block = res->astems_1[i].open_right_block = &(bl->blocks[od]);
	 }
      } else if(t == 1) {
	 res->astems_1[i].open_left_block = res->astems_1[i].open_right_block;
      } else if(t == 2) {
	 res->astems_1[i].open_right_block = res->astems_1[i].open_left_block;
      }

   }





   for(i = 0; i < l2.nb_metastems; i++) {

      t = 0;

      j = bl->nb_blocks - 1;
      while((j >= 0) && begin_stop_leq(l2.metastems[i], bl->blocks[j].from2)) {
	 j--;
      }

      if(j >= 0) {
	 cg = j;

	 if(begin_stop_leq(l2.metastems[i], bl->blocks[j].to2)) {
	    cd = j;
 	    res->astems_2[i].open_right_block = &(bl->blocks[j]);
	 } else {
	    j++;
	    cd = j;
	    if(j < bl->nb_blocks) {
	       res->astems_2[i].open_right_block = &(bl->blocks[j]);
	    }
	 }
      } else {
	 cg = -1;
	 cd = 0;
	 res->astems_2[i].open_right_block = &(bl->blocks[0]);	 
      }


      j = 0;
      while((j < bl->nb_blocks) && begin_start_gt(l2.metastems[i], bl->blocks[j].to2)) {
	 j++;
      }



      if(j < bl->nb_blocks) {
	 od = j;

	 if(begin_start_geq(l2.metastems[i],bl->blocks[j].from2)) {
	    og = j;
	    res->astems_2[i].open_left_block = &(bl->blocks[j]);
	 } else {
	    j--;
	    og = j;
	    if(j >= 0) {
	       res->astems_2[i].open_left_block = &(bl->blocks[j]);
	    }
	 }
      } else {
	 od = -1;
	 og = bl->nb_blocks - 1;
	 res->astems_2[i].open_left_block = &(bl->blocks[bl->nb_blocks - 1]);	 
      }


      if(cg == cd) { t = 1; }
      if(og == od) { t += 2; }

      if(t == 0) {
	 if((od == cg) && (od != -1)) {
	    res->astems_2[i].open_left_block = res->astems_2[i].open_right_block = &(bl->blocks[od]);
	 }
      } else if(t == 1) {
	 res->astems_2[i].open_left_block = res->astems_2[i].open_right_block;
      } else if(t == 2) {
	 res->astems_2[i].open_right_block = res->astems_2[i].open_left_block;
      }

   }
   /**************/




   /*********  CLOSINGS **********/

   for(i = 0; i < l1.nb_metastems; i++) {

      t = 0;


      
      j = bl->nb_blocks - 1;
      while((j >= 0) && end_stop_lt(l1.metastems[i], bl->blocks[j].from1)) {
	 j--;
      }

      if(j >= 0) {
	 cg = j;

	 if(end_stop_leq(l1.metastems[i], bl->blocks[j].to1)) {
	    cd = j;
 	    res->astems_1[i].close_right_block = &(bl->blocks[j]);
	 } else {
	    j++;
	    cd = j;
	    if(j < bl->nb_blocks) {
	       res->astems_1[i].close_right_block = &(bl->blocks[j]);
	    }
	 }
      } else {
	 cg = -1;
	 cd = 0;
	 res->astems_1[i].close_right_block = &(bl->blocks[0]);	 
      }


      j = 0;
      while((j < bl->nb_blocks) && end_start_gt(l1.metastems[i], bl->blocks[j].to1)) {
	 j++;
      }

      if(j < bl->nb_blocks) {
	 od = j;

	 if(end_start_geq(l1.metastems[i], bl->blocks[j].from1)) {
	    og = j;
	    res->astems_1[i].close_left_block = &(bl->blocks[j]);
	 } else {
	    j--;
	    og = j;
	    if(j >= 0) {
	       res->astems_1[i].close_left_block = &(bl->blocks[j]);
	    }
	 }
      } else {
	 od = -1;
	 og = bl->nb_blocks - 1;
	 res->astems_1[i].close_left_block = &(bl->blocks[bl->nb_blocks - 1]);	 
      }


      if(cg == cd) { t = 1; }
      if(og == od) { t += 2; }

      if(t == 0) {
	 if((od == cg) && (od != -1)) {
	    res->astems_1[i].close_left_block = res->astems_1[i].close_right_block = &(bl->blocks[od]);
	 }
      } else if(t == 1) {
	 res->astems_1[i].close_left_block = res->astems_1[i].close_right_block;
      } else if(t == 2) {
	 res->astems_1[i].close_right_block = res->astems_1[i].close_left_block;
      }

   }





   for(i = 0; i < l2.nb_metastems; i++) {

      t = 0;


      
      j = bl->nb_blocks - 1;
      while((j >= 0) && end_stop_lt(l2.metastems[i], bl->blocks[j].from2)) {
	 j--;
      }

      if(j >= 0) {
	 cg = j;

	 if(end_stop_leq(l2.metastems[i], bl->blocks[j].to2)) {
	    cd = j;
 	    res->astems_2[i].close_right_block = &(bl->blocks[j]);
	 } else {
	    j++;
	    cd = j;
	    if(j < bl->nb_blocks) {
	       res->astems_2[i].close_right_block = &(bl->blocks[j]);
	    }
	 }
      } else {
	 cg = -1;
	 cd = 0;
	 res->astems_2[i].close_right_block = &(bl->blocks[0]);	 
      }


      j = 0;
      while((j < bl->nb_blocks) && end_start_gt(l2.metastems[i], bl->blocks[j].to2)) {
	 j++;
      }

      if(j < bl->nb_blocks) {
	 od = j;

	 if(end_start_geq(l2.metastems[i], bl->blocks[j].from2)) {
	    og = j;
	    res->astems_2[i].close_left_block = &(bl->blocks[j]);
	 } else {
	    j--;
	    og = j;
	    if(j >= 0) {
	       res->astems_2[i].close_left_block = &(bl->blocks[j]);
	    }
	 }
      } else {
	 od = -1;
	 og = bl->nb_blocks - 1;
	 res->astems_2[i].close_left_block = &(bl->blocks[bl->nb_blocks - 1]);	 
      }


      if(cg == cd) { t = 1; }
      if(og == od) { t += 2; }

      if(t == 0) {
	 if((od == cg) && (od != -1)) {
	    res->astems_2[i].close_left_block = res->astems_2[i].close_right_block = &(bl->blocks[od]);
	 }
      } else if(t == 1) {
	 res->astems_2[i].close_left_block = res->astems_2[i].close_right_block;
      } else if(t == 2) {
	 res->astems_2[i].close_right_block = res->astems_2[i].close_left_block;
      }

   }
   /***************/


}





#if defined(CARNAC_OLD_MODE) || defined(CARNAC_NO_FLOATING_STEM)

#define open_flt(As,Bs) ((((As)->open_left_block == NULL) || ((As)->open_left_block != (As)->open_right_block)) ? (CARNAC_FLOATING) : (0))
#define close_flt(As,Bs) ((((As)->close_left_block == NULL) || ((As)->close_left_block != (As)->close_right_block)) ? (CARNAC_FLOATING) : (0))

#else

int
open_flt(const anchor_stem_t *s1, const anchor_stem_t *s2) {

   if(((s1->open_left_block == NULL) && (s2->open_left_block == NULL))
      || ((s1->open_right_block == NULL) && (s2->open_right_block == NULL))
      || ((s1->open_left_block != s1->open_right_block) && (s2->open_left_block != s2->open_right_block))) {

      return CARNAC_FLOATING;
   }
   
   return 0;
}


int
close_flt(const anchor_stem_t *s1, const anchor_stem_t *s2) {
   if(((s1->close_left_block == NULL) && (s2->close_left_block == NULL))
      || ((s1->close_right_block == NULL) && (s2->close_right_block == NULL))
      || ((s1->close_left_block != s1->close_right_block) && (s2->close_left_block != s2->close_right_block))) {

      return CARNAC_FLOATING;
   }
    
   return 0;
}



#endif




int
open_ext_condition(const int olas, const int oras, const metastem_t *m1, const metastem_t *m2, const int optimal_shift, const int open_flt) {
   int m, n, k;

   k = 0;
   for(m = 0; m < m1->nb_seqs; m++) {
      for(n = 0; n < m2->nb_seqs; n++) {

	 if(!(MIN(olas, oras) <= (m1->seq_stems[m].begin_start - m2->seq_stems[n].begin_start + optimal_shift + open_flt))
	    || !((m1->seq_stems[m].begin_start - m2->seq_stems[n].begin_start + optimal_shift) <= (MAX(olas, oras) + open_flt))) {
	    k++;
	 }
      }
   }

   return k < (m1->nb_seqs * m2->nb_seqs)/2.0;
}


int
open_int_condition(const int olas, const int oras, const metastem_t *m1, const metastem_t *m2, const int optimal_shift, const int open_flt) {
   int m, n, k;

   k = 0;
   for(m = 0; m < m1->nb_seqs; m++) {
      for(n = 0; n < m2->nb_seqs; n++) {

	 if(!(MIN(olas, oras) <= (m1->seq_stems[m].begin_stop - m2->seq_stems[n].begin_stop + optimal_shift + open_flt))
	    || !((m1->seq_stems[m].begin_stop - m2->seq_stems[n].begin_stop + optimal_shift) <= (MAX(olas, oras) + open_flt))) {
	    k++;
	 }
      }
   }

   return k < (m1->nb_seqs * m2->nb_seqs)/2.0;
}

int
close_ext_condition(const int clas, const int cras, const metastem_t *m1, const metastem_t *m2, const int optimal_shift, const int close_flt) {
   int m, n, k;

   k = 0;
   for(m = 0; m < m1->nb_seqs; m++) {
      for(n = 0; n < m2->nb_seqs; n++) {

	 if(!(MIN(clas, cras) <= (m1->seq_stems[m].end_stop - m2->seq_stems[n].end_stop - optimal_shift + close_flt))
	    || !((m1->seq_stems[m].end_stop - m2->seq_stems[n].end_stop - optimal_shift) <= (MAX(clas, cras) + close_flt))) {
	    k++;
	 }
      }
   }
   return k < (m1->nb_seqs * m2->nb_seqs)/2.0;
}


int
close_int_condition(const int clas, const int cras, const metastem_t *m1, const metastem_t *m2, const int optimal_shift, const int close_flt) {
   int m, n, k;

   k = 0;
   for(m = 0; m < m1->nb_seqs; m++) {
      for(n = 0; n < m2->nb_seqs; n++) {

	 if(!(MIN(clas, cras) <= (m1->seq_stems[m].end_start - m2->seq_stems[n].end_start - optimal_shift + close_flt))
	    || !((m1->seq_stems[m].end_start - m2->seq_stems[n].end_start - optimal_shift) <= (MAX(clas, cras) + close_flt))) {
	    k++;
	 }
      }
   }

   return k < (m1->nb_seqs * m2->nb_seqs)/2.0;
}




short
are_compatible(const anchor_stem s1, const anchor_stem s2, const int max_shift, const int optimal_shift, int (*open_condition)(const int, const int, const metastem_t*, const metastem_t*, const int, const int), int (*close_condition)(const int, const int, const metastem_t*, const metastem_t*, const int, const int)) {
   int open_left_allowed_shift;
   int open_right_allowed_shift;
   int close_left_allowed_shift;
   int close_right_allowed_shift;


   if((s1->open_left_block == NULL) && (s1->open_right_block == NULL)) {
      /* no anchor */
      open_left_allowed_shift = 0;
      open_right_allowed_shift = max_shift;
   } else {
      /* at least one anchor */

      if(s1->open_left_block == NULL) {
	 /* open before first anchor */
	 
	 open_left_allowed_shift = 0;
	 open_right_allowed_shift = s1->open_right_block->from1 - s1->open_right_block->from2;
	 
      } else {
	 open_left_allowed_shift = s1->open_left_block->from1 - s1->open_left_block->from2;

	 if(s1->open_right_block) {
	    open_right_allowed_shift = s1->open_right_block->from1 - s1->open_right_block->from2;
	 } else {
	    open_right_allowed_shift = max_shift;
	 }
      }

   }

   /*
   INFO_ "olas = %i, oras = %i, of = %i", open_left_allowed_shift, open_right_allowed_shift, open_flt(s1, s2) _INFO;
   */ 
   
   if(open_condition(open_left_allowed_shift, open_right_allowed_shift, s1->metastem, s2->metastem, optimal_shift, open_flt(s1,s2))) {

      if((s1->close_left_block == NULL) && (s1->close_right_block == NULL)) {
	 /* no anchor */
	 close_left_allowed_shift = 0;
	 close_right_allowed_shift = max_shift;
      } else {
	 if(s1->close_left_block == NULL) {
	    /* close before first anchor */
	 
	    close_left_allowed_shift = 0;
	    close_right_allowed_shift = s1->close_right_block->from1 - s1->close_right_block->from2;

	 } else {
	    close_left_allowed_shift = s1->close_left_block->from1 - s1->close_left_block->from2;
	    
	    if(s1->close_right_block) {
	       close_right_allowed_shift = s1->close_right_block->from1 - s1->close_right_block->from2;
	    } else {
	       close_right_allowed_shift = max_shift;
	    }
	 }
      }

      
      
      
      /*        
      INFO_ " clas = %i, cras = %i, cf = %i", close_left_allowed_shift, close_right_allowed_shift, close_flt(s1,s2) _INFO;
      */
      
      
      
      return close_condition(close_left_allowed_shift, close_right_allowed_shift, s1->metastem, s2->metastem, optimal_shift, close_flt(s1,s2));

   }

   /*
     INFO_ " FAIL OPEN" _INFO;
   */
 

   return 0;
}





void
destroy_anchor_stem_list(anchor_stem_list l) {
   DESTROY(l->astems_1);
   DESTROY(l->astems_2);
}







cofoldable_t**
compatible_stems_meta(const metasequence_t m1, const metastem_t_list_t l1, const metasequence_t m2, const metastem_t_list_t l2, const block_list bl, const int id) {
   anchor_stem_list_t as;
   cofoldable_t **res = NULL;
   int i, j, k;
   int os;

   create_anchor_stem_list(l1, l2, bl, &as);

   

   NEW(res, cofoldable_t*, l1.nb_metastems);

   for(i = 0; i < l1.nb_metastems; i++) {
      NEW(res[i], cofoldable_t, l2.nb_metastems);
   }





#ifdef _OPENMP
#pragma omp parallel default(shared) private(j,os,k)
   {
#pragma omp for
#endif
   for(i = 0; i < l1.nb_metastems; i++) {

	 for(j = 0; j < l2.nb_metastems; j++) {

	 /*
	 print_metastem(as.astems_1[i].metastem, NULL);
 	 INFO_ " / " _INFO;
 	 print_metastem(as.astems_2[j].metastem, NULL);
	 */

	    res[i][j].data &= ~DO_COVARIATE_MASK;
	    res[i][j].data &= ~COMPATIBLE_MASK;
	    res[i][j].data &= ~HAVE_NON_CANONICAL_CONSERVED_MASK;
	    /*
	 res[i][j].do_covariate = 0;
	 res[i][j].compatible = 0;
	 res[i][j].have_non_canonical_conserved = 0;
	    */

	    /*	    INFO_ "%i \n", res[i][j].data _INFO;*/

	 res[i][j].shifts = NULL;
	 
	 if((as.astems_1[i].open_left_block != as.astems_2[j].open_left_block)
	    || (as.astems_1[i].open_right_block != as.astems_2[j].open_right_block)
	    || (as.astems_1[i].close_left_block != as.astems_2[j].close_left_block)
	    || (as.astems_1[i].close_right_block != as.astems_2[j].close_right_block)) {
	    
	    
	    
	    /*
	    INFO_ "   NOT THE SAME BLOCK [%p..%p : %p..%p]  /  [%p..%p : %p..%p]", as.astems_1[i].open_left_block, as.astems_1[i].open_right_block, as.astems_1[i].close_left_block, as.astems_1[i].close_right_block, as.astems_2[j].open_left_block, as.astems_2[j].open_right_block, as.astems_2[j].close_left_block, as.astems_2[j].close_right_block _INFO;
	    */

	    /*
	    INFO_ "   NOT THE SAME BLOCK " _INFO;
	    */ 
	    
	 } else {
	    

	    adjust_meta(m1, *(as.astems_1[i].metastem), m2, *(as.astems_2[j].metastem), &(res[i][j].shifts));


	    os = (m1.length - m2.length);


#ifdef CARNAC_STEM_LENGTH_RATIO
	    if((MAX(m1.length,m2.length))/(MIN(m1.length,m2.length)) <= CARNAC_STEM_LENGTH_RATIO) {
#endif


#ifdef CARNAC_OLD_MODE
	
	    /*
	   INFO_ " adjust = [%i..%i] ms = %i ", shift_min, shift_max, m1.length-m2.length _INFO;
	    */

	    k = 0;
	    while(((!(res[i][j].compatible) || !(res[i][j].do_covariate))) && (k < STACK_SIZE(res[i][j].shifts))) {
	       if(are_compatible(&(as.astems_1[i]), &(as.astems_2[j]), os, STACK_VALUE_AT(res[i][j].shifts, k), open_ext_condition, close_ext_condition)) {
		  res[i][j].compatible = 1;
		  res[i][j].covariate = do_covar_meta(&m1, as.astems_1[i].metastem, &m2, as.astems_2[j].metastem, STACK_VALUE_AT(res[i][j].shifts, k));
#ifdef CARNAC_NON_WATSON_CRICK
		  res[i][j].have_non_canonical_conserved = conserved_non_canonical_meta(&m1, as.astems_1[i].metastem, &m2, as.astems_2[j].metastem, STACK_VALUE_AT(res[i][j].shifts, k);
#endif
		  }
	       }
	       k++;
	    }

	    
#else


	    k = 0;
	    while((!(COMPATIBLE(res[i][j])) || !(DO_COVARIATE(res[i][j]))) && (k < STACK_SIZE(res[i][j].shifts))) {

	       /*
	       INFO_ " adjust = %i ms = %i ", STACK_VALUE_AT(res[i][j].shifts, k), m1.length-m2.length _INFO;
	       */

	       if(are_compatible(&(as.astems_1[i]), &(as.astems_2[j]), os, STACK_VALUE_AT(res[i][j].shifts, k), open_int_condition, close_int_condition)
		  || are_compatible(&(as.astems_1[i]), &(as.astems_2[j]), os, STACK_VALUE_AT(res[i][j].shifts, k), open_ext_condition, close_ext_condition)) {

		  res[i][j].data |= COMPATIBLE_MASK;

		  if(do_covar_meta(&m1, as.astems_1[i].metastem, &m2, as.astems_2[j].metastem, STACK_VALUE_AT(res[i][j].shifts, k), id)) {
		     res[i][j].data |= DO_COVARIATE_MASK;
		  }

#ifdef CARNAC_NON_WATSON_CRICK
		  if(conserved_non_canonical_meta(&m1, as.astems_1[i].metastem, &m2, as.astems_2[j].metastem, STACK_VALUE_AT(res[i][j].shifts, k))) {
		     res[i][j].data |= HAVE_NON_CANONICAL_CONSERVED_MASK;
		  }
#endif
	       }
	       k++;
	    }
	    
#endif

#ifdef CARNAC_STEM_LENGTH_RATIO
	    }
#endif


	    
	 }
	 
	 /*
	 INFO_ "\n" _INFO;
	 */
	 
      }

   }



#ifdef _OPENMP
   }
#endif


   destroy_anchor_stem_list(&as);

   return res;
}
