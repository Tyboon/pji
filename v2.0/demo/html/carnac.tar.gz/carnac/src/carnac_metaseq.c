#ifdef HAVE_CONFIG_H
    #include "config.h"
#endif
#include "carnac_metaseq.h"
#include "carnac_stems.h"
#include "opts.h"
#include "display.h"

#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <stdint.h>


















int
try_to_resolve_block_conflict(block_t *bloc1, metasequence m1, block_t *bloc2, metasequence m2) {
   block_t b1, b2;
   int inter1, inter2, inter, i,j,k;




   if((bloc1->from1 - bloc2->from1) * (bloc1->from2 - bloc2->from2) <= 0) {
      return 0;
   }

   if((IS_BETWEEN(bloc2->from1, bloc2->to1, bloc1->from1)
       && IS_BETWEEN(bloc2->from1, bloc2->to1, bloc1->to1))
      ||
      ((IS_BETWEEN(bloc1->from1, bloc1->to1, bloc2->from1)
	&& IS_BETWEEN(bloc1->from1, bloc1->to1, bloc2->to1)))) {
      return 0;
   }
   
   if((IS_BETWEEN(bloc2->from2, bloc2->to2, bloc1->from2)
       && IS_BETWEEN(bloc2->from2, bloc2->to2, bloc1->to2))
      ||
      ((IS_BETWEEN(bloc1->from2, bloc1->to2, bloc2->from2)
	&& IS_BETWEEN(bloc1->from2, bloc1->to2, bloc2->to2)))) {
      return 0;
   }
   

   b1 = *bloc1;
   b2 = *bloc2;
   

   if(IS_BETWEEN(b1.from1, b1.to1, b2.from1)) {
      inter1 = b1.to1 - b2.from1 + 1;
   } else {
      inter1 = b2.to1 - b1.from1 + 1;
   }

   if(IS_BETWEEN(b1.from2, b1.to2, b2.from2)) {
      inter2 = b1.to2 - b2.from2 + 1;
   } else {
      inter2 = b2.to2 - b1.from2 + 1;
   }
   
   inter = MAX(inter1, inter2);
   if(inter == 0) {
      return 1; /* no conflict ... */
   }

   if((b1.to1-b1.from1+1+b2.to1-b2.from1+1-inter) < 2*BLOCK_MIN_LENGTH) {
      return 0; /* no solution */
   }





#ifdef CARNAC_EMULE_BLOC_BUG 
   /********** WARNING : TO ONLY DEAL WITH A CARNAC BUG *********/
   if(inter > 1) { return 0; }
#endif

#ifndef CARNAC_BLOCK_BEST_EFFORT
   return 0;
#endif
   
   if(b1.from1 < b2.from1) {
      b1.to1 -= inter;
      b1.to2 -= inter;
      b2.from1 += inter;
      b2.from2 += inter;
   } else {
      b1.from1 += inter;
      b1.from2 += inter;
      b2.to1 -= inter;
      b2.to2 -= inter;
   }
   
   /* no conflict between b1 and b2, extending blocks */
   while(inter) {
      if(b1.from1 < b2.from1) {
	 if(((b1.to1-b1.from1+1) < BLOCK_MIN_LENGTH)
	    || (((b1.to1-b1.from1) <= (b2.to1-b2.from1))
		&& ((b1.to1-b1.from1) < (bloc1->to1-bloc1->from1)))) {
	    b1.to1++;
	    b1.to2++;
	 } else {
	    b2.from1--;
	    b2.from2--;
	 }
      } else {
	 if(((b2.to1-b2.from1+1) < BLOCK_MIN_LENGTH)
	    || (((b2.to1-b2.from1+1) < (b1.to1-b1.from1+1))
		&& ((b2.to1-b2.from1) < (bloc2->to1-bloc2->from1)))) {
	    b2.to1++;
	    b2.to2++;
	 } else {
	    b1.from1--;
	    b1.from2--;
	 }
      }
      inter--;
   }




   /* recompute score */

   if((b1.to1 - b1.from1 + 1) < BLOCK_MIN_LENGTH) {
      return 0;
   }

   for(i = 0; i < (b1.to1 - b1.from1 + 1); i++) {
      for(j = 0;j < m2->nb_seqs; j++) {
	 for(k = 0; k < m1->nb_seqs; k++) {
	    if(m1->seqs[k]->bases[b1.from1 + i] != m2->seqs[j]->bases[b1.from2 + i])
	       return 0;
	 }
      }
   }

   if((b2.to1 - b2.from1 + 1) < BLOCK_MIN_LENGTH) {
      return 0;
   }

   for(i = 0; i < (b2.to1 - b2.from1 + 1); i++) {
      for(j = 0;j < m2->nb_seqs; j++) {
	 for(k = 0; k < m1->nb_seqs; k++) {
	    if(m1->seqs[k]->bases[b2.from1 + i] != m2->seqs[j]->bases[b2.from2 + i])
	       return 0;
	 }
      }
   }


   (*bloc1) = b1;
   (*bloc2) = b2;

   return 1;
}















block_list
blocks_between_meta(const metasequence m1, const metasequence m2) {
   block_list res = NULL, resret = NULL;

   int i, j, k, shs1, shs2, length, state;
   int clength, mlength, cfrom, mscore, cscore, acc;

   res = new_block_list(100);

   
   shs1 = m1->length - BLOCK_MIN_LENGTH;
   shs2 = 0;

   while((shs1 >= 0) && (shs2 <= (m2->length - BLOCK_MIN_LENGTH))) {
      length = MIN((m1->length - shs1), (m2->length - shs2));
   
   /*
     shs1 = MAX(0,(m1->length - m2->length));
     shs2 = 0;
     
     while((shs1 >= 0) && (shs2 <= MAX(0,(m2->length - m1->length)))) {
     length = MIN(m1->length, m2->length);
   */

      state = 0;

      mscore = cscore = 0;
      mlength = clength = 0;
      cfrom = 0;
      
      for(i = 0; i < length; i++) {
	 switch(state) {
	 case 0: /* READY */

	    j = 0;
	    k = 0;
	    while((j < m2->nb_seqs) && (k < m1->nb_seqs) && (m1->seqs[k]->bases[i+shs1] == m2->seqs[j]->bases[i+shs2])) {
	       j++;
	       if(j == m2->nb_seqs) { k++; j = 0; }
	    }
	    
	    if(k >= m1->nb_seqs) {
	       /* 100% MATCHING POSITION */
	       
	       state = 1; /* opening block */
	       mlength = clength = 1;
	       cfrom = i;
	       mscore = cscore = m1->nb_seqs * m2->nb_seqs;
	    }
	    
	    break;
	    
	 case 1: /* IN BLOCK */
	    
	    clength++;

	    acc = 0;
	    for(j = 0;j < m2->nb_seqs; j++) {
	       for(k = 0; k < m1->nb_seqs; k++) {
		  if(m1->seqs[k]->bases[i+shs1] != m2->seqs[j]->bases[i+shs2])
		     acc++;
	       }
	    }
	    
	    /*
	    cscore += (m2->nb_seqs * m1->nb_seqs - acc) + (BLOCK_SUBSTITUTION * acc);
	    
	    if(mscore <= cscore) {
	       mscore = cscore;
	       mlength = clength;
	    }

	    if(cscore <= 0) {
	       state = 0;
	       }
	    
	    if((mlength >= BLOCK_MIN_LENGTH)
	       && (mscore >= (BLOCK_MIN_LENGTH * m1->nb_seqs * m2->nb_seqs))) {
	       state = 2;
	       }
	    */
	    if(acc != 0) {
	       state = 0;
	    } else {
	       cscore++;
	       if(clength >= BLOCK_MIN_LENGTH) {
		  mlength = clength;
		  mscore = cscore;
		  state = 2;
	       }
	    }

	    
	    break;
	    
	 case 2: /* kept block */

	    clength++;
	    
	    acc = 0;
	    for(j = 0;j < m2->nb_seqs; j++) {
	       for(k = 0; k < m1->nb_seqs; k++) {
		  if(m1->seqs[k]->bases[i+shs1] != m2->seqs[j]->bases[i+shs2])
		     acc++;
	       }
	    }
	    
	    
	    /*
	    cscore += (m2->nb_seqs * m1->nb_seqs - acc) + (BLOCK_SUBSTITUTION * acc);

	    if(cscore >= mscore) {
	       mlength = clength;
	       mscore = cscore;
	    }

	    if(cscore <= 0) {
	       add_block(res, (cfrom + shs1), (cfrom + shs2),
			 (cfrom + shs1 + mlength - 1), (cfrom + shs2 + mlength - 1),
			 ((mlength * m1->nb_seqs * m2->nb_seqs) - mscore)/(-BLOCK_SUBSTITUTION), mscore);
	       state = 0;
	    }
	    
	    */
	    if(acc != 0) {
	       state = 0;
	       add_block(res, (cfrom + shs1), (cfrom + shs2),
			 (cfrom + shs1 + mlength - 1), (cfrom + shs2 + mlength - 1),
			 ((mlength * m1->nb_seqs * m2->nb_seqs) - mscore)/(-BLOCK_SUBSTITUTION), mscore);
	    } else {
	       cscore++;
	       mlength = clength;
	       mscore = cscore;
	    }
	    

	    break;
	    
	    
	    
	 default:
	    ERROR_ "You've discovered a strong bug !!!\n" _ERROR;
	    break;
	 }
      }

      if(state == 2) {
	 add_block(res, (cfrom + shs1), (cfrom + shs2),
		   (cfrom + shs1 + mlength - 1), (cfrom + shs2 + mlength - 1),
		   ((mlength * m1->nb_seqs * m2->nb_seqs) - mscore)/(-BLOCK_SUBSTITUTION), mscore);

      }
      
      if(shs1 > 0) {
	 shs1--;
      } else {
	 shs2++;
      }
   }
   
   
   
   order_blocks_by_decreasing_score(res);
   
   
   resret = new_block_list(res->nb_blocks);
   
   i = 0;
   while(i < res->nb_blocks) {
      
      j = 0;
      while((j < resret->nb_blocks)
	    && (((res->blocks[i].from1 < resret->blocks[j].from1)
		 && (res->blocks[i].to1 < resret->blocks[j].from1)
		 && (res->blocks[i].from2 < resret->blocks[j].from2)
		 && (res->blocks[i].to2 < resret->blocks[j].from2))
		
		||

		((res->blocks[i].from1 > resret->blocks[j].to1)
		 && (res->blocks[i].to1 > resret->blocks[j].to1)
		 && (res->blocks[i].from2 > resret->blocks[j].to2)
		 && (res->blocks[i].to2 > resret->blocks[j].to2)))) {
	 j++;
      }

      if(j >= resret->nb_blocks) {

	 add_block(resret, res->blocks[i].from1, res->blocks[i].from2, res->blocks[i].to1, res->blocks[i].to2, res->blocks[i].nb_mism, res->blocks[i].score);

      } else {

	 
	 
#if defined(CARNAC_BLOCK_BEST_EFFORT) || defined(CARNAC_EMULE_BLOC_BUG)


	 while((j < resret->nb_blocks) && (try_to_resolve_block_conflict(&(res->blocks[i]), m1, &(resret->blocks[j]), m2))) {
	    
	    j++;
	    
	    while((j < resret->nb_blocks)
		  && (((res->blocks[i].from1 < resret->blocks[j].from1)
		       && (res->blocks[i].to1 < resret->blocks[j].from1)
		       && (res->blocks[i].from2 < resret->blocks[j].from2)
		       && (res->blocks[i].to2 < resret->blocks[j].from2))
		      
		      ||
		      
		      ((res->blocks[i].from1 > resret->blocks[j].to1)
		       && (res->blocks[i].to1 > resret->blocks[j].to1)
		       && (res->blocks[i].from2 > resret->blocks[j].to2)
		       && (res->blocks[i].to2 > resret->blocks[j].to2)))) {
	       j++;
	    }
	 }
#endif

	 if(j >= resret->nb_blocks) {
	    add_block(resret, res->blocks[i].from1, res->blocks[i].from2, res->blocks[i].to1, res->blocks[i].to2, res->blocks[i].nb_mism, res->blocks[i].score);
	 }
#ifdef CARNAC_KILL_CONFLICTING_BLOCKS
	 else {

	    /* removing conflicting block */
	    if((res->blocks[i].score == resret->blocks[j].score)
	       && ((res->blocks[i].to1 - res->blocks[i].from1) == (resret->blocks[j].to1 - resret->blocks[j].from1))) {
	       remove_block(resret, j);
	    }
	 }
#endif


      }

      i++;
   }


   destroy_block_list(res);

   /*order_blocks_by_increasing_from(resret);*/



   return resret;
}















