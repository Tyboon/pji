#ifdef HAVE_CONFIG_H
    #include "config.h"
#endif
#include "carnac_sankoff_stems.h"

#include "opts.h"
#include "display.h"


#include <stdlib.h>
#include <assert.h>




void
prepare_sankoff_stems(const metastem_t_list ostems, const metastem_list stems, stem_open_index_t **oindex, stem_close_index_t **cindex) {
   short i, j, k;
   metastem_list sbegin, sclose;

   stem_open_index_t *reso = NULL;
   stem_close_index_t *resc = NULL;
   

   NEW(reso, stem_open_index_t, (stems.nb_metastems));
   (*oindex) = reso;
   NEW(resc, stem_close_index_t, (stems.nb_metastems));
   (*cindex) = resc;

   NEW(sbegin.metastem_id, int, stems.nb_metastems);
   NEW(sclose.metastem_id, int, stems.nb_metastems);


   for(i = 0; i < stems.nb_metastems; i++) {
      sbegin.metastem_id[i] = sclose.metastem_id[i] = stems.metastem_id[i];
   }
   
   sbegin.nb_metastems = sclose.nb_metastems = stems.nb_metastems;

   sort_metastems_id_by_begin_then_length(&(sbegin), ostems);
   sort_metastems_id_by_end_closure_then_length(&(sclose), ostems);


   i = 0;
   
   while(i < stems.nb_metastems) {
      reso[i].stem_id = sbegin.metastem_id[i];
      reso[i].close_index = -1;
      reso[i].open_next = -1;
      reso[i].close_prev = -1;
      reso[i].is_hairpin = 1;

      i++;      
   }


   j = 0;
   
   while(j < stems.nb_metastems) {
      resc[j].stem_id = sclose.metastem_id[j];
      resc[j].close_prev = -1;
      
      k = 0;
      while((k < stems.nb_metastems) && (reso[k].stem_id != resc[j].stem_id)) {
	 k++;
      }
      resc[j].open_index = k;
      reso[k].close_index = j;

      j++;  
   }



   DESTROY(sbegin.metastem_id);
   DESTROY(sclose.metastem_id);



   /* open_next */
   for(i = 0; i < stems.nb_metastems; i++) {

      /* skipping everything overlapping */
      j = i+1;
      while((j < stems.nb_metastems)
	    && (reso[i].open_next < 0)) {
	 if(!begin_start_leq_begin_stop(ostems->metastems[reso[j].stem_id], ostems->metastems[reso[i].stem_id], -CARNAC_TOLERATE_OVERLAP)) {
	    reso[i].open_next = j;
	 }
	 
	 j++;
      }
      /**/
   }
   /**/



   /* close_prev */
   for(i = stems.nb_metastems - 1; i >= 0; i--) {
      
      /* skipping everything overlapping */
      j = i-1;
      while((j >= 0)
	    && (resc[i].close_prev < 0)) {
	 if(!end_stop_geq_end_start(ostems->metastems[resc[j].stem_id], ostems->metastems[resc[i].stem_id], CARNAC_TOLERATE_OVERLAP)) {
	    resc[i].close_prev = j;
	 }
	 
	 j--;
      }
      /**/
   }
   /**/

   /* close_prev */
   for(i = 0; i < stems.nb_metastems; i++) {
      
      /* skipping everything overlapping */
      j = reso[i].close_index-1;
      while((j >= 0)
	    && (reso[i].close_prev < 0)) {
	 if(!end_stop_geq_begin_start(ostems->metastems[resc[j].stem_id], ostems->metastems[reso[i].stem_id], CARNAC_TOLERATE_OVERLAP)) {
	    reso[i].close_prev = j;
	 }
	 
	 j--;
      }
      /**/
   }


   /* detecting hairpins */
   for(i = 0; i < stems.nb_metastems; i++) {
      if((reso[i].open_next >= 0)
	 && (resc[reso[i].close_index].close_prev >= 0)) {

	 j = resc[reso[i].close_index].close_prev;

	 while((j > reso[i].close_prev) && (reso[i].is_hairpin) ) {
	    if(resc[j].open_index >= reso[i].open_next) {
	       reso[i].is_hairpin = 0;
	    }

	    j--;
	 }
      }
   }
   /**/
}









void
computeTable_Cell(int **table, int **graph, const int i, const metastem_t_list ostemsA, const stem_open_index_t *open_atA, const stem_close_index_t *close_atA, const int j, const metastem_t_list ostemsB, const stem_open_index_t *open_atB, const stem_close_index_t *close_atB) {
   int w, x, y;
   int subA, subB;




   subA = 1+open_atA[open_atA[i-1].open_next].close_prev;
   subB = 1+open_atB[open_atB[j-1].open_next].close_prev;
   

   /*   INFO_ "*** TABLE CELL COMPUTING SUB [%i..%i] [%i..%i]\n", subA, (1+close_atA[open_atA[i-1].close_index].close_prev), subB, (1+close_atB[open_atB[j-1].close_index].close_prev) _INFO;*/

   for(x = subA; x <= (1+close_atA[open_atA[i-1].close_index].close_prev); x++) {
      table[x][subB] = 0;
   }
   for(y = subB; y <= (1+close_atB[open_atB[j-1].close_index].close_prev); y++) {
      table[subA][y] = 0;
   }

   for(x = subA+1; x <= (1+close_atA[open_atA[i-1].close_index].close_prev); x++) {
      for(y = subB+1; y <= (1+close_atB[open_atB[j-1].close_index].close_prev); y++) {
	 
	 /*
	   INFO_ "  tc[%i][%i] table[%2i][%2i] = MIN(", i,j,x, y _INFO;
	 */
	 
	 table[x][y] = MIN(table[x-1][y], table[x][y-1]);

	 /*
	   INFO_ "%5i, %5i", table[x-1][y], table[x][y-1] _INFO;
	 */
	 
	 if((close_atA[x-1].open_index >= open_atA[i-1].open_next)
	    && (close_atB[y-1].open_index >= open_atB[j-1].open_next)) {

	    w = graph[x][y];
	    
	    /*
	      INFO_ ", g = %5i", w _INFO;
	    */
	    
	    if(((1+open_atA[close_atA[x-1].open_index].close_prev) > subA) &&
	       ((1+open_atB[close_atB[y-1].open_index].close_prev) > subB)) {
	       
	       w += table[1+open_atA[close_atA[x-1].open_index].close_prev][1+open_atB[close_atB[y-1].open_index].close_prev];
	       /*
		 INFO_ ", g' = %5i", w _INFO;
	       */
	    }
	    
	    table[x][y] = MIN(table[x][y], w);
	 }
	 
	 /*
	   INFO_ ") = %5i\n", table[x][y] _INFO;
	 */

      }
   }
}






void
build_alignment_graph(const metasequence metaA, const metastem_t_list ostemsA, const metastem_list stemsA, const stem_open_index_t *open_atA, const stem_close_index_t *close_atA, const metasequence metaB, const metastem_t_list ostemsB, const metastem_list stemsB, const stem_open_index_t *open_atB, const stem_close_index_t *close_atB, int **table, int **graph, cofoldable_t **compatibles) {

   int i,j,x,y;
   int olsA, olsB, clsA, clsB;

   olsA = olsB = clsA = clsB = -1;
   
   /*****************************/ 
   /*    weight of the edges    */
   /*****************************/
   for (i = stemsA.nb_metastems; i > 0; i--) {
      for (j = stemsB.nb_metastems; j > 0; j--) {

	 if(COMPATIBLE(compatibles[open_atA[i-1].stem_id][open_atB[j-1].stem_id])
	    && DO_COVARIATE(compatibles[open_atA[i-1].stem_id][open_atB[j-1].stem_id])) {
	    	    
	    graph[1+open_atA[i-1].close_index][1+open_atB[j-1].close_index] = ostemsA->metastems[open_atA[i-1].stem_id].energy + ostemsB->metastems[open_atB[j-1].stem_id].energy;

	    /*	    INFO_ "graph[%i][%i]  e = %i", 1+open_atA[i-1].close_index, 1+open_atB[j-1].close_index, graph[1+open_atA[i-1].close_index][1+open_atB[j-1].close_index] _INFO;*/
	    
	    if(!(open_atA[i-1].is_hairpin || open_atB[j-1].is_hairpin)) {

	             
	       if((clsA < 1+close_atA[open_atA[i-1].close_index].close_prev)
		  || (clsB < 1+close_atB[open_atB[j-1].close_index].close_prev)
		  || (olsA != 1+open_atA[i-1].open_next)
		  || (olsB != 1+open_atB[j-1].open_next)) {
	       
		  computeTable_Cell(table, graph, i, ostemsA, open_atA, close_atA, j, ostemsB, open_atB, close_atB);

		   
		  clsA = 1+close_atA[open_atA[i-1].close_index].close_prev;
		  clsB = 1+close_atB[open_atB[j-1].close_index].close_prev;
		  olsA = 1+open_atA[i-1].open_next;
		  olsB = 1+open_atB[j-1].open_next;
		  
	       }
		  
	       
	       graph[1+open_atA[i-1].close_index][1+open_atB[j-1].close_index] += table[1+close_atA[open_atA[i-1].close_index].close_prev][1+close_atB[open_atB[j-1].close_index].close_prev];	       

	       /*	       INFO_ " withunder(%i,%i) = %i", 1+close_atA[open_atA[i-1].close_index].close_prev, 1+close_atB[open_atB[j-1].close_index].close_prev, graph[1+open_atA[i-1].close_index][1+open_atB[j-1].close_index] _INFO;*/

	    }

	    /*	    INFO_ "\n" _INFO;*/
	    
#if defined(CARNAC_NON_WATSON_CRICK) && defined(CARNAC_CONSERVED_NON_CANONICAL_BONUS)
	    if(HAVE_NON_CANONICAL_CONSERVED(compatibles[open_atA[i-1].stem_id][open_atB[j-1].stem_id])) {
	       graph[1+open_atA[i-1].close_index][1+open_atB[j-1].close_index] += CARNAC_CONSERVED_NON_CANONICAL_BONUS;
	    }
#endif
	 }
      }
   }
}






void
computeTable(const metastem_list stemsA, const stem_open_index_t *open_atA, const stem_close_index_t *close_atA, const metastem_list stemsB, const stem_open_index_t *open_atB, const stem_close_index_t *close_atB, int **table, int **graph) {
   int w, x, y;


   table[0][0] = 0;
   

   for(x = 0; x <= stemsA.nb_metastems; x++) {
      table[x][0] = 0;
   }
   for(y = 0; y <= stemsB.nb_metastems; y++) {
      table[0][y] = 0;
   }
	 

   

   for(x = 1; x <= stemsA.nb_metastems; x++) {

      for(y = 1; y <= stemsB.nb_metastems; y++) {

	 /*	 INFO_ "table[%2i][%2i] = MIN(", x, y _INFO;*/

	 table[x][y] = MIN(table[x-1][y], table[x][y-1]);
	 
	 /*	 INFO_ "%5i, %5i", table[x-1][y], table[x][y-1] _INFO;*/
	 
	 
	 w = graph[x][y];
	 
	 /*	 INFO_ ", g = %5i", w  _INFO;*/
	 
	 if((open_atA[close_atA[x-1].open_index].close_prev >= 0)
	    && (open_atB[close_atB[y-1].open_index].close_prev >= 0)) {

	    /*	    INFO_ ", g' = %5i", table[1+open_atA[close_atA[x-1].open_index].close_prev][1+open_atB[close_atB[y-1].open_index].close_prev] _INFO;*/

	    w += table[1+open_atA[close_atA[x-1].open_index].close_prev][1+open_atB[close_atB[y-1].open_index].close_prev];
	 }

	 table[x][y] = MIN(table[x][y], w);


	 /*	 INFO_ ") = %5i\n", table[x][y] _INFO;*/
      }
   }

   /*   INFO_ "ENERGY GLOBALE : %i\n", table[stemsA.nb_metastems][stemsB.nb_metastems] _INFO;*/
}








void
build_optimal_folding(const int i, const int k, const metastem_t_list ostemsA, const stem_open_index_t *open_atA, const stem_close_index_t *close_atA, const int j, const int l, const metastem_t_list ostemsB, const stem_open_index_t *open_atB, const stem_close_index_t *close_atB, int **table, int **graph, stack *p, sankoff_result_pair res) {

   int x, y;
   int m;

   x = k;
   y = l;

   /*   INFO_ "  OPTIMAL FOLDING : i = %i, k = %i, j = %i, l = %i\n",i,k,j,l _INFO;*/
   

   while((x>i) || (y>j)) {
      if ((y>j) && (table[x][y] == table[x][y-1])){
	 /*	 INFO_ "  SKIP x = %i, y = %i (%i) TO x = %i, y = %i (%i)\n", x, y, table[x][y],x,y-1, table[x][y-1] _INFO;*/
	 y--; 
      } else if((x>i) && (table[x][y] == table[x-1][y])) {
	 /*	 INFO_ "  SKIP x = %i, y = %i (%i) TO x = %i, y = %i (%i)\n", x, y, table[x][y],x-1,y, table[x-1][y] _INFO;*/
	 x--;
      } else {

	 /*	 INFO_ "  TAKE x = %i, y = %i (%i) JUMP TO x = %i, y = %i (%i, stem+under = %i)\n", x, y, table[x][y], 1+open_atA[close_atA[x-1].open_index].close_prev, 1+open_atB[close_atB[y-1].open_index].close_prev, table[1+open_atA[close_atA[x-1].open_index].close_prev][1+open_atB[close_atB[y-1].open_index].close_prev], graph[x][y] _INFO;*/


	 if(!(open_atA[close_atA[x-1].open_index].is_hairpin || open_atB[close_atB[y-1].open_index].is_hairpin)) {
	    /* should look for subopt */
	    push(p, x, y);
	    /*	    INFO_ "  PUSH %i, %i\n", x, y _INFO;*/
	 }

	 if(res->nb_stems == 0) {
	    NEW(res->stems1, metastem_t, 1);
	    NEW(res->stems2, metastem_t, 1);
	 } else {
	    RENEW(res->stems1, metastem_t, (res->nb_stems+1));
	    RENEW(res->stems2, metastem_t, (res->nb_stems+1));
	 }

	 res->stems1[res->nb_stems] = ostemsA->metastems[close_atA[x-1].stem_id];
	 NEW(res->stems1[res->nb_stems].seq_stems, stem_t, ostemsA->metastems[close_atA[x-1].stem_id].nb_seqs);
	 for(m = 0; m < ostemsA->metastems[close_atA[x-1].stem_id].nb_seqs; m++) {
	    res->stems1[res->nb_stems].seq_stems[m] = ostemsA->metastems[close_atA[x-1].stem_id].seq_stems[m];
	 }
	 res->energy1 += ostemsA->metastems[close_atA[x-1].stem_id].energy;

	 res->stems2[res->nb_stems] = ostemsB->metastems[close_atB[y-1].stem_id];
	 NEW(res->stems2[res->nb_stems].seq_stems, stem_t, ostemsB->metastems[close_atB[y-1].stem_id].nb_seqs);
	 for(m = 0; m < ostemsB->metastems[close_atB[y-1].stem_id].nb_seqs; m++) {
	    res->stems2[res->nb_stems].seq_stems[m] = ostemsB->metastems[close_atB[y-1].stem_id].seq_stems[m];
	 }
	 res->energy2 += ostemsB->metastems[close_atB[y-1].stem_id].energy;
	 
	 res->nb_stems++;
	 
	 x = 1+open_atA[close_atA[x-1].open_index].close_prev;
	 y = 1+open_atB[close_atB[y-1].open_index].close_prev;
      }
   }
}







void
trace_back(const metastem_t_list ostemsA, const metastem_list stemsA, const stem_open_index_t *open_atA, const stem_close_index_t *close_atA, const metastem_t_list ostemsB, const metastem_list stemsB, const stem_open_index_t *open_atB, const stem_close_index_t *close_atB, int **table, int **graph, sankoff_result_pair res) {
   stack *p = NULL;
   int x, y;


   NEW(p, stack, 1);

   init_stack(p, (stemsA.nb_metastems + stemsB.nb_metastems)*2);
   
   /*   INFO_ "TRACE BACK\n" _INFO;*/

   computeTable(stemsA, open_atA, close_atA, stemsB, open_atB, close_atB, table, graph);

   /*   INFO_ "table = %i\n", table[stemsA.nb_metastems][stemsB.nb_metastems] _INFO;*/
   
   
   x = stemsA.nb_metastems;
   y = stemsB.nb_metastems;

   build_optimal_folding(0, x, ostemsA, open_atA, close_atA, 0, y, ostemsB, open_atB, close_atB, table, graph, p, res);


   while(!is_empty_stack(p)) {
      pop(p, &x,&y);
      /*      INFO_ "POP %i, %i\n", x, y _INFO;*/
      
      computeTable_Cell(table, graph, 1+close_atA[x-1].open_index, ostemsA, open_atA, close_atA, 1+close_atB[y-1].open_index, ostemsB, open_atB, close_atB);

      build_optimal_folding(1+open_atA[open_atA[close_atA[x-1].open_index].open_next].close_prev, 1+close_atA[x-1].close_prev, ostemsA, open_atA, close_atA, 1+open_atB[open_atB[close_atB[y-1].open_index].open_next].close_prev, 1+close_atB[y-1].close_prev, ostemsB, open_atB, close_atB, table, graph, p, res);

   }


   free_stack(p);
}






void
sankoff_stems(const metasequence metaA, const metastem_t_list ostemsA, const metastem_list stemsA, const stem_open_index_t *open_atA, const stem_close_index_t *close_atA, const metasequence metaB, const metastem_t_list ostemsB, const metastem_list stemsB, const stem_open_index_t *open_atB, const stem_close_index_t *close_atB, cofoldable_t **compatibles, sankoff_result_pair res) {

   int i, j;
   int **table = NULL;
   int **graph = NULL;

   
   NEW(table, int*, (stemsA.nb_metastems+1));
   NEW(graph, int*, (stemsA.nb_metastems+1));
   for(i = 0; i <= stemsA.nb_metastems; i++) {
      NEW(table[i], int, (stemsB.nb_metastems+1));
      NEW(graph[i], int, (stemsB.nb_metastems+1));
      for(j = 0; j <= stemsB.nb_metastems; j++) {
	 table[i][j] = 0;
	 graph[i][j] = 0;
      }	 
   }

   build_alignment_graph(metaA, ostemsA, stemsA, open_atA, close_atA, metaB, ostemsB, stemsB, open_atB, close_atB, table, graph, compatibles);


   trace_back(ostemsA, stemsA, open_atA, close_atA, ostemsB, stemsB, open_atB, close_atB, table, graph, res);

   
   for (i = 0; i <= (stemsA.nb_metastems); i++) {
      DESTROY(table[i]);
      DESTROY(graph[i]);
   }
   DESTROY(table);
   DESTROY(graph);

}
