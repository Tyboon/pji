#ifndef __ARNICA_CARNAC_COMPATIBLE_H__
#define __ARNICA_CARNAC_COMPATIBLE_H__



#include "metasequence.h"
#include "carnac_blocks.h"
#include "carnac_stems.h"
#include "carnac_metastems.h"
#include "sequence.h"
#include "alignment.h"



#define DO_COVARIATE_MASK 0x1
#define COMPATIBLE_MASK 0x2
#define HAVE_NON_CANONICAL_CONSERVED_MASK 0x4


#define DO_COVARIATE(Cc) ((Cc).data & DO_COVARIATE_MASK)
#define COMPATIBLE(Cc) ((Cc).data & COMPATIBLE_MASK)
#define HAVE_NON_CANONICAL_CONSERVED(Cc) ((Cc).data & HAVE_NON_CANONICAL_CONSERVED_MASK)


typedef struct {
   char data;
   short_stack shifts;
} cofoldable_t;


typedef struct {
   metastem_t *metastem;
   block_t *open_left_block;
   block_t *open_right_block;
   block_t *close_left_block;
   block_t *close_right_block;
} anchor_stem_t;

typedef anchor_stem_t *anchor_stem;

typedef struct {
   anchor_stem_t *astems_1;
   int nb_astems_1;
   anchor_stem_t *astems_2;
   int nb_astems_2;
} anchor_stem_list_t;

typedef anchor_stem_list_t *anchor_stem_list; 




extern cofoldable_t**
compatible_stems_meta(const metasequence_t m1, const metastem_t_list_t l1, const metasequence_t m2, const metastem_t_list_t l2, const block_list bl, const int id);





#endif
