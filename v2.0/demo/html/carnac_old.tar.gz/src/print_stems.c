

/*----------------------------------------------*/
/* print_stems.c                                */
/*----------------------------------------------*/

#include "print_stems.h"

void print_stems (string_t m, sequence_t seq, stem_list_t K) {
  
  int i, j, n;
  FILE *out;

  out = fopen("stems.out","a");

  n = stem_list_length (K);

  // entete
  fprintf(out,"\n *** %s ***", m);
  fprintf(out,"\n   nom : %s\n", seq.name);
  fprintf(out,"   taille de la s�quence :  %4i\n", seq.length);
  fprintf(out,"   nombre de tiges :        %4i\n\n", n);
  
  // tiges
  fprintf(out,"      flag        position      ");
  fprintf(out,"  energie       sequence\n");
  fprintf(out,"________________________________");
  fprintf(out,"________________________________\n");
  fprintf(out,"     |    |                      |       | |\n");
  for(i=1; i<=n; i++) {
    fprintf(out," %4i|%s |", K[i]->s[0]+1, int2string(K[i]->flag,1));
    fprintf(out,"%4i:%4i", K[i]->s[1]+1, K[i]->s[2]+1);
    fprintf(out," / %4i:%4i |", K[i]->s[3]+1, K[i]->s[4]+1);
    fprintf(out," %5i |", K[i]->energy);
    //    if (K[i]->substem) fprintf (out, "sub|"); else fprintf (out, "   |");
    if (K[i]->true_match>=10) fprintf(out,"m|");
    else if (K[i]->true_match>0) fprintf(out,"s|");
    else fprintf(out," |");
    for(j=K[i]->s[1]; j<=K[i]->s[2]; j++) fprintf(out,"%c", seq.nucl[j]);
    fprintf(out," / ");
    for(j=K[i]->s[3]; j<=K[i]->s[4]; j++) fprintf(out,"%c", seq.nucl[j]);
    fprintf(out,"\n");}
  fprintf(out,"________________________________");
  fprintf(out,"________________________________\n\n");

  fclose(out);
}

void print_stems_compare (string_t m, sequence_t seq, stem_list_t K) {
  
  int i, j, n;
  FILE *out;

  out = fopen("stems.out","a");

  n = stem_list_length (K);

  // entete
  fprintf(out,"\n *** %s ***\n", m);
  fprintf(out,"\n   nom : %s\n", seq.name);
  fprintf(out,"   taille de la s�quence :  %4i\n", seq.length);
  fprintf(out,"   nombre de tiges :        %4i\n\n", n);
  
  // tiges
  fprintf(out,"             position     ");
  fprintf(out,"   match        sequence\n");
  fprintf(out,"________________________________");
  fprintf(out,"________________________________\n");
  fprintf(out,"     |                      | |\n");
  for(i=0; i<n; i++) {
    fprintf(out," %4i|", K[i]->s[0]+1);
    fprintf(out,"%4i:%4i", K[i]->s[1]+1, K[i]->s[2]+1);
    fprintf(out," / %4i:%4i |", K[i]->s[3]+1, K[i]->s[4]+1);
    //    if (K[i]->substem) fprintf (out, "sub|"); else fprintf (out, "   |");
    if (K[i]->true_match>=10) fprintf(out,"m|");
    else if (K[i]->true_match>0) fprintf(out,"s|");
    else fprintf(out," |");
    for(j=K[i]->s[1]; j<=K[i]->s[2]; j++) fprintf(out,"%c", seq.nucl[j]);
    fprintf(out," / ");
    for(j=K[i]->s[3]; j<=K[i]->s[4]; j++) fprintf(out,"%c", seq.nucl[j]);
    fprintf(out,"\n");}
  fprintf(out,"________________________________");
  fprintf(out,"________________________________\n\n");

  fclose(out);
}
