
/*------------------------------------------------------*/
/* print_folding.c                                      */
/*------------------------------------------------------*/

#include "print_folding.h"

alignment_t stretch;
int count_out_bp0, count_out_bp1;

/*------------------------------------------------------*/
void recurs_print_partial_tree (FILE *out, stem_list_t K0,
				stem_list_t K1, node_t *n);
void recurs_print_full_tree (FILE *out, stem_list_t K0,
			     stem_list_t K1, node_t *n);
alignment_t build_folding (stem_list_t K0, stem_list_t K1, node_t *n);
void build_bp (int x, stem_list_t K, vector_t *basep, node_t *n);
void build_bn (int x, stem_list_t K, string_t *p_blocnu,
	       block_list_t blockl, int mark_block);
/*------------------------------------------------------*/

void create_str_out_file (int i, int j, stem_list_t K0, stem_list_t K1,
			  sequence_list_t seq, node_t *stree) {

  FILE *out;
  string_t name;
  
  // ouverture fichier
  name = cat(cat(cat(cat(new_string("str."),intoa(i+1)),
		     new_string(".")),intoa(j+1)),new_string(".out"));
  out = fopen(name,"w");

  // impression sous format '.out'
  fprintf (out,"\n [%2i] %s : [%2i] %s\n\n", i+1, seq[0].name, j+1, seq[1].name);
  recurs_print_partial_tree (out, K0, K1, stree);
  fprintf (out, "\n");

  // cloture fichier
  fclose (out);
}

void create_str_str_file (int i, int j, stem_list_t K0, stem_list_t K1,
			  sequence_list_t seq, node_t *stree) {

  FILE *out;
  string_t name;

  // ouverture fichier
  name = cat(cat(cat(cat(new_string("str."),intoa(i+1)),
		     new_string(".")),intoa(j+1)),new_string(".str"));
  out = fopen(name,"w");

  // impression sous format '.str'
  fprintf (out,"\n [%2i] %s : [%2i] %s\n\n", i+1, seq[0].name, j+1, seq[1].name);
  recurs_print_full_tree (out, K0, K1, stree);
  fprintf (out,"\n");

  // cloture fichier
  fclose (out);
}

void print_full_label (FILE *out, stem_list_t K0,
		       stem_list_t K1, node_t *n) {
  if (root(n)) fprintf (out, "@");
  else {
    if ((n->label[0]!=-1) && (n->label[1]!=-1))
      fprintf (out, "[%s:%i.%i.%i.%i:e%i.i%i][%s:%i.%i.%i.%i:e%i.i%i]\n",
	       int2string (K0[n->label[0]]->flag,1),
	       K0[n->label[0]]->s[1],
	       K0[n->label[0]]->s[2],
	       K0[n->label[0]]->s[3],
	       K0[n->label[0]]->s[4],
	       K0[n->label[0]]->energy,
	       K0[n->label[0]]->index,
	       int2string (K1[n->label[1]]->flag,1),
	       K1[n->label[1]]->s[1],
	       K1[n->label[1]]->s[2],
	       K1[n->label[1]]->s[3],
	       K1[n->label[1]]->s[4],
	       K1[n->label[1]]->energy,
	       K1[n->label[1]]->index);
    else if (n->label[0]!=-1)
      fprintf (out, "[%s:%i.%i.%i.%i:e%i.i%i][***]\n",
	       int2string (K0[n->label[0]]->flag,1),
	       K0[n->label[0]]->s[1],
	       K0[n->label[0]]->s[2],
	       K0[n->label[0]]->s[3],
	       K0[n->label[0]]->s[4],
	       K0[n->label[0]]->energy,
	       K0[n->label[0]]->index);
    else if (n->label[1]!=-1)
      fprintf (out, "[***][%s:%i.%i.%i.%i:e%i.i%i]\n",
	       int2string (K1[n->label[1]]->flag,1),
	       K1[n->label[1]]->s[1],
	       K1[n->label[1]]->s[2],
	       K1[n->label[1]]->s[3],
	       K1[n->label[1]]->s[4],
	       K1[n->label[1]]->energy,
	       K1[n->label[1]]->index);
    else // fprintf (out, "#");
      {fprintf (out, "\n\n  ERROR in print_full_label\n\n"); exit(0);}
  }
}

void print_partial_label (FILE *out, stem_list_t K0,
			  stem_list_t K1, node_t *n) {
  if (root(n)) fprintf (out, "@");
  else {
    if ((n->label[0]!=-1) && (n->label[1]!=-1))
      fprintf (out, "[%s:%s]",
	       int2string (K0[n->label[0]]->flag,1),
	       int2string (K1[n->label[1]]->flag,1));
    else if (n->label[0]!=-1)
      fprintf (out, "[%s:***]",
	       int2string (K0[n->label[0]]->flag,1));
    else if (n->label[1]!=-1)
      fprintf (out, "[***:%s]",
	       int2string (K1[n->label[1]]->flag,1));
    else // fprintf (out, "#");
      {fprintf (out, "\n\n  ERROR in print_partial_label\n\n"); exit(0);}
  }
}

void recurs_print_partial_tree (FILE *out, stem_list_t K0,
				stem_list_t K1, node_t *n) {
  int i;
  if (n!=NULL) {
    print_partial_label (out, K0, K1, n);
    if (n -> arity) {fprintf (out, " (");
    for (i=0; i<n -> arity; i++)
      recurs_print_partial_tree (out, K0, K1, n->child[i]);
    fprintf (out, ") ");}}}

void recurs_print_full_tree (FILE *out, stem_list_t K0,
			     stem_list_t K1, node_t *n) {
  int i;
  if (n!=NULL) {
    print_full_label (out, K0, K1, n);
    if (n -> arity) {fprintf (out, " (\n");
    for (i=0; i<n -> arity; i++)
      recurs_print_full_tree (out, K0, K1, n->child[i]);
    fprintf (out, " )\n");}}}


void create_str_ct_file (int i, int j, int x, stem_list_t K,
			 sequence_list_t seq, node_t *stree) {

  FILE *out;
  int ii, n;
  string_t name, blocnu;
  vector_t basep;
  extern block_list_t block;

  // rep�rage des paires & blocs  
  n = seq[x].length;
  basep  = new_vector (n);  basep[0] = 0;
  build_bp (x, K, &basep,  stree);
  build_bn (x, K, &blocnu, block, 0);

  // ouverture fichier
  name = cat(cat(cat(cat(new_string("str."),
			 intoa(i+1)),new_string(".")),intoa(j+1)),new_string(".ct"));
  out = fopen(name,"w");

  // impression sous format '.ct'
  fprintf (out,"%5i %s\n", n, seq[x].name);
  for (ii=0; ii<n; ii++) {
    fprintf (out,"%5i ", ii+1);
    fprintf (out,"%c ", blocnu[ii]);
    fprintf (out,"%5i ", ii);
    fprintf (out,"%5i ", (ii+2)%(n+1));
    fprintf (out,"%5i ", basep[ii]);
    fprintf (out,"%5i\n", ii+1);
  }

  // cloture fichier
  fclose (out);
}

void build_bn (int x, stem_list_t K, string_t *p_blocnu,
	       block_list_t blockl, int mark_block) {
  int i, l, nb, n; extern sequence_list_t seq;
  n = seq[x].length; 
  nb = block_list_length (blockl);
  (*p_blocnu) = (string_t) malloc (n*sizeof(char));
  for (i=0; i<n; i++) (*p_blocnu)[i]=toupper(seq[x].nucl[i]);
  if (mark_block)
    for (l=1; l<=nb; l++)
      for (i=blockl[l]->begin[x]; i<blockl[l]->begin[x]+blockl[l]->length; i++)
	(*p_blocnu)[i] = tolower((*p_blocnu)[i]);}

void build_bp (int x, stem_list_t K, vector_t *p_basep, node_t *n) {
  int y, open, close, length;
  if (n->label[x]+1) {
    open =   K[n->label[x]] -> s[1]; close =  K[n->label[x]] -> s[3];
    length = K[n->label[x]] -> s[2] - K[n->label[x]] -> s[1] + 1;
    for (y=0; y<length; y++) {
      (*p_basep)[open+y] = close+length-y;
      (*p_basep)[close+y] = open+length-y;
    }} for (y=0; y<n->arity; y++) build_bp (x, K, p_basep, n->child[y]);}

void retrieve_folding (stem_list_t K0, stem_list_t K1, node_t *stree) {
  count_out_bp0 = -1; count_out_bp1 = -1;
  // construction de l'alignement
  stretch = build_folding (K0, K1, stree);
  // affichage de l'alignement
  // modif helene if (VERBOSE) printf("[out %2i:%2i]", count_out_bp0+1, count_out_bp1+1);
}

void print_folding (sequence_list_t seq, int i_seq, int j_seq) {

  char tmp;
  int i, j, length;
  FILE *out;

  // ouverture fichier
  out = fopen("folding.out","a");

  // entete
  fprintf (out, "\n              [%2i:%2i]\n", i_seq+1, j_seq+1);
  fprintf(out, "\n   ---  %s\n", seq[0].name);
  fprintf(out, "   ---  %s\n\n", seq[1].name);

  length = (int) strlen (stretch.nu_0);
  if ((length != (int) strlen(stretch.nu_1)) ||
      (length != (int) strlen(stretch.str_0)) ||
      (length != (int) strlen(stretch.str_1)))
    {printf ("\n ERROR in print_fold. : seq. diff. lengths\n\n"); exit(1);}

  for(i=0; i<length/LARGE; i++) {

    for(j=0; j<LARGE; j++) fprintf(out,"-"); fprintf(out,"\n");

    tmp = stretch.str_0[(i+1)*LARGE];
    stretch.str_0[(i+1)*LARGE] = '\0';
    fprintf(out,"%s\n", stretch.str_0+i*LARGE);
    stretch.str_0[(i+1)*LARGE] = tmp;

    tmp = stretch.nu_0[(i+1)*LARGE];
    stretch.nu_0[(i+1)*LARGE] = '\0';
    fprintf(out,"%s\n", stretch.nu_0+i*LARGE);
    stretch.nu_0[(i+1)*LARGE] = tmp;

    tmp = stretch.nu_1[(i+1)*LARGE];
    stretch.nu_1[(i+1)*LARGE] = '\0';
    fprintf(out,"%s\n", stretch.nu_1+i*LARGE);
    stretch.nu_1[(i+1)*LARGE] = tmp;

    tmp = stretch.str_1[(i+1)*LARGE];
    stretch.str_1[(i+1)*LARGE] = '\0';
    fprintf(out,"%s\n", stretch.str_1+i*LARGE);
    stretch.str_1[(i+1)*LARGE] = tmp;
  }

  for(j=0; j<LARGE; j++) fprintf(out,"-"); fprintf(out,"\n");
  fprintf(out,"%s\n", stretch.str_0 + i * LARGE);
  fprintf(out,"%s\n", stretch.nu_0 + i * LARGE);
  fprintf(out,"%s\n", stretch.nu_1 + i * LARGE);
  fprintf(out,"%s\n", stretch.str_1 + i * LARGE);
  fprintf(out,"\n");

  // fermeture fichier
  fclose(out);}

alignment_t build_folding (stem_list_t K0, stem_list_t K1, node_t *n) {

  extern sequence_list_t seq;
  string_t symbol = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ&#|@�$*��!�+."
    "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ&#|@�$*��!�+.-";
  int x, count_out_bp, match=0, x0[5], xx0[5], xx1[5], x1[5];
  alignment_t A, A1, A11, A22, A2;

  A.nu_0 =  new_string ("");
  A.nu_1 =  new_string ("");
  A.str_0 = new_string ("");
  A.str_1 = new_string ("");

  if (root(n)) {

    xx0 [1] = 0;
    if (ask_for_son_from_left (n,0))
      xx0 [2] = K0[(ask_for_son_from_left (n,0))->label[0]]->s[1]-1;
    else xx0 [2] = -1;
    xx1 [1] = 0;
    if (ask_for_son_from_left (n,1))
      xx1 [2] = K1[(ask_for_son_from_left (n,1))->label[1]]->s[1]-1;
    else xx1 [2] = -1;

    A11.nu_0 = cut (seq[0].nucl, xx0[1], xx0[2], 0);
    A11.nu_0 = w_compl (A11.nu_0, xx1[2]-xx1[1]-xx0[2]+xx0[1], 'r');
    A11.str_0 = w_compl (new_string(""), MAX(xx0[2]-xx0[1],xx1[2]-xx1[1])+3, 'r');
    A11.nu_1 = cut (seq[1].nucl, xx1[1], xx1[2], 0);
    A11.nu_1 = w_compl (A11.nu_1, xx0[2]-xx0[1]-xx1[2]+xx1[1], 'r');
    A11.str_1 = w_compl (new_string(""), MAX(xx0[2]-xx0[1],xx1[2]-xx1[1])+3, 'r');}

  else
    {A11.nu_0=new_string(""); A11.str_0=new_string("");
    A11.nu_1=new_string(""); A11.str_1=new_string("");}

  for (x=0; x<n->arity; x++) {

    if ((ask_for_left_brother (n,x,0) != NULL)
	&& ((n->child[x])->label[0]+1))
      {
	xx0[1] = K0[(ask_for_left_brother(n,x,0))->label[0]]->s[4]+1;
	xx0[2] = K0[(n->child[x])->label[0]]->s[1]-1;
      }
    else  {xx0[1]=0; xx0[2]=-1;}
    
    if ((ask_for_left_brother (n,x,1) != NULL)
	&& ((n->child[x])->label[1]+1))
      {
	xx1[1] = K1[(ask_for_left_brother(n,x,1))->label[1]]->s[4]+1;
	xx1[2] = K1[(n->child[x])->label[1]]->s[1]-1;
      }
    else {xx1[1]=0; xx1[2]=-1;}

    A22.nu_0 = cut (seq[0].nucl, xx0[1], xx0[2], 0);
    A22.nu_0 = w_compl (A22.nu_0, xx1[2]-xx1[1]-xx0[2]+xx0[1], 'r');
    A22.str_0 = w_compl (new_string(""), MAX(xx0[2]-xx0[1],xx1[2]-xx1[1])+3, 'r');
    A22.nu_1 = cut (seq[1].nucl, xx1[1], xx1[2], 0);
    A22.nu_1 = w_compl (A22.nu_1, xx0[2]-xx0[1]-xx1[2]+xx1[1], 'r');
    A22.str_1 = w_compl (new_string(""), MAX(xx0[2]-xx0[1],xx1[2]-xx1[1])+3, 'r');

    A = CAT (A, CAT (A22, build_folding (K0, K1, n->child[x])));
  }

  if (root(n)) {

    if (ask_for_son_from_right (n,0))
      xx0 [3] = K0[(ask_for_son_from_right(n,0))->label[0]]->s[4]+1;
    else xx0 [3] = 0;
    xx0 [4] = strlen(seq[0].nucl)-1;
    if (ask_for_son_from_right (n,1))
      xx1 [3] = K1[(ask_for_son_from_right(n,1))->label[1]]->s[4]+1;
    else xx1 [3] = 0;
    xx1 [4] = strlen(seq[1].nucl)-1;

    A22.nu_0 = cut (seq[0].nucl, xx0[3], xx0[4], 0);
    A22.nu_0 = w_compl (A22.nu_0, xx1[4]-xx1[3]-xx0[4]+xx0[3], 'r');
    A22.str_0 = w_compl (new_string(""), MAX(xx0[4]-xx0[3],xx1[4]-xx1[3])+3, 'r');
    A22.nu_1 = cut (seq[1].nucl, xx1[3], xx1[4], 0);
    A22.nu_1 = w_compl (A22.nu_1, xx0[4]-xx0[3]-xx1[4]+xx1[3], 'r');
    A22.str_1 = w_compl (new_string(""), MAX(xx0[4]-xx0[3],xx1[4]-xx1[3])+3, 'r');}

  else
    {A22.nu_0=new_string(""); A22.str_0=new_string("");
    A22.nu_1=new_string(""); A22.str_1=new_string("");}
  
  A = CAT (A11, CAT (A, A22));

  if ((n->label[0]+1) || (n->label[1]+1)) {
    
    if (n->label[0]+1) count_out_bp0 ++;
    if (n->label[1]+1) count_out_bp1 ++;
    count_out_bp = MAX (count_out_bp0, count_out_bp1);

    // x[1].x[2] | xx[1].xx[2] | .. | xx[3].xx[4] | x[3].x[4]

    if (n->label[0]+1){

      x0 [1] = K0[n->label[0]]->s[1];
      x0 [2] = K0[n->label[0]]->s[2];
      x0 [3] = K0[n->label[0]]->s[3];
      x0 [4] = K0[n->label[0]]->s[4];

      if (ask_for_son_from_left(n,0)!=NULL) {

	xx0 [1] = K0[n->label[0]]->s[2]+1;
	xx0 [2] = K0[(ask_for_son_from_left (n,0))->label[0]]->s[1]-1;
	xx0 [3] = K0[(ask_for_son_from_right(n,0))->label[0]]->s[4]+1;
	xx0 [4] = K0[n->label[0]]->s[3]-1;
      }

      else {

	xx0 [1] = K0[n->label[0]]->s[2]+1;
	xx0 [2] = K0[n->label[0]]->s[3]-1;
	xx0 [3] = 0;
	xx0 [4] = -1;
      }
    }

    else
      {x0[1]=0;  x0[2]=-1;  x0[3]=0;  x0[4]=-1;
      xx0[1]=0; xx0[2]=-1; xx0[3]=0; xx0[4]=-1;}
    
    if (n->label[1]+1) {

      x1 [1] = K1[n->label[1]]->s[1];
      x1 [2] = K1[n->label[1]]->s[2];
      x1 [3] = K1[n->label[1]]->s[3];
      x1 [4] = K1[n->label[1]]->s[4];

      if (ask_for_son_from_left(n,1)!=NULL) {

	xx1 [1] = K1[n->label[1]]->s[2]+1;
	xx1 [2] = K1[(ask_for_son_from_left (n,1))->label[1]]->s[1]-1;
	xx1 [3] = K1[(ask_for_son_from_right(n,1))->label[1]]->s[4]+1;
	xx1 [4] = K1[n->label[1]]->s[3]-1;
      }

      else {

	xx1 [1] = K1[n->label[1]]->s[2]+1;
	xx1 [2] = K1[n->label[1]]->s[3]-1;
	xx1 [3] = 0;
	xx1 [4] = -1;
      }
    }

    else
      {x1[1]=0;  x1[2]=-1;  x1[3]=0;  x1[4]=-1;
      xx1[1]=0; xx1[2]=-1; xx1[3]=0; xx1[4]=-1;}

    A1.nu_0 = cut (seq[0].nucl, x0[1], x0[2], match);
    A1.nu_0 = w_compl (A1.nu_0, x1[2]-x1[1]-x0[2]+x0[1], 'r');
    A2.nu_0 = cut (seq[0].nucl, x0[3], x0[4], match);
    A2.nu_0 = w_compl (A2.nu_0, x1[4]-x1[3]-x0[4]+x0[3], 'l');
    A11.nu_0 = cut (seq[0].nucl, xx0[1], xx0[2], 0);
    A11.nu_0 = w_compl (A11.nu_0, xx1[2]-xx1[1]-xx0[2]+xx0[1], 'r');
    A22.nu_0 = cut (seq[0].nucl, xx0[3], xx0[4], 0);
    A22.nu_0 = w_compl (A22.nu_0, xx1[4]-xx1[3]-xx0[4]+xx0[3], 'r');

    A1.nu_1 = cut (seq[1].nucl, x1[1], x1[2], match);
    A1.nu_1 = w_compl (A1.nu_1, x0[2]-x0[1]-x1[2]+x1[1], 'r');
    A2.nu_1 = cut (seq[1].nucl, x1[3], x1[4], match);
    A2.nu_1 = w_compl (A2.nu_1, x0[4]-x0[3]-x1[4]+x1[3], 'l');
    A11.nu_1 = cut (seq[1].nucl, xx1[1], xx1[2], 0);
    A11.nu_1 = w_compl (A11.nu_1, xx0[2]-xx0[1]-xx1[2]+xx1[1], 'r');
    A22.nu_1 = cut (seq[1].nucl, xx1[3], xx1[4], 0);
    A22.nu_1 = w_compl (A22.nu_1, xx0[4]-xx0[3]-xx1[4]+xx1[3], 'r');

    A1.str_0 = helix_signal ('<', symbol[count_out_bp], x0[2]-x0[1]+1);
    A1.str_0 = w_compl (A1.str_0, x1[2]-x1[1]-x0[2]+x0[1], 'r');
    A2.str_0 = helix_signal ('>', symbol[count_out_bp], x0[4]-x0[3]+1);
    A2.str_0 = w_compl (A2.str_0, x1[4]-x1[3]-x0[4]+x0[3], 'l');
    A11.str_0 = w_compl (new_string(""), MAX(xx0[2]-xx0[1],xx1[2]-xx1[1])+3, 'r');
    A22.str_0 = w_compl (new_string(""), MAX(xx0[4]-xx0[3],xx1[4]-xx1[3])+3, 'r');

    A1.str_1 = helix_signal ('<', symbol[count_out_bp], x1[2]-x1[1]+1);
    A1.str_1 = w_compl (A1.str_1, x0[2]-x0[1]-x1[2]+x1[1], 'r');
    A2.str_1 = helix_signal ('>', symbol[count_out_bp], x1[4]-x1[3]+1);
    A2.str_1 = w_compl (A2.str_1, x0[4]-x0[3]-x1[4]+x1[3], 'l');
    A11.str_1 = w_compl (new_string(""), MAX(xx0[2]-xx0[1],xx1[2]-xx1[1])+3, 'r');
    A22.str_1 = w_compl (new_string(""), MAX(xx0[4]-xx0[3],xx1[4]-xx1[3])+3, 'r');

    A = CAT (A1, CAT (A11, CAT (A, CAT (A22, A2) ) ) );
  }
  return A;
}

/* modif helene : suppression de la generation de latex*/

