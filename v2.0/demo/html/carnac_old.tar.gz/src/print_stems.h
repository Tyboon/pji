

/*----------------------------------------------*/
/* print_stems.h                                */
/*----------------------------------------------*/

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "types.h"

void print_stems (string_t m, sequence_t seq, stem_list_t K);
void print_stems_compare (string_t m, sequence_t seq, stem_list_t K);

