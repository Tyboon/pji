
/*--------------------------------------------*/
/* correlate.h                                */
/*--------------------------------------------*/

#include <ctype.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include "types.h"
// modif helene  #include "parse.h"
#include "find_blocks.h"
#include "stem.h"

#ifndef CORRELATE
#define CORRELATE
int open_block_position (stem_t p, int x);
int close_block_position (stem_t p, int x);
int allow_single_stem (stem_t p, int x);
int allow_big_hp_non_covar (stem_t p);
int covary (stem_t p, stem_t q);
int open_flt (stem_t p, stem_t q);
int close_flt (stem_t p, stem_t q);
int open_left_allowed_shift (stem_t p, stem_t q);
int open_right_allowed_shift (stem_t p, stem_t q);
int close_left_allowed_shift (stem_t p, stem_t q);
int close_right_allowed_shift (stem_t p, stem_t q);
int hairpin (stem_t p);
int big_hairpin (stem_t p);
int mary (stem_t p, stem_t q);
matrix2_t correlate (stem_list_t all0, stem_list_t all1,
		     stem_list_t *K0, stem_list_t *K1,
		     int i_seq, int j_seq, int covar);
#endif
