/* -------------------------------------------*/
/* find_blocks.c                              */
/*--------------------------------------------*/

#include "find_blocks.h"
#include "parse.h"


int  SEUIL_PROBA_BLOCKS = 100; 
matrix2_t bino;

void free_block_list (block_list_t b){
int i, n; 
 n = block_list_length (b); 
 for (i=0; i<=n; i++) free (b[i]); 
 free(b);
}

int block_list_length (block_list_t b){
  return b[0]->length; 
}

typedef struct{
  int begin0; 
  int begin1; 
  int length; 
  int significance; 
} scored_block;

int subst(char a, char b){
  if (a==b) 
    return 1;
  else 
    return SUB;
}

int significant (int rel_x0, int rel_x1, int length, int mism) {
  int k; 
  float proba=0;
  int SEUIL_LENGTH_BLOCKS = 30;
  // WARN !! bino computed only below 32 !!
  // so SEUIL_LENGTH_BLOCKS should be less than 32
  if (mism<0) return 0; 
  if (length <= 7) return 0;
  if (length <= SEUIL_LENGTH_BLOCKS) {
    for (k=0; k<=mism; k++)
      proba += (float) bino[length][k] * power(3, k);
    proba *= power(.25, length);
    proba *= (float) (1 + ABS (rel_x1 - rel_x0));
    //  proba *= (float) (1 + ABS (rel_x1 - rel_x0) * ABS (rel_x1 - rel_x0));
    if (proba!=0){
      //printf ("%d \n", ((int) - log (proba)) );
      if  ( ((int) - log (proba))  >= 12){
	//printf("creation d'un bloc : %d, (%d  mismatches) \n", length, mism);
      return 1; 
    }
    }
    else 
      return 1;
  }
  return 1;
}

//return (score>8)  ;





scored_block * make_block (int begin0, int begin1, int length, int significance){
  scored_block * b = (scored_block *) malloc(sizeof(scored_block));
  b->begin0 = begin0; 
  b->begin1 = begin1;
  b->length = length; 
  b->significance = significance;
  return b;
}

block_list_t alloc_block_list (int size){
  block_list_t b;
  int i; 
  b = (block_list_t) sec_malloc((size+1)*sizeof(block_t));
  for (i=0; i<=size; i++)
    b[i]= (block_t) malloc (sizeof(_block_t)); 
  b[0]->length=size;
  return b;
}

block_list_t find_blocks (sequence_list_t seq) {

  extern int brk_lp;
   int d,e;
  int l =0; // numero du block en cours
  int m = seq[0].length;
  int n = seq[1].length;
  int block_id; 
  int nombre_bloc; 
  int maximum; //maximum local de la matrice
  int recherche_finie =0; 
  scored_block * bblock[n*m/8];
  block_t tmp;
  block_list_t b; 
  int longueur_bloc=0; 
  int max_score=0; 
  int current_score=0; 
  int length=0; 
  int begin1, begin2; 
  int i, j; //pour la binomiale
  int mism =0; 

 // compute and store binomial coefs
  bino = alloc_matrix2 (32, 32, 0);
  bino[0][0] = 1; for (i=1; i<32; i++) {
    bino[i][0] = 1; for (j=1; j<i; j++)
      bino[i][j] = bino[i-1][j] + bino[i-1][j-1];}

  
  // recherche des segments conserves
  for (d=0; d<m; d++){
    longueur_bloc=0;
    current_score=0; 
    max_score=0; 
    length=0; 
    mism=0;
    for (e=0; e<MIN(m-d,n); e++) { 
      length++; 
      if (seq[0].nucl[d+e]==seq[1].nucl[e]) { //identite
	current_score++;
	if (current_score==1){// on commence un nouveau bloc
	  begin1=d+e; 
	  begin2=e; 
          mism=0;
          length=1;
	}
	if (max_score<current_score){
	  longueur_bloc=length; 
	  max_score=current_score; 
	}
      }
      else { //substitution
	current_score +=  SUB; 
	mism++; 
	if (current_score<0) {current_score=0; mism=0;}
      }
      if (current_score==0){
       	if (significant(begin1, begin2, longueur_bloc, mism)) { //creation d'un nouveau bloc
	  bblock[l] = make_block (begin1, begin2, longueur_bloc, max_score);
	  l++;
	}
	mism=0; 
	longueur_bloc=0;
	length=0; 
	max_score=0; 
      }
    } // fin  for (e=0; e<MIN(m-d,n); e++) 
    // fin de parcours de la sequence : test du bloc de fin
 
    if  (significant(begin1, begin2, longueur_bloc, mism)) { //creation d'un nouveau bloc
      bblock[l] = make_block (begin1, begin2, longueur_bloc, max_score);
      l++; 
    }
    mism=0; 
    longueur_bloc=0;
    length=0; 
    max_score=0; 
  } // fin  for (d=0; d<m; d++)
   
  for (d=1; d<n; d++){
    longueur_bloc=0;
    current_score=0; 
    length=0; 
    max_score=0;
    mism=0;
     for (e=0; e<MIN(n-d, m); e++){
      length++; 
      if (seq[0].nucl[e]== seq[1].nucl[d+e]){ //identite
	current_score++;
	if (current_score==1){
	  begin1=e; 
	  begin2=d+e;
	  mism=0;
          length=1; 
	}
        if (max_score<current_score){
	  longueur_bloc=length; 
	  max_score=current_score; 
	}
      }
      else { //substitution
	current_score += SUB;
	mism++; 
      	if (current_score<0) {current_score=0;mism=0;} 
      }
      if (current_score==0) {
	if  (significant(begin1, begin2, longueur_bloc, mism)){ //creation d'un nouveau bloc
	  bblock[l] = make_block (begin1, begin2, longueur_bloc, max_score);
	  l++; 
	}
	mism=0; 
	longueur_bloc=0; 	
	length=0; 
	max_score=0; 
      }
     } 
     // fin de parcours de la sequence

       if  (significant(begin1, begin2, longueur_bloc, mism)){ //creation d'un nouveau bloc
	 bblock[l] = make_block (begin1, begin2, longueur_bloc, max_score);
	 l++; 
       }
  }

  // selection des blocs les plus significatifs et elimination des 
  // blocs conflictuels
  nombre_bloc=0; 
  recherche_finie=0;   
  do{
    // recherche du meilleur bloc non encore trait� ou elimine
    // traite : significativite mise a 0
    // elimine : significativite mise a -1
     maximum=0; 
     for (d=0; d<l; d++){
       if (bblock[d]->significance>maximum){
	maximum=bblock[d]->significance; 
	block_id = d; 
      }
    }
    if (maximum>0){ // on a un nouveau bloc
      bblock[block_id]->significance=0; 
      nombre_bloc++; 
      // on elimine les blocs conflictuels
      for (d=0; d<l; d++)
	if (bblock[d]->significance>0){
	  if ((bblock[d]->begin0-bblock[block_id]->begin0)*(bblock[d]->begin1-bblock[block_id]->begin1)<=0)
	    bblock[d]->significance=-1;
	  else if ( (bblock[d]->begin0>=bblock[block_id]->begin0) && (bblock[d]->begin0<bblock[block_id]->begin0+bblock[block_id]->length-1))
	    bblock[d]->significance=-1;      
	  else if  ( (bblock[d]->begin1>=bblock[block_id]->begin1) && (bblock[d]->begin1<bblock[block_id]->begin1+bblock[block_id]->length-1))
	    bblock[d]->significance=-1;      
	   else if ( (bblock[block_id]->begin0>=bblock[d]->begin0) && (bblock[block_id]->begin0<bblock[d]->begin0+bblock[d]->length-1))
	    bblock[d]->significance=-1;      
	  else if  ( (bblock[block_id]->begin1>=bblock[d]->begin1) && (bblock[block_id]->begin1<bblock[d]->begin1+bblock[d]->length-1))
	    bblock[d]->significance=-1;  
}
    }
    else
      recherche_finie=1; 
  } while (!recherche_finie);

  
  // on recopie dans la liste finale
  b = alloc_block_list(nombre_bloc); 
  e = 1; 
  for (d=0; d<l; d++)
    if (bblock[d]->significance==0) { // on recopie
      b[e]->begin[0]=bblock[d]->begin0; 
      b[e]->begin[1]=bblock[d]->begin1; 
      b[e]->length=bblock[d]->length; 
      e++;   
}  

  // on trie la liste des blocs par rapport � begin[0]
  recherche_finie=0;
  for (e=nombre_bloc; (e>=2)&& (!recherche_finie); e--){
    recherche_finie=1; 
    for (d=1; d<e; d++) {
      if (b[d]->begin[0] > b[d+1]->begin[0]){
	recherche_finie=0; 
	tmp=b[d];  
	b[d]=b[d+1];
	b[d+1]=tmp;
      }
    }
  } 
  
  return b; 
}
