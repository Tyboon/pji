
/*----------------------------------------------*/
/* nuss.h                                       */
/*----------------------------------------------*/

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "tree.h"
#include "parse.h"
#include "types.h"
#include "stem.h"

node_t* nuss (int i, stem_list_t K, int shorten);
