/*-----------------------------------------*/
/*     parse.c                             */
/*-----------------------------------------*/

#include "parse.h"
#include <unistd.h>
#include <malloc.h>
#include <string.h>


void default_parameters(){

  //ANCHOR POINTS

AP_THD = 8; 	       // threshold for anchor points selection
SUB = -5; 	       // cost for a substitution
SIMIL_THD = 98;       // percent similarity threshold

// ENERGY THRESHOLDS FOR STEMS 

SCALING = 1;		// scaling mult. factor for threshold
INI_THD = -500;     	// threshold for preselection
SIZE_HAIRPIN = 3;	// min hairpin loop size

DIST_1 = 50;		// distance  1
THD_1 = -800;		// threshold 1    piecewise  affine
DIST_2 = 300;		// distance  2        threshold
THD_2 = -1300;		// threshold 2

// SINGLE HAIRPINS 

SIZE_MAX_HP = 8	;	// max loop size to be a hairpin
THD_HP = -1500;  	// energy threshold for a hairpin to be preselected

// MATCHABLE STEMS 

COVAR = 1;		// matchable stems must covary ?
FLT = 1	;		// number of floating nucl. outside anchor points

// PRINT 

LARGE = 90;         	/// column width in output files
}

void parse_command_line (int argc, char **argv) {
  int c;
  extern char* infile_seq;
  extern char* infile_date;//GMI3
  WEB=0; 
  CORRECT_THD = 1;
  OUTPUT = 1;
  GRAPH = 0;
  CLEAN = 0;
  SINGLE_HP = 0;
    while ((c = getopt(argc,argv,"p:e:f:codigytlahw")) != EOF) {
      if (c =='h') SINGLE_HP = 1; // single hairpins allowed
      else if (c =='y') DYNAM = 0;    // undisplay percentages
      else if (c =='g') GRAPH = 1;    // create graph files '.dot'
      else if (c =='c') CLEAN = 1;    // discard sequences too similar
      else if (c =='a') CORRECT_THD = 0; /* pas de correction pour le seuil de l'energie des tiges*/
      else if (c =='w') WEB=1; 
      else exit(0);
    }

  
    if (WEB){
      infile_seq = (char*) malloc (strlen(argv[argc-2])+1 * sizeof(char));
      strcpy (infile_seq, argv[argc-2]);
      //GMI3 nouveau param pour la cr�ation du nom des fichiers
      infile_date = (char*) malloc (strlen(argv[argc-1])+1 * sizeof(char));
      strcpy (infile_date, argv[argc-1]);
    }
    else{
      infile_seq = (char*) malloc (strlen(argv[argc-1])+1 * sizeof(char));
      strcpy (infile_seq, argv[argc-1]);
    }

}

void print_infos () {
  
  fprintf(stdout,"\n Parameter values :\n"); 
  fprintf(stdout,"\n  AP_THD         %i",        AP_THD);
  fprintf(stdout,"\n  SUB            %i",           SUB);

  fprintf(stdout,"\n  SIZE_HAIRPIN   %i",  SIZE_HAIRPIN);

  fprintf(stdout,"\n  CORRECT_THD    %i",   CORRECT_THD);
  fprintf(stdout,"\n  INI_THD        %i",       INI_THD);
  fprintf(stdout,"\n  DIST_1         %i",        DIST_1);
  fprintf(stdout,"\n  DIST_2         %i",        DIST_2);
  fprintf(stdout,"\n  Energy tresholds :          "); 
  fprintf(stdout, "%i -  %i", THD_1, THD_2); 
  fprintf(stdout,"\n  Allowing single hairpins : "); 
  if (SINGLE_HP) fprintf(stdout,"yes"); else fprintf(stdout, "no"); 
  fprintf(stdout,"\n  SIZE_MAX_HP    %i",   SIZE_MAX_HP);
  fprintf(stdout,"\n  THD_HP         %i",        THD_HP);
  fprintf(stdout,"\n  FLT            %i\n",           FLT);

}
