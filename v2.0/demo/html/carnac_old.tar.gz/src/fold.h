
/*----------------------------------------------*/
/* fold.h                                       */
/*----------------------------------------------*/

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "tree.h"
#include "parse.h"
#include "correlate.h"
#include "types.h"
#include "find_stems.h"
#define	NB_MAX_MATCHABLE 3000
#define	TIME_BREAK_SEC    600 // break cofolding if too long

node_t* fold (stem_list_t *S0, stem_list_t *S1, int verb, int shorten);

