

/*----------------------------------------------*/
/* graph.h                                      */
/*----------------------------------------------*/

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "types.h"
#include "parse.h"
#include "string.h"
#include "stem.h"

#ifndef RATIO_NB_MAX_G_NODES
#define RATIO_NB_MAX_G_NODES           200     // 200
#define RATIO_NB_MAX_COMPOUNDS         50      // 50
#define RATIO_NB_MAX_LINKS_BY_G_NODE   8       // 5
#define RATIO_NB_NODES_BY_COMPOUND     4       // 3
// SIZE = RATIO x nb_seq

// le graphe est stock� sous forme d'une liste de g_nodes
// de la meme mani�re qu'une chaine de caract�res
// un g_node contient un ensemble de tiges �quivalentes

typedef struct _g_node_t {
  int seq;                   // num�ro de la s�quence correspondante
  int rank;		     // rang dans la liste initiale
  int visited;		     // bool: noeud d�j� visit� ?
  int eject;		     // bool: noeud � �liminer ?
  stem_list_t in_stem_list;  // liste des tiges contenues dans le noeud
  int arity_out;	     // arit� des arcs de type 'corepli�'
  int arity_id;              // arit� des arcs de type 'non_covari�'
  struct _g_node_t **out_g_node_list; // liste des noeuds connect�s par un arc de type 'corepli�'
  struct _g_node_t **id_g_node_list;  // liste des noeuds connect�s par un arc de type 'non_covari�'
} _g_node_t, *g_node_t;
typedef g_node_t *g_node_list_t;

// (maintenant) on ne conserve en m�moire que la composante connexe en
// cours d'examen, de type compound_t

typedef struct _compound_t {
  struct _g_node_t ** list; // liste de ses noeuds
  int size;                 // nombre de noeuds
  int corrected_size;       // tient compte des fusions de noeuds (voir compute_stats)
  int sq;                   // nombre de s�quences pr�sentes dans la composante (voir compute_stats)
  int co;		    // nombre d'arcs 'copli�s' (voir compute_stats)
  int id;		    // nombre d'arcs 'non_covari�' (voir compute_stats)
  int me;		    // nombre max d'arcs (voir compute_stats)
  int index;                // indicve du graphe (voir compute_stats)
} _compound_t, *compound_t;
typedef compound_t *compound_list_t;

#endif

g_node_list_t new_g_node_list (int size);
g_node_t new_g_node (int seq, int rank);
int g_node_list_length (g_node_list_t gc);
void add_to_out_g_node_list (g_node_t G, g_node_t out);
void add_to_id_g_node_list (g_node_t G, g_node_t out);
void free_g_node_list (g_node_list_t G, int size);

//compound_list_t new_compound_list (int size);
compound_t new_compound (int size);
int add_g_node_to_compound (compound_t C, g_node_t G, int nb_compound);
void delete_g_node (g_node_list_t S, int i, g_node_t G);
//void free_compound_list (compound_list_t CL, int size);

void sort_list_compound(compound_t C);
void sort_out_g_node_list (g_node_t G);

int belongs2g_node_list (g_node_t G, g_node_list_t Glist);
int rank (g_node_list_t S, g_node_t G);

void print_class_content (g_node_list_t g_node, int i);
void print_class_connect (g_node_list_t g_node, int i);
void print_connex_compound (compound_t C);
void print_graph_infos (compound_t C);
void close_graph_infos ();

void compute_stats (compound_t C);
void generate_dot_file (compound_t C);

