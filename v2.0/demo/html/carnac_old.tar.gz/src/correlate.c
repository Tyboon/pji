
/*--------------------------------------------*/
/* correlate.c                                */
/*--------------------------------------------*/

#include "correlate.h"

/*---------------------------------------------------*/
void check_mary (stem_t p, int x, stem_t q, int y);
/*---------------------------------------------------*/

extern sequence_list_t seq;


int covary (stem_t p, stem_t q) {
  int k, delta, answer, long0, long1, long_min;
  char a0, a1, b0, b1;
  delta = adjust (p,q);
  answer = 0;
  long0 = p->s[2] - p->s[1] + 1;
  long1 = q->s[2] - q->s[1] + 1;
  long_min = MIN (long0, long1);
  for (k=0; k<long_min; k++) {
    a0 = seq[0].nucl[p->s[1]+k+MAX(delta,0)];
    b0 = seq[0].nucl[p->s[4]-k-MAX(delta,0)];
    a1 = seq[1].nucl[q->s[1]+k+MAX(-delta,0)];
    b1 = seq[1].nucl[q->s[4]-k-MAX(-delta,0)];
    answer += covariation (a0, a1, b0, b1);
  }

  // at least one out of  5 bases is conserved
  //  if (5*answer > 4*long_min) answer = 0;

  // at least 1 covariation per 7 bases
  //  if (7*answer < long_min) answer = 0;

  return answer;
}

int hairpin (stem_t p){
  return (p->s[3] - p->s[2] - 1 <= SIZE_MAX_HP)
;}

int big_hairpin (stem_t p){
  return ((hairpin(p)) && (p->energy <= THD_HP));
}

int allow_single_stem (stem_t p, int x) {
  return (SINGLE_HP) && (big_hairpin(p));
/*    return (SINGLE_HP) && (big_hairpin(p)) && */
/*      ((open_block_position (p, x) - 50) % 100 == 0) && */
/*      ((close_block_position (p, x) - 50) % 100 == 0); */
}

int allow_big_hp_non_covar (stem_t p){
  return (p->energy <= THD_HP) && (p->s[3] - p->s[2] - 1 <= SIZE_MAX_HP);
}

//  0 ..... x0-------x0+l0 ..... x1-------x1+l1 ..... x2--------x2+l2 .....
//  0 ..... y0-------y0+l0 ..... y1-------y1+l1 ..... y2--------y2+l2 .....
//  blocks :      0                   1                    2
//     50   75   100   125   150     200  225   250  275  300  325  .....

int open_block_position (stem_t p, int x) {
  extern block_list_t block; int n, t, pos;

  n = block_list_length (block);
  for (t=1; (t<=n) && (p->s[2] > block[t]->begin[x]+block[t]->length); t++);

  // p->s[1]  in  .................. xt+lt ]
  // p->s[2]  in  ] x(t-1)+l(t-1) .. xt+lt ]
  pos = 100 * t;
  if (t==n+1) pos -=50;

  // p->s[1]  in  .................. xt [
  // p->s[2]  in  ] x(t-1)+l(t-1) .. xt+lt ]
  if ((t<=n) && (p->s[1] < block[t]->begin[x])) pos -= 25;

  // p->s[1]  in  .................. xt [
  // p->s[2]  in  ] x(t-1)+l(t-1) .. xt [
  if ((t<=n) && (p->s[2] < block[t]->begin[x])) pos -= 25;

  // p->s[1]  in  ....... x(t-1)+l(t-1) [
  // p->s[2]  in  ] x(t-1)+l(t-1) .. xt ]
  if ((t>1) && (p->s[1] < block[t-1]->begin[x]+block[t-1]->length)) pos -= 25;

  return pos;
}

int close_block_position (stem_t p, int x) {
  extern block_list_t block; int n, t, pos;

  n = block_list_length (block);
  for (t=1; (t<=n) && (p->s[4] > block[t]->begin[x]+block[t]->length); t++);

  // p->s[3]  in  .................. xt+lt ]
  // p->s[4]  in  ] x(t-1)+l(t-1) .. xt+lt ]
  pos = 100 * t;
  if (t==n+1) pos -=50;

  // p->s[3]  in  .................. xt [
  // p->s[4]  in  ] x(t-1)+l(t-1) .. xt+lt ]
  if ((t<=n) && (p->s[3] < block[t]->begin[x])) pos -= 25;

  // p->s[3]  in  .................. xt [
  // p->s[4]  in  ] x(t-1)+l(t-1) .. xt [
  if ((t<=n) && (p->s[4] < block[t]->begin[x])) pos -= 25;

  // p->s[3]  in  ....... x(t-1)+l(t-1) [
  // p->s[4]  in  ] x(t-1)+l(t-1) .. xt ]
  if ((t>1) && (p->s[3] < block[t-1]->begin[x]+block[t-1]->length)) pos -= 25;

  return pos;
}

//  0 ..... x0--------x0+l0 ...... x1-------x1+l1 ..... x2-------x2+l2 .....
//  0 ..... y0--------y0+l0 ...... y1-------y1+l1 ..... y2-------y2+l2 .....
//  blocks :      0                     1                    2
//     50   75   100   125   150  175  200   225   250  275  300  325  .....
//  open_left_allowed_shift      |        bl. 1       |
//  open_right_allowed_shift                     |        bl. 2       |

int open_flt (stem_t p, stem_t q){
  int pos, flt; 
  pos = open_block_position (p,0);
  if ((pos%50 == 0) && (pos%100 != 0)) flt=FLT; else flt=0;
  return flt;
}

int close_flt (stem_t p, stem_t q){
int pos, flt; 
 pos = close_block_position (p,0);
 if ((pos%50 == 0) && (pos%100 != 0)) flt=FLT; else flt=0;
 return flt;
}

int open_left_allowed_shift (stem_t p, stem_t q) {
  extern block_list_t block; int pos_p, pos_q, shift;
  int seq_n0, seq_n1;
  seq_n0 = seq[0].length;
  seq_n1 = seq[1].length;
  pos_p = open_block_position (p,0);
  pos_q = open_block_position (q,1);
  pos_p += 25; pos_p = pos_p/100 ;
  pos_q += 25; pos_q = pos_q/100 ;
  shift = Z;
  if (pos_p == pos_q) {
    if ((pos_p>0) && (pos_p<=block_list_length (block)))
      shift = block[pos_p]->begin[0] - block[pos_p]->begin[1];
    else if (pos_p == 0) shift = 0;
    else if (pos_p > block_list_length (block)) shift = seq_n0 - seq_n1;
    else {printf("correcorr\n ERROR in covar :"); print_(pos_p);
    print_(pos_q); printf("correcanardcorr\n"); exit(0);}
  }
  return shift;
}

int open_right_allowed_shift (stem_t p, stem_t q) {
  extern block_list_t block; int pos_p, pos_q, shift;
  int seq_n0, seq_n1;
  seq_n0 = seq[0].length;
  seq_n1 = seq[1].length;
  pos_p = open_block_position (p,0);
  pos_q = open_block_position (q,1);
  pos_p += 50; pos_p = pos_p/100 ;
  pos_q += 50; pos_q = pos_q/100 ;
  shift = Z;
  if (pos_p == pos_q) {
    if ((pos_p>0) && (pos_p<=block_list_length (block)))
      shift = block[pos_p]->begin[0] - block[pos_p]->begin[1];
    else if (pos_p == 0) shift = 0;
    else if (pos_p > block_list_length (block)) shift = seq_n0 - seq_n1;
    else {printf("correcorr\n ERROR in covar :"); print_(pos_p);
    print_(pos_q); printf("correcanardcorr\n"); exit(0);}
  }
  return shift;
}

int close_left_allowed_shift (stem_t p, stem_t q) {
  extern block_list_t block; int pos_p, pos_q, shift;
  int seq_n0, seq_n1;
  seq_n0 = seq[0].length;
  seq_n1 = seq[1].length;
  pos_p = close_block_position (p,0);
  pos_q = close_block_position (q,1);
  pos_p += 25; pos_p = pos_p/100 ;
  pos_q += 25; pos_q = pos_q/100 ;
  shift = Z;
  if (pos_p == pos_q) {
    if ((pos_p>0) && (pos_p<=block_list_length (block)))
      shift = block[pos_p]->begin[0] - block[pos_p]->begin[1];
    else if (pos_p == 0) shift = 0;
    else if (pos_p > block_list_length (block)) shift = seq_n0 - seq_n1;
  }
  return shift;
}

int close_right_allowed_shift (stem_t p, stem_t q) {
  extern block_list_t block; int pos_p, pos_q, shift;
  int seq_n0, seq_n1;
  seq_n0 = seq[0].length;
  seq_n1 = seq[1].length;
  pos_p = close_block_position (p,0);
  pos_q = close_block_position (q,1);
  pos_p += 50; pos_p = pos_p/100 ;
  pos_q += 50; pos_q = pos_q/100 ;
  shift = Z;
  if (pos_p == pos_q) {
    if ((pos_p>0) && (pos_p<=block_list_length (block)))
      shift = block[pos_p]->begin[0] - block[pos_p]->begin[1];
    else if (pos_p == 0) shift = 0;
    else if (pos_p > block_list_length (block)) shift = seq_n0 - seq_n1;
  }
  return shift;
}





//  0 ..... x0--------x0+l0 ..... x1-----x1+l1 ..... x2-------x2+l2 .....
//  0 ..... y0--------y0+l0 ..... y1-----y1+l1 ..... y2-------y2+l2 .....
//  blocks :      0                   1                    2
//     50   75   100   125   150     200  225   250  275  300  325  .....

matrix2_t correlate (stem_list_t all0, stem_list_t all1,
		     stem_list_t *K0, stem_list_t *K1,
		     int i_seq, int j_seq, int covar) {

  int i, j; 
  int ii=0; 
  int jj=0; 
  int n0 = stem_list_length (all0);
  int n1 = stem_list_length (all1);
  int number_of_stems0=0; 
  int number_of_stems1=0;
  matrix2_t correlatetmp = alloc_matrix2 (n0+1, n1+1, 0);
  matrix2_t correlate; 
  
  for (i=1; i<=n0; i++) all0[i]->lonely=1;
  for (j=1; j<=n1; j++) all1[j]->lonely=1;

  // rep�re et marque les tiges corr�l�es
  for (i=1; i<=n0; i++)
    for (j=1; j<=n1; j++)
      if (mary (all0[i], all1[j]) &&  (covar || covary (all0[i], all1[j]))){
	if (all0[i]->lonely==1) {all0[i]->lonely=0; number_of_stems0++; }
	if (all1[j]->lonely==1) {all1[j]->lonely=0; number_of_stems1++; }
	correlatetmp[i][j]=1;
      }
      
   // marquage des  tiges superflues de all0 en vue de la construction
  // de K0
  for (i=1; i<=n0; i++)
    if (all0[i]->lonely==1){
      if  (allow_single_stem (all0[i], 0))
	number_of_stems0++; // creation d'une tige celibataire
      else  // marquage
	all0[i]->lonely=-1; 
    }

  // marquage des  tiges superflues de all1 en vue de la construction
  // de K1
  for (j=1; j<=n1; j++)
    if (all1[j]->lonely==1){
      if  (allow_single_stem (all1[j], 1))
	number_of_stems1++; //creation d'une tige celibataire
      else  // marquage
	all1[j]->lonely=-1;
    }

  // creation de la matrice definitive et des listes de tiges associ�es 
  correlate=alloc_matrix2(number_of_stems0+1,  number_of_stems1+1, 0);//remarque helene : probleme avec le +2
  (*K0) = new_stem_list (number_of_stems0);
  (*K1) = new_stem_list (number_of_stems1);

  // la matrice et K0
  for (i=1; i<=n0; i++)
    if 	(all0[i]->lonely!=-1){
      ii++; 
      (*K0)[ii]=all0[i];
      jj=0; 
      for (j=1; j<=n1; j++)
	if (all1[j]->lonely!=-1){
	  jj++;
	  correlate[ii][jj]=correlatetmp[i][j];
	}
    }
  // K1
   jj=0; 
   for (j=1; j<=n1; j++)
     if (all1[j]->lonely!=-1){
       jj++;
       (*K1)[jj]=all1[j];
     }
   //printf ("\n nombre de tiges filtr�es pour seq 1 : %i\n", stem_list_length(*K0)); 
   //printf (" nombre de tiges filtr�es pour seq 2 : %i\n", stem_list_length(*K1)); 
   return correlate;
}

int mary (stem_t p, stem_t q) {

  //  check_mary (p, 1, q, 1);

  return ((open_left_allowed_shift(p,q) != Z) &&
	  (open_right_allowed_shift(p,q) != Z) &&
	  (close_left_allowed_shift(p,q) != Z) &&
	  (close_right_allowed_shift(p,q) != Z) &&

	  (MIN(open_left_allowed_shift(p,q),
	       open_right_allowed_shift(p,q))
	   <= p->s[1]-q->s[1]+adjust(p,q) + open_flt(p,q)) &&

	  (p->s[1]-q->s[1]+adjust(p,q) <=
	   MAX(open_left_allowed_shift(p,q),
	       open_right_allowed_shift(p,q)) + open_flt(p,q)) &&

	  (MIN(close_left_allowed_shift(p,q),
	       close_right_allowed_shift(p,q))
	   <= p->s[4]-q->s[4]-adjust(p,q) + close_flt(p,q)) &&

	  (p->s[4]-q->s[4]-adjust(p,q) <=
	   MAX(close_left_allowed_shift(p,q),
	       close_right_allowed_shift(p,q)) + close_flt(p,q)));
}

void check_mary (stem_t p, int x, stem_t q, int y) {

  //  if ((p->s[0]+1==x) && (q->s[0]+1==y)) {
  if ((p->s[1]+1==x) && (q->s[1]+1==y)) {

    printf("correcorr\ncorr\nstem (%i) [%i.%i.%i.%i]corr\n"
	   "open_left_allowed_shift : %icorr\n"
	   "open_right_allowed_shift : %icorr\n"
	   "close_left_allowed_shift : %icorr\n"
	   "close_right_allowed_shift : %icorr\n",
	   p->s[0]+1, p->s[1]+1, p->s[2]+1, p->s[3]+1, p->s[4]+1,
	   open_left_allowed_shift(p,q),
	   open_right_allowed_shift(p,q),
	   close_left_allowed_shift(p,q),
	   close_right_allowed_shift(p,q));

    printf("correcorr\ncorr\nstem (%i) [%i.%i.%i.%i]corr\n"
	   "open_left_allowed_shift : %icorr\n"
	   "open_right_allowed_shift : %icorr\n"
	   "close_left_allowed_shift : %icorr\n"
	   "close_right_allowed_shift : %icorr\ncorr\n",
	   q->s[0]+1, q->s[1]+1, q->s[2]+1, q->s[3]+1, q->s[4]+1,
	   open_left_allowed_shift(p,q),
	   open_right_allowed_shift(p,q),
	   close_left_allowed_shift(p,q),
	   close_right_allowed_shift(p,q));

    printf("correcorr\nadjust(p,q) : %icorr\n"
	   "corr\np->s[1]-q->s[1]+adjust(p,q) : %icorr\n"
	   "p->s[4]-q->s[4]-adjust(p,q) : %icorr\n"
	   "FLT : %icorr\ncorr\n",
	   adjust(p,q),
	   p->s[1]-q->s[1]+adjust(p,q),
	   p->s[4]-q->s[4]-adjust(p,q),
	   FLT);

    printf("correcorr\n covary : %icorr\ncorr\n"
	   " MIN open_allowed_shift(p,q) <="
	   " p.s[1]-q.s[1]+adjust(p,q)+FLT : %icorr\ncorr\n"
	   "                               "
	   " p.s[1]-q.s[1]+adjust(p,q)+FLT <="
	   " MAX open_allowed_shift(p,q) : %icorr\ncorr\n"
	   " MIN close_allowed_shift(p,q) <="
	   " p.s[4]-q.s[4]+adjust(p,q)+FLT : %icorr\ncorr\n"
	   "                               "
	   " p.s[4]-q.s[4]+adjust(p,q)+FLT <="
	   " MAXclose_allowed_shift(p,q) : %icorr\ncorr\n",
	   
	   (covary(p,q)),

	   (MIN(open_left_allowed_shift(p,q),
		open_right_allowed_shift(p,q))
	    <= p->s[1]-q->s[1]+adjust(p,q) + FLT),

	   (p->s[1]-q->s[1]+adjust(p,q) <=
	    MAX(open_left_allowed_shift(p,q),
		open_right_allowed_shift(p,q)) + FLT),

	  (MIN(close_left_allowed_shift(p,q),
	       close_right_allowed_shift(p,q))
	   <= p->s[4]-q->s[4]-adjust(p,q) + FLT),

	   (p->s[4]-q->s[4]-adjust(p,q) <=
	   MAX(close_left_allowed_shift(p,q),
	       close_right_allowed_shift(p,q)) + FLT));

    exit(1);
  }
}
