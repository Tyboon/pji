

/*----------------------------------------------*/
/* print_alignment.h                            */
/*----------------------------------------------*/

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "string.h"
#include "types.h"
#include "parse.h"
#include "find_blocks.h"

void print_alignment (sequence_list_t seq, block_list_t block,
		      int i_seq, int j_seq);
