
/*------------------------------------------------------*/
/* string.c                                             */
/*------------------------------------------------------*/

#include "string.h"
//#include </usr/include/string.h>

string_t new_string (string_t in){
return strdup (in);
}

string_t intoa (int i)
{int k, p; string_t ans;
  ans = (string_t) malloc (4 * sizeof(char));
  for (k=2; k>=0; k--) {
    p = (int) (pow(10,(double)k));
    ans[2-k] = (i/p) + '0'; i = (i%p);}
  ans[3]='\0'; return ans;}

string_t cut (string_t string, int debut, int fin, int upper) {
   int i; string_t aux;
   if (fin<debut) {
     aux = (string_t) malloc(3*sizeof(char));
     aux[0]=' '; aux[1]=' '; aux[2]='\0'; 
     return aux;
   }
   aux  = (string_t) malloc((fin-debut+4)*sizeof(char)); 
   aux[ 0]=' '; 
   for (i =debut; i<=fin; i++)
     if ( upper) aux[i-debut+1] = toupper(string[i]);
     else        aux[i-debut+1] =         string[i];
   aux[fin-debut+2]=' '; aux[fin-debut+3]='\0'; 
   return aux;
}

string_t cat (string_t prefix, string_t suffix) {
  char *aux; char *str2;
  aux = (char*) malloc((strlen (prefix)+strlen(suffix)+1)*sizeof(char));
  strcpy (aux, prefix); str2 = strdup (suffix);
  aux = strcat (aux, str2); free (prefix);
  free (str2); return aux;}

string_t fill (string_t s, char c, int l) {
  int i, ls; string_t aux;
  ls=(int)strlen(s); 
  aux = (string_t) calloc((ls+l+1), sizeof(char));
  for (i=0; i<ls; i++) aux[i]=s[i];
  for (i=0; i<l; i++) aux[ls+i]=c;
  aux[ls+l]='\0'; free (s); return aux;}

string_t w_compl (string_t s, int l, char rl) {
  int i, ls, lw; string_t aux;
  lw=POS(l); ls=(int)strlen(s); 
  aux = (string_t) calloc(ls+lw+1, sizeof(char));
  if (rl=='r') {
    for (i=0; i<ls; i++) aux[i]=s[i];
    for (i=0; i<lw; i++) aux[ls+i]=' ';}
  else {
    for (i=0; i<lw; i++) aux[i]=' ';
    for (i=0; i<ls; i++) aux[lw+i]=s[i];}
  aux[ls+lw]='\0'; free (s); return aux;}

string_t helix_signal (char b, char x, int l)
{int i; string_t aux;
 aux = (string_t) calloc(l+3,sizeof(char));
 aux[0]=' '; aux[1]=b; for (i=2; i<l; i++) aux[i]=x;
 if (l) aux[l]=b; aux[l+1]=' '; aux[l+2]='\0'; return aux;}

alignment_t CAT (alignment_t PREF, alignment_t SUF) {
  alignment_t AUX;
  AUX.nu_0 = cat (PREF.nu_0, SUF.nu_0);
  AUX.nu_1 = cat (PREF.nu_1, SUF.nu_1);
  AUX.str_0 = cat (PREF.str_0, SUF.str_0);
  AUX.str_1 = cat (PREF.str_1, SUF.str_1);
  return AUX;}
