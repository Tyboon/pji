/*------------------------------------------------------*/
/* string.h                                             */
/*------------------------------------------------------*/

#include <ctype.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include "types.h"

#ifndef ALI
#define ALI
typedef struct {
  string_t nu_0;
  string_t str_0;
  string_t nu_1;
  string_t str_1;
} alignment_t;


string_t new_string (string_t in);
string_t intoa (int i);
string_t cut (string_t string, int debut, int fin, int upper);
string_t cat (string_t prefix, string_t suffix);
string_t fill (string_t s, char c, int l);
string_t w_compl (string_t s, int l, char rl);
string_t helix_signal (char b, char x, int l);
alignment_t CAT (alignment_t PREF, alignment_t SUF);
#endif
