

/* -------------------------------------------*/
/* clique.h                                   */
/*--------------------------------------------*/

#include <stdio.h>
#include "types.h"
#include "graph.h"
#include "tree.h"
#include "correlate.h"
#include "stem.h"

void compute_equiv_stems (stem_list_t S, int i_seq, int si);
void compute_uncovaried_stems (stem_list_t *R);
void build_graphs ();
void get_remaining_stems ();
