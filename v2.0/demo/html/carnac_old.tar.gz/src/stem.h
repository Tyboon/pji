
/*--------------------------------------------*/
/* find_stems.h                               */
/*--------------------------------------------*/

#include <ctype.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include "parse.h"
#include "string.h"
#include "types.h"
#include "find_blocks.h"

#ifndef stem
#define stem


cpl_stem_list_t new_cpl_stem_list (int size);
void add_stem_list (stem_list_t *L, stem_t P);

int cpl_stem_list_length (cpl_stem_list_t K);
stem_list_t cat_stem_list (stem_list_t K1, stem_list_t K2);
void shorten_stems (stem_list_t K);
void extend_stems (stem_list_t K);

stem_list_t sort_stems_by_end (stem_list_t K_in);
void sort_stems_by_sig (stem_list_t K);
void sort_stems_by_freq (stem_list_t K);
void sort_stems_by_index (stem_list_t K);
void sort_stems_by_begin (stem_list_t K);

void print_stem (stem_t P);
void print_stem_list (string_t msg, stem_list_t K, int x);
void print_forced_stems (sequence_list_t all_seq, int x);
void print_reference_stems (sequence_list_t all_seq, int x, stem_list_t K);
void print_true_stems (sequence_list_t all_seq, int x, stem_list_t K);
void print_married_stems (stem_list_t S);

int test_father (stem_t P1, stem_t P2);
int test_brother (stem_t P1, stem_t P2);
int is_compatible (stem_t P, stem_list_t K);
int is_almost_compatible (stem_t P, stem_list_t K);
int same_stem (stem_t K1, stem_t K2);
int belongs (stem_t P, stem_list_t K);
int equiv_stem (stem_t P, stem_t Q);
int adjust (stem_t p, stem_t q);
int identity (stem_t p, stem_t q);
int uncovary (stem_t p, stem_t q);
int substem (stem_t p, stem_t q);
int meet_substem (stem_t P, stem_list_t K);
int stem_list_length (stem_list_t K);
stem_t new_stem (int seq, int rank, int flag, int i, int j, int k, int l, int energy);
stem_list_t new_stem_list (int size);
stem_list_t new_stem_sequence(int size);
void free_stem_list( stem_list_t S);
#endif
