
/* -------------------------------------------*/
/* clique.c                                   */
/*--------------------------------------------*/

#include <unistd.h>
#include "clique.h"

extern sequence_list_t all_seq;
extern stem_list_t *R;
extern int nb_seq;
g_node_list_t g_node;
compound_t current_compound;

/*--------------------------------------------*/
// cr�e et visualise la matrice (sym�trique) des confrontations de s�quences
// matrice de bool�ens qui dit : le corepliement des s�quences i et j
// a-t-il �t� effectu� (jusqyu'au bout) ?
void gather_cofolded_seq (int i);
void display_cofolded_seq ();
// tiges �quivalentes (de la m s�q) stor�es dans un chamlp de la structure stem_t
// les tiges �quivalentes appartiennendront au meme noeud dans le graphe
void find_equiv_stems (stem_list_t S, int i_seq, int si);
// cr�ation/connection du noeud � partir d'une tige graine
void create_g_node (stem_t P, int t);
void connect_g_node (g_node_t G);
// cr�e la composante en cours
void create_compound (g_node_t G, int nb_compounds);
// ajout des arcs de type 'non_covari�'
void add_id_edges (compound_t C);
// (obsolete)
void delete_arity_one (compound_t C);
// gestion des composantes qui 'explosent'
// par d�passement de m�moire
// actuellement notifi� par le champ 'eject' du g_node
// (qui vaut 0, 1 ou 2 je crois) mais � revoir compl�tement
// si allocation dynamique de la m�moire
void clear_conficting_nodes (compound_t C);
/*--------------------------------------------*/

void build_graphs () {

  int i, ii, j, k, t, n, check, kk, nn;
  int nb_gnodes, nb_compounds;
  vector_t ns;
  g_node_t G, GG;

  // gather cofolded sequences and display
  // cofolded sequences info (as a matrix)

  // le fichier output 'cofoldseq.out' permet de visualiser la
  // matrice des confrontations de s�quences

  for (i=0; i<nb_seq; i++) gather_cofolded_seq (i);
  //display_cofolded_seq ();

  // allocate memory

  ns = new_vector (nb_seq);
  g_node = new_g_node_list (RATIO_NB_MAX_G_NODES * nb_seq);

  // find equivalent stems (they are stored in a field of stem_t)
  // + refresh field 'tag' & 'g_node' of each stem

  for (i=0; i<nb_seq; i++) {
    ns[i] = stem_list_length (R[i]);
    for (j=1; j<=ns[i]; j++) {
      R[i][j]->tag=0;
      R[i][j]->g_node=-1;
      if (R[i][j]->equiv!=NULL) free(R[i][j]->equiv); // il va falloir revoir ca, helene
      find_equiv_stems (R[i], i, j);
    }
  }

  // create g_nodes

  t=0; 
   printf ("\n");
  for (i=0; i<nb_seq; i++)
    for (j=1; j<=ns[i]; j++) {
            create_g_node (R[i][j], t);
      g_node[t] -> seq = i;
      if (stem_list_length (g_node[t]->in_stem_list) != 0) t++;
      if (t>=RATIO_NB_MAX_G_NODES*nb_seq)
	{printf("  too many nodes\n\n");
	fprintf(stderr, "  (RATIO_NB_MAX_G_NODES = %i\n", RATIO_NB_MAX_G_NODES);
	exit(0);
	}
    }
  g_node[t] = NULL;
  nb_gnodes = g_node_list_length (g_node);
  
  // print classes
  
  if (DEBUG) for (i=0; i<nb_gnodes; i++) print_class_content (g_node, i);
  
  // connect g_nodes
  
  for (i=0; i<nb_gnodes; i++) {
    G = g_node[i];
    if (!G->visited) connect_g_node (G);
  }
  for (i=0; i<nb_gnodes; i++) {
    g_node[i]->visited=0;
    sort_out_g_node_list (g_node[i]);
  }
  
  // create current connex compound (= transitive closures)
  
  nb_compounds = 0;
  for (i=0; i<nb_gnodes; i++) {
    G = g_node[i];
    
    if (!G->visited) {
      
      if (DEBUG) {
	printf ("%3i.", nb_compounds+1); fflush (stdout);
	if ((nb_compounds!=0) && ((nb_compounds+1)%10==0)) printf ("\n");}

      nb_compounds++;
      
      current_compound = new_compound (RATIO_NB_NODES_BY_COMPOUND * nb_seq);
      // modif helene Equiv
      check = add_g_node_to_compound (current_compound, G,  nb_compounds);
     
      create_compound (G, nb_compounds);

      if (G->eject != 2) {
	add_id_edges (current_compound);
	clear_conficting_nodes (current_compound);
	sort_out_g_node_list (G);
	compute_stats (current_compound);
	// report index to stems
	nn = current_compound -> size;
	for (kk=0; kk<nn; kk++) {
	  GG = (current_compound -> list)[kk];
	  n = stem_list_length (GG->in_stem_list);
	  for (k=1; k<=n; k++) GG->in_stem_list[k]->index = current_compound->index;
	}
      }

      if (DEBUG) print_connex_compound (current_compound);
      if (GRAPH) generate_dot_file (current_compound);
      print_graph_infos (current_compound);
      free (current_compound);
    }

  }

  // print  &  display

  printf(" Combination of pairwise foldings: %i classes of stems in %i connex components\n\n", nb_gnodes, nb_compounds);

  close_graph_infos ();

  // refresh field 'married' of each stem

  for (i=0; i<nb_seq; i++)
    for (j=1; j<=ns[i]; j++)
        for (k=0; k<nb_seq; k++)
	  R[i][j]->married[k] = NULL;

  // free memory

  free_g_node_list (g_node, g_node_list_length(g_node));
  free (ns);

}

void gather_cofolded_seq (int i) {

  int flag, j, k;

  if (all_seq[i].N == -1) { // seq #i hasn't been visited yet
    all_seq[i].N = -2;
    // now it has been
    flag = 1;
    while (flag) {
      flag = 0;
      for (j=0; j<nb_seq; j++)
	if ( (all_seq[i].cofold[j]) && (all_seq[j].N == -1)) {
	  all_seq[j].N = -2;
	  for (k=0; k<nb_seq; k++) {
	    if ( (k != i) && (!all_seq[i].cofold[k]) && (all_seq[j].cofold[k])) {
	      all_seq[i].cofold[k] = 2;
	      flag = 1;
	    }
	  }
	}
    }
    all_seq[i].N = 0;
    for (j=0; j<nb_seq; j++)
      if (all_seq[i].cofold[j]) all_seq[i].N++;
  }

  else if (all_seq[i].N == -2) {
    // seq #i has already been visited
    for (j=0; ((!all_seq[j].cofold[i]) || (all_seq[j].N < 0)) && (j<nb_seq); j++);
    for (k=0; k<nb_seq; k++)
      if (
	  (!all_seq[i].cofold[k]) &&
	  (all_seq[j].cofold[k])
	  )  all_seq[i].cofold[k] = 2;
    all_seq[i].N = all_seq[j].N;
  }
}

void display_cofolded_seq () {
  FILE *out; int i, j, cpt;
  out = fopen ("cofoldseq.out", "w");
  fprintf (out, "\n    ");
  for (j=0; j<nb_seq; j++) fprintf (out, "%2i ", j+1); fprintf (out, "\n\n");
  for (i=0; i<nb_seq; i++) {
    fprintf (out, "%2i: ", i+1);
    cpt = 0;
    for (j=0; j<nb_seq; j++) {
      if (i==j) fprintf (out, "  ");
      else if (all_seq[i].cofold[j] == 1) {cpt++; fprintf (out, " � ");} // cofold
      else if (all_seq[i].cofold[j] == 2) fprintf (out, " . ");  // trans. closure
      else fprintf (out, "   ");}
    fprintf (out, " (%2i ->", cpt);
    fprintf (out, " %2i) ", all_seq[i].N);
    fprintf (out, " %s\n", all_seq[i].name);}
  fprintf (out, "\n");
  fclose (out);
}



// Pour la tige si de la sequence i_seq,  construit la liste des tiges equivalentes 
// presentes dans S, et la stocke dans S[si]->equiv
void find_equiv_stems (stem_list_t S, int i_seq, int si){
  int i, t;
  int n=stem_list_length (S); 
  stem_t P=S[si];
  P -> equiv = new_stem_list (SIZE_EQUIV+1);
  t = 1; 
  for (i=1; i<=n; i++) {
    if ( (equiv_stem (P, S[i]))&& (i!=si) && (t<=SIZE_EQUIV)) {
      P -> equiv[t] = S[i]; 
      t++;
    }
  } 
  (P -> equiv[0])->energy = t-1;
}


void create_g_node (stem_t P, int t) { 
  int i, n;
  if (P->tag == 0) {
    P->tag = 1; 
    P->g_node = t;
        add_stem_list (&(g_node[t]->in_stem_list), P);
    n = stem_list_length(P->equiv);
    for (i=1; i<=n; i++)
      create_g_node (P->equiv[i], t);
  }
}


void connect_g_node (g_node_t G) {
  int i, j, n;
  stem_t P, Pe;
  g_node_t out;
  if (!G->visited) {
    G ->visited = 1;
    n = stem_list_length (G->in_stem_list);
    for (i=1; i<=n; i++) {
      P = G->in_stem_list[i];
      for (j=0; j<nb_seq; j++) {
	Pe = P->married[j];
	if (Pe) {
	  out = g_node[Pe->g_node];
	  add_to_out_g_node_list (G, out);
	  connect_g_node (out);
	}
      }
    }
  }
}

void clean_compound (g_node_t G) {
  int i, n; g_node_t Gout;
  G -> visited = 2;
  G -> eject = 2;
  n = G->arity_out;
  for (i=0; i<n; i++) {
    Gout = G->out_g_node_list[i];
    if (Gout->visited != 2)
      clean_compound (Gout);
  }
}


void create_compound (g_node_t G, int nb_compound) {
  int i, n, too_large=0; g_node_t Gout;
  if (!G->visited) {
    G -> visited = 1;
    n = G->arity_out;
    for (i=0; i<n; i++) {
      Gout = G->out_g_node_list[i];
      if (!Gout->visited) {
	//modif helene Equiv
	too_large += add_g_node_to_compound (current_compound, Gout, nb_compound);
	if (too_large) {
	  clean_compound (G);
	  printf("compound too large\n");}
	else create_compound (Gout, nb_compound);
      }
    }
  }
}


void add_id_edges (compound_t C) {
  int i, ii, j, jj, n, nn;
  int witness;
  stem_t P, PP;
  g_node_t G, GG;
  for (j=0; j<C->size; j++) {
    G = C->list[j];
    n = stem_list_length (G->in_stem_list);
    for (jj=j+1; jj<C->size; jj++) {
      GG = C->list[jj];
      if ((G->seq != GG->seq) &&
	  (!belongs2g_node_list(G,GG->out_g_node_list))) {
	witness=0;
	for (i=1; i<=n; i++) {
	  P = G->in_stem_list[i];
	  nn = stem_list_length (GG->in_stem_list);
	  for (ii=1; ii<=nn; ii++) {
	    PP = GG->in_stem_list[ii];
	    if (
		(!witness) &&
		(P->married[PP->seq] != PP) &&
		(uncovary (P, PP))
		) {
	      witness = 1;
	      add_to_id_g_node_list (G, GG);
	      add_to_id_g_node_list (GG, G);}
	  }
	}
      }
    }
  }
}




void clear_conficting_nodes (compound_t C) {
  int witness; int i, j, min_arity;
  g_node_t G1, G2, Gid, Gout; g_node_list_t S;
  int ARITY = nb_seq/4;
  for (min_arity=1; min_arity<=ARITY; min_arity++) {
    witness = 1;
    while (witness) {
      sort_list_compound (C);
      witness = 0;
      for (i=0; i<C->size-1; i++) {
	G1 = C->list[i];
	G2 = C->list[i+1];
	if (G1->seq == G2->seq) {
	  // delete G1
	  if ((G1->arity_out <= min_arity) &&
	      (G2->arity_out >= min_arity+1)) {
	    witness = 1;
	    for (j=0; j<G1->arity_id; j++) {
	      // delete all incoming 'id' edges
	      Gid = G1->id_g_node_list[j];
	      S = Gid->id_g_node_list;
	      delete_g_node (S, rank(S,G1), G1);
	      Gid -> arity_id --;
	    }
	    for (j=0; j<G1->arity_out; j++) {
	      // delete all incoming 'out' edges
	      Gout = G1->out_g_node_list[j];
	      S = Gout->out_g_node_list;
	      delete_g_node (S, rank(S,G1), G1);
	      Gout -> arity_out --;
	    }
	    G1 -> eject = 1;
	    //	    G1 -> arity_id = 0;
	    //	    G1 -> arity_out = 0; 
	    delete_g_node (C->list, i, G1);
	    C -> size --;}
	  // delete G2
	  else if ((G2->arity_out <= min_arity) &&
		   (G1->arity_out >= min_arity+1)) {
	    witness = 1;
	    for (j=0; j<G2->arity_id; j++) {
	      // delete all incoming 'id' edges
	      Gid = G2->id_g_node_list[j];
	      S = Gid->id_g_node_list;
	      delete_g_node (S, rank(S,G2), G2);
	      Gid -> arity_id --;
	    }
	    for (j=0; j<G2->arity_out; j++) {
	      // delete all incoming 'out' edges
	      Gout = G2->out_g_node_list[j];
	      S = Gout->out_g_node_list;
	      delete_g_node (S, rank(S,G2), G2);
	      Gout -> arity_out --;
	    }
	    G2 -> eject = 1;
	    //	    G2 -> arity_id = 0;
	    //	    G2 -> arity_out = 0;
	  delete_g_node (C->list, i+1, G2);
	  C -> size --;
	  }
	}
      }
    }
  }
}

// question helene : ca fait quoi ?

void get_remaining_stems () {
  
  extern stem_list_t *finalR, *remain;
  extern sequence_list_t all_seq;
  extern stem_list_t *all_stems;
  extern int nb_seq;
  int nb_cofolds;
  stem_list_t K;
  int x, i, n, nr, nf;

  for (x=0; x<nb_seq; x++) {
    K = all_stems[x];
    n = stem_list_length (K);
    nb_cofolds = -1;
    for(i=0; i<nb_seq; i++)
      nb_cofolds += (all_seq[x].cofold[i]==1);
    for(i=1; i<=n; i++)
      if (is_almost_compatible (K[i],finalR[x]))
		add_stem_list (&(remain[x]), K[i]);
    nr = stem_list_length (remain[x]);
    nf = stem_list_length (finalR[x]);
    printf ("  sequence %2i: %2i cofoldings with %4i  stems -> %3i selected stems +%4i remaining stems \n",
	      x+1, nb_cofolds, n, nf, nr-nf); /* modif helene car division par 0 possible */
    // print_remaining_stems (all_seq, x, remain[x]); modif helene
  }
}
