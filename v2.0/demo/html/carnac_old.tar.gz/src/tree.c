
/*------------------------------------------*/
/* tree.c                                   */
/*------------------------------------------*/

#include "tree.h"

node_t *new_node (int a, int b) {
  node_t *t = (node_t*) malloc(sizeof(node_t));
  t -> label[0] = a;
  t -> label[1] = b;
  t -> arity = 0;
  t -> child = NULL;
  return t;}

int root (node_t *n)
{return (!(1+n -> label[0])) && (!(1+n -> label[1]));}

void add_right_child (node_t *father, node_t *new_child) {
  (father -> arity)++;
  father -> child = (node_t**) realloc
    (father -> child,(father -> arity)*sizeof(node_t*));
  father -> child[(father -> arity)-1] = new_child;}

void add_left_child (node_t *father, node_t *new_child) {
  int i; (father -> arity)++;
  father -> child = (node_t**) realloc
    (father -> child,(father -> arity)*sizeof(node_t*));
  for (i=(father -> arity)-1 ; i>=1 ; i--) {
    father -> child[i] = father -> child[i-1];}
  father -> child[0] = new_child;}

node_t *ask_for_son_from_left (node_t *n, int x) {
  int i; node_t *ans;
  ans = NULL; i=0; while ((i<n -> arity) && (ans==NULL))
    {if (((n -> child[i]) -> label[x])+1) ans = n -> child[i];
    else ans = ask_for_son_from_left ((n -> child[i]),x); i++;}
  return ans;}

node_t *ask_for_son_from_right (node_t *n, int x) {
  int i; node_t *ans;
  ans = NULL; i=n -> arity-1; while ((i>=0) && (ans==NULL))
    {if (((n -> child[i]) -> label[x])+1) ans = n -> child[i];
    else ans = ask_for_son_from_right ((n -> child[i]),x); i--;}
  return ans;}

node_t *ask_for_right_brother (node_t *father, int rank, int x) {
  int i; node_t *ans;
  ans = NULL; i=rank+1; while ((i<father -> arity) && (ans==NULL))
    {if (((father -> child[i]) -> label[x])+1) ans = father -> child[i];
    else ans = ask_for_son_from_left ((father -> child[i]),x); i++;}
  return ans;}

node_t *ask_for_left_brother (node_t *father, int rank, int x) {
  int i; node_t *ans;
  ans = NULL; i=rank-1; while ((i>=0) && (ans==NULL))
    {if (((father -> child[i]) -> label[x])+1) ans = father -> child[i];
    else ans = ask_for_son_from_right ((father -> child[i]),x); i--;}
  return ans;}

void print_label (FILE *out, node_t *n)
{if (root(n)) fprintf (out, "*"); else
fprintf (out, "[%hi,%hi]", n -> label[0]+1, n -> label[1]+1);}

void recurs_print_tree (FILE *out, node_t *n) {
  int i;
  if (n!=NULL) {print_label(out, n); if (n -> arity)
    {fprintf (out, " (");
    for (i=0; i<n -> arity; i++) recurs_print_tree (out, n -> child[i]);
    fprintf (out, ") ");}}}

void print_tree (node_t *n) {
  FILE *out; extern int i, j;
  out = fopen("stree.out","a");
  fprintf (out, "%i|%i ", i+1, j+1);
  recurs_print_tree (out, n);
  fprintf (out, "\n");
  fclose (out);}
