/*----------------------------------------------*/
/* types.h                                      */
/*----------------------------------------------*/

#include <ctype.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "parse.h"

#ifndef MAX

#define Z 33333333       // > 2^24
#define MAX(a,b)      ((a)>(b) ? (a):(b))
#define MIN(a,b)      ((a)>(b) ? (b):(a))
#define ABS(a)        ((a)>0   ? (a):(-(a)))
#define POS(a)        ((a)>0   ? (a):(0))
#define AU(a,b)       (((a == 'a') && (b == 'u')) ? 1 : 0)
#define CG(a,b)       (((a == 'c') && (b == 'g')) ? 1 : 0)
#define GU(a,b)       (((a == 'g') && (b == 'u')) ? 1 : 0)
#define RND_FRAC(n,m) ((10*(n)/(m)+5)/10)
#define SQR(n)        ((n)*(n))
#define print(x) printf("\n %i\n\n",x);fflush(stdout)
#define print_(x) printf("%i.",x);fflush(stdout)
#define SIZE_EQUIV 10

// 0: a  1: c  2: g  3: u
#define VALb(a) ((((a)>>1)&3)^(((a)>>2)&1))
// 0: au  1: cg  2: gc  3: ua  4: gu  5: ug
#define VALp(a,b) (VALb(a)+((VALb(a)+VALb(b)==5)<<1))
//  0: au/au  1: au/cg  2: au/gc  3: au/ua  4: au/gu  5: au/ug
//  6: cg/au  7: cg/cg  8: cg/gc  9: cg/ua 10: cg/gu 11: cg/ug
// 12: gc/au 13: gc/cg 14: gc/gc 15: gc/ua 16: gc/gu 17: gc/ug
// 18: ua/au 19: ua/cg 20: ua/gc 21: ua/ua 22: ua/gu 23: ua/ug
// 24: gu/au 25: gu/cg 26: gu/gc 27: gu/ua 28: gu/gu 29: gu/ug
// 30: ug/au 31: ug/cg 32: ug/gc 33: ug/ua 34: ug/gu 35: ug/ug
#define VALpp(a,b,c,d) (6*VALp(a,b)+VALp(c,d))


typedef char      *string_t;
typedef int       *vector_t;
typedef vector_t  *matrix2_t;
typedef matrix2_t *matrix3_t;
typedef matrix3_t *matrix4_t;

typedef struct {
  int min;
  int max;
} cpl_t;

typedef struct {
  string_t nucl;   // sequence of bases
  string_t name;   // name
  int length;	   // length
  int cg;	   // gc content (%)
   vector_t cofold; // has been cofolded ? values 0 (no), 1 (yes), 2 (trans_clo)
  int N;           // size of cofolding compound
} sequence_t;
typedef sequence_t  *sequence_list_t;


typedef struct _stem_t {
  int seq;    // sequence number
  int energy; // energy
  int flag;   // label de la tige (via int2string)
  int s[5];   // 0 : rank in original filtered list K // 1.2.3.4 : abscisses
  cpl_t k_bounds;  //
  cpl_t l_bounds;  //
  int last_out;	   //  voir fold.c
  int next_in;	   //  bornes pour la matrice de corepliement
  int last_in;	   //
  int next_out;    //
  int shortened;   // bool : on autorise la tige � chevaucher une autre ?
  int substem;     // bool : is a substem of a larger one
  int lonely;      // bool : single stem
  struct _stem_t *forced;   // current cofolded stem
  struct _stem_t **married; // list of cofolded stems (size = nb_seq)
  // list is NULL ptr if stem is never folded
  struct _stem_t **equiv; // list of equivalent stems in the same sequence (shift etc.)
  // list is NULL ptr if stem is never folded
  int g_node; // equivalence class when the graph is built
  int folded; // bool : has been folded at least once
  int freq;   // frequence de repliement
  int connectivity; // 100 x connectivity of its stem graph
  int tag;    // used as a flag 'yet visited' when building the graph
  int true_match;  // comparaison � la vraie structure
  int index; // indice provenant du graphe des tiges
  int component;  // numero de la composante connexe
} _stem_t, *stem_t;
typedef stem_t *stem_list_t;
typedef stem_t **cpl_stem_list_t;

typedef struct {
  stem_list_t stem_list;
  int size;
  int open_absc;
  int close_absc;
} _class_t, *class_t;
typedef class_t *class_list_t;




// secure malloc
void *sec_malloc (size_t size);

// int
vector_t new_vector (int size);
void add_to_vector (vector_t *z, int last);
int vectorlength (vector_t z);
int is (char x, string_t alphabet); // remarque helene: inutile avec get_sequences.chelene 


// classes
// modif helene class_t new_class (int open_absc, int close_absc, stem_list_t K, int begin, int end);
// modif helene class_list_t new_class_list (int size_list);
int class_list_length (class_list_t x);
void print_class_list (class_list_t x);



// matrices
matrix2_t alloc_matrix2 (int a, int b, int fill);
void free_matrix2 (matrix2_t mat, int a);
void print_matrix2 (matrix2_t mat, int a, int b, int l, int n);

// misc.
int canoniq (char a, char b);
int covariation (char a0, char a1, char b0, char b1);
string_t int2string (int n, int up);
float power (float x, int n);
int break_loop (int i, int j, string_t msg);

#endif
