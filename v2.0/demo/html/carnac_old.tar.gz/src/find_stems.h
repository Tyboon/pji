
/*--------------------------------------------*/
/* find_stems.h                               */
/*--------------------------------------------*/

#include <ctype.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include "parse.h"
#include "correlate.h"
#include "string.h"
#include "types.h"
#include "find_blocks.h"
#include "stem.h"

#ifndef find_stem
#define find_stem
// modif helene #define	NB_MAX_STEMS_1  500000  // avant filtrage
#define	NB_MAX_STEMS_2  20000   // avant corr�lation
#define	NB_MAX_STEMS_3  2000    // avant repliement
#define	MIN_EXTEND  2    // |bp| min pour l'extention des tiges
#define	MISM_MALUS  250  // malus syst�matique pour les mismatches


void find_stems ();
// modif helene int seuil (int dist, sequence_t seq);
void get_stems (string_t infile_stem);
// void filter_stems ();
// void get_forced_stems (string_t infile_forced);
matrix2_t pre_select (stem_list_t *K0, stem_list_t *K1,
		      stem_list_t *L0, stem_list_t *L1, int covar);

#endif
