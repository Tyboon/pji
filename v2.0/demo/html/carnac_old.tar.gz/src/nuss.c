
/*----------------------------------------------*/
/* nuss.c                                       */
/*----------------------------------------------*/

#include "nuss.h"

int Kn;
matrix2_t E;

/*--------------------------------------------*/
void compute_bounds_nuss (stem_list_t K, stem_list_t L);
void fill_matrix_nuss (int seq_i, stem_list_t K, stem_list_t L);
void trace_back_nuss (node_t *tree, int i, int j, stem_list_t L);
/*--------------------------------------------*/

node_t* nuss (int i, stem_list_t K, int shorten) {

  node_t *stree;
  stem_list_t L;

  stree = NULL;
  Kn = stem_list_length (K);

  // shorten ?
  if (shorten) shorten_stems (K);

  // compute bounds
  sort_stems_by_begin (K);
  L = sort_stems_by_end (K);
  compute_bounds_nuss (K, L);
/*    {int j; if (i==0) for (j=0; j<Kn; j++) {printf ("%2i ", j); print_stem (K[j]);} nnn;} */
/*    {int j; if (i==0) for (j=0; j<Kn; j++) {printf ("%2i ", j); print_stem (L[j]);} nnn;} */

  // fill matrix
  E = alloc_matrix2 (Kn, Kn, 0);
  fill_matrix_nuss (i, K, L);

  // trace back
  stree = new_node (-1, -1);
  trace_back_nuss (stree, 0, Kn-1, L);

  // unshorten
  if (shorten) extend_stems (K);

  // free
  free_matrix2 (E, Kn);
  free (L);

  return stree;

}


void compute_bounds_nuss (stem_list_t K, stem_list_t L) {

  int j, k;

  // ( 0 .. last_out ) [xxx[ (next_in .. last_in) ]xxx] (next_out ..)

  //  next (i,k) in         [0 .. Kn-1] U {Z}
  //  last (j,l) in  {-1} U [0 .. Kn-1]

  // last_in & last_out
  for (j=1; j<=Kn; j++) {
    for (k=j-1; ((k>=0) && (L[k]->s[4] >= L[j]->s[1])); k--);
    L[j] -> last_out = k;
    for (k=j-1; ((k>0) && (L[k]->s[4] >= L[j]->s[3])); k--);
    L[j] -> last_in = k;}
  // next_in
  for (j=1; j<=Kn; j++) {
    for (k=j+1; ((k<=Kn) && (K[k]->s[1] <= K[j]->s[2])); k++);
    K[j] -> next_in = k; if (k==Kn) K[j] -> next_in = -1;}
}


// remarque helene : a regarder de pres a cause des indices de E
void fill_matrix_nuss (int seq_i, stem_list_t K, stem_list_t L) {

  int i, j;
  stem_t P;

  for (j=1; j<=Kn; j++) {
    P = L[j];
    for (i=Kn-1; i>0; i--) {
      if (K[i]->s[1] <= P->s[1])
	E[i][j] = MAX (E[i][j-1],
		       P->index + E[i][P->last_out] +
		       E[P->next_in][P->last_in]);
      else E[i][j] = E[i][j-1];
    }
  }

/*    if (seq_i==0) for (i=0; i<Kn; i++) */
/*      {for (j=0; j<Kn; j++) printf ("%3i.", E[i][j]); nnn;} nnn; */

}

void trace_back_nuss (node_t *tree, int i, int j, stem_list_t L) {
  
  int go_on;
  stem_t P;
  node_t *new;

  go_on = E[i][j];
  P = L[j];

  //  printf (" [%2i:%2i] %i\n", i, j, E[i][j]); fflush (stdout);

  if ((go_on) && (E[i][j] == P->index + E[i][P->last_out]
		  + E[P->next_in][P->last_in])) {
    go_on = 0;
    P -> folded ++;
    new = new_node (P->s[0], -1);
    add_left_child (tree, new);
    trace_back_nuss (tree, i, P->last_out, L);
    trace_back_nuss (new, P->next_in, P->last_in, L);}

  if ((go_on) && (j>-1) && (E[i][j] == E[i][j-1]))
    trace_back_nuss (tree, i, j-1, L);

}
