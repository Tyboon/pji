
/*----------------------------------------------*/
/* fold.c                                       */
/*----------------------------------------------*/

#include "fold.h"

extern int brk_lp;
extern stem_list_t K0, K1, L0, L1;
extern matrix2_t correlated;
int Kn0, Kn1; 
vector_t E;
vector_t kkk, lll, sigma_kkk, sigma_lll;
int ll, kk; unsigned long size;
// modif helene : suppression du temps CPU 


/*--------------------------------------------*/
void compute_bounds ();
void compute_sigma ();
int  f (stem_t p, stem_t q);
void fill_matrix (int seq_i, int seq_j, int verb);
void check_size (int verb);
void trace_back (node_t *tree, int i, int j, int k, int l);
void create_stem_str (int x, int seq_i, int seq_j, stem_list_t *S);
/*--------------------------------------------*/

node_t* fold (stem_list_t *S0, stem_list_t *S1, int verb, int shorten) {

  extern int i, j;
  node_t *stree;

  stree = NULL;
  Kn0 = stem_list_length (K0);
  Kn1 = stem_list_length (K1);

  if (shorten) shorten_stems (K0);
  if (shorten) shorten_stems (K1);

  compute_bounds ();
  compute_sigma ();
  check_size (verb);

  if (!brk_lp) {
    fill_matrix (i, j, verb);
    stree = new_node (-1, -1);
    trace_back (stree, 1, Kn0, 1, Kn1);
    create_stem_str (0, i, j, S0);
    create_stem_str (1, j, i, S1);
    free (E);
  }

  if (shorten) extend_stems (K0);
  if (shorten) extend_stems (K1);

  return stree;
}


int f (stem_t p, stem_t q){
  if (p==NULL) return q->energy; 
  if (q==NULL) return p->energy;
  return correlated [p->s[0]][q->s[0]] * 10 * (p->energy+q->energy);
}


void compute_bounds () {
  
  int i, j, k, l;
  
  //  min_bound  in        [1 .. Kn] U {Z}  (Z for single stem)
  //  max_bound  in  {0} U [1 .. Kn]       (0 for single stem)

  // k bounds : 0
  for (i=1; i<=Kn0; i++) {
    for (k=1; ((k<=Kn1) && (!correlated [K0[i]->s[0]] [K1[k]->s[0]])); k++);
    K0[i]->k_bounds.min = k; if (k==Kn1+1) K0[i]->k_bounds.min = Z;
    for (k=Kn1; ((k>0) && (!correlated [K0[i]->s[0]] [K1[k]->s[0]])); k--);
    K0[i]->k_bounds.max = k;}

  // extend k bounds to single stems in seq 1
  for (i=1; i<=Kn0; i++) 
    if (!K0[i]->lonely)
      while ((K1 [MAX (K0[i]->k_bounds.min-1, 0)]->lonely) &&  (K0[i]->k_bounds.min >= 2)) 
	K0[i]->k_bounds.min--;

  // l bounds : 0
  for (j=1; j<=Kn0; j++) {
    for (l=1; ((l<=Kn1) && (!correlated [L0[j]->s[0]] [L1[l]->s[0]])); l++);
    L0[j]->l_bounds.min = l; if (l==Kn1+1) L0[j]->l_bounds.min = Z;
    for (l=Kn1; ((l>0) && (!correlated [L0[j]->s[0]] [L1[l]->s[0]])); l--);
    L0[j]->l_bounds.max = l;}

  // extend l bounds to single stems in seq 1
  for (j=1; j<=Kn0; j++) 
    if (!L0[j]->lonely)
      while ((L1 [MIN (L0[j]->l_bounds.max+1, Kn1-1)]->lonely) && (L0[j]->l_bounds.max <= Kn1-1)) 
	L0[j]->l_bounds.max++;

  // k bounds : 1
  for (k=1; k<=Kn1; k++) {
    for (i=1; ((i<=Kn0) && (!correlated [K0[i]->s[0]] [K1[k]->s[0]])); i++);
    K1[k]->k_bounds.min = i; if (i==Kn0+1) K1[k]->k_bounds.min = Z;
    for (i=Kn0; ((i>0) && (!correlated [K0[i]->s[0]] [K1[k]->s[0]])); i--);
    K1[k]->k_bounds.max = i;}


  // extend k bounds to single stems in seq 0
  for (k=1; k<=Kn1; k++) if (!K1[k]->lonely) //devrait assurer K1[k]-> k_bounds.min != Z
    while ((K0 [MAX (K1[k]->k_bounds.min-1, 0)]->lonely) && //question helene : O ou 1 dans le MAX ? idem ailleurs
	   (K1[k]->k_bounds.min >= 2)) K1[k]->k_bounds.min--;

  // l bounds : 1
  for (l=1; l<=Kn1; l++) {
    for (j=1; ((j<=Kn0) && (!correlated [L0[j]->s[0]] [L1[l]->s[0]])); j++);
    L1[l]->l_bounds.min = j; if (j==Kn0+1) L1[l]->l_bounds.min = Z;
    for (j=Kn0; ((j>0) && (!correlated [L0[j]->s[0]] [L1[l]->s[0]])); j--);
    L1[l]->l_bounds.max = j;}

  // extend l bounds to single stems in seq 0
  for (l=1; l<=Kn1; l++) if (!L1[l]->lonely)
    while ((L0 [MIN (L1[l]->l_bounds.max+1, Kn0-1)]->lonely) &&
	   (L1[l]->l_bounds.max <= Kn0-1)) L1[l]->l_bounds.max++;

  // ( 0 .. last_out ) [xxx[ (next_in .. last_in) ]xxx] (next_out ..)

  //  next (i,k) in         [0 .. Kn-1] U {Z}
  //  last (j,l) in  {-1} U [0 .. Kn-1]

  // last_in & last_out  :  0
  for (j=1; j<=Kn0; j++) {
    for (k=j-1; ((k>0) && (L0[k]->s[4] >= L0[j]->s[1])); k--);
    L0[j] -> last_out = k;
    for (k=j-1; ((k>0) && (L0[k]->s[4] >= L0[j]->s[3])); k--);
    L0[j] -> last_in = k;}
  // next_in & next_out :  0
  for (j=1; j<=Kn0; j++) {
    for (k=j+1; ((k<=Kn0) && (K0[k]->s[1] <= K0[j]->s[2])); k++);
    K0[j] -> next_in = k; if (k==Kn0+1) K0[j] -> next_in = Z;
    for (k=j+1; ((k<=Kn0) && (K0[k]->s[1] <= K0[j]->s[4])); k++);
    K0[j] -> next_out = k; if (k==Kn0+1) K0[j] -> next_out = Z;}

  // last_in & last_out  :  1
  for (j=1; j<=Kn1; j++) {
    for (k=j-1; ((k>0) && (L1[k]->s[4] >= L1[j]->s[1])); k--);
    L1[j] -> last_out = k;
    for (k=j-1; ((k>0) && (L1[k]->s[4] >= L1[j]->s[3])); k--);
    L1[j] -> last_in = k;}
  // next_in & next_out :  1
  for (j=1; j<=Kn1; j++) {
    for (k=j+1; ((k<=Kn1) && (K1[k]->s[1] <= K1[j]->s[2])); k++);
    K1[j] -> next_in = k; if (k==Kn1+1) K1[j] -> next_in = Z;
    for (k=j+1; ((k<=Kn1) && (K1[k]->s[1] <= K1[j]->s[4])); k++);
    K1[j] -> next_out = k; if (k==Kn1+1) K1[j] -> next_out = Z;}
}

// check� par helene

void compute_sigma () {
  int i, j;
  kkk = new_vector (Kn0+1);
  lll = new_vector (Kn0+1);
  sigma_kkk = new_vector (Kn0+1); // modif helene sigma_kkk++; 
  // modif helene sigma_kkk[-1] = 0; 
  sigma_kkk[0] = 0;
  sigma_lll = new_vector (Kn0+1); // modif helene sigma_lll++; 
  // modif helene  sigma_lll[-1] = 0; 
  sigma_lll[0] = 0;
  for (i=1; i<=Kn0; i++) {
    kkk[i] = K0[i]->k_bounds.max - K0[i]->k_bounds.min + 2;
    if (K0[i]->lonely) kkk[i] = 1;
    sigma_kkk[i] = kkk[i] + sigma_kkk[i-1];}
  for (j=1; j<=Kn0; j++) {
    lll[j] = L0[j]->l_bounds.max - L0[j]->l_bounds.min + 2;
    if (L0[j]->lonely) lll[j] = 1;
    sigma_lll[j] = lll[j] + sigma_lll[j-1];}
  kk = sigma_kkk[Kn0];
  ll = sigma_lll[Kn0];
}

void check_size (int verb) {

  int i, j, nb_matchable;
  FILE *out;

  // check nb of couple of matchable stems
  nb_matchable = 0;
  size = (unsigned long) ll * (unsigned long) kk;
  for (i=1; i<=Kn0; i++) 
    for (j=1; j<=Kn1; j++)
      if (correlated [K0[i]->s[0]] [K1[j]->s[0]]) nb_matchable++;
    // break if matrix size can be too big
  if (nb_matchable >= NB_MAX_MATCHABLE) {
    if (DEBUG) {
      out = fopen("check_fold.out", "w");
      fprintf(out,"\n\n --- too many couples of matchable stems : %i", nb_matchable);
      fclose (out);}
    brk_lp++;}
}


//inline 
int is_allocated (int i, int j, int k, int l){
  return
   (i>0) && (i<=Kn0) && (j>0) && (j<=Kn0) &&
   (K0[i]->k_bounds.min <= k) && (k <= K0[i]->k_bounds.max) &&
   (L0[j]->l_bounds.min <= l) && (l <= L0[j]->l_bounds.max);
}

//inline 
int right_lonely_can_fold0 (int i, int j)
{return (i>0) && (i<=Kn0) && (j>0) && (j<=Kn0) &&
   (L0[j]->lonely) && (K0[i]->s[1] <= L0[j]->s[1]);}
//inline 
int right_lonely_can_fold1 (int k, int l)
{return (k>0) && (k<=Kn1) && (l>0) && (l<=Kn1) &&
   (L1[l]->lonely) && (K1[k]->s[1] <= L1[l]->s[1]);}

//inline 
int left_lonely_can_fold0 (int i, int j)
{return (i>0) && (i<=Kn0) && (j>0) && (j<=Kn0) &&
   (K0[i]->lonely) && (K0[i]->s[4] <= L0[j]->s[4]);}
//inline 
int left_lonely_can_fold1 (int k, int l)
{return (k>0) && (k<=Kn1) && (l>0) && (l<=Kn1) &&
   (K1[k]->lonely) && (K1[k]->s[4] <= L1[l]->s[4]);}

//inline 
int right_lonely_can_fold (int i, int j, int k, int l)
{return (right_lonely_can_fold0 (i,j)) || (right_lonely_can_fold1 (k,l));}
//inline 
int left_lonely_can_fold (int i, int j, int k, int l)
{return (left_lonely_can_fold0 (i,j)) || (left_lonely_can_fold1 (k,l));}
//inline 
int lonely_can_fold (int i, int j, int k, int l)
{return (SINGLE_HP) && 
   ((left_lonely_can_fold (i,j,k,l)) ||
    (right_lonely_can_fold (i,j,k,l)));}

void check (int i, int j, int k, int l,
	    int ii, int jj, int kk, int ll) {
  if ((i>ii) || (j<jj) || (k>kk) || (l<ll) ||
      ((i==ii) && (j==jj) && (k==kk) && (l==ll)))
    {printf("checked : [%i.%i.%i.%i] ==>",i,j,k,l);
    printf("[%i.%i.%i.%i]\n",ii,jj,kk,ll);
    fflush(stdout); exit(0);}}


//  min_bound  in         [0 .. Kn-1] U {Z}  (Z for single stem)
//  max_bound  in  {-1} U [0 .. Kn-1]       (-1 for single stem)

//  next (i,k) in         [0 .. Kn-1] U {Z}
//  last (j,l) in  {-1} U [0 .. Kn-1]


int get (int i, int j, int k, int l) {

  int shift;

  // si les tiges celibtaires sont autorisees

  if (SINGLE_HP) {

    // single stem 0 (can fold at right)
    if (right_lonely_can_fold0 (i,j))
      return MIN (get (i, j-1, k, l), f(L0[j], NULL)
		  + get (i, L0[j] -> last_out, k, l));

    // single stem 1 (can fold at right)
    if (right_lonely_can_fold1 (k,l))
      return MIN (get (i, j, k, l-1), f(NULL, L1[l])
		  + get (i, j, k, L1[l] -> last_out));

    // single stem 0 (can fold at left)
    if (left_lonely_can_fold0 (i,j))
      return MIN (get (i+1, j, k, l), f(K0[i], NULL)
		  + get (K0[i] -> next_out, j, k, l));

    // single stem 1 (can fold at left)
    if (left_lonely_can_fold1 (k,l))
      return MIN (get (i, j, k+1, l), f(NULL, K1[k])
		  + get (i, j, K1[k] -> next_out, l));
  } // fin SINGLE_HP

  // limit cases
  if ((k>Kn1) || (l==0) || (L1[l]->s[3] <= K1[k]->s[2]))
    {if ((i<=Kn0) && (j>0)) return get (i, j-1, k, l); else return 0;}
  if ((i>Kn0) || (j==0) || (L0[j]->s[3] <= K0[i]->s[2]))
    {if ((k<=Kn1) && (l>0)) return get (i, j, k, l-1); else return 0;}

    // allocated case (default)
  if (is_allocated (i, j, k, l)) {
    k -= K0[i]->k_bounds.min; l -= L0[j]->l_bounds.min;
    //      printf("[%i.%i.%i.%i]\n",i,j,k,l); fflush(stdout);
    shift = sigma_kkk[i-1]*ll + kkk[i]*sigma_lll[j-1] + k*lll[j] + l;
    if (shift >= (int) size)
      {printf("\n get out of range in matrix :");
      printf(" [%i.%i.%i.%i]  ", i, j, k, l);
      printf("%i > %li\n\n", shift, size);
      fflush(stdout); exit (1);}
    return *(E + shift);
  }

  {int energy;
  int ik, jl, ki, lj;
  int xi, xj, xk, xl;

  // question helene : a partir de la, on doit avoir i,j,k,l >0 ? 
  int  i_min = K1[k]->k_bounds.min;
  int  i_max = K1[k]->k_bounds.max;

  int j_min = L1[l]->l_bounds.min;
  int j_max = L1[l]->l_bounds.max;

  int k_min = K0[i]->k_bounds.min;
  int k_max = K0[i]->k_bounds.max;

  int l_min = L0[j]->l_bounds.min;
  int l_max = L0[j]->l_bounds.max;

  // speed up

  if ((i<Kn0) && ((k_max < k) || (L1[l]->s[4] <= K1[k_min]->s[1])))
    return get (i+1, j, k, l);

  if ((j>0) && ((l < l_min) || (L1[l_max]->s[4] <= K1[k]->s[1])))
    return get (i, j-1, k, l);

  if ((k<Kn1) && ((i_max < i) || (L0[j]->s[4] <= K0[i_min]->s[1])))
    return get (i, j, k+1, l);

  if ((l>0) && ((j < j_min) || (L0[j_max]->s[4] <= K0[i]->s[1])))
    return get (i, j, k, l-1);

  // not allocated case (default)
  ik = MAX (i, i_min); if (ik== Z) ik = i+1;
  jl = MIN (j, j_max); if (jl==0) jl = j-1;
  ki = MAX (k, k_min); if (ki== Z) ki = k+1;
  lj = MIN (l, l_max); if (lj==0) lj = l-1;
  while	((ik <= Kn0-1) && (!correlated [K0[ik]->s[0]][K1[k]->s[0]])) ik++;
  while	((jl >= 2)     && (!correlated [L0[jl]->s[0]][L1[l]->s[0]])) jl--;
  while	((ki <= Kn1-1) && (!correlated [K0[i]->s[0]][K1[ki]->s[0]])) ki++;
  while	((lj >= 2)     && (!correlated [L0[j]->s[0]][L1[lj]->s[0]])) lj--;
  energy = 0;


  for (xi=i; xi<=ik; xi++)
    for (xj=j; xj>=jl; xj--)
      for (xk=k; xk<=ki; xk++)
	for (xl=l; xl>=lj; xl--) {
	  //	  loop_count++;
	  //	  printf("=");fflush(stdout);
	  if ((is_allocated (xi, xj, xk, xl)) ||
    	      (lonely_can_fold (xi, xj, xk, xl)))
	    energy = MIN (energy, get (xi, xj, xk, xl));}
  //  printf(" >");fflush(stdout);
  return energy;
  }
}

void put (int i, int j, int k, int l, int energy) {
  int shift;
  if ((i>0) && (i<=Kn0) && (j>0) && (j<=Kn0) &&
      (k>=K0[i]->k_bounds.min) && (k<=K0[i]->k_bounds.max) &&
      (l>=L0[j]->l_bounds.min) && (l<=L0[j]->l_bounds.max)) {
    k -= K0[i]->k_bounds.min; l -= L0[j]->l_bounds.min;
    shift = sigma_kkk[i-1]*ll + kkk[i]*sigma_lll[j-1] + k*lll[j] + l;

/*      if (*(E + shift)!=0) */
/*        {printf("\n overwrite in put : [%i.%i.%i.%i] (e=%i)\n", */
/*  	      i, j, k, l, *(E + shift)); fflush(stdout); exit(1);} */

    *(E + shift) = energy;}

  else {printf("\n put out of range in matrix : [%i.%i.%i.%i]\n",
	       i, j, k, l); fflush(stdout); exit(1);}

}

void fill_matrix (int seq_i, int seq_j, int verb) {

  int i, j, k, l, energy;
  unsigned long advance, new_adv, old_adv;
  cpl_t kb, lb;
  unsigned long clock_b, clock_e; // clock, begin and end
  int save_i, save_j, save_k, save_l, save=0;

  // allocation
   E = new_vector (size); E[0] = 0;

  //  min_bound  in         [0 .. Kn-1] U {Z}  (Z for single stem)
  //  max_bound  in  {-1} U [0 .. Kn-1]       (-1 for single stem)

  // init advance 
  advance = 0; new_adv = 0; old_adv = -1;
  
  // init clock
  clock_b = (unsigned long) clock () / 1000000;

  for (j=1; j<=Kn0; j++) {
    lb = L0[j]->l_bounds;

    for (i=Kn0; i>0; i--) {
      kb = K0[i]->k_bounds;
      if ((!K0[i]->lonely) && (!L0[j]->lonely)) advance+=kkk[i];
      for (l=lb.min; l<=lb.max; l++) {
	if ((!K0[i]->lonely) && (!L0[j]->lonely) && (!L1[l]->lonely)) advance++;
	
	for (k=kb.max; k>=kb.min; k--) {
	  if ((!K0[i]->lonely) && (!L0[j]->lonely) &&
	      (!K1[k]->lonely) && (!L1[l]->lonely)) advance++;

	  // check clock

	  // SPECIAL EXIT : FOLDING IS TOO LONG
	  clock_e = (unsigned long) clock () / 1000000;
	  if (clock_e - clock_b > TIME_BREAK_SEC) {
	    if (VERBOSE) printf("  --- exit (too long)"); fflush(stdout);
	    if (DEBUG) {
	      FILE *out; out=fopen("check_fold.out", "w");
	      fprintf(out,"\n\n --- too long"); fclose (out);}
	    brk_lp++; goto end_loop;}
	  // SPECIAL EXIT

	  // drop stem  0
	  energy = get(i, j-1, k, l);

	  // drop stem  1
	  energy = MIN (energy, get(i, j, k, l-1));

  	  // fold together : 0 <--> 1
	  if ((!K0[i]->lonely) && (!L0[j]->lonely) &&
	      (!K1[k]->lonely) && (!L1[l]->lonely) &&
	      (K0[i]->s[1] <= L0[j]->s[1]) &&
	      (K1[k]->s[1] <= L1[l]->s[1])) {
	    energy = MIN (energy, f(L0[j], L1[l]) +
			  get (i, L0[j] -> last_out, k, L1[l] -> last_out) +
			  get (L0[j] -> next_in, L0[j] -> last_in,
			       L1[l] -> next_in, L1[l] -> last_in));}

	  if (energy < save)
	    {save = energy; save_i = i; save_j = j; save_k = k; save_l = l;}

	  if (is_allocated (i, j, k, l)) put (i, j, k, l, energy);
	}
      }
    }
  }
  
  // SPECIAL EXIT
  end_loop :;
  // SPECIAL EXIT

}

void trace_back (node_t *tree, int i, int j, int k, int l) {

  int stop;
  node_t *new;
  int i_min=0, i_max=0, j_min=0, j_max=0;
  int k_min=0, k_max=0, l_min=0, l_max=0;
  int ik, jl, ki, lj, xi, xj, xk, xl, energy;
  int next_i, next_j, next_k, next_l;

  stop = !get (i, j, k, l);

  // single stem  0 (right)

  if ((!stop) && (right_lonely_can_fold0 (i,j)) &&
      (get (i, j, k, l) == f(L0[j], NULL) + get (i, L0[j]->last_out, k, l)))
    {stop = 1;
    new = new_node (L0[j]->s[0], -1);
    L0[j] -> folded++;
    add_left_child (tree, new);

    trace_back (tree, i, L0[j]->last_out, k, l);}

  // single stem  1 (right)

  if ((!stop) && (right_lonely_can_fold1 (k,l)) &&
      (get (i, j, k, l) == f(NULL, L1[l]) + get (i, j, k, L1[l]->last_out)))
    {stop = 1;
    new = new_node (-1, L1[l]->s[0]);
    L1[l] -> folded++;
    add_left_child (tree, new);

    trace_back (tree, i, j, k, L1[l]->last_out);}

  // mary  0 <--> 1

  if ((!stop) &&
      (i<=Kn0) && (j>=0) && (K0[i]->s[1] <= L0[j]->s[1]) &&
      (k<=Kn1) && (l>=0) && (K1[k]->s[1] <= L1[l]->s[1]) &&
      (get (i, j, k, l) == f(L0[j], L1[l]) +
       get (i, L0[j]->last_out, k, L1[l]->last_out) +
       get (L0[j]->next_in, L0[j]->last_in, L1[l]->next_in, L1[l]->last_in)))
    {stop = 1;
    new = new_node (L0[j]->s[0], L1[l]->s[0]);
    L0[j] -> forced = L1[l];
    L1[l] -> forced = L0[j];
    L0[j] -> folded++;
    L1[l] -> folded++;
    add_left_child (tree, new);
    trace_back (tree, i, L0[j]->last_out, k, L1[l]->last_out);
    trace_back (new, L0[j]->next_in, L0[j]->last_in,
		L1[l]->next_in, L1[l]->last_in);}

  // drop  0

  if ((!stop) && (j>=0) && (get (i, j, k, l) == get (i, j-1, k, l)))
    {stop = 1;
    trace_back (tree, i, j-1, k, l);}



  if ((!stop) && (l>=0) && (get (i, j, k, l) == get (i, j, k, l-1))){
    stop = 1;
    trace_back (tree, i, j, k, l-1);
}

  // single stem  0 (left)

  if ((!stop) && (left_lonely_can_fold0 (i,j)) &&
      (get (i, j, k, l) == f(K0[i], NULL) + get (K0[i] -> next_out, j, k, l)))
    {stop = 1;
    new = new_node (K0[i]->s[0], -1);
    K0[i] -> folded++;
    add_left_child (tree, new);
    trace_back (tree, K0[i] -> next_out, j, k, l);
    }

  // single stem  1 (left)

  if ((!stop) && (left_lonely_can_fold1 (k,l)) &&
      (get (i, j, k, l) == f(NULL, K1[k]) + get (i, j, K1[k] -> next_out, l)))
    {stop = 1;
    new = new_node (-1, K1[k]->s[0]);
    K1[k] -> folded++;
    add_left_child (tree, new);
/*        printf (" single stem 1 (*, %2i) [%i.%i.%i.%i] -> ",  K1[k]->s[0]+1, i, j, k, l); */
/*        printf (" [%i.%i.%i.%i]\n", i, j, K1[k] -> next_out, l); fflush(stdout); */
    trace_back (tree, i, j, K1[k] -> next_out, l);}

  // not allocated case (speed up)

  if (!stop) {
    i_min = K1[k]->k_bounds.min; i_max = K1[k]->k_bounds.max;
    j_min = L1[l]->l_bounds.min; j_max = L1[l]->l_bounds.max;
    k_min = K0[i]->k_bounds.min; k_max = K0[i]->k_bounds.max;
    l_min = L0[j]->l_bounds.min; l_max = L0[j]->l_bounds.max;}

  if ((!stop) && (i<=Kn0) && (get (i, j, k, l) == get (i+1, j, k, l)))
    {stop = 1; trace_back (tree, i+1, j, k, l);}

  if ((!stop) && (j>0) && (get (i, j, k, l) == get (i, j-1, k, l)))
    {stop = 1; trace_back (tree, i, j-1, k, l);}

  if ((!stop) && (k<=Kn1) && (get (i, j, k, l) == get (i, j, k+1, l)))
    {stop = 1; trace_back (tree, i, j, k+1, l);}

  // modif helene ??? sur l>=0
  if ((!stop) && (l>0) && (get (i, j, k, l) == get (i, j, k, l-1)))
    {stop = 1; trace_back (tree, i, j, k, l-1);}

  // not allocated case (default)

  if (!stop) {

    ik = MAX (i, i_min); if (ik== Z) ik = i+1;
    jl = MIN (j, j_max); if (jl==0) jl = j-1;
    ki = MAX (k, k_min); if (ki== Z) ki = k+1;
    lj = MIN (l, l_max); if (lj==0) lj = l-1;

    while ((ik <= Kn0-1) && (!correlated [K0[ik]->s[0]][K1[k]->s[0]])) ik++;
    while ((jl >= 2)     && (!correlated [L0[jl]->s[0]][L1[l]->s[0]])) jl--;
    while ((ki <= Kn1-1) && (!correlated [K0[i]->s[0]][K1[ki]->s[0]])) ki++;
    while ((lj >= 2)     && (!correlated [L0[j]->s[0]][L1[lj]->s[0]])) lj--;

    energy = get (i, j, k, l);
    next_i =  Z; next_j = 0;
    next_k =  Z; next_l = 0;

    for (xi=i; (!stop) && (xi<=ik); xi++)
      for (xj=j; (!stop) && (xj>=jl); xj--)
	for (xk=k; (!stop) && (xk<=ki); xk++)
	  for (xl=l; (!stop) && (xl>=lj); xl--)
	    if (((is_allocated (xi, xj, xk, xl)) ||
		 (lonely_can_fold (xi, xj, xk, xl))) &&
		(energy == get (xi, xj, xk, xl)))
	      {stop = 1; next_i = xi; next_j = xj; next_k = xk; next_l = xl;}

    trace_back (tree, next_i, next_j, next_k, next_l);}

}

//repris par helene

void create_stem_str (int x, int seq_i, int seq_j, stem_list_t *S) {
  int i, j, nK; stem_list_t K;
  extern stem_list_t all0, all1;
  extern int nb_seq;
  if (x) K=all1; else K=all0;
  nK = stem_list_length(K);
  // utile ? helene  (*S) = new_stem_list (nK);
  j=0;
  for (i=1; i<=nK; i++)
    if (K[i]->folded) j++; 
  (*S) = new_stem_list (j);
  j=1; 
  for (i=1; i<=nK; i++)
    if (K[i]->folded) {
      K[i]->folded = 0;
      (*S)[j] = K[i];
      if ((*S)[j]->married == NULL) 
	(*S)[j] -> married = new_stem_sequence (nb_seq);
      (*S)[j] -> married [seq_j] = K[i] -> forced;
      K[i] -> forced = NULL; 
      j++;
    }
 }

