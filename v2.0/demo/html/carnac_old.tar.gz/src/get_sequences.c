/*----------------------------------------------*/
/* get_sequences.c                              */
/*----------------------------------------------*/

#include "get_sequences.h"

vector_t true_bp;
int ave_true_bp;
vector_t correct_stems_in;
int ave_correct_stems_in;
stem_list_t *true_stems;


sequence_list_t get_sequences (string_t infile_seq) {

  extern sequence_list_t seq;
  extern int nb_seq;
  extern stem_list_t *R, *finalR, *remain;
  extern char* infile_date;  
  sequence_list_t all_seq;
  int i, j, k, n, skip, au,  cg; 
  char c;
  FILE *f;
 
  
  f=fopen(infile_seq,"r");
  
  printf (" Sequences \n");

  // read sequences
   nb_seq = 0; 
  while ((c=fgetc(f))!=EOF){
    if (c=='>') nb_seq++; 
  }
 
  all_seq = (sequence_list_t) sec_malloc (nb_seq * sizeof(sequence_t));
  seq = (sequence_list_t) sec_malloc( 2 * sizeof(sequence_t));
  f=fopen(infile_seq,"r");
  while((c != '>')  && (c != EOF)) c=fgetc(f);
  c=fgetc(f); for (j=0; j<nb_seq; j++) {
    // remarque helene : longueur sequence exacte ?
    all_seq[j].nucl = (string_t) calloc(SIZE_MAX_NUCL,sizeof(char));
    all_seq[j].name = (string_t) calloc(SIZE_MAX_NAME,sizeof(char));
    all_seq[j].cofold = new_vector (nb_seq);
    for (k=0; k<nb_seq; k++) all_seq[j].cofold[k] = 1;
    all_seq[j].N = -1;
    // sequence name + skip comments
    skip = 1; while ((skip) && (c != EOF)){
      while ( (c != '>') && (c != EOF)) c=fgetc(f);
      fgets((all_seq[j].name),SIZE_MAX_NAME,f);
       if (c == '>') skip=0;}
    // erase blancs at the ends
    n = strlen(all_seq[j].name); all_seq[j].name[n-1]='\0';
    for (k=0; k<n; k++) {
      c = all_seq[j].name[k];
      if ((c=='\\') || (c=='/') || (c==' ')) all_seq[j].name[k] = '_';
    }
    k=2; while (all_seq[j].name[n-k]=='_') {all_seq[j].name[n-k]='\0'; k++;}
    k=0; while (all_seq[j].name[k]=='_') {all_seq[j].name++; k++;}
    printf("\n  sequence %2i", j+1);
    // sequence: nucl = nucl[0..n-1]
    i=0;  au=0; cg=0;
    while (((c = fgetc(f)) != '>')  && (c != EOF)){
      if ((c=='a')||(c=='A')) {(all_seq[j].nucl)[i++]='a'; au++;}
      else if ((c=='u')||(c=='U')) {(all_seq[j].nucl)[i++]='u'; au++;}
      else if ((c=='c')||(c=='C')) {(all_seq[j].nucl)[i++]='c'; cg++;}
      else if ((c=='g')||(c=='G')) {(all_seq[j].nucl)[i++]='g'; cg++;}
      else if ((c=='t')||(c=='T')) {(all_seq[j].nucl)[i++]='u'; au++;}
    }
    (all_seq[j].nucl)[i]='\0';
    // a, u, c, g
    all_seq[j].length = au+cg;
    if ( all_seq[j].length>0){
	all_seq[j].cg = cg * 100 / all_seq[j].length;
	printf (" (length  %3i, ", all_seq[j].length);
	printf (" gc %i): %s", all_seq[j].cg, all_seq[j].name);
    }
    else
      printf(" - empty sequence :  %s",all_seq[j].name);
  }
  fclose(f);
  
  // no sequence
  if (nb_seq==0){
    printf("  No sequence was read by CARNAC\n\n"); 
    exit(0);
  }

  // allocate memory: R, finalR & remain
  R = (stem_list_t*) sec_malloc (nb_seq * sizeof(stem_list_t));
  for (i=0; i<nb_seq; i++) R[i] = new_stem_list (0);
  finalR = (stem_list_t*) sec_malloc (nb_seq * sizeof(stem_list_t));
  for (i=0; i<nb_seq; i++) finalR[i] = new_stem_list (0);
  remain = (stem_list_t*) sec_malloc (nb_seq * sizeof(stem_list_t));
  for (i=0; i<nb_seq; i++) remain[i] = new_stem_list (0);

  return all_seq;
  }



int simil (sequence_list_t all_seq, int ii, int jj) {
  matrix2_t m; int i, j, n0, n1, ans; char a, b;
  n0 = all_seq[ii].length;
  n1 = all_seq[jj].length;
  m = alloc_matrix2 (n0, n1, 0);
  // match = +1
  // subst = -1
  // indel = -2 
  for (i=0; i<n0; i++) {
    for (j=0; j<n1; j++) {
      a = all_seq[ii].nucl[i];
      b = all_seq[jj].nucl[j];
      m[i][j] = m[i-1][j-1] + ((a)==(b) ? (1):(-1));
      m[i][j] = MAX (m[i][j], m[i-1][j] - 2);
      m[i][j] = MAX (m[i][j], m[i][j-1] - 2);}}
  // global
  ans = m[n0-1][n1-1];
  // neglecting ends
  for (i=0; i<n0; i++) ans = MAX (ans, m[i][n1-1]);
  for (j=0; j<n1; j++) ans = MAX (ans, m[n0-1][j]);
  ans = 100 * ans / MIN (n0, n1);
  free_matrix2 (m, n0); 
  return ans;
}



sequence_list_t reduce_set (sequence_list_t all_seq) {

  int similarity; // similarit� des deux s�quences consid�r�es
  extern int nb_seq;
  int i, j;
  sequence_list_t new_all_seq;
  int discarded=0; // booleen : oui si une sequence est ecartee
  int discd[nb_seq]; 
  memset(discd, 0, nb_seq*sizeof(int));
  
  printf("\n\n Eliminating similar sequences (> %i%c) : ", SIMIL_THD, '%');
  for (i=0; i<nb_seq; i++) {
    for (j=i+1; j<nb_seq; j++) {
      if  ((!discd[i]) && (!discd[j])){
	similarity  = simil(all_seq, i,j);
	if (similarity  >= SIMIL_THD) {
	  // discard the longest one
	  if (all_seq[i].length > all_seq[j].length) {
	    printf("seq %2i ", i+1);
	    discd [i] = 1;}
	  else {
	    printf("seq %2i ", j+1);
	    discd [j] = 1;}
	  discarded++;
	}
      }
    }
  }
  if (discarded==0) {
    printf ("none \n");
    return all_seq; 
  }
  else{
    printf ("deleted   * * *  WARNING\n");
      // exclude sequences
    nb_seq -= discarded;
    new_all_seq = (sequence_list_t) sec_malloc (nb_seq * sizeof(sequence_t));
    printf("\n New sequence set:\n");
    j=0; 
    for (i=0; i<nb_seq+discarded; i++) 
      if (!discd[i]) {
	printf("\n  sequence %2i: %s", j+1, all_seq[i].name);
	new_all_seq[j] = all_seq[i]; 
	j++;
      }
    free (all_seq);
    return new_all_seq;
  }
}

// fait CARNAC2
void tournament (int i, int j, stem_list_t *IN, stem_list_t *all0, stem_list_t *all1) {
  extern sequence_list_t all_seq, seq;
  int ii, jj, n0, n1;
  printf("  seq %2i / seq %2i: ", i+1, j+1); fflush(stdout);
  seq[0] = all_seq[i]; seq[1] = all_seq[j];
  (*all0) = IN[i]; (*all1) = IN[j];
  n0 = stem_list_length (*all0);
  n1 = stem_list_length (*all1);
  for (ii=0; ii<n0; ii++) (*all0)[ii]->lonely=1;
  for (jj=0; jj<n1; jj++) (*all1)[jj]->lonely=1;
}
