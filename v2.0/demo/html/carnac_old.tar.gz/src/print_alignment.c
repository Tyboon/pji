/*------------------------------------------------------*/
/* print_alignment.c                                    */
/*------------------------------------------------------*/

#include "print_alignment.h"

void print_alignment (sequence_list_t seq, block_list_t block,
		      int i_seq, int j_seq) {

  int i, j, n, length;
  string_t nucl0, nucl1, corresp;
  char tmp;
  FILE *out;

 

  // construction de l'alignement
  n = block_list_length (block);

  nucl0 = new_string("");
  nucl1 = new_string("");
  corresp = new_string("");

  if (n>0) {

    // avant premier bloc    
    nucl0 = cut (seq[0].nucl, 0, block[1]->begin[0]-1, 0);
    nucl1 = cut (seq[1].nucl, 0, block[1]->begin[1]-1, 0);
    nucl0 = fill (nucl0, ' ', POS((int)strlen(nucl1)-(int)strlen(nucl0)));
    nucl1 = fill (nucl1, ' ', POS((int)strlen(nucl0)-(int)strlen(nucl1)));
    corresp = fill (corresp, ' ', (int)strlen(nucl0)+1);

    // 0 <= i <= n-2
    for (i=1; i<n; i++) {
      // bloc 'i'
      nucl0 = cat(nucl0, cut (seq[0].nucl, block[i]->begin[0],
			      block[i]->begin[0] + block[i]->length-1, 0));
      nucl1 = cat(nucl1, cut (seq[1].nucl, block[i]->begin[1],
			      block[i]->begin[1] + block[i]->length-1, 0));
      for(j=0; j<block[i]->length; j++)
	{if (seq[0].nucl[block[i]->begin[0]+j]==
	     seq[1].nucl[block[i]->begin[1]+j])
	  corresp = fill (corresp, '|', 1);
	else corresp = fill (corresp, '*', 1);}
      corresp = fill (corresp, ' ', 1);
      // entre bloc 'i' et bloc 'i+1'
      nucl0 = cat(nucl0, cut (seq[0].nucl, block[i]->begin[0] + block[i]->length,
			      block[i+1]->begin[0]-1, 0));
      nucl1 = cat(nucl1, cut (seq[1].nucl, block[i]->begin[1] + block[i]->length,
			      block[i+1]->begin[1]-1, 0));
      nucl0 = fill (nucl0, ' ', POS((int)strlen(nucl1)-(int)strlen(nucl0)));
      nucl1 = fill (nucl1, ' ', POS((int)strlen(nucl0)-(int)strlen(nucl1)));
      corresp = fill (corresp, ' ', POS((int)strlen(nucl0)-(int)strlen(corresp))+1);
    }

    // dernier bloc, n  
    nucl0 = cat(nucl0, cut (seq[0].nucl, block[n]->begin[0],
			    block[n]->begin[0] + block[n]->length-1, 0));
    nucl1 = cat(nucl1, cut (seq[1].nucl, block[n]->begin[1],
			    block[n]->begin[1] + block[n]->length-1, 0));
    for(j=0; j<block[n]->length; j++)
      {if (seq[0].nucl[block[n]->begin[0]+j]==
	   seq[1].nucl[block[n]->begin[1]+j])
	corresp = fill (corresp, '|', 1);
      else corresp = fill (corresp, '*', 1);}
    corresp = fill (corresp, ' ', 1);

    // apr�s bloc n
    nucl0 = cat(nucl0, cut (seq[0].nucl, block[n]->begin[0] + block[n]->length,
			    (int)strlen(seq[0].nucl)-1, 0));
    nucl1 = cat(nucl1, cut (seq[1].nucl, block[n]->begin[1] + block[n]->length,
			    (int)strlen(seq[1].nucl)-1, 0));
    nucl0 = fill (nucl0, ' ', POS((int)strlen(nucl1)-(int)strlen(nucl0))+1);
    nucl1 = fill (nucl1, ' ', POS((int)strlen(nucl0)-(int)strlen(nucl1)));
    corresp = fill (corresp, ' ', POS((int)strlen(nucl0)-(int)strlen(corresp)));
  }

  // affichage de l'alignement
  out = fopen("alignment.out","a");
  fprintf (out, " - Sequence %2i (%s) / sequence %2i (%s)\n\n", i_seq+1, seq[0].name,  j_seq+1, seq[1].name);

// affichage de b
  // fprintf (out, "\n\n"); 
  //for (i=1; i<=block_list_length (block); i++)
  //fprintf (out, "Bloc %d, %d (%d)  \n", block[i]->begin[0], block[i]->begin[1], block[i]->length); 

  length = (int) strlen (nucl0);
  if ((length != (int) strlen(nucl1)) || (length != (int) strlen(corresp)))
    {printf ("\n ERROR in print_align. : seq. diff. lengths\n\n"); exit(1);}

  for(i=0; i<length/LARGE; i++) {

    tmp = nucl0[(i+1)*LARGE];
    nucl0[(i+1)*LARGE] = '\0';
    fprintf(out,"  %s\n", nucl0+i*LARGE);
    nucl0[(i+1)*LARGE] = tmp;

    tmp = corresp[(i+1)*LARGE];
    corresp[(i+1)*LARGE] = '\0';
    fprintf(out,"  %s\n", corresp+i*LARGE);
    corresp[(i+1)*LARGE] = tmp;

    tmp = nucl1[(i+1)*LARGE];
    nucl1[(i+1)*LARGE] = '\0';
    fprintf(out,"  %s\n\n", nucl1+i*LARGE);
    nucl1[(i+1)*LARGE] = tmp;
  }
  
  fprintf(out,"  %s\n", nucl0 + i * LARGE);
  fprintf(out,"  %s\n", corresp + i * LARGE);
  fprintf(out,"  %s\n\n", nucl1 + i * LARGE);

  fclose(out);
}
