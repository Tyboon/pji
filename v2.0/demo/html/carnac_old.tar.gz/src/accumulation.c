

/*------------------------------------------------------*/
/* accumulation.c                                       */
/*------------------------------------------------------*/

#include "accumulation.h"

/*------------------------------------------------------*/
void conglom_x (sequence_list_t all_seq, int x);
void final_structure_x (sequence_list_t all_seq, int x,
			int magnify, int TH1, int TH2);
void cumul_freq (stem_list_t * H, int seq);
/*------------------------------------------------------*/

// remarque helene : a revoir car couteux en realloc
void cat_stems (stem_list_t S, int x){
  extern stem_list_t *R; 
  int i; 
  int n=stem_list_length (S);
  int m=stem_list_length (R[x]);
  stem_list_t P =new_stem_list(n+m); 
  for (i=1; i<=m; i++) P[i]=R[x][i]; 
  for (i=1; i<=n; i++) P[i+m]=S[i];
  R[x]=P; 
  // liberation ?
}


void conglomerate_stems (sequence_list_t all_seq){
 int i; 
 extern int nb_seq;
 for(i=0; i<nb_seq; i++) conglom_x (all_seq, i);
}

void conglom_x (sequence_list_t all_seq, int x) {
  extern stem_list_t *R; int n;
   
  // sort stems & cumulate frequencies
  n = stem_list_length (R[x]);
  sort_stems_by_begin (R[x]);
  cumul_freq (&R[x], x);
  sort_stems_by_freq (R[x]);
}

// repris par helene 

void  cumul_freq (stem_list_t *H, int seq) {
  int i, j, g; 
  stem_list_t L;
  int n = stem_list_length (* H);
  stem_list_t K=*H;
  j=1;g=1;
  if (n>0){//test de vide
  K[1]->seq=seq;
  for (i=2; i<=n; i++) { 
    if (same_stem (K[g], K[i])) {
      (K[g]->freq)++;
      // free (K[i]); //il faut revoir ca helene 
      K[i]=NULL;
    }
    else {
      g=i; j++;
      K[i]->seq=seq;
    }
  }
  L = new_stem_list (j);
  j=0;  
  for (i=1; i<=n; i++)
    if (K[i]!=NULL){j++; L[j]=K[i]; } ;
  free (K); 
  *H=L;}
}

/*------------------------------------------------------*/

void final_structure (sequence_list_t all_seq, int magnify, int TH1, int TH2)
{int i; extern int nb_seq;
 for(i=0; i<nb_seq; i++) final_structure_x (all_seq, i, magnify, TH1, TH2);}

void final_structure_x (sequence_list_t all_seq, int x,
			int magnify, int TH1, int TH2) {

  extern stem_list_t *R, *finalR;
  // DOWNLOAD 
  extern char *infile_date;
  extern char *infile_seq; 
  stem_list_t  fR; 
  int i, j, n, N;
  char filename[20];
  FILE *out, *ct_out;
  string_t name;
  vector_t basep, equivalence;
  int LIMIT_FREQ = 1;

  // finalR[x] will be the final list of stems for the seq x
  n = stem_list_length (R[x]);
  sort_stems_by_index (R[x]);
  fR = new_stem_list (n);
  fR[0]->energy=0;  
  N=0;

  // stepwise greedy incorporation by decreasing index
  for (i=1; i<=n; i++)
    if (
	(R[x][i]->freq > LIMIT_FREQ) &&
	(R[x][i]->index >= TH1) &&
	(is_almost_compatible (R[x][i], fR))
	){
      N++; fR[N]= R[x][i]; fR[0]->energy=N; 
    } 
  //modif helene pour supprimer add_stem_list 
  // a ameliorer avec une nouvelle fonction adequate

  for (i=1; i<=n; i++)
    if (
	(R[x][i]->freq <= LIMIT_FREQ) &&
	(R[x][i]->index >= TH2) &&
	(is_almost_compatible (R[x][i], fR))
	)
      {N++; fR[N]= R[x][i];fR[0]->energy=N;}
  finalR[x]=new_stem_list(N); 
  for (i=1; i<=N; i++)
    finalR[x][i]=fR[i];
  free (fR); 

  // init file Z_* --> show list R[x]
  filename[0]='Z'; filename[1]='_';
  filename[2]='0'+((x+1)/100);
  filename[3]='0'+(((x+1)%100)/10);
  filename[4]='0'+((x+1)%10);
  filename[5]='.'; j=6;
  for (i=0; (i<10) && ((all_seq[x].name)[i]!='\0'); i++)
    if ((all_seq[x].name)[i]!=' ') {filename[j++]=(all_seq[x].name)[i];}
  filename[j++]='.'; filename[j++]='o'; filename[j++]='u';
  filename[j++]='t'; filename[j++]='\0';
  name =new_string(filename);
  out = fopen(name,"w");

  // headings Z_*
  fprintf(out,"\n\n   name  : %s [%2i]\n", all_seq[x].name, x+1);
  fprintf(out,"   size  : %i nucl.\n", all_seq[x].length);
  fprintf(out,"   stems : %i\n\n", n);

  // contents  Z_*
  fprintf(out,"     flag        position      ");
  fprintf(out,"  freq  index     sub   sequence\n");
  fprintf(out,"____________________________________");
  fprintf(out,"_____________________________________\n");
  fprintf(out,"     |    |                      |    |     | | |   |\n");
  for(i=1; i<=n; i++) {
    fprintf(out," %4i|%s |", i+1, int2string(R[x][i]->flag,1));
    fprintf(out,"%4i:%4i", R[x][i]->s[1]+1, R[x][i]->s[2]+1);
    fprintf(out," / %4i:%4i |", R[x][i]->s[3]+1, R[x][i]->s[4]+1);
    fprintf(out," %2i |", R[x][i]->freq);
    fprintf(out," %3i |", R[x][i]->index);
    // print star '*' if the stem belongs to finalR[x]
    if (belongs(R[x][i], finalR[x])) fprintf(out,"*|");
    else if (is_almost_compatible(R[x][i], finalR[x])) fprintf(out,"c|");
    else fprintf(out," |");
    // print star 'm' if the stem matches a true stem
    if (R[x][i]->true_match>=10) fprintf(out,"m|");
    else if (R[x][i]->true_match>0) fprintf(out,"s|");
    else fprintf(out," |");
    // highlight substems
    if (meet_substem(R[x][i], R[x]))
      fprintf (out, "sub|"); else fprintf (out, "   |");
    for(j=R[x][i]->s[1]; j<=R[x][i]->s[2]; j++)
      fprintf(out,"%c", all_seq[x].nucl[j]); fprintf(out," / ");
    for(j=R[x][i]->s[3]; j<=R[x][i]->s[4]; j++)
      fprintf(out,"%c", all_seq[x].nucl[j]); fprintf(out,"\n");}
  fprintf(out,"_______________________________________");
  fprintf(out,"_______________________________________\n");
  fclose (out);

  // construction of the result file .ct
  n = all_seq[x].length;
  N = stem_list_length (finalR[x]);  
  // A vector 'basep' is pre-computed. 
  // For each position in the sequence, 'basep' contains the position of the pairing base. 
  //finalR[x] should be sorted by
  // decreasing significance so stems are incorporated in basep in that
  // order. If there is an overlap, the prior stem has  priority
  // in the locus of the overlap; the remainder is filled by the new
  // stem, even if it remains only one base pair.
  basep  = new_vector (n);  basep[0] = 0;
  // modif helene : equivalence
  equivalence  = new_vector (n); equivalence[0]=0;
   for (i=1; i<=N; i++)
    for (j=finalR[x][i]->s[1]; j<=finalR[x][i]->s[2]; j++) {
      if (
	  (basep[j] == 0) &&
	  (basep[finalR[x][i]->s[4] + finalR[x][i]->s[1] - j] == 0)
	  ) {
	basep[j] = finalR[x][i]->s[4] + finalR[x][i]->s[1] - j + 1;
	basep[finalR[x][i]->s[4] + finalR[x][i]->s[1] - j] = j + 1;
	equivalence[j]= finalR[x][i]->component; 
	// Equiv printf ("classe  %i\n", finalR[x][i]->component);
	equivalence[finalR[x][i]->s[4] + finalR[x][i]->s[1] - j]= - finalR[x][i]->component;
      }
    }

 if (WEB)
    name = cat(cat(cat(new_string(""), infile_date) , intoa(x+1)), new_string(".ct"));
  else
    name = cat(cat(cat(new_string(""), infile_seq) , intoa(x+1)), new_string(".ct"));

  ct_out = fopen(name,"w");

  //  creation of the ct file
  fprintf (ct_out,"%5i %s \n", n, all_seq[x].name);
  for (i=0; i<n; i++) {
    fprintf (ct_out,"%5i ", i+1);
    fprintf (ct_out,"%c ", toupper(all_seq[x].nucl[i]));
    fprintf (ct_out,"%5i ", i);
    fprintf (ct_out,"%5i ", (i+2)%(n+1));
    fprintf (ct_out,"%5i ", basep[i]);
    fprintf (ct_out,"%5i\n", i+1);}
  fclose (ct_out);

 // Creation of the file containing all equivalent stems (.eq)

  if (WEB)
    name = cat(cat(cat(new_string(""), infile_date) , intoa(x+1)), new_string(".eq"));
  else
    name = cat(cat(cat(new_string(""), infile_seq) , intoa(x+1)), new_string(".eq"));

  ct_out = fopen(name,"w");
  fprintf (ct_out,"%5i %s\n", n, all_seq[x].name);
  for (i=0; i<n; i++) {
    fprintf (ct_out,"%5i ", i+1);
    fprintf (ct_out,"%c ", toupper(all_seq[x].nucl[i]));
    fprintf (ct_out,"%4i \n", equivalence[i]);
  }
  fclose (ct_out);

  // magnify energy
  if (magnify) for (i=1; i<=N; i++) finalR[x][i]->energy *= finalR[x][i]->index;
}
