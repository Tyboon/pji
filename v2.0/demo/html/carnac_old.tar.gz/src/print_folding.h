

/*----------------------------------------------*/
/* print_folding.h                              */
/*----------------------------------------------*/

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "parse.h"
#include "correlate.h"
#include "tree.h"
#include "string.h"
#include "types.h"

void retrieve_folding (stem_list_t K0, stem_list_t K1, node_t *stree);

void print_folding (sequence_list_t seq, int i_seq, int j_seq);

void create_str_str_file (int i, int j, stem_list_t K0, stem_list_t K1,
			  sequence_list_t seq, node_t *stree);

void create_str_out_file (int i, int j, stem_list_t K0, stem_list_t K1,
			  sequence_list_t seq, node_t *stree);

void create_str_ct_file (int i, int j, int x, stem_list_t K,
			 sequence_list_t seq, node_t *stree);

void generate_latex (int argc, char **argv);
