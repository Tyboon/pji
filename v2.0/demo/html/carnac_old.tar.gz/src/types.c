

/*----------------------------------------------*/
/* types.c                                      */
/*----------------------------------------------*/

#include "types.h"

// secure malloc
void* sec_malloc (size_t size)
{void* flag=malloc(size);
 if (flag!=NULL) return flag;
 else {printf("\n\n   *** out of memory ***\n\n"); exit(1);}}

// int
vector_t new_vector (int size){
  vector_t z; 
  z = (vector_t) calloc((size+1),sizeof(int));
  z[0] = -1; return z;
}

void add_to_vector (vector_t *z, int last)
 {int size = vectorlength(*z);
  (*z) = (vector_t) realloc(*z,(size+2)*sizeof(int));
  (*z)[size] = last; (*z)[size+1] = -1;}
int vectorlength (vector_t z)
{int i; for(i=0; (z[i]!=-1); i++); return i;}





// classes
/* modif helene class_t new_class (int open_absc, int close_absc,
		   stem_list_t K, int begin, int end) {
  int i; class_t new;
  new = (class_t) sec_malloc(sizeof(_class_t));
  if (K!=NULL) {
    new -> stem_list = new_stem_list (end-begin+1);
    for (i=begin; i<=end; i++) {
      (new -> stem_list)[i-begin] = (stem_t) sec_malloc(sizeof(_stem_t));
      (new -> stem_list)[i-begin] = K[i];}
    (new -> stem_list)[end-begin+1] = NULL;
    new -> size = stem_list_length (new -> stem_list);}
  else {new -> stem_list = NULL; new -> size = 0;}
  new -> open_absc = open_absc;
  new -> close_absc = close_absc;
  return new;
  }*/

/* modif helene
class_list_t new_class_list (int size_list) {
  class_list_t list;
  list = (class_list_t) sec_malloc((size_list+1)*sizeof(class_t));
  list[0] = new_class (-1, -1, NULL, 0, -1);
  return list;}
*/

int class_list_length (class_list_t x){
  int i; for(i=0; (x[i]->stem_list!=NULL); i++); return i;
}

void print_class_list (class_list_t x) {
  int i,j,l; FILE *out;
  out = fopen("output/classes.out", "a");
  l = class_list_length (x); fprintf (out, "\n");
  for(i=0; i<l; i++) {
    fprintf (out, "[ (%2i) - %3i .. %3i ] [", i+1,
	     x[i] -> open_absc+1, x[i] -> close_absc+1);
    for(j=0; j<x[i]->size; j++)
      fprintf (out, "%i.", (x[i]->stem_list)[j]->s[0]+1);
/*      fprintf (out, "]\n                      ["); */
/*      for(j=0; j<x[i]->size; j++) */
/*        fprintf (out, "%s.", int2string((x[i]->stem_list)[j]->flag)); */
    fprintf (out, "]\n");} fclose (out);}




// matrices
matrix2_t alloc_matrix2 (int a, int b, int fill) {
  matrix2_t mat; int i,j;
  mat = (matrix2_t) sec_malloc((a+1)*sizeof(vector_t));
  mat ++; for (i=-1; i<a; i++)
    {mat[i] = (vector_t) sec_malloc((b+1)*sizeof(int)); mat[i] ++;
    for(j=-1; j<b; j++) {mat[i][j] = fill;}} return mat;}
void free_matrix2 (matrix2_t mat, int a)
{int i; for (i=-1; i<a; i++) {mat[i] --; free(mat[i]);} mat--; free(mat);}
void print_matrix2 (matrix2_t mat, int a, int b, int l, int n) {
  int i, j;
  printf ("\n\n     |");
  for (j=MAX(b-l,0);   j<MIN(b+l,n-1); j++) printf ("%4i|", j);
  printf("\n ");
  for (j=MAX(b-l,0)-1; j<MIN(b+l,n-1); j++) printf ("-----");
  printf("\n");
  for (i=MAX(a-l,0); i<MIN(a+l,n-1); i++) {
    printf ("%4i |", i);
    for (j=MAX(b-l,0); j<MIN(b+l,n-1); j++) {
      if (ABS(i-j)<=1) printf ("  - |");
      else if (!mat[i][j]) printf ("    |");
      else printf ("%4i|",-mat[i][j]);}
    printf("\n");}
  printf(" ");
  for (j=MAX(b-l,0)-1; j<MIN(b+l,n-1); j++) printf ("-----");
  printf("\n\n");}

// misc.
int canoniq (char a, char b)
{return CG(a,b) || AU(a,b) || GU(a,b) || CG(b,a) || AU(b,a) || GU(b,a);}
int covariation (char a0, char a1, char b0, char b1)
{return ((a0 != a1) && (b0 != b1) && canoniq (a0, b0) && canoniq (a1, b1));}
string_t int2string (int n, int up)
{int i; char *res; char tab[33] =
		   {'A','B','C','D','E','F','G','H','J','K','L','M',
		    'N','P','Q','R','S','T','U','V','W','X','Y','Z',
		    '1','2','3','4','5','6','7','8','9'};
 res = sec_malloc (4*sizeof(char));
 res[3] = '\0';
 res[2] = tab[n % 33]; n /=33;
 res[1] = tab[n % 33]; n /=33;
 res[0] = tab[n % 33];
 if (!up) for (i=0; i<3; i++) res[i] = (char)tolower((int)res[i]);
 // if (res[0] == 'A') res[0] = ' ';
 return res;}
float power (float x, int n)
{float p=1; while(n--) p *= x; return p;}


int break_loop (int i, int j, string_t msg) {
  extern int brk_lp;
  extern sequence_list_t all_seq;
  if (brk_lp) {
    brk_lp=0;
    if (!strcmp(msg,"no block"))
      {all_seq[i].cofold[j] = 0; all_seq[j].cofold[i] = 0;}
    // if(VERBOSE) printf("            broken: %s\n", msg);
    if(VERBOSE) printf("\n");
    return 1;
  }
  else {
    return 0;
  }
}


// remarque helene : inutile avec get_sequences.cold
int is (char x, string_t alphabet) {
  int i,j; char a;
  i=0; j=0; while ((a=alphabet[i]) != '\0')
    {if (x == alphabet[i]) j=1; i++;}
  return j;}
