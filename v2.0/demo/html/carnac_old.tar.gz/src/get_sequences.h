

/*----------------------------------------------*/
/* get_sequences.h                              */
/*----------------------------------------------*/

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "types.h"
#include "parse.h"
#include "string.h"
#include "stem.h"

#ifndef SIZE_MAX_NUCL
#define	SIZE_MAX_NUCL 10000
#define	NB_MAX_TRUE_STEMS 1000
#define	SIZE_MAX_NAME 128
#endif

sequence_list_t get_sequences (string_t infile_seq);
sequence_list_t reduce_set (sequence_list_t all_seq);
void tournament (int i, int j, stem_list_t *IN, stem_list_t *all0, stem_list_t *all1);
void get_true_structure ();
void final_compare ();
