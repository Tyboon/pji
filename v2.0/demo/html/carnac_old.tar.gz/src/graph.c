
/*----------------------------------------------*/
/* graph.c                                      */
/*----------------------------------------------*/

#include "graph.h"

extern int nb_seq;

// g_node
g_node_list_t new_g_node_list (int size) {
  g_node_list_t new; int i;
  new = (g_node_list_t) calloc (size, sizeof(g_node_t));
  for (i=0; i<size; i++)
    new[i] = new_g_node (-1, i);
  return new;
}

g_node_t new_g_node (int seq, int rank) {
  g_node_t new; int i;
  new = (g_node_t) sec_malloc(sizeof(_g_node_t));
  new -> seq = seq;
  new -> rank = rank;
  new -> visited = 0;
  new -> arity_out = 0;
  new -> arity_id = 0;
  new -> eject = 0;
  new -> in_stem_list = new_stem_list (0);
  new -> out_g_node_list = (g_node_list_t)
    sec_malloc (RATIO_NB_MAX_LINKS_BY_G_NODE*nb_seq * sizeof(g_node_t));
  for (i=0; i<RATIO_NB_MAX_LINKS_BY_G_NODE*nb_seq; i++)
    new -> out_g_node_list[i] = NULL;
  new -> id_g_node_list = (g_node_list_t)
    sec_malloc (RATIO_NB_MAX_LINKS_BY_G_NODE*nb_seq * sizeof(g_node_t));
  for (i=0; i<RATIO_NB_MAX_LINKS_BY_G_NODE*nb_seq; i++)
    new -> id_g_node_list[i] = NULL;
  return new;
}

int g_node_list_length (g_node_list_t gc){
  int i; for (i=0; (gc[i]!=NULL); i++); return i;
}


void add_to_out_g_node_list (g_node_t G, g_node_t out){
  int n=G->arity_out;
  if (n >= RATIO_NB_MAX_LINKS_BY_G_NODE*nb_seq-1)
    {fprintf(stderr, "out of range in add_to_out_g_node_list\n"); exit(0);}
  G->out_g_node_list[n] = out;
  G->arity_out++; 
  G->out_g_node_list[n+1] = NULL;
}

void add_to_id_g_node_list (g_node_t G, g_node_t id)
{int n=G->arity_id;
 if (n >= RATIO_NB_MAX_LINKS_BY_G_NODE*nb_seq-1)
   {fprintf(stderr, "out of range in add_to_id_g_node_list\n"); exit(0);}
 G->id_g_node_list[n] = id;
 G->arity_id++; G->id_g_node_list[n+1] = NULL;}

void free_g_node_list (g_node_list_t G, int size) {
  int i;
  for (i=0; i<size; i++) {
    free (G[i]->in_stem_list);
    free (G[i]->out_g_node_list);
    free (G[i]->id_g_node_list);
    free (G[i]);
  }
  free (G);}

// compounds
//compound_list_t new_compound_list (int size) {
//  extern int nb_seq;
//  compound_list_t new; int i;
//  new = (compound_list_t) sec_malloc (size * sizeof(compound_t));
//  for (i=0; i<size; i++)
//    new[i] = new_compound (nb_seq * RATIO_NB_NODES_BY_COMPOUND);
//  return new;}

compound_t new_compound (int size) {
  compound_t new;
  new = (compound_t) sec_malloc(sizeof(_compound_t));
  new -> list = new_g_node_list (size);
  new -> size = 0;
  new -> corrected_size = 0;
  new -> sq = -1;
  new -> co = 0;
  new -> id = 0;
  new -> me = 0;
  new -> index = 0;
  return new;}

//modif helene Equiv
int add_g_node_to_compound (compound_t C, g_node_t G, int nb_compound) {
  stem_list_t  liste=G->in_stem_list; 
  int s=C->size;
  extern int nb_seq;
  int i; 
  for (i=1; i<=stem_list_length(liste); i++){
	 liste[i]->component=nb_compound; 
  }
  if (s >= RATIO_NB_NODES_BY_COMPOUND*nb_seq-1)
    {C->list[0]=NULL; C->size=0; return 1;}

  C->list[s]=G;
  C->list[s+1]=NULL;
  C->size++;
  return 0;
}

//void free_compound_list (compound_list_t CL, int size)
//{int i; g_node_list_t list;
// for (i=0; i<size; i++) {list =  CL[i]->list;
// /*     sl = g_node_list_length (list); */
// /*     if (list) free_g_node_list (list, sl); */
// if (list) free (list); free (CL[i]);} free (CL);}

int compare_seq (const void* alpha1, const void* alpha2) {
  g_node_list_t G1, G2;
  G1 = (g_node_list_t) alpha1;
  G2 = (g_node_list_t) alpha2;
  if ((*G1) -> seq > (*G2) -> seq)
    return 1; else return -1;}

void sort_list_compound (compound_t C)
{int n=C->size; qsort(C->list, n, sizeof(g_node_t), compare_seq);}

void sort_out_g_node_list (g_node_t G)
{int n=G->arity_out; qsort(G->out_g_node_list, n, sizeof(g_node_t), compare_seq);}

void sort_id_g_node_list (g_node_t G)
{int n=G->arity_id; qsort(G->id_g_node_list, n, sizeof(g_node_t), compare_seq);}

int belongs2g_node_list (g_node_t G, g_node_list_t Glist)
{int i, n=g_node_list_length(Glist);
 for (i=0; (i<n) && (G!=Glist[i]); i++); return (i!=n);}


void print_class_content (g_node_list_t g_node, int i) {
  int j, n; FILE *out;
  if (g_node[i]->in_stem_list != NULL) {
    out = fopen("class_content.out","a");
    n = stem_list_length (g_node[i]->in_stem_list);
    fprintf (out, "\n[%s]", int2string (i,0));
    for (j=1; j<=n; j++)
      fprintf (out, " [%2i:%s]", g_node[i]->in_stem_list[j]->seq+1,
	       int2string (g_node[i]->in_stem_list[j]->flag,1));
    fclose (out);}
}

void print_class_connect (g_node_list_t g_node, int i) {
  int j, n; FILE *out; g_node_t Gi, Gj;
  Gi = g_node[i];
  if (Gi->in_stem_list != NULL) {
    out = fopen("class_connect.out","a");
    // remarque helene : a quoi sert le n ?
    n = stem_list_length (Gi->in_stem_list);
    fprintf (out, "\n[%2i:%s] ->", Gi->seq+1, int2string (i,0));
    for (j=0; j<Gi->arity_out; j++) {
      if ((j!=0) && (j%7==0)) fprintf (out, "\n           ");
      Gj = g_node[i]->out_g_node_list[j];
      fprintf (out, " [%2i:%s]", Gj->seq+1, int2string(Gj->rank,0));}
    fclose (out);}}


void compute_stats (compound_t C) {

  extern sequence_list_t all_seq;
  int i, N, Ns, sq, co, id, me, ind, ratio;
  g_node_t G, GG; stem_t P, PP;
  int lG, lGG, j, k, t, merge, witness=0;

  //  printf ("%s.", int2string (C->list[0]->in_stem_list[0]->flag,1)); fflush(stdout);

  C->sq = all_seq[C->list[0]->in_stem_list[1]->seq].N;
  sq = C->sq;

  N = C->size;
  merge = 0;
  co = 0;
  id = 0;
  Ns = 1;

  for (i=0; i<N; i++) {
    if (C->list[i]->eject==2)
      {printf ("\n error in compute_stats: ");
      printf ("empty compound not detected !\n\n"); exit(0);}
    co += C->list[i]->arity_out;
    id += C->list[i]->arity_id;
    if ((i) && (C->list[i-1]->seq != C->list[i]->seq)) Ns++;
  }

  // merge some nodes if stacked stems
  for (i=0; i<N-1; i++) {
    G = C->list[i];
    lG = stem_list_length (G->in_stem_list);
    witness = 0;
    for (j=1; (j<=lG) && (!witness); j++) {
      P = G->in_stem_list[j];
      GG = C->list[i+1];
      t = 2;
      while ((i+t<N) && (GG->seq == G->seq)) {
	lGG = stem_list_length (GG->in_stem_list);
	for (k=1; (k<=lGG) && (!witness); k++) {
	  PP = GG->in_stem_list[k];
	  if (test_father(P,PP)||test_father(PP,P))
	    {witness = 1; merge++;}}
	GG = C->list[i+t];
	t++;}
    }
  }

  if ((merge) && (DEBUG))
    printf (" --> [%s]: %i node(s) merged on %i\n\n",
	    int2string(C->list[0]->rank,0), merge, N);
  
  N -= merge;
  C -> corrected_size = N;
  co /= 2;
  id /= 2;

  //  me = N * (N-1) / 2;
  me = Ns * (Ns-1) / 2;

  if (N) {

    if (2*Ns-N>0) ratio = (int) (100 * (float) SQR(2*Ns-N) / (float) SQR(sq));
    else ratio = 0;

    //    ratio = 100;

    if (me-id) ind = ratio * co / (me-id); else ind = 0;

    // retrieve single stems when only 2 sequences are folded
    // g�re le cas particulier o� n=2 s�quences
    {extern int nb_seq; if ((nb_seq==2) && (co+id==0)) ind = 100;}

    C->index=ind; C->co=co; C->id=id; C->me=me;}

  else C->index=-1;
}

void print_graph_infos (compound_t C) {

  FILE *out; g_node_t G;
  int i, j, gn, flag, N, T, n, t, tt, me;

  N = C->size;

  T = 0;
  n = 0;
  t = 0;

  for (i=0; i<N; i++) {
    G = C->list[i];
    gn = stem_list_length (G->in_stem_list);
    n += gn;
    flag = 0;
    for (j=1; j<=gn; j++)
      if (G->in_stem_list[j]->true_match>=10)
	{t++; flag=1;}
    if (flag) T++;
  }

  tt = C->co + C->id;
  me = C->me;

  out = fopen("graph.out","a");

  if (N) fprintf (out, "%s |", int2string(C->list[0]->rank,0));
  else fprintf (out, "    |");
  fprintf (out, " %3i/%3i |", T, N);
  fprintf (out, " %3i/%3i |", t, n);
  fprintf (out, "%3i |", C->sq);
  fprintf (out, "%3i |", C->co);
  fprintf (out, "%3i |", C->id);
  fprintf (out, "%3i |", tt);
  fprintf (out, "%4i ||", me);
  fprintf (out, "%3i |", C->index);
  if ((T==N) && (N>=3)) fprintf (out, "**|");
  else if ((T>0) && (N<3)) fprintf (out, " -|");
  else if ((T>0) && (T>=N/2)) fprintf (out, " *|");
  else if (N>3) fprintf (out, " o|");
  else fprintf (out, "  |");

  {
    extern int nb_seq;
    if (
	(N>=nb_seq/2) &&
	(C->index<70) &&
	(T>=N/2)
	)
    fprintf (out, "<-");
  else if (
	   (
	    (N>=nb_seq/2) &&
	    (C->index<50) &&
	    (3*T>=2*N)
	    ) ||
	   (
	    (N>=nb_seq/2) &&
	    (C->index>=40) &&
	    (3*T<2*N)
	    )
	   )
    fprintf (out, "<=");
  }

  fprintf (out, "\n");
  fclose (out);
}


void close_graph_infos (){
  FILE *out = fopen("graph.out","a");
 fprintf (out, "--------------------------------------------");
 fprintf (out, "--------------------------\n"); fclose (out);
}


void print_connex_compound (compound_t C) {
  int j, n; g_node_t G; FILE *out;
  out = fopen("connect.out","a");
  fprintf (out, " size= %i - ", C->size);
  fprintf (out, "index= %3i - ", C->index);
  n = C -> size;
  for (j=0; j<n; j++) {
    G = C -> list[j];
    if ((j) && (!(j%8))) fprintf (out, "\n     ");
    fprintf (out, "[%2i:%s] ", G->seq+1, int2string (G->rank,0));}
  fprintf (out, "\n");
  fclose (out);
}

void generate_dot_file (compound_t C) {
  int j, k, n, nn, n_seq, nn_seq; char c;
  string_t label, llabel; g_node_t G, GG;
  stem_t K; FILE *out;
  n = C -> size;
  if (n) {
    out = fopen(cat(new_string(int2string(C->list[0]->rank,0)),
		    new_string(".dot")),"w");
    fprintf (out, "digraph ");
    fprintf (out, "%s {\n\n", int2string(C->list[0]->rank,0));
    fprintf (out, "overlap=\"scale\"\n");
    fprintf (out, "x [label=\"\", style=\"invis\"];\n");
    fprintf (out, "center=x\n\n");
    for (j=0; j<n; j++) {
      G = C -> list[j];
      n_seq = G->seq+1;
      label = int2string (G->rank,0);
      fprintf (out, "%s ", label);
      fprintf (out, "[label=\"%2i [%s]", n_seq, label);
      nn = stem_list_length (G -> in_stem_list);
      for (k=1; k<=nn; k++) {
	K = G -> in_stem_list [k];
	if (K -> true_match >= 10) c='m';
	else if (K -> true_match > 0) c='s';
	else c='o';
	fprintf (out, " \\n [%s] [%c:f=%i]", int2string (K->flag,1), c, K->freq);}
      fprintf (out, "\"]\n");}
    fprintf (out, "\nedge [style=\"invis\"]\n\n");
    for (j=0; j<n; j++) {
      G = C -> list[j];
      n_seq = G->seq+1;
      label = int2string (G->rank,0);
      fprintf (out, "x -> %s\n", label);}
    fprintf (out, "\nedge [arrowhead=\"none\", style=\"bold\"]\n\n");
    for (j=0; j<n; j++) {
      G = C -> list[j];
      n_seq = G->seq+1;
      label = int2string (G->rank,0);
      nn = G -> arity_out;
      for (k=0; k<nn; k++) {
	GG = G -> out_g_node_list [k];
	nn_seq = GG->seq+1;
	llabel = int2string (GG->rank,0);
	if (n_seq <= nn_seq)
	  fprintf (out, "%s -> %s\n", label, llabel);}
      nn = G -> arity_id;
      for (k=0; k<nn; k++) {
	GG = G -> id_g_node_list [k];
	nn_seq = GG->seq+1;
	llabel = int2string (GG->rank,0);
	if (n_seq <= nn_seq)
	  fprintf (out, "%s -> %s [style=\"dashed\", color=\"red\"]\n", label, llabel);}}
    fprintf (out, "\n}\n");
    fclose (out);}
}


// Warning: disorder g_node list
void delete_g_node (g_node_list_t S, int i, g_node_t G)
{int size=g_node_list_length(S); S[i]=S[size-1]; S[size-1]=NULL;}


// G is assumed to belong to S (else oor error)
int rank (g_node_list_t S, g_node_t G)
{int i, j, size=g_node_list_length(S);
 for (i=0; ((i<size) && (S[i]!=G)); i++);
 if (i==size) {
   fprintf(stderr, "\n ** oor in rank: node G does not belong to node list S **\n\n");
   fprintf(stderr, " out_g_node_list: ");
   for (j=0; j<G->arity_out; j++) fprintf(stderr,"[%s] ",int2string(G->out_g_node_list[j]->rank,0));
   fprintf(stderr, "\n\n id_g_node_list: ");
   for (j=0; j<G->arity_id; j++) fprintf(stderr,"[%s] ",int2string(G->id_g_node_list[j]->rank,0));
   fprintf(stderr, "\n\n      [%2i:%s]\n", G->seq+1, int2string (G->rank,0));
   fprintf(stderr, " G -> seq = %i\n", G->seq+1);
   fprintf(stderr, " G -> rank = %i\n", G->rank);
   fprintf(stderr, " G -> visited = %i\n", G->visited);
   fprintf(stderr, " G -> arity_out = %i\n", G->arity_out);
   fprintf(stderr, " G -> arity_id = %i\n", G->arity_id);
   fprintf(stderr, " G -> eject = %i\n", G->eject); 
   for (j=0; j<size; j++) {
     fprintf(stderr, "\n      [%2i:%s]\n", S[j]->seq+1, int2string (S[j]->rank,0));
     fprintf(stderr, " S[%i] -> seq = %i\n", j, S[j]->seq+1);
     fprintf(stderr, " S[%i] -> rank = %i\n", j, S[j]->rank);
     fprintf(stderr, " S[%i] -> visited = %i\n", j, S[j]->visited);
     fprintf(stderr, " S[%i] -> arity_out = %i\n", j, S[j]->arity_out);
     fprintf(stderr, " S[%i] -> arity_id = %i\n", j, S[j]->arity_id);
     fprintf(stderr, " S[%i] -> eject = %i\n", j, S[j]->eject); 
   }
   exit(0);}
 return i;}
