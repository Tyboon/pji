
/* -------------------------------------------*/
/* tree.h                                     */
/*--------------------------------------------*/

#include <stdlib.h>
#include <stdio.h>

#ifndef TREE
#define TREE
typedef struct _node {
  // label contient le rang de la tige dans la liste
  // label contient -1 sinon
  int label[2];
  int arity;
  struct _node **child;
} node_t;
#endif

node_t *new_node (int a, int b);
int root (node_t *n);
void add_right_child (node_t *father, node_t *new_child);
void add_left_child (node_t *father, node_t *new_child);
node_t *ask_for_son_from_left (node_t *n, int x);
node_t *ask_for_son_from_right (node_t *n, int x);
node_t *ask_for_left_brother (node_t *n, int rank, int x);
node_t *ask_for_right_brother (node_t *n, int rank, int x);
void print_tree (node_t *n);
