/*--------------------------------------------*/
/* find_blocks.h                              */
/*--------------------------------------------*/

#include <ctype.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include "types.h"
#include "parse.h"

#ifndef BLOCK
#define BLOCK
typedef struct {
  int begin[2];
  int length;
} _block_t, * block_t;


// modif helene
//typedef struct {
//  int begin[2];
//  int length;
//} block;

typedef block_t * block_list_t;

block_list_t find_blocks (sequence_list_t seq);

void free_block_list (block_list_t b);
int block_list_length (block_list_t b);
#endif
