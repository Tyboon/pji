
/* -------------------------------------------*/
/* stem.c                               */
/*--------------------------------------------*/

#include "stem.h"


extern sequence_list_t all_seq;


stem_t new_stem (int seq, int rank, int flag, int i, int j, int k, int l, int energy) {
  stem_t new;
  new = (stem_t) sec_malloc(sizeof(_stem_t));
  new -> seq = seq;
  new -> energy = energy;
  new -> flag = flag;
  new -> s[0] = rank;
  new -> s[1] = i;
  new -> s[2] = j;
  new -> s[3] = k;
  new -> s[4] = l;
  new -> shortened = 0;
  new -> substem = 0;
  new -> lonely = 1;
  new -> forced = NULL;
  new -> married = NULL;
  new -> equiv = NULL;
  new -> g_node = -1;
  new -> k_bounds.min = -1;
  new -> k_bounds.max = -1;
  new -> l_bounds.min = -1;
  new -> l_bounds.max = -1;
  new -> folded = 0;
  new -> last_in  = -1;
  new -> last_out = -1;
  new -> next_in  = -1;
  new -> next_out = -1;
  new -> freq = 1;
  new -> connectivity = 0;
  new -> tag = 0;
  new -> true_match = 0;
  new -> index = -1;
  return new;
}

stem_list_t new_stem_list (int size) {
  stem_list_t new_list;
  new_list = (stem_list_t) calloc((size+1), sizeof(stem_t));
  new_list[0] = (stem_t) malloc (sizeof(_stem_t));
  new_list[0]->energy = size; 
  return new_list;
}

//la liste est indexee a partir de 0
// utilise uniquement pour le champ married des tiges, 
//dont la taille est toujours nb_seq
stem_list_t new_stem_sequence(int size) {
  stem_list_t new_list;
  new_list = (stem_list_t) calloc((size), sizeof(stem_t));
  return new_list;

}

void free_stem_list( stem_list_t S){
  int i;
  int nb = S[0]->energy;
  for (i=1; ((S[i]!=NULL) && (i<=nb)); i++) free (S[i]); 
  free (S); 
}

int stem_list_length (stem_list_t K){
    if (K==NULL) 
      return 0; 
    else if (K[0]==NULL)
      return 0; 
    else   
      return K[0]->energy;
}

void print_true_stems (sequence_list_t all_seq, int x, stem_list_t K) {
  extern stem_list_t *finalR;
  int i, k, n; FILE *true;
  n = stem_list_length (K);
  true = fopen("true.out","a");
  fprintf (true, "\n\n %2i - %s\n", x+1, all_seq[x].name);	  
  for(i=1; i<=n; i++) {
    if ((K[i] -> true_match >= 10) && (K[i] -> true_match < 20)) {
      fprintf (true, "[%s] ", int2string(K[i]->flag,1));
      fprintf (true, "%4i:%4i", K[i]->s[1]+1, K[i]->s[2]+1);
      fprintf (true, " / %4i:%4i |", K[i]->s[3]+1, K[i]->s[4]+1);
      // index
      if (K[i]->index != -1) fprintf (true, " %3i |", K[i]->index);
      else fprintf(true,"     |");
      // belongs to final structure ?
      if (belongs(K[i], finalR[x])) fprintf(true,"*|");
      else fprintf(true," |");
      // true match ? (should always be 'm')
      if (K[i]->true_match>=10) fprintf(true,"m|");
      else if (K[i]->true_match>0) fprintf(true,"s|");
      else fprintf(true," |");
      // substem ?
      if (K[i]->substem) fprintf (true, "sub|");
      else fprintf (true, "   |");
      // sequence
      for (k=K[i]->s[1]; k<=K[i]->s[2]; k++)
	fprintf (true, "%c", all_seq[x].nucl[k]);
      fprintf (true, " / ");
      for (k=K[i]->s[3]; k<=K[i]->s[4]; k++)
	fprintf (true, "%c", all_seq[x].nucl[k]);
      fprintf (true, "\n");}}
  fclose(true);
}

void print_forced_stems (sequence_list_t all_seq, int x) {
  extern stem_list_t *forced_stems;
  int i, k, n; FILE *forced;
  stem_list_t K = forced_stems[x];
  n = stem_list_length (K);
  forced = fopen("output/forced.out","a");
  fprintf (forced, "\n\n %2i - %s\n", x+1, all_seq[x].name);	  
  for(i=1; i<=n; i++) {
    fprintf (forced, "[%s] ", int2string(K[i]->flag,1));
    fprintf (forced, "%4i:%4i", K[i]->s[1]+1, K[i]->s[2]+1);
    fprintf (forced, " / %4i:%4i |", K[i]->s[3]+1, K[i]->s[4]+1);
    // sequence
    for (k=K[i]->s[1]; k<=K[i]->s[2]; k++)
      fprintf (forced, "%c", all_seq[x].nucl[k]);
    fprintf (forced, " / ");
    for (k=K[i]->s[3]; k<=K[i]->s[4]; k++)
      fprintf (forced, "%c", all_seq[x].nucl[k]);
    fprintf (forced, "\n");}
  fclose(forced);}

void print_married_stems (stem_list_t S) {
  int i, j, n; extern int nb_seq;
  n = stem_list_length (S);
  for (j=1; j<=n; j++) {
    printf ("\n-->"); print_stem (S[j]);
    for (i=0; i<nb_seq; i++)
      print_stem (S[j]->married[i]);}
}

cpl_stem_list_t new_cpl_stem_list (int size) {
  cpl_stem_list_t new_list; int i;
  new_list = (cpl_stem_list_t) sec_malloc((size+1)*sizeof(stem_list_t));
  for (i=0; i<=size; i++) new_list[i] = (stem_list_t) sec_malloc(2*sizeof(stem_t));
  new_list[0][0] = NULL; new_list[0][1] = NULL; return new_list;}

// ajouter un element a une liste
void add_stem_list (stem_list_t *L, stem_t P) {
  int size =  (*L)[0]->energy; 
  (*L) = (stem_list_t) realloc(*L,(size+2)*sizeof(stem_t));
  (*L)[size+1] = P;
  (*L)[0]->energy=size+1; 
}

int cpl_stem_list_length (cpl_stem_list_t K)
{int i=-1; if (K!=NULL) for(i=0; (K[i][0]!=NULL) || (K[i][1]!=NULL); i++); return i;}
stem_list_t cat_stem_list (stem_list_t K1, stem_list_t K2) {
  int i, n1, n2; stem_list_t K;
  n1 = stem_list_length (K1); n2 = stem_list_length (K2);
  K = new_stem_list (n1 + n2);
  for (i=1; i<=n1; i++) K[i] = K1[i];
  for (i=1; i<=n2; i++) K[n1+i] = K2[i];
  K[n1+n2] = NULL; free(K1); free(K2); return K;}
int belongs (stem_t P, stem_list_t K) {
  int i, n, out; n = stem_list_length (K); out = 0;
  for (i=1; i<=n; i++) if (P == K[i]) out++; return out;}

// quick sort by decreasing frequencies (then decreasing energies)
int compare_freq (const void* alpha1, const void* alpha2){
stem_list_t K1, K2; K1 = (stem_list_t) alpha1; K2 = (stem_list_t) alpha2;
 if (((*K1) -> freq < (*K2) -> freq) ||
     (((*K1) -> freq == (*K2) -> freq) &&
      ((*K1) -> energy > (*K2) -> energy)))
   return 1; else return -1;}

void sort_stems_by_freq (stem_list_t K){
  int i; int nK = stem_list_length(K);
  qsort(K+1, nK, sizeof(stem_t), compare_freq);
  for (i=1; i<=nK; i++) K[i] -> s[0] = i;
}

// quick sort by decreasing index
// (then increasing frequency)
int compare_index (const void* alpha1, const void* alpha2)
{stem_list_t K1, K2; K1 = (stem_list_t) alpha1; K2 = (stem_list_t) alpha2;
 if (
     ((*K1) -> index < (*K2) -> index) ||
     (
      ((*K1) -> index == (*K2) -> index) &&
      ((*K1) -> freq < (*K2) -> freq)
      )
     )
   return 1; else return -1;}

void sort_stems_by_index (stem_list_t K){
int i; 
int nK = stem_list_length(K);
 qsort(K+1, nK, sizeof(stem_t), compare_index);
 for (i=1; i<=nK; i++) K[i] -> s[0] = i;
}


// quick sort by lexicographic order: s[1] < s[2] < s[3]
int compare_begin (const void* alpha1, const void* alpha2){
  stem_list_t K1= (stem_list_t) alpha1;
  stem_list_t K2= (stem_list_t) alpha2;
  if (((*K1)->s[1] > (*K2)->s[1]) ||
      (((*K1)->s[1] == (*K2)->s[1]) && ((*K1)->s[2] > (*K2)->s[2])) ||
      ((((*K1)->s[1] == (*K2)->s[1]) && ((*K1)->s[2] == (*K2)->s[2]))
       && ((*K1)->s[3] > (*K2)->s[3]))) 
    return 1; 
  else 
    return -1;
}

void sort_stems_by_begin (stem_list_t K){
  int i; 
  int nK = stem_list_length(K);
  qsort(K+1, nK, sizeof(stem_t), compare_begin);
  for (i=1; i<=nK; i++) K[i]->s[0] = i;
}

// quick sort by antilexicographic order: s[3] > s[4]
int compare_end (const void* alpha1, const void* alpha2)
{stem_list_t L1, L2; L1 = (stem_list_t) alpha1; L2 = (stem_list_t) alpha2;
 if (((*L1)->s[4] > (*L2)->s[4]) ||
     (((*L1)->s[4] == (*L2)->s[4]) && ((*L1)->s[3] > (*L2)->s[3])))
   return 1; else return -1;}
stem_list_t sort_stems_by_end (stem_list_t K_in){
int i,nK; stem_list_t K_out;
 nK = stem_list_length(K_in); K_out = new_stem_list (nK);
 for(i=0; i<=nK; i++) K_out[i]=K_in[i];
 qsort(K_out+1, nK, sizeof(stem_t), compare_end); return K_out;}

int same_stem (stem_t K1, stem_t K2) {
  return
    (K1->s[4] == K2->s[4]) &&
    (K1->s[3] == K2->s[3]) &&
    (K1->s[2] == K2->s[2]) &&
    (K1->s[1] == K2->s[1]);}

// P1--P2-..-P2--P1
int test_father (stem_t P1, stem_t P2)
{return ((P1->s[2]<P2->s[1]) && (P2->s[4]<P1->s[3]));}

int test_almost_father (stem_t P1, stem_t P2, int overlap){
  return ((P1->s[2]<P2->s[1]+overlap) &&
	 (P2->s[4]<P1->s[3]+overlap));
}

// P1..P1--P2..P2
int test_brother (stem_t P1, stem_t P2)
{return (P1->s[4]<P2->s[1]);}
int test_almost_brother (stem_t P1, stem_t P2, int overlap)
{return (P1->s[4]<P2->s[1]+overlap);}

int is_compatible (stem_t P, stem_list_t K)
{int i, n, out, sure; out = 1; sure = 0; n = stem_list_length (K);
 for (i=1; (i<=n) && (out) && (!sure); i++) { 
   out *= ((test_father (P, K[i])) || (test_brother (P, K[i])) ||
	   (test_father (K[i], P)) || (test_brother (K[i], P)));
   sure = (P == K[i]);}
 return out + sure;}

// almost compatible --> return 1
// belongs to stem list --> return 2
int is_almost_compatible (stem_t P, stem_list_t K){
  int i, n, out, sure; int OVERLAP = 3;
  out = 1; sure = 0; 
  n = stem_list_length (K);
  for (i=1; (i<=n) && (out) && (!sure); i++) { 
    out *= ((test_almost_father (P, K[i], OVERLAP)) ||
	    (test_almost_brother (P, K[i], OVERLAP)) ||
	    (test_almost_father (K[i], P, OVERLAP)) ||
	    (test_almost_brother (K[i], P, OVERLAP)));
    sure = (P == K[i]);}
  return out + 2 * sure;
}

int adjust (stem_t p, stem_t q) {
  extern sequence_list_t seq;
  int seq_n0, seq_n1, k, shift;
  int long0, long1, score, score_min, delta;
  seq_n0 = seq[0].length;
  seq_n1 = seq[1].length;
  long0 = p->s[2] - p->s[1] + 1;
  long1 = q->s[2] - q->s[1] + 1;
  score_min = 1000; delta = 0;
  // delta est le d�calage optimal de (l'ouverture de) la
  // deuxi�me tige par rapport � (l'ouverture de) la premi�re
  if (long1 >= long0) {
    for (shift=0; shift>=long0-long1; shift--) {
      score = 0;
      for (k=0; k<long1; k++) {
	score += (seq[0].nucl[p->s[1]+k] != seq[1].nucl[q->s[1]+k-shift]);
	score += (seq[0].nucl[p->s[4]-k] != seq[1].nucl[q->s[4]-k+shift]);
      }
      if (score < score_min) {score_min = score; delta = shift;}}}
  else {
    for (shift=0; shift<=long0-long1; shift++) {
      score = 0;
      for (k=0; k<long0; k++) {
	score += (seq[0].nucl[p->s[1]+k+shift] != seq[1].nucl[q->s[1]+k]);
	score += (seq[0].nucl[p->s[4]-k-shift] != seq[1].nucl[q->s[4]-k]);
      }
      if (score < score_min) {score_min = score; delta = shift;}}}
  return delta;
}

// identity = true if p (resp. q)
// is a 'factor stem' of q (resp. p)

int identity (stem_t p, stem_t q) {
  extern sequence_list_t all_seq;
  sequence_t seq0, seq1;
  int k, delta, long0, long1, long_min;
  char a0, a1, b0, b1;
  seq0 = all_seq[p->seq];
  seq1 = all_seq[q->seq];
  delta = adjust (p,q);
  long0 = p->s[2] - p->s[1] + 1;
  long1 = q->s[2] - q->s[1] + 1;
  long_min = MIN (long0, long1);
  for (k=0; k<long_min; k++) {
    a0 = seq0.nucl[p->s[1]+k+MAX(delta,0)];
    b0 = seq0.nucl[p->s[4]-k-MAX(delta,0)];
    a1 = seq1.nucl[q->s[1]+k+MAX(-delta,0)];
    b1 = seq1.nucl[q->s[4]-k-MAX(-delta,0)];

    if ((a0 != a1) || (b0 != b1)) return 0;
  } return 1;}


int uncovary (stem_t p, stem_t q) {
  extern sequence_list_t all_seq;
  sequence_t seq0, seq1;
  int k, delta, long0, long1, long_min;
  char a0, a1, b0, b1;
  seq0 = all_seq[p->seq];
  seq1 = all_seq[q->seq];
  delta = adjust (p,q);
  long0 = p->s[2] - p->s[1] + 1;
  long1 = q->s[2] - q->s[1] + 1;
  long_min = MIN (long0, long1);
  for (k=0; k<long_min; k++) {
    a0 = seq0.nucl[p->s[1]+k+MAX(delta,0)];
    b0 = seq0.nucl[p->s[4]-k-MAX(delta,0)];
    a1 = seq1.nucl[q->s[1]+k+MAX(-delta,0)];
    b1 = seq1.nucl[q->s[4]-k-MAX(-delta,0)];
    if (covariation (a0, a1, b0, b1)) return 0;
  }
  return 1;
}

int substem (stem_t K1, stem_t K2) {
  return
    (K1->s[1] >= K2->s[1]) &&
    (K1->s[2] <= K2->s[2]) &&
    (K1->s[3] >= K2->s[3]) &&
    (K1->s[4] <= K2->s[4]) &&
    (K1->s[1]+K1->s[4] == K2->s[1]+K2->s[4]);}

int meet_substem (stem_t P, stem_list_t K) {
  int i; int n=stem_list_length(K);
  for (i=1; i<=n; i++)
    if ((!same_stem(P,K[i])) && (substem(P,K[i]))) return 1;
  return 0;}

int one_common_bp (stem_t P, stem_t Q) {

  int a,b,c,d,aa,bb,cc,dd;

  a = P -> s[1]+1;
  b = P -> s[2]+1;
  c = P -> s[3]+1;
  d = P -> s[4]+1;

  aa = Q -> s[1]+1;
  bb = Q -> s[2]+1;
  cc = Q -> s[3]+1;
  dd = Q -> s[4]+1;

  return ((((a<=aa) && (aa<=b)) ||
	   ((aa<=a) && (a<=bb)))
	  && (a+d == aa+dd));
}

// equiv_shifted = true
// if the opening (resp. the closure)
// of P and Q have at least 1 base in common

int equiv_shifted (stem_t P, stem_t Q)
{return
   (!(Q->s[2] < P->s[1])) && (!(P->s[2] < Q->s[1])) &&
   (!(Q->s[4] < P->s[3])) && (!(P->s[4] < Q->s[3]));}

// equiv_stem = true if P
// . either has at least 1 bp in common with Q
// . either is stacked on Q
//  (1 common base is allowed
//  when stacking is checked)
// P and Q play the same role

int equiv_stem (stem_t P, stem_t Q) {
  int OVERLAP = 2;
  int MAX_DIST = 5;
  return ((one_common_bp (P, Q)) ||
	  ((Q->s[1]-P->s[2] + P->s[3]-Q->s[4] <= MAX_DIST) &&
	   (test_almost_father (P, Q, OVERLAP))) ||
	  ((P->s[1]-Q->s[2] + Q->s[3]-P->s[4] <= MAX_DIST) &&
	   (test_almost_father (Q, P, OVERLAP))));
}


void shorten_stems (stem_list_t K) {
  int i, n;
  int SHORT=2;
  n = stem_list_length (K);
  for(i=1; i<=n; i++)
    if (K[i]->s[2] - K[i]->s[1] > 2*SHORT + 1) {
      K[i]->shortened = SHORT;
      K[i]->s[1] += SHORT;
      K[i]->s[2] -= SHORT;
      K[i]->s[3] += SHORT;
      K[i]->s[4] -= SHORT;
    }
}

void extend_stems (stem_list_t K) {
  int i, n;
  n = stem_list_length (K);
  for(i=1; i<=n; i++)
    if (K[i]->shortened) {
      K[i]->s[1] -= K[i]->shortened;
      K[i]->s[2] += K[i]->shortened;
      K[i]->s[3] -= K[i]->shortened;
      K[i]->s[4] += K[i]->shortened;
      K[i]->shortened = 0;
    }}

void print_stem (stem_t P)
{int j; 
 extern sequence_list_t all_seq; sequence_t seq;
 if (P) {
   printf("."); fflush(stdout);
   seq = all_seq[P->seq];
   printf(" %4i [%s] ", P->seq+1, int2string(P->flag, 1));
   printf ("%4i:%4i", P->s[1]+1, P->s[2]+1);
   printf (" / %4i:%4i |", P->s[3]+1, P->s[4]+1);
   printf (" %5i |", P->energy);
   printf (" %2i |", P->freq);
   printf (" %2i |", P->index);
   //   printf (" %2i |", P->last_out);
   //   printf (" %2i |", P->next_in);
   //   printf (" %2i |", P->last_in);
   if (P->substem) printf ("sub|"); else printf ("   |");
   if (P->true_match>=10) printf("m|");
   else if (P->true_match>0) printf("s|");
   else printf(" |");
   for (j=P->s[1]; j<=P->s[2]; j++)
     printf ("%c", seq.nucl[j]); printf (" / ");
   for (j=P->s[3]; j<=P->s[4]; j++)
     printf ("%c", seq.nucl[j]); printf ("\n");}
 else printf ("          NULL stem\n");
}

void print_stem_list (string_t msg, stem_list_t K, int x) {
  extern sequence_list_t all_seq;
  int i, j, n; FILE *out;
  out = fopen("stems.out","a");
  n = stem_list_length (K);
  fprintf(out, "\n\n %s \n", msg);
  fprintf(out, "\n\n %2i - %s\n", x+1, all_seq[x].name);
  fprintf(out,"------------------------------");
  fprintf(out,"------------------------------\n");
  for(i=1; i<=n; i++) {
    fprintf(out, "%2i", x+1);
    fprintf(out, " [%s]", int2string(K[i]->flag,1));
    fprintf(out," %4i|", K[i]->s[0]);
    fprintf(out,"%4i:%4i", K[i]->s[1]+1, K[i]->s[2]+1);
    fprintf(out," / %4i:%4i |", K[i]->s[3]+1, K[i]->s[4]+1);
    fprintf(out," %5i|", K[i]->energy);
    if (K[i]->true_match>=10) fprintf(out,"m|");
    else if (K[i]->true_match>0) fprintf(out,"s|");
    else fprintf(out," |");
    for(j=K[i]->s[1]; j<=K[i]->s[2]; j++) fprintf(out,"%c", all_seq[x].nucl[j]);
    fprintf(out," / ");
    for(j=K[i]->s[3]; j<=K[i]->s[4]; j++) fprintf(out,"%c", all_seq[x].nucl[j]);
    fprintf(out,"\n");}
  fprintf(out,"------------------------------__");
  fprintf(out,"------------------------------__\n\n");
  fclose(out);
}


void print_reference_stems (sequence_list_t all_seq, int x, stem_list_t K) {
  int i, j, n; FILE *out;
  out = fopen("reference.out","a");
  n = stem_list_length (K);
  fprintf(out, "\n\n %2i - %s\n", x+1, all_seq[x].name);	  
  fprintf(out,"------------------------------__");
  fprintf(out,"------------------------------__\n");
  fprintf(out,"     |                      | |\n");
  for(i=1; i<=n; i++) {
    fprintf(out," %4i|", K[i]->s[0]+1);
    fprintf(out,"%4i:%4i", K[i]->s[1]+1, K[i]->s[2]+1);
    fprintf(out," / %4i:%4i |", K[i]->s[3]+1, K[i]->s[4]+1);
    if (K[i]->true_match>=10) fprintf(out,"m|");
    else if (K[i]->true_match>0) fprintf(out,"s|");
    else fprintf(out," |");
    for(j=K[i]->s[1]; j<=K[i]->s[2]; j++) fprintf(out,"%c", all_seq[x].nucl[j]);
    fprintf(out," / ");
    for(j=K[i]->s[3]; j<=K[i]->s[4]; j++) fprintf(out,"%c", all_seq[x].nucl[j]);
    fprintf(out,"\n");}
  fprintf(out,"------------------------------__");
  fprintf(out,"------------------------------__\n\n");
  fclose(out);}

