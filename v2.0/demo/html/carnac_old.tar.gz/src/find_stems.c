
/* -------------------------------------------*/
/* find_stems.c                               */
/*--------------------------------------------*/

#include "find_stems.h"

typedef struct {
  string_t nucl;
  int w;
} w_nucl_t;


#include "tstackh.dat"
#include "tstacki.dat"
#include "stack.dat"
#include "tloop.dat"

#include "bulge.dat"
#include "sint2.dat"
#include "sint4.dat"
#include "asint1x2.dat"


/*---------------------------------------------------------*/
int tstack_inside (sequence_t seq, int i, int j);
int stack_inside (sequence_t seq, int i, int j);
int stack_outside (sequence_t seq, int i, int j);
int tloop (sequence_t seq, int i, int j);
/*---------------------------------------------------------*/
int asint1x2_inside (sequence_t seq, int i, int j);
int asint2x1_inside (sequence_t seq, int i, int j);
int asint1x2_outside (sequence_t seq, int i, int j);
int asint2x1_outside (sequence_t seq, int i, int j);
int sint2_inside (sequence_t seq, int i, int j);
int sint2_outside (sequence_t seq, int i, int j);
int sint4_inside (sequence_t seq, int i, int j);
int sint4_outside (sequence_t seq, int i, int j);
/*---------------------------------------------------------*/
stem_list_t find_stems_single_seq (int seq_i);
matrix2_t fill_stem_matrix (int n, int seq_i);
stem_list_t hairpin_backtrack (matrix2_t E, int n, int seq_i);
stem_list_t backtrack (matrix2_t E, int n, int seq_i);
stem_list_t extend (stem_list_t old_K, int seq_i);
int seuil (int dist, sequence_t seq);
/*---------------------------------------------------------*/

extern sequence_list_t all_seq;


void allocate_block_list () {
  int i, j;
  extern int nb_seq;
  extern block_list_t **block_list;
  block_list = (block_list_t**) sec_malloc(nb_seq*sizeof(block_list_t*));
  for (i=0; i<nb_seq; i++) {
    block_list[i] = (block_list_t*) sec_malloc(nb_seq*sizeof(block_list_t));
    for(j=0; j<nb_seq; j++) block_list[i][j] = NULL;
  }
}


// repris par helene 
stem_list_t erase_copies (stem_list_t K_in) {
  int j=1; 
  int i; 
  int number_of_stems = 1;
  int nK = stem_list_length(K_in);
  stem_list_t K_out ;
  if (nK==0)  return K_in; 
  for (i=2; i<=nK; i++)  {
    if  (same_stem(K_in[j], K_in[i])){
      free (K_in[i]); 
      K_in[i]=NULL;       
    }
    else {// on a une nouvelle tige
      j=i; 
      number_of_stems ++;
    }
  }
  K_out=new_stem_list(number_of_stems);
  j=1 ;
    for (i=1; i<=nK; i++)
      if (K_in[i]!=NULL) {
	K_out[j]=K_in[i];
	j++; 
      }
  free (K_in); 
  return K_out;
}


void find_stems () {
  int i; FILE *out;
  extern int nb_seq;
  extern int brk_lp;
  extern stem_list_t *all_stems;
  // allocate all_stems
  all_stems = (stem_list_t*) sec_malloc (nb_seq * sizeof(stem_list_t));
  printf ("\n\n Finding all potential stems \n\n");
  // for each sequence
  for (i=0; i<nb_seq; i++) {
    all_stems[i] = find_stems_single_seq (i);
    if (stem_list_length(all_stems[i]) == 0) {
      // modif helene if (DEBUG) {
      //	out=fopen("output/check_stems.out", "a");
      //	fprintf(out, "\n\n --- no stem");
      //	fclose(out);}
      brk_lp++;
    }
    // print std output
      printf("  sequence %2i : %3i potential stems\n", i+1, stem_list_length(all_stems[i]));
    // sort stems
    sort_stems_by_begin (all_stems[i]);
  }
  printf("\n");
  allocate_block_list();
}

stem_list_t find_stems_single_seq (int seq_i) {
  int n=  all_seq[seq_i].length;
  matrix2_t E = fill_stem_matrix (n, seq_i); 
  stem_list_t K = backtrack (E, n, seq_i);
   
  sort_stems_by_begin (K);
  K = extend (K, seq_i);
  sort_stems_by_begin (K);
  K = erase_copies (K);
  free_matrix2 (E, n);
  return K;
}

matrix2_t fill_stem_matrix (int n, int seq_i) {
  sequence_t seq;
  int i, j, diago;
  matrix2_t E;

  seq = all_seq[seq_i];

  // matrice sup�rieure droite
  // parcourue en diagonales montantes
  E = alloc_matrix2 (n, n, 0);
  for (diago=1+SIZE_HAIRPIN; diago<n; diago++) {
    for (i=0; i<=n-1-diago; i++) {
      j = diago + i;
      // stack AU, CG, GU
      E[i][j] = MIN (E[i][j], E[i+1][j-1] + stack_inside (seq,i,j));
      // close stem
      E[i][j] = MIN (E[i][j], tstack_inside (seq,i,j));
    }
  }
  return E;
}
//modif helene
//void too_many_stems (){printf("\n    --- too many potential stems --- \n ");
//  exit(1);
//}

stem_list_t backtrack (matrix2_t E, int n, int seq_i) {

  int i, j, l, diago, debut, fin, large;
  char a, b;
  sequence_t seq= all_seq[seq_i];
  stem_list_t K = new_stem_list (seq.length*seq.length/2); 
  stem_list_t R; 
 
  l=1;

  for (diago=0; diago<=2*n-2; diago++) {
    large = 0;
    debut = MAX (0, diago-n+1);
    fin = diago/2 - SIZE_HAIRPIN + 1;

    for (i=fin; i>=debut; i--) {

      j = diago - i;
      a = MIN (seq.nucl[i], seq.nucl[j]);
      b = MAX (seq.nucl[i], seq.nucl[j]);

      if ((i == debut) && (E[i][j] <= INI_THD)) {
	K[l] =  new_stem (seq_i, l, 0, i, i+large, j-large, j, E[i][j]);
	large = 0; 
	l++;	// modif helene if (l > NB_MAX_STEMS_1 - 2) too_many_stems ();
      }
      else if ((!canoniq(a, b)) && (E[i+1][j-1] <= INI_THD)) {
	K[l] =  new_stem (seq_i, l, 0, i+1, i+large, j-large, j-1, E[i+1][j-1]);
	large = 0; 
	l++;	// modif helene if (l > NB_MAX_STEMS_1 - 2) too_many_stems ();
      }
      if (canoniq(a, b)) large++; else large = 0;
    }
  }
  l--;
  R=new_stem_list(l);
  if (l>0)
    for (i=1; i<=l; i++){
      R[i]=K[i]; 
    }
  free (K[0]); 
  free (K);
  return R;
}

stem_list_t extend (stem_list_t old_K, int seq_i) {

  int i, store_p, ii, jj, kk, ll, dist, nrj, init_nrj;
  int ni, nj, nk, nl, ext;
  int nK =stem_list_length (old_K);
  stem_list_t K = new_stem_list (nK*5);
  sequence_t seq = all_seq[seq_i];
  int  p=1;
  stem_list_t R; // liste resultat, contenant le nombre exact de tiges

  for (i=1; (i<=nK); i++) {
    ii = old_K[i] -> s[1];
    jj = old_K[i] -> s[2];
    kk = old_K[i] -> s[3];
    ll = old_K[i] -> s[4];                        
    dist = ll - ii;
    init_nrj = old_K[i] -> energy;
    store_p = 0;

    // select stem if enough energy
    if (init_nrj <= seuil (dist, seq)){
      
      K[p] = new_stem (seq_i, p, p, ii, jj, kk, ll, init_nrj); 
      store_p=p; 
      p++;
    }


    // try to extend outside : {1,2} MISMATCHES

    //   ------ o ------ ........ ------ o ---
    //  --- oo ------ ........ ------ oo ---

    ni = ii - 2;
    nl = ll + 2;
    nrj = old_K[i] -> energy + MISM_MALUS;

    if (canoniq (seq.nucl[ni], seq.nucl[nl])) {
      // mismatch destibilizing energy
      nrj += sint2_outside (seq, ii, ll);
      // stack AU, CG, GU
      for (ext=0; (canoniq (seq.nucl[ni], seq.nucl[nl])) &&
	     (ni>0) && (nl<seq.length-1); ext++)
	{nrj += stack_outside (seq, ni, nl); ni--; nl++;}
      // close stem
      if (ext > 1) nrj -= stack_outside (seq, ni+1, nl-1);
      // check if energy < threshold
      if ((ext >= MIN_EXTEND) && (nrj <= seuil (dist, seq)) && (nrj < init_nrj)) {
	K[p] = new_stem (seq_i, p, p, ni+1, jj, kk, nl-1, nrj);
	if (store_p != 0) K[store_p]->substem = 1;
	p++;
      }
    }

    ni = ii - 3;
    nl = ll + 3;
    nrj = old_K[i] -> energy + 2*MISM_MALUS;

    if ((canoniq (seq.nucl[ni], seq.nucl[nl])) && (!canoniq (seq.nucl[ni+1], seq.nucl[nl-1]))) {
      // mismatch destibilizing energy
      nrj += sint4_outside (seq, ii, ll);
      // stack AU, CG, GU
      for (ext=0; (canoniq (seq.nucl[ni], seq.nucl[nl])) &&(ni>0) && (nl<seq.length-1); ext++){
	nrj += stack_outside (seq, ni, nl); ni--; nl++;
      }
      // close stem
      if (ext > 1) nrj -= stack_outside (seq, ni+1, nl-1);
      // check if energy < threshold
      if ((ext >= MIN_EXTEND) &&
	  (nrj <= seuil (dist, seq)) &&
	  (nrj < init_nrj)) {
	K[p] = new_stem (seq_i, p, p, ni+1, jj, kk, nl-1, nrj);
	if (store_p != 0) K[store_p]->substem = 1;
	p++;
      }
    }


    // try to extend inside : {1,2} MISMATCHES

    //  ------ o --- ........ --- o ------
    // ------ oo --- ........ --- oo ------

    nj = jj + 2;
    nk = kk - 2;
    nrj = old_K[i] -> energy - tstack_inside (seq, jj, kk) + MISM_MALUS;

    if (canoniq (seq.nucl[nj], seq.nucl[nk])) {
      // mismatch destibilizing energy
      nrj += sint2_inside (seq, jj, kk);
      // stack AU, CG, GU
      for (ext=0; (canoniq (seq.nucl[nj], seq.nucl[nk])) &&(nk-nj-1 >= SIZE_HAIRPIN); ext++){
	nrj += stack_inside (seq, nj, nk); nj++; nk--;
      }
      // close stem
      if (ext > 1) {
	nrj -= stack_inside (seq, nj-1, nk+1);
	nrj += tstack_inside (seq, nj-1, nk+1);
      }
      // check if energy < threshold
      if ((ext >= MIN_EXTEND) &&
	  (nrj <= seuil (dist, seq)) &&
	  (nrj < init_nrj)) {
	K[p] = new_stem (seq_i, p, p, ii, nj-1, nk+1, ll, nrj);
	if (store_p != 0) K[store_p]->substem = 1;
	p++;
      }
    }

    nj = jj + 3;
    nk = kk - 3;
    nrj = old_K[i] -> energy - tstack_inside (seq, jj, kk) + 2*MISM_MALUS;

    if ((canoniq (seq.nucl[nj], seq.nucl[nk])) &&(!canoniq (seq.nucl[nj-1], seq.nucl[nk+1]))) {
      // mismatch destibilizing energy
      nrj += sint4_inside (seq, jj, kk);
      // stack AU, CG, GU
      for (ext=0; (canoniq (seq.nucl[nj], seq.nucl[nk])) &&(nk-nj-1 >= SIZE_HAIRPIN); ext++){
	nrj += stack_inside (seq, nj, nk); nj++; nk--;
      }
      // close stem
      if (ext > 1) {
	nrj -= stack_inside (seq, nj-1, nk+1);
	nrj += tstack_inside (seq, nj-1, nk+1);
      }
      // check if energy < threshold
      if ((ext >= MIN_EXTEND) &&(nrj <= seuil (dist, seq)) &&(nrj < init_nrj)) {
	K[p] = new_stem (seq_i, p, p, ii, nj-1, nk+1, ll, nrj);
	if (store_p != 0) K[store_p]->substem = 1;
	//	print_stem (K[p], seq); fflush(stdout);
	p++;
      }
    }
  }
  p--;
  R = new_stem_list(p);
  for (i=1;i<=p; i++){
    R[i]=K[i];
  }
  free_stem_list (old_K);
  free (K);
  return R;
}

int seuil (int dist, sequence_t seq) {
  int a, b, out;
  const int STD = 50;
  a = (THD_2 - THD_1) / (DIST_2 - DIST_1);
  b = THD_1 - a * DIST_1;
  out =  a * dist + b; 
  //out = MAX (THD_2, out); 
  if (CORRECT_THD) out -=  out * (STD-seq.cg)/STD/2;
  out = MAX (THD_2, out);  
  return out;
}

matrix2_t pre_select (stem_list_t *K0, stem_list_t *K1,
		      stem_list_t *L0, stem_list_t *L1,
		      int covar) {

  extern int brk_lp;
  extern stem_list_t all0, all1;
  extern int i, j;
  matrix2_t correl;
  FILE *out;

  // compute matchable stems
  correl = correlate (all0, all1, K0, K1, i, j, covar);

  if (stem_list_length(*K0) >= NB_MAX_STEMS_3) {
    // modif helene if (DEBUG) {
    //  out=fopen("output/check_stems.out", "a");
    //  fprintf(out,"\n\n --- too many stems : %i", stem_list_length(*K0));
    //  fclose(out);}
    brk_lp++;}

  else if (stem_list_length(*K0) == 0) {
    // modif helene if (DEBUG) {
    //  out=fopen("output/check_stems.out", "a");
    //  fprintf(out, "\n\n --- no stem");
    //  fclose (out);}
    brk_lp++;}
  
    printf("%3i vs %3i stems\n", stem_list_length(*K0), stem_list_length(*K1));
     sort_stems_by_begin (*K0);
  sort_stems_by_begin (*K1);

   *L0 = sort_stems_by_end (*K0);
  *L1 = sort_stems_by_end (*K1);

  return correl;
}

// energy parameters :   NO MISMATCH
//---------------------------------------------------------//
// bases   ...   0: a   1: c   2: g   3: u
//                     inside           outside
//    5' --> 3'     5' ------> 3'     5' ------> 3'
//       12            i  i+1            i-1  i
//       34            j  j-1            j+1  j
//   3' <-- 5'     3' <------ 5'     3' <------ 5'
// 1 3 : canonic pair       2 4 : mismatch or canonic pair
//---------------------------------------------------------//

int tstackh (sequence_t seq, int i, int j) {
  return tstackh_mat [VALb(seq.nucl[i])][VALb(seq.nucl[i+1])]
    [VALb(seq.nucl[j])][VALb(seq.nucl[j-1])];}

int tstacki (sequence_t seq, int i, int j) {
  return tstacki_mat [VALb(seq.nucl[i])][VALb(seq.nucl[i+1])]
    [VALb(seq.nucl[j])][VALb(seq.nucl[j-1])];}

int tstack_inside (sequence_t seq, int i, int j) {
  //  if (j-i < 1.5 * SIZE_MAX_HP)
  return tstackh (seq,i,j) + tloop (seq,i,j);
  //  else return tstacki (seq,i,j);
}

int stack_inside (sequence_t seq, int i, int j) {
  return stack_mat [VALb(seq.nucl[i])][VALb(seq.nucl[i+1])]
    [VALb(seq.nucl[j])][VALb(seq.nucl[j-1])];}
int stack_outside (sequence_t seq, int i, int j) {
  return stack_mat [VALb(seq.nucl[i-1])][VALb(seq.nucl[i])]
    [VALb(seq.nucl[j+1])][VALb(seq.nucl[j])];}

int tloop (sequence_t seq, int i, int j) {
  int k, match, out; out = 0;
  if (j-i == 5) {match = 0;
    for (k=0; (k<30) && (!match); k++) {
      if ((seq.nucl[i]   == tloop_bonus[k].nucl[0]) &&
	  (seq.nucl[i+1] == tloop_bonus[k].nucl[1]) &&
	  (seq.nucl[i+2] == tloop_bonus[k].nucl[2]) &&
	  (seq.nucl[i+3] == tloop_bonus[k].nucl[3]) &&
	  (seq.nucl[i+4] == tloop_bonus[k].nucl[4]) &&
	  (seq.nucl[i+5] == tloop_bonus[k].nucl[5]))
	{match = 1; out = tloop_bonus[k].w;}}}
  return out;}

// energy parameters :    MISMATCHES  /  LOOPS  /  BULGES
//-------------------------------------------------------------------//

// bases   ...     0: a   1: c   2: g   3: u

// pairs   ...     0: au  1: cg  2: gc  3: ua  4: gu  5: ug

// pair of pairs ...
//  0: au/au  1: au/cg  2: au/gc  3: au/ua  4: au/gu  5: au/ug
//  6: cg/au  7: cg/cg  8: cg/gc  9: cg/ua 10: cg/gu 11: cg/ug
// 12: gc/au 13: gc/cg 14: gc/gc 15: gc/ua 16: gc/gu 17: gc/ug
// 18: ua/au 19: ua/cg 20: ua/gc 21: ua/ua 22: ua/gu 23: ua/ug
// 24: gu/au 25: gu/cg 26: gu/gc 27: gu/ua 28: gu/gu 29: gu/ug
// 30: ug/au 31: ug/cg 32: ug/gc 33: ug/ua 34: ug/gu 35: ug/ug

//-------------------------------------------------------------------//
// loop 2 x 1    (1 & 4 are canonic pairs)

//    5' ------> 3' 	5' -----------> 3' 	5' -----------> 3'
//         3                 i+1                      j-1
//       1     4           i          i+2         j-2          j
//       1     4           j          j-3         i+3          i
//         5 2	             j-1  j-2                 i+2  i+1
//    3' <------ 5' 	3' <----------- 5' 	3' <----------- 5'

//                  	5' -----------> 3' 	5' -----------> 3'
//                            i-1                   j+1
//                        i-2          i          j          j+2
//                        j+3          j          i          i-3
//            	              j+2  j+1              i-1  i-2
//                  	3' <----------- 5' 	3' <----------- 5'

int asint1x2_inside (sequence_t seq, int i, int j) {
  return
    asint1x2_mat
    [VALp (seq.nucl[i], seq.nucl[j])]
    [VALb (seq.nucl[j-2])]
    [VALb (seq.nucl[i+1])]
    [VALp (seq.nucl[i+2], seq.nucl[j-3])]
    [VALb (seq.nucl[j-1])];}

int asint2x1_inside (sequence_t seq, int i, int j) {
  return
    asint1x2_mat
    [VALp (seq.nucl[j-2], seq.nucl[i+3])]
    [VALb (seq.nucl[i+1])]
    [VALb (seq.nucl[j-1])]
    [VALp (seq.nucl[j], seq.nucl[i])]
    [VALb (seq.nucl[i+2])];}

int asint1x2_outside (sequence_t seq, int i, int j) {
  return
    asint1x2_mat
    [VALp (seq.nucl[i-2], seq.nucl[j+3])]
    [VALb (seq.nucl[j+1])]
    [VALb (seq.nucl[i-1])]
    [VALp (seq.nucl[i], seq.nucl[j])]
    [VALb (seq.nucl[j+2])];}

int asint2x1_outside (sequence_t seq, int i, int j) {
  return
    asint1x2_mat
    [VALp (seq.nucl[j], seq.nucl[i])]
    [VALb (seq.nucl[i-2])]
    [VALb (seq.nucl[j+1])]
    [VALp (seq.nucl[j+2], seq.nucl[i-3])]
    [VALb (seq.nucl[i-1])];}

//-------------------------------------------------------------------//
// mismatch 1 x 1    (1 & 3 are canonic pairs)

//    5' ----> 3'     5' --------> 3'     5' --------> 3'
//         2	   	   i+1	                 i-1	 
//       1   3	   	 i     i+2           i-2     i  
//       1   3	   	 j     j-2           j+2     j  
//         4	   	   j-1	                 j+1	 
//    3' <---- 5'     3' <-------- 5'     3' <-------- 5'

int sint2_inside (sequence_t seq, int i, int j) {
  return
    sint2_mat
    [VALp (seq.nucl[i], seq.nucl[j])]
    [VALb (seq.nucl[i+1])]
    [VALp (seq.nucl[i+2], seq.nucl[j-2])]
    [VALb (seq.nucl[j-1])];}

int sint2_outside (sequence_t seq, int i, int j) {
  return
    sint2_mat
    [VALp (seq.nucl[i-2], seq.nucl[j+2])]
    [VALb (seq.nucl[i-1])]
    [VALp (seq.nucl[i], seq.nucl[j])]
    [VALb (seq.nucl[j+1])];}

//-------------------------------------------------------------------//
// mismatch 2 x 2    (1 is a canonic pair of pairs)

//    5' ------> 3'  	5' ------------> 3'    	5' ------------> 3'
//         2 3	     	     i+1  i+2                  i-2  i-1
//       1     1     	   i          i+3      	   i-3          i  
//       1     1     	   j          j-3      	   j+3          j  
//         2 3	     	     j-1  j-2          	       j+2  j+1
//    3' <------ 5'  	3' <------------ 5''   	3' <------------ 5'

int sint4_inside (sequence_t seq, int i, int j) {
  return
    sint4_mat
    [VALpp (seq.nucl[i], seq.nucl[j], seq.nucl[i+3], seq.nucl[j-3])]
    [VALp (seq.nucl[i+1], seq.nucl[j-1])]
    [VALp (seq.nucl[i+2], seq.nucl[j-2])];}

int sint4_outside (sequence_t seq, int i, int j) {
  return
    sint4_mat
    [VALpp (seq.nucl[i-3], seq.nucl[j+3], seq.nucl[i], seq.nucl[j])]
    [VALp (seq.nucl[i-2], seq.nucl[j+2])]
    [VALp (seq.nucl[i-1], seq.nucl[j+1])];}

//-------------------------------------------------------------------//

int nrj (int x, int i, int j, int k, int l) {
  extern sequence_list_t all_seq;
  sequence_t seq=all_seq[x];
  int nrj=0; int t;
  for (t=0; t<j-i; t++) nrj += stack_inside (seq,i+t,l-t);
  nrj += tstack_inside (seq,j,k);
  return nrj;
}
