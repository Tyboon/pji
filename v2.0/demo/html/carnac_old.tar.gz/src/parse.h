/*----------------------------------------------*/
/* parse.h                                      */
/*----------------------------------------------*/

#include <stdlib.h>
#include <stdio.h>
#ifndef PARSE
#define PARSE
// verbose
//int INTERFACE;
int VERBOSE;
int DYNAM;
int OUTPUT;
int GRAPH;
int COMPARE;
int CLEAN;
int DEBUG;
// modif helene int TRY;
//int LATEX;

// simil & anchor points
int AP_THD;
int SUB;
int SIMIL_THD;

// single hairpins
int SIZE_MAX_HP;
int THD_HP;
int SINGLE_HP;

// hairpins
int SIZE_HAIRPIN;

// threshold stems
float SCALING;
int CORRECT_THD;
int INI_THD;
int DIST_1;
int THD_1;
int DIST_2;
int THD_2;

// matchable stems
int FLT;
int COVAR;

// print
int LARGE;

// OUI si c'est la version pour l'interface WEB
int WEB; 

void default_parameters(); 
void parse_command_line (int argc, char **argv);
#endif
