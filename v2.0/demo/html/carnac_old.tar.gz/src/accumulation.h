

/*----------------------------------------------*/
/* accumulation.h                               */
/*----------------------------------------------*/

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "types.h"
#include "parse.h"
#include "string.h"
#include "stem.h"

void print_infos ();
void cat_stems (stem_list_t S, int x);
void conglomerate_stems (sequence_list_t all_seq);
void final_structure (sequence_list_t all_seq, int magnify, int TH1, int TH2);
